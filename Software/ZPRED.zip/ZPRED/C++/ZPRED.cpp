# include <algorithm>
# include <cmath>
# include <cstdio>					// defines remove
# include <cstdlib>
# include <cstring>
# include <ctime>					// defines clock_t, clock, CLOCKS_PER_SEC
# include <exception>
# include <fstream>
# include <iostream>
# include <new>
# include <sstream>
# include <string>
# include <thread>
# include <utility>
# include <vector>
# include <fcntl.h>					// Defines O_CREAT flag
# include <sys/reg.h>
# include <sys/syscall.h>			// Defines OS System Calls
# include <sys/ptrace.h>
# include <sys/types.h>
# include <sys/user.h>
# include <sys/wait.h>
# include <sys/stat.h>				// Defines chmod function
# include <boost/filesystem.hpp>		// create_directory
# include <boost/numeric/odeint.hpp>
# include <openssl/conf.h>
# include <openssl/evp.h>				// ciphers and message digests
# include <openssl/err.h>
# include <openssl/ssl.h>				// for libssl
# include <unistd.h>
# include "ap.h"
# include "solvers.h"
# include "stdafx.h"

using namespace std;
using namespace boost::numeric::odeint;

// Acceptable Deviation During Newton-Ralphson Iteration
# define ACCEPTED_ERROR_PERCENT 5e-4
// Default Length of a Number to consider for cnvrtNumToStrng
# define BUFFER_SIZE 12
// Number of digits behind  point for ion radii and inflation distance/slip plane position
# define DISTANCE_SIG_FIGS 2
// Number of digits behind  point for solvent dielectric constant
# define ER_SIG_FIGS 2
// Default Number of Threads to Execute ZPRED on (if not user specified)
# define MAX_THREADS 3
// Maximum Number of Rows for Terminal Display
# define MAX_DISPLAY_ROWS 25
// Maximum Number of Columns for Terminal Display
# define MAX_DISPLAY_COLS 6
// Maximum Number of Iterations to Solve for PBE Coefficient
# define MAX_PBE_ITERATIONS 1000
// Maximu Number of File Open Attempts
# define MAX_FILE_OPEN_ATTEMPTS 100000

// Physical Constants
// Avogadro's Number (Particles per mole)
# define Na 6.022140857e23
// Universal Gas Constant (Joule/(Kelvin*mol))
# define Rg 8.3144598
//Boltzmann Constant (Joule/Kelvin)
# define kb Rg/Na
//Electron (or Elementary) Charge (Coulomb)
# define ec 1.6021766208e-19
// PI
# define pi 3.14159265358979323846
// Permeability of Free Space (Tesla*meter/Ampere)
# define uo pi*0.0000004
// Speed of Light in Vacuum (meter/second)
# define sol 299792458
// Permittivity of Free Space (Farad/meter)
# define eo 1/(uo*sol*sol)

typedef vector<double> state_type;

struct push_back_state_and_time
{
    vector<state_type>& m_states;
    vector<double>& m_times;

    push_back_state_and_time(vector<state_type> &states,vector<double> &times ) : m_states(states),m_times(times){}

    void operator()(const state_type &x ,double t)
    	{m_states.push_back(x);
        m_times.push_back(t);}
};

struct Error
{double absolute;double relative;double a_x;double a_dxdt;};

typedef runge_kutta_dopri5<state_type> error_stepper_type;

typedef controlled_runge_kutta< error_stepper_type > controlled_stepper_type;

struct Reference
{double** E;double** y;double* ka;int numPlots;int* numPnts;};

// ZPRED Component Software Executables
struct softwareComponents
{string apbsExecutable;string multivalueExecutable;string hydroproExecutable;string msmsExecutable;string msmsAtmTypeNumbers;string msmsPdbToXyzr;string msmsPdbToXyzrn;string pdb2pqr;};

// MSMS Input Parameter Data Class
struct msmsInput
{string PDB;string pdbFile;string msmsFldr;string pdb_msmsFldr;string pdb_surfFldr;string surfPointDensity;string surfPointHiDensity;string probeRadius;string PDB_TO_XYZRN;string MSMS;bool SUCCESS;};

// ZPRED Input Parameter Data Structure Array (for taking data from GUI)
struct zInput
{int numSolCond;
string* id;
double* shapeFactor;
double* molecularWeight;
string* files;
int numFiles;
string name;
string* pH;
string** solvent;
int* numSolvent;
double** solventConc;
string* solventConcType;
string** solute;
int* numSolute;
double** soluteConc;
string* soluteConcType;
double* temperature;
double* proteinConc;
string outputTitle;
string* apbsWriteTypes;
int numApbsWriteTypes;
softwareComponents SC;
msmsInput msms;
string hydroproCalcType;
string forceField;
bool saveTemps;
string pdie;
string dime_x;string dime_y;string dime_z;
bool RUN_APBS;bool RUN_PDB2PQR;bool RUN_HYDROPRO;bool RUN_HULLRAD;bool RUN_ZPRED;bool RUN_COLLIDE;
int maxThreads;
// User Specified Values (-1 if not specified)
double* dielectric;double* viscosity;double* density;double* inflationDistance;
// Generate Pot Profile
bool* GENERATE_POT_PROFILE;
string plot;};

// ZPRED Input Parameter Structure Array for Parallel Execution of the Problem (each represents only one file and solution condition)
struct zExeInput
{string id;
string file;
string pH;
string* solvent;
int numSolvent;
double* solventConc;
string solventConcType;
string* solute;
int numSolute;
double* soluteConc;
string soluteConcType;
double temperature;
double proteinConc;
string outputTitle;
string* apbsWriteTypes;
int numApbsWriteTypes;
softwareComponents SC;
msmsInput msms;
string hydroproCalcType;
string forceField;
bool saveTemps;
string pdie;
string dime_x;string dime_y;string dime_z;
bool RUN_APBS;bool RUN_PDB2PQR;bool RUN_HYDROPRO;bool RUN_HULLRAD;bool RUN_ZPRED;bool RUN_COLLIDE;
int maxThreads;
// User Specified Values (-1 if not specified)
double dielectric;double viscosity;double density;double inflationDistance;
// Generate Pot Profile
bool GENERATE_POT_PROFILE;
};

// Single Solution Properties Data Structure Array
struct solProp
{string pH;string temperature;string dielectric;string viscosity;string density;int numSolute;string* solute;string* soluteConc;string debyeLength;int numSolvent;string* solvent;string* solventConc;};

// Total Solution Properties Data Structure Array
struct allSolProp
{string* pH;string* temperature;string* dielectric;string* viscosity;string* density;int numSolute;string** solute;string** soluteConc;string* debyeLength;int numSolvent;string* solvent;string* solventConc;};

struct electricProfile
{double* position;double* potential;int numPnts;};

// Single ZPRED Output Data Structure Array
struct zOutput
{string proteinName;string solCondNum;double proteinRadius;double solvatedRadius;double zetaPotential;string Xsp;double charge;double semMobility;double henryMobility;double kuwabaraMobility;double diffusivity;solProp solution;electricProfile EP;};

// COLLIDE Input Data Structure Array
struct colInput
{int numSols;string* pRadius;double* proteinRadius;double* proteinRadiusStd;string* sRadius;double* solvatedRadius;double* solvatedRadiusStd;string* zPotential;double* zetaPotential;double* zetaPotentialStd;string* chrg;double* charge;double* chargeStd;string* eMob;double* mobility;double* mobilityStd;string* diff;double* diffusivity;double* diffusivityStd;allSolProp solution;double* collisionEfficiency;double* coagulationTime;};

// General Vector
struct Vec
{double x;double y;double z;};

// 2D Vector
struct Vec2d
{double x;double y;};

// String Vector
struct strVec
{string x;string y;string z;};

// Solution Properties Class
class Solution
	{public:
		// Constructor
		Solution(string solvent,string solventConc,string solventConcType,string solute,string soluteConc,double T,string delimiter);
		Solution();
		string interpretMoleculeName(string Molecule);
		double calcMoleculeMolecularWeight(string structure);
		double getBondLength(string atomicBond);
		double calcPureSolventDensity(string solventName,double temperature);
		double calcPureSolventViscosity(string solventName,double temperature);
		double calcPureSolventDielectric(string solventName,double temperature);
		double* getDensityCoefficients(string saltName);
		double* getViscosityCoefficients(string saltName);
		double getDielectricLinearCoefficient(string soluteName);
		double calcSolutionDensity(double T);
		double calcSolutionViscosity(double T);
		double calcSolutionDielectric(double T);
		string getIonData(string saltConc,string saltName,string delimiter);
		string interpretSolute(string solute);
		double calcDebyeLength(double T);
		//void generateLEaPFile(string Molecule,string outFile);
		// Ion Data: valence,molarConc,angstromRadius,
		string ionData;
		// Solution Debye Length [Angstroms]
		double debyeLength;
		// Largest Ion [Angstroms]
		string largestIon;
		// Computed Solution Viscosity [Pa s]
		double viscosity;
		// Computed Solution Density [kg/L]
		double density;
		// Computed Solution Relative Dielectric
		double dielectric;
		// Solution Temperature [Kelvin]
		double temperature;
		int numSolvents;
		int numSolutes;
		int numIon;
		// Structural Formula(e) of Ions(s) under Assessment
		string* ion;
		// Ion Valence
		int* ionVal;
		// Molar Concentration [mol/L] of Ion(s)
		double* ionConc;
		// Ionic Radii of Ion(s) [Angstroms]
		double* ionRad;
		// Structural Formula(e) of Solvent(s) under Assessment
		string* solvents;
		// Mole Fractions of Solvent(s)
		double* solventsConc;
		// Molecular Weight of Solvent(s) [g/mol]
		double* solventsMW;
		// Structural Formula(e) of Solute(s) under Assessment
		string* solutes;
		// Molar Concentration [mol/L] of Solute(s)
		double* solutesConc;
		// Molecular Weight of Solute(s) [g/mol]
		double* solutesMW;
		double* moleFrac2MassFrac(double* x,double* MW,int numComps);
		double* massFrac2MoleFrac(double* w,double* MW,int numComps);
		double* massFrac2MoleFrac(string* sW,double* MW,int numComps);
		double* volFrac2MoleFrac(double* v,double* MW,double* density,int numComps);
		double* volFrac2MoleFrac(string* sV,double* MW,double* density,int numComps);
		double* molarity2MassFrac(double* M,double* MW,int numComps,double solventDensity);
		// Number of Elements on Periodic Table
		static const int numElements=118;
		// Atomic Symbols of Elements on Periodic Table
		string atomicSymbol[numElements]={"H","He","Li","Be","B","C","N","O","F","Ne","Na","Mg","Al","Si","P","S","Cl","Ar","K","Ca","Sc","Ti","V","Cr","Mn","Fe","Co","Ni","Cu","Zn","Ga","Ge","As","Se","Br","Kr","Rb","Sr","Y","Zr","Nb","Mo","Tc","Ru","Rh","Pd","Ag","Cd","In","Sn","Sb","Te","I","Xe","Cs","Ba","La","Ce","Pr","Nd","Pm","Sm","Eu","Gd","Tb","Dy","Ho","Er","Tm","Yb","Lu","Hf","Ta","W","Re","Os","Ir","Pt","Au","Hg","Tl","Pb","Bi","Po","At","Rn","Fr","Ra","Ac","Th","Pa","U","Np","Pu","Am","Cm","Bk","Cf","Es","Fm","Md","No","Lr","Rf","Db","Sg","Bh","Hs","Mt","Ds","Rg","Cn","ut","Fl","up","Lv","us","uo"};
		// Atomic Names of ELements on Periodic Table
		string atomicName[numElements]={"Hydrogen","Helium","Lithium","Beryllium","Boron","Carbon","Nitrogen","Oxygen","Fluorine","Neon","Sodium","Magnesium","Aluminium","Silicon","Phosphorus","Sulfur","Chlorine","Argon","Potassium","Calcium","Scandium","Titanium","Vanadium","Chromium","Manganese","Iron","Cobalt","Nickel","Copper","Zinc","Gallium","Germanium","Arsenic","Selenium","Bromine","Krypton","Rubidium","Strontium","Yttrium","Zirconium","Niobium","Molybdenum","Technetium","Ruthenium","Rhodium","Palladium","Silver","Cadmium","Indium","Tin","Antimony","Tellurium","Iodine","Xenon","Cesium","Barium","Lanthanum","Cerium","Praseodymium","Neodymium","Promethium","Samarium","Europium","Gadolinium","Terbium","Dysprosium","Holmium","Erbium","Thulium","Ytterbium","Lutetium","Hafnium","Tantalum","Tungsten","Rhenium","Osmium","Iridium","Platinum","Gold","Mercury","Thallium","Lead","Bismuth","Polonium","Astatine","Radon","Francium","Radium","Actinium","Thorium","Protactinium","Uranium","Neptunium","Plutonium","Americium","Curium","Berkelium","Californium","Einsteinium","Fermium","Mendelevium","Nobelium","Lawrencium","Rutherfordium","Dubnium","Seaborgium","Bohrium","Hassium","Meitnerium","Darmstadtium","Roentgenium","Copernicium","Ununtrium","Flerovium","Ununpentium","Livermorium","Ununseptium","Ununoctium"};
		// Atomic Molecular Weight of Elements on Periodic Table [g/mol]
		double atomicMolecularWeight[numElements]={1.0079,4.0026,6.941,9.0122,10.811,12.0107,14.0067,15.9994,18.9984,20.1797,22.9897,24.305,26.9815,28.0855,30.9738,32.065,35.453,39.948,39.0983,40.078,44.9559,47.867,50.9415,51.9961,54.938,55.845,58.9332,58.6934,63.546,65.39,69.723,72.64,74.9216,78.96,79.904,83.8,85.4678,87.62,88.9059,91.224,92.9064,95.94,98,101.07,102.9055,106.42,107.8682,112.411,114.818,118.71,121.76,127.6,126.9045,131.293,132.9055,137.327,138.9055,140.116,140.9077,144.24,145,150.36,151.964,157.25,158.9253,162.5,164.9303,167.259,168.9342,173.04,174.967,178.49,180.9479,183.84,186.207,190.23,192.217,195.078,196.9665,200.59,204.38,207.2,208.9804,209,210,222,223,226,227,232.0381,231.0359,238.0289,237,244,243,247,247,251,252,257,258,259,262,261,262,263,262,265,266,281,272,285,284,289,288,292,0,294};
		// Atomic Charge of Elements on Periodic Table
		string atomicCharge[numElements]={"1+","0","1+","2+","3+","4+","3-","2-","1-","0","1+","2+","3+","4+","3-","2-","1-","0","1+","2+","3+","4+|3+","5+|4+","3+|2+","2+|4+","3+|2+","2+|3+","2+|3+","2+|1+","2+","3+","4+","3-","2","1-","0","1+","2+","3+","4+","5+|3+","6+","7+","3+|4+","3+","2+|4+","1+","2+","3+","4+|2+","3+|5+","2-","1-","0","1+","2+","3+","3+","3+","3+","3+","3+|2+","3+|2+","3+","3+","3+","3+","3+","3+","3+|2+","3+","4+","2","6+","7+","4+","4+","4+|2+","3+|1+","2+|1+","2","2+|4+","3+|5+","2+|4+","1-","0","1+","2+","3+","4+","5+|4+","6+|4+","5+","4+|6+","3+|4+","3+","3+|4+","3+","3+","3+","2+|3+","2+|3+","3+","NAN","NAN","NAN","NAN","NAN","NAN","NAN","NAN","NAN","NAN","NAN","NAN","NAN","NAN","NAN"};
		// Ion Properties Data
		static const int numIons=79;
		// Ion Names that are used to identify input ions
		string modeledIons[numIons]={"Ag","Al","AsO4","B(OH)4","Ba","Be","BO3","Br","BrO","BrO3","Ca","Cd","CH3COO","CH3NH3","Cl","ClO","ClO2","ClO3","ClO4","CN","Co","Co","CO3","HCO2","Cr","Cr","CrO4","Cr2O7","Cs","Cu","Cu","C2O4","HC2O4","F","Fe","Fe","H","Hg","In","IO","IO3","IO4","K","Li","Mg","Mn","Mn","MnO4","Na","NH4","Ni","Ni","NO3","NO2","O2","OH","HCO3","HSO3","HSO4","H2PO4","HPO4","PO4","HPO3","PO3","Rb","Rh","SeO4","Sn","Sn","SO4","SO3","S2O3","Sr","Th","Tl","Tl","Y","Zn","Citrate"};
		// Ion Structural Formulae
		string modeledIonsStructures[numIons]={"Ag","Al","As[::O]O3","B[OH]4","Ba","Be","BO3","Br","BrO","Br[::O]2O","Ca","Cd","CH3C[::O]O","CH3NH3","Cl","ClO","Cl[::O]O","Cl[::O]2O","Cl[::O]3O","C:::N","Co{2}","Co{3}","C[::O]O2","HC[::O]O","Cr{2}","Cr{3}","Cr[::O]2O2","OCr[::O]2OCr[::O]2O","Cs","Cu{1}","Cu{2}","OC[::O]C[::O]O","OC[::O]C[::O]OH","F","Fe{2}","Fe{3}","H","Hg{2}","In","IO","I[::O]2O","I[::O]3O","K","Li","Mg","Mn{2}","Mn{3}","Mn[::O]3O","Na","NH4","Ni{2}","Ni{4}","N[::O]2O","N[::O]O","O2","OH","C[::O][O]OH","S[::O][O]OH","S[::O]2[O]OH","P[::O][O][OH]2","P[::O][O]2OH","P[::O][O]3","P[O]2OH","PO3","Rb","Rh{3}","Se[::O]2[O]2","Sn{2}","Sn{4}","S[::O]2[O]2","S[::O][O]2","S::S[::O][O]2","Sr","Th","Tl{1}","Tl{3}","Y","Zn","OC[::O]C[H]2C[O][C[::O]O]C[H]2C[::O]O"};
		// Ion Chemical Names
		string modeledIonsNames[numIons]={"Silver","Aluminum","Arsenate","Tetrahydroxyborate","Barium","Beryllium","Borate","Bromide","Hyprobromite","Bromate","Calcium","Cadmium","Acetate","Methylammonium","Chloride","Hypochlorite","Chlorite","Chlorate","Perchlorate","Cyanide","Cobalt (II)","Cobalt (III)","Carbonate","Formate","Chromium (II)","Chromium (III)","Chromate","Dichromate","Cesium","Copper (I)","Copper (II)","Oxalate","Hydrogenoxalate","Floride","Iron (II)","Iron (III)","Hydrogen","Mercury (II)","Indium","Hypoiodite","Iodate","Periodate","Potassium","Lithium","Magnesium","Manganese (II)","Manganese (III)","Permanganate","Sodium","Ammonium","Nickel (II)","Nickel (IV)","Nitrate","Nitrite","Peroxide","Hydroxide","Bicarbonate","Bisulfite","Bisulfate","Dihydrogen Phosphate","Hydrogen Phosphate","Phosphate","Hydrogen Phosphite","Phosphite","Rubidium","Rhodium","Selenate","Tin (II)","Tin (IV)","Sulfate","Sulfite","Thiosulfate","Strontium","Thorium","Thallium (I)","Thallium (III)","Yttrium","Zinc","Citrate"};
		// Ionic Radii (A); Reference: 1988. Ionic radii in aqueous solutions
		string modeledIonsRadius[numIons]={"0.99","0.46","2.44","2.44","1.48","0.33","1.91","1.95","1.49","1.54","1.00","0.88","2.18","2.28","1.76","2.16","2.18","1.71","2.28","1.91","0.68","0.68","1.78","1.28","0.54","0.54","2.56","2.98","1.71","0.98","0.98","2.32","2.32","1.45","0.69","0.61","0.25","1.00","0.73","1.60","1.22","2.49","1.37","0.66","0.67","0.77","0.77","2.29","0.93","1.18","0.64","0.64","2.03","1.92","1.42","1.33","1.56","2.17","2.28","2.38","2.30","2.23","2.22","2.22","1.50","0.61","2.53","1.20","1.20","2.39","2.39","2.44","1.22","1.11","0.81","0.81","0.93","0.67","3.47"};
		// Ion Charge Valence
		string modeledIonsCharge[numIons]={"1","3","-3","-1","2","2","-3","-1","-1","-1","2","2","-1","1","-1","-1","-1","-1","-1","-1","2","3","-2","-1","2","3","-2","-2","1","1","2","-2","-1","-1","2","3","1","2","3","-1","-1","-1","1","1","2","2","3","-1","1","1","2","4","-1","-1","-2","-1","-1","-1","-1","-1","-2","-3","-2","-3","1","3","-2","2","4","-2","-2","-2","2","4","1","3","3","2","-3"};
	private:
		int countDelimiter(string Data,string delimiter);
		double* fillDoubleArray(string Data,int numPnts,string delimiter);
		string* fillStringArray(string Data,int numPnts,string delimiter);
		static const int numModeledSolvents=39;
		// List of Modeled Solvents Structures
		string modeledSolvents[numModeledSolvents]={"CH3C::[O]OH","CH3C[CH3]::O","CH3C:::N","CH3(CH2)3OH","CH3(CH2)3C[::O]CH3","*1CHCHC[Cl]CHCH*1CH","CHCl3","*1CH2(CH2)4*1CH2","CH3(CH2)3O(CH2)3CH3","C[Cl]H2C[Cl]H2","ClC[Cl]H2","CH3OCH2CH2OCH3","CH3C[::O]N[CH3]CH3","CH3N[CH3]C[::O]H","*1CH2OCH2CH2O*1CH2","CH3S[::O]CH3","CH3CH2OH","CH3C[::O]OCH2CH3","CH3CH2OCH2CH3","HOCH2CH2OH","CH3(CH2)3C[CH2CH3]HCH2OH","NH2C[::O]H","HOCH2C[OH]HCH2OH","CH3(CH2)4CH3","CH3C[CH3]HCH2OH","CH3OH","CH3O(CH2)2OH","CH3CH2C[::O]CH3","CH3C[CH3]HC[::O]CH3","CH3N[::O]O","CH3C[OH]HCH2OH","CH3(CH2)2OH","CH3C[OH]HCH3","*1CH2(CH2)3*1O","*1CH(CH)2C[CH2(CH2)2*2CH2]*2C*1CH","CH3C[CH3]HCH2C[::O]CH3","*1CH(CH)4*1C[CH3]","ClC[Cl]::C[Cl]H","H2O"};
		// Structural Formula Interpretation:
		// Paranthesis () should always be followed by a number indicating the number of repeats
		// Square brackets [] indicate bonding with previous atom but not next atom, i.e. a branch
		// Square brackets can be followed by a number indicating the number of repeats of the branch connected to the central atom
		// Any Square brackets following square brackets means atom bonds to previous atom with no square brackets
		// for cyclic and polycyclic compounds, connections are specified by *Num preceding atom
		// Squiggly Brackets {} designates the oxidation state of the preceding atom
		// (single bond is assumed so must indicate double bond as :: and triple bond as :::)
		string modeledSolventsNames[numModeledSolvents]={"acetic acid","acetone","acetonitrile","butanol","butyl methyl ketone","chlorobenzene","chloroform","cyclohexane","dibutyl ether","1,2-dichloroethane","dichloromethane","1,2-dimethoxyethane","n,n-dimethylacetamide","n,n-dimethylformamide","1,4-dioxane","dimethyl sulfoxide","ethanol","ethyl acetate","diethyl ether","ethylene glycol","2-ethylhexanol","formamide","glycerol","hexane","isobutanol","methanol","2-methoxyethanol","methyl ethyl ketone","methyl isopropyl ketone","nitromethane","propylene glycol","propanol","isopropanol","tetrahydrofuran","tetralin","methyl isobutyl ketone","toluene","trichloroethene","water"};
	};

// PDB File Data Type
struct pdbData
{string* recordType;int* atomNum;string* atomLabel;string* residue;string* chainLabel;int* atmChainNum;double* x;double* y;double* z;double* atmOccupancy;double* bFactor;string* terminus;};

// Vertices Data Structure Array [output of MSMS]
struct vertData
{double* x;double* y;double* z;double* nx;double* ny;double* nz;int* analyticSurf;int* sphereNum;int* vertType;string* closestAtom;int numVertices;};

// Structure Array for Ion Data
struct ion_Data
{double* conc;int* valence;double* mobility;double* radius;int numIons;};

// Collision Computation Parameters
struct collisionParameters
{double zeta;double Rp;double Rh;double Xsp;};

string getBaseFolder(string f);
string checkWhiteSpaceInFilePath(string iFile);
double interpolate(double x,double x1,double x2,double y1,double y2);
string array2String(int* Data,int numPnts,string delimiter);
double calcHydrodynamicRadius(double diffusivity,double temperature,double viscosity);
string checkFilePathParantheses(string f);
bool IN_STRING_ARRAY(string X,string* L,int N);
bool IN_LIST(string X,string list,int N,string delimiter);
string nameBuffer(string soluteName,string soluteConc);
void chmod_x(string binFile);
void copyFile(string inFile,string outFile);
int countNumLinesMSMSVertFile(string fileName);
void make_folder(string Fldr);
string makeUpperCase(string X);
string makeWhiteSpace(int Sz);
string makeHTMLWhiteSpace(int Sz);
void resizeTerminal(int width,int height);
zInput read_zpred_input_file(string inFile);
zExeInput cnvrtStr2Input(string cmd,string delimiter,string& Fldr,string& calcNum,string& display);
string* cnvrtzInput2Str(zInput In,string delimiter,string zFldr);
string cnvrtNumToStrng(int Num,int numberAfterDecimalpoint);
string cnvrtNumToStrng(double Num,int numberAfterDecimalpoint);
string cnvrtNumToStrng(long double Num,int numberAfterDecimalpoint);
string cnvrtNumToStrng(float Num,int numberAfterDecimalpoint);
int count_delimiter(string Data,string delimiter);
void define_msmsInput(string PDB,string pdbFile,string msmsFldr,string pdb_msmsFldr,string pdb_surfFldr,string surfPointDensity,string surfPointHiDensity,string probeRad,string msmsBinFile,msmsInput& In);
void erase_display();
void handleErrors(void);
static inline bool is_base64(unsigned char c);
void decryptString(string encStr,const string salt,const string pass,string outFile);
string base64_decode(string const& encoded_string);
string base64_encode(unsigned char const* bytes_to_encode, unsigned int in_len);
string readFile2Encrypt(string inFile);
string encryptFile(string inFile,const string salt,const string pass);
string getFileName(string filePath);
double* fill_double_array(string Data,int numPnts,string delimiter);
int* fill_int_array(string Data,int numPnts,string delimiter);
string* fill_string_array(string Data,int numPnts,string delimiter);
string formatNumberString(string Num);
long getFileSize(string inFile);
string initialize_ZPRED_display(int totalCalc,bool& MULTI_DISPLAY);
string initialize_ZPRED_gui_display(int totalCalc,bool& MULTI_DISPLAY);
string repeatString(string Input,int Num);
void rewind_display(string display);
void* runZPRED(void* Ptr);
void updateDisplayString(string dispStr,string calcNum,int updatePos,int nRows,string& dispLn);
void updateGuiDisplayString(string dispStr,string calcNum,int updatePos,int nRows,string dispLn,string guiDisplayFile);
string update_display(int totalCalc,int currCalc,int threadOffset);
void writeAPBSInputGen(string oFile);
void writeHullRad(string oFile);
void writePsize(string oFile);
void* runMSMS(msmsInput& In,string calcNum);
void readMSMSVertFile(string fileName,vertData& Data);
void writeHydroproInput(string calcType,string density,string molecularWeight,string proteinName,string oFile,string PDB,double specificVolume,double temperature,double viscosity);
void runHYDROPRO(string PDB,string pdb_hydroFldr,string inFile,string logFile,string calcNum);
double getDiffusivity(string hydroproFile);
void runPROPKA_PDB2PQR(string pdbFile,string pqrFile,string calcNum,string forceField,string pdb_pqrFldr,string propkaOutFile,string pH,string PDB2PQR,string logFile);
void runAPBS(string exeFile,string inFile,string logFile);
int countNumLines(string file);
void readPDBFile(string file,pdbData& Data);
double calc_protein_radius_std(vertData Data,int Sz,Vec centerCoord,double Radius);
double calc_protein_radius(vertData Data,int Sz,Vec centerCoord);
double calc_distance(Vec Vec1,Vec Vec2);
Vec calc_center_of_mass(pdbData Data,int Sz);
double getSpecificVolume(string msmsOutputFile,double molecularWeight);
void definePDBData(pdbData& Data,int Sz);
double calcProteinMolecularWeight(string pdbFile);
void runMULTIVALUE(string exeFile,string csvFile,string potFile,string mvFile,string logFile);
void inFileEditer(string* writeTypes,int N,string pdie,strVec dim,string pqrFile,string apbsInputgen,string ionData,string temperature,string largestIon,string er,string fldrExt);
void vert2csv(string inVertFile,string outCsvFile,bool VERBOSE);
void inflateVert(double inflationDistance,string inVertFile,string outVertFile,bool VERBOSE);
void writeMSMSVertFile(string fileName,vertData Data);
float readPQRFile(string pqrFile);
void clear_ion_Data(ion_Data& In);
double calc_OF_for_Sphere(ion_Data Ion,double er,double temperature,double zetaPot,double ka);
double calc_HF_for_Cylinder(double ka);
double calc_HF_for_Sphere(double ka);
double calc_OHWF_for_Sphere(ion_Data Ion,double er,double temperature,double zetaPot,double ka);
double getDiffusivity_hullrad(string hullradFile);
// MOBILITY Functions
double two_ion_problem(double ZP,double a,Solution S,Error E,bool VERBOSE);
double three_ion_problem(double ZP,double a,Solution S,Error E,bool VERBOSE);
double four_ion_problem(double ZP,double a,Solution S,Error E,bool VERBOSE);
double five_ion_problem(double ZP,double a,Solution S,Error E,bool VERBOSE);
double six_ion_problem(double ZP,double a,Solution S,Error E,bool VERBOSE);
double seven_ion_problem(double ZP,double a,Solution S,Error E,bool VERBOSE);
double eight_ion_problem(double ZP,double a,Solution S,Error E,bool VERBOSE);
double nine_ion_problem(double ZP,double a,Solution S,Error E,bool VERBOSE);
double calc_PBE_coefficient(double Zeta,double &r0,double rf,double &dr,Solution S,Error E,bool VERBOSE);
//
void homogeneous_form_2ion(const state_type &y,state_type &dy,const double r);
void homogeneous_form_3ion(const state_type &y,state_type &dy,const double r);
void homogeneous_form_4ion(const state_type &y,state_type &dy,const double r);
void homogeneous_form_5ion(const state_type &y,state_type &dy,const double r);
void homogeneous_form_6ion(const state_type &y,state_type &dy,const double r);
void homogeneous_form_7ion(const state_type &y,state_type &dy,const double r);
void homogeneous_form_8ion(const state_type &y,state_type &dy,const double r);
void homogeneous_form_9ion(const state_type &y,state_type &dy,const double r);
//
void inhomogeneous_Prob1_2ion(const state_type &y,state_type &dy,const double r);
void inhomogeneous_Prob1_3ion(const state_type &y,state_type &dy,const double r);
void inhomogeneous_Prob1_4ion(const state_type &y,state_type &dy,const double r);
void inhomogeneous_Prob1_5ion(const state_type &y,state_type &dy,const double r);
void inhomogeneous_Prob1_6ion(const state_type &y,state_type &dy,const double r);
void inhomogeneous_Prob1_7ion(const state_type &y,state_type &dy,const double r);
void inhomogeneous_Prob1_8ion(const state_type &y,state_type &dy,const double r);
void inhomogeneous_Prob1_9ion(const state_type &y,state_type &dy,const double r);
//
void inhomogeneous_Prob2_2ion(const state_type &y,state_type &dy,const double r);
void inhomogeneous_Prob2_3ion(const state_type &y,state_type &dy,const double r);
void inhomogeneous_Prob2_4ion(const state_type &y,state_type &dy,const double r);
void inhomogeneous_Prob2_5ion(const state_type &y,state_type &dy,const double r);
void inhomogeneous_Prob2_6ion(const state_type &y,state_type &dy,const double r);
void inhomogeneous_Prob2_7ion(const state_type &y,state_type &dy,const double r);
void inhomogeneous_Prob2_8ion(const state_type &y,state_type &dy,const double r);
void inhomogeneous_Prob2_9ion(const state_type &y,state_type &dy,const double r);
//
void poisson_boltzmann(const state_type &y,state_type &dy,const double r);
void initialize_PBE(state_type &y,double r0,double C,Solution S);
double calc_Ion_Mobility(int ion_val,double ion_radius,double viscosity);
double calc_Ion_Friction_Coefficient(int ion_val,double ion_mobility);
zOutput read_zpred_output_file(string zOutFile);
double calc_std_dev(double* X,int Sz,double Avg);
double calc_average(double* X,int Sz);
double calc_Kuwabara_Correction_for_Sphere(double ka,double volFrac,double Zeta,double a);
double shoelace(Vec2d p1,Vec2d p2,Vec2d p3);
double shoelace(Vec2d p1,Vec2d p2,Vec2d p3,Vec2d p4);
double calcAreaUnderCurve(double* x,double* y,int N);

int main(int argc,char *argv[])
{	//string salt="783e007c783e007c";
	//string passWord="Password";
	string inFile,passWord,salt;
	bool VERBOSE=false,MULTI_DISPLAY=false;// boolean for controlling display updates beyond 150 threads
	int ch;
	while((ch=getopt(argc,argv,"i:v"))!=EOF)
		{switch(ch)
			{case 'i':
				// ZPRED Input File
				inFile=optarg;
				break;
			case 'v':
				// Turn Comments on or off
				VERBOSE=true;
				break;
			default:
				exit(EXIT_FAILURE);}}

	// Get Current Working Directory
	string Fldr=get_current_dir_name();Fldr+="/";

	zInput Z=read_zpred_input_file(inFile);
	// Check should be performed by GUI
	//cout<<display_zpred_input(Z)<<endl;
	// Main (ZPRED) Output Folder
	string outputFldr=Fldr+Z.outputTitle+"/"; make_folder(outputFldr);
	Fldr=outputFldr;
	// Formatted Data Folders Folder (Also Holds ZPRED Configuration File)	
	string fFldr=Fldr+"Files/"; make_folder(fFldr);
	//string fFldr=outputFldr+"Files/";make_folder(fFldr);
	// ZPRED Output Folder
	string zpredFldr=fFldr+"Z/"; make_folder(zpredFldr);
	// Program Stdout/Stderr Log Folder
	string logFldr=fFldr+"LOG/"; make_folder(logFldr);
	// APBS Output Folder (in DX Matrix Format)
	string dxFldr=fFldr+"DX/"; make_folder(dxFldr);
	// HYDROPRO Output Folder (HP stands for hydrodynamic properties)
	string hydroFldr=fFldr+"HP/"; make_folder(hydroFldr);
	// APBS Input Command File Folder
	string inFldr=fFldr+"IN/"; make_folder(inFldr);
	// PROPKA Output Folder
	string propkaFldr=fFldr+"PROPKA/"; make_folder(propkaFldr);
	// PQR Formatted PDB Files Folder
	string pqrFldr=fFldr+"PQR/"; make_folder(pqrFldr);
	// MSMS Surface Output Folder
	string surfFldr=fFldr+"S/"; make_folder(surfFldr);
	string surfFldrContents[6]={"CGO/","colorCGO/","CSV/","fromMSMS/","SAS/","fromMV/"};	
	// String Array Delimiter
	string delimiter=";";
	// Determine Total Number of Zeta Potential Calculations
	int totalCalc=Z.numFiles*Z.numSolCond;
	string display,*cmdStrng,*cmd;
	vector<thread> t;
	int Counter=0,start=0,end=0,remainingCalc=totalCalc,numCalc=0;
	bool RUNNING_MULTI_DISPLAY;
	clock_t Tme;
	// Run ZPRED
	//cerr<<"Starting ZPRED timer...\n";
	//Tme=clock();
	// Initialize GUI Display
	string guiHdr="<b>Executing "+cnvrtNumToStrng(totalCalc,0)+" ZPRED calculations ("+cnvrtNumToStrng(Z.numFiles,0)+" structures in "+cnvrtNumToStrng(totalCalc/Z.numFiles,0)+" solution conditions)</b><br>";
	guiHdr+="<b>&nbsp;---------------&nbsp;-----------------------&nbsp;&nbsp;--------------&nbsp;&nbsp;-----------------&nbsp;&nbsp;-------------&nbsp;&nbsp;----------- </b><br>";
	guiHdr+="<b>| A = APBS | H = HYDROPRO | M = MSMS | MV = MULTIVALUE | P = PDB2PQR | Z = ZPRED |</b><br>";
	guiHdr+="<b>&nbsp;---------------&nbsp;-----------------------&nbsp;&nbsp;--------------&nbsp;&nbsp;-----------------&nbsp;&nbsp;-------------&nbsp;&nbsp;----------- </b><br>";
	cerr<<"Executing "<<totalCalc<<" ZPRED calculations ("<<Z.numFiles<<" structures in "<<totalCalc/Z.numFiles<<" solution conditions)\n";
	cerr<<" ---------- -------------- ---------- ----------------- ------------- ----------- \n";
	if(Z.RUN_HULLRAD)
		{cerr<<"| A = APBS | H = HULLRAD  | M = MSMS | MV = MULTIVALUE | P = PDB2PQR | Z = ZPRED |\n";}
	else
		{cerr<<"| A = APBS | H = HYDROPRO | M = MSMS | MV = MULTIVALUE | P = PDB2PQR | Z = ZPRED |\n";}
	cerr<<" ---------- -------------- ---------- ----------------- ------------- ----------- \n";
	display=initialize_ZPRED_display(totalCalc,MULTI_DISPLAY); cerr<<display; rewind_display(display);
	string guiDisplayFile=Fldr+".gui_display.txt";
	ofstream fOut;
	fOut.open(guiDisplayFile.c_str(),ofstream::out|ofstream::trunc);
	if(fOut.fail()){cerr<<"ERROR in ZPRED\nZPRED Output file could not be opened.\n"<<guiDisplayFile;exit(EXIT_FAILURE);}
	fOut<<guiHdr+initialize_ZPRED_gui_display(totalCalc,MULTI_DISPLAY); fOut.close();
	// Convert ZPRED Input Parameters into string
	cmdStrng=cnvrtzInput2Str(Z,delimiter,Fldr);

	if(MULTI_DISPLAY)
		{// Only Perform 150 threads MAX at a time
		RUNNING_MULTI_DISPLAY=true;start=0;end=MAX_DISPLAY_ROWS*MAX_DISPLAY_COLS;
		while(RUNNING_MULTI_DISPLAY)
			{Counter=0;
			for(int i=start;i<end;i++)
				{// Execute ZPRED on Separate Thread for Each Structure and Solution conditions
				cmd=new string(cmdStrng[i]);
				// Append Calculation Number and initialized display string
				*cmd+=cnvrtNumToStrng(i+1,0)+";"+display+";";
				if(Counter<Z.maxThreads)
					{t.push_back(thread(runZPRED,(void*)cmd));
					Counter++;}
				else{// Counter Reached Maximum Threads, wait for their completion
					for(int j=i-Z.maxThreads;j<i;j++){t[j].join();}
					t.push_back(thread(runZPRED,(void*)cmd));
					Counter=1;}}
			for(int i=0;i<Counter;i++){t[end+i-Counter].join();}
			// Once Finished with 150 threads start again with remainder
			start+=MAX_DISPLAY_ROWS*MAX_DISPLAY_COLS;
			remainingCalc-=MAX_DISPLAY_ROWS*MAX_DISPLAY_COLS;
			if(remainingCalc>=MAX_DISPLAY_ROWS*MAX_DISPLAY_COLS){end+=MAX_DISPLAY_ROWS*MAX_DISPLAY_COLS;}
			else if(remainingCalc<=0){break;RUNNING_MULTI_DISPLAY=false;}
			else{end+=remainingCalc;}
			// Update Display
			numCalc=end-start;
			display=update_display(totalCalc,numCalc,start);cerr<<display;rewind_display(display);}
		}
	else{
		for(int i=0;i<totalCalc;i++)
			{cmd=new string(cmdStrng[i]);
			*cmd+=cnvrtNumToStrng(i+1,0)+";"+display+";";
			if(Counter<Z.maxThreads){t.push_back(thread(runZPRED,(void*)cmd));Counter++;}
			else{for(int j=i-Z.maxThreads;j<i;j++){t[j].join();}
				t.push_back(thread(runZPRED,(void*)cmd));
				Counter=1;}}
		for(int i=0;i<Counter;i++){t[totalCalc+i-Counter].join();}}
	erase_display();
	//cerr<<totalCalc<<" ZPRED calculations complete.\nOutput stored in:\n"<<outputFldr+Z.outputTitle.substr(0,Z.outputTitle.length()-1)+".txt"<<"\n";
	cerr<<totalCalc<<" ZPRED calculations complete.\n";
	//Tme=clock()-Tme;
	//cerr<<"ZPRED Timer = "<<((float)Tme)/CLOCKS_PER_SEC<<" s\n";
	// After all ZPRED computations complete, store in user-specified folder (outputTitle parameter in input File)
	string zpredOutputFile=outputFldr+Z.outputTitle+".txt";
	// Read List of ZPRED Output Files
	string zOutListFile=fFldr+"zpredOutFilesList.txt",zFile="";	
	ifstream fIn;
	fIn.open(zOutListFile.c_str());
	if(fIn.fail()){cerr<<"ERROR in theZPRED!\nZPRED Output File List file could not be opened.\n"<<zOutListFile<<endl;exit(EXIT_FAILURE);}
	int Sz=15000;
	char Val[Sz];
	zOutput zRes;
	// Collect and Average Zeta Potentials of the ensemble of structures for each solution condition
	int* fCounter=new int[Z.numSolCond];
	double** srVal=new double*[Z.numSolCond];	
	double** prVal=new double*[Z.numSolCond];	
	double** zpVal=new double*[Z.numSolCond];
	double** qVal=new double*[Z.numSolCond];
	double** kMobVal=new double*[Z.numSolCond];	
	double** hMobVal=new double*[Z.numSolCond];
	double** semMobVal=new double*[Z.numSolCond];
	double** difVal=new double*[Z.numSolCond];
	double*** electricPotential=new double**[Z.numSolCond];
	double* Sum;
	string*** position=new string**[Z.numSolCond];
	int** numProfilePnts=new int*[Z.numSolCond];
	string* sER=new string[Z.numSolCond];
	string* sDens=new string[Z.numSolCond];
	string* sVisc=new string[Z.numSolCond];
	string* sXsp=new string[Z.numSolCond];
	string* fNm=new string[Z.numFiles];
	for(int i=0;i<Z.numSolCond;i++)
		{fCounter[i]=0;
		srVal[i]=new double[Z.numFiles];
		prVal[i]=new double[Z.numFiles];
		zpVal[i]=new double[Z.numFiles];
		qVal[i]=new double[Z.numFiles];
		semMobVal[i]=new double[Z.numFiles];
		hMobVal[i]=new double[Z.numFiles];
		kMobVal[i]=new double[Z.numFiles];
		difVal[i]=new double[Z.numFiles];
		electricPotential[i]=new double*[Z.numFiles];
		position[i]=new string*[Z.numFiles];
		numProfilePnts[i]=new int[Z.numFiles];}
	int tabIndex;
	string s;
	fIn.getline(Val,Sz);
	while(!fIn.eof())
		{// Read Single ZPRED Output Results
		zFile=Val;
		zRes=read_zpred_output_file(zFile);
		s=zRes.solCondNum;tabIndex=atoi(s.c_str());
		srVal[tabIndex][fCounter[tabIndex]]=zRes.solvatedRadius;
		prVal[tabIndex][fCounter[tabIndex]]=zRes.proteinRadius;
		zpVal[tabIndex][fCounter[tabIndex]]=zRes.zetaPotential;
		qVal[tabIndex][fCounter[tabIndex]]=zRes.charge;
		semMobVal[tabIndex][fCounter[tabIndex]]=zRes.semMobility;
		hMobVal[tabIndex][fCounter[tabIndex]]=zRes.henryMobility;
		kMobVal[tabIndex][fCounter[tabIndex]]=zRes.kuwabaraMobility;
		difVal[tabIndex][fCounter[tabIndex]]=zRes.diffusivity;
		sER[tabIndex]=zRes.solution.dielectric;
		sDens[tabIndex]=zRes.solution.density;
		sVisc[tabIndex]=zRes.solution.viscosity;
		sXsp[tabIndex]=zRes.Xsp;
		if(zRes.EP.numPnts>0)
			{// Electric Potential Profile Generated
			numProfilePnts[tabIndex][fCounter[tabIndex]]=zRes.EP.numPnts;
			electricPotential[tabIndex][fCounter[tabIndex]]=new double[zRes.EP.numPnts];
			position[tabIndex][fCounter[tabIndex]]=new string[zRes.EP.numPnts];			
			for(int i=0;i<zRes.EP.numPnts;i++)
				{position[tabIndex][fCounter[tabIndex]][i]=cnvrtNumToStrng(zRes.EP.position[i],DISTANCE_SIG_FIGS);
				electricPotential[tabIndex][fCounter[tabIndex]][i]=zRes.EP.potential[i];}
			}
		else
			{numProfilePnts[tabIndex][fCounter[tabIndex]]=0;}
		fNm[fCounter[tabIndex]]=zRes.proteinName;
		fCounter[tabIndex]++;
		fIn.getline(Val,Sz);}
	fIn.close();

	string Output="";
	double avgSR,stdSR,avgPR,stdPR,avgZP,stdZP,avgQ,stdQ,avgkMOB,stdkMOB,avghMOB,stdhMOB,avgsemMOB,stdsemMOB,avgDIF,stdDIF,avgPot,stdPot;
	double* dArr;
	// 9|9|8|9|6|8|8|
	// Determine header Width
	int lnPR=0,lnSR=0,lnZP=0,lnQ=0,lnMOB=0,lnDIF=0;
	string tmp,tmp2,tmp3,tmp4,tmp5,tmp6;
	for(int j=0;j<Z.numFiles;j++)
		{//fNm=cnvrtNumToStrng(j,0);
		//Output+="file #"+fNm+repeatString(" ",3-fNm.length())+"|";
		tmp=formatNumberString(cnvrtNumToStrng(prVal[0][j],BUFFER_SIZE));
		if(tmp.length()>lnPR){lnPR=tmp.length();}
		tmp2=formatNumberString(cnvrtNumToStrng(srVal[0][j],BUFFER_SIZE));
		if(tmp2.length()>lnSR){lnSR=tmp2.length();}
		tmp3=formatNumberString(cnvrtNumToStrng(zpVal[0][j],BUFFER_SIZE));
		if(tmp3.length()>lnZP){lnZP=tmp3.length();}
		tmp4=formatNumberString(cnvrtNumToStrng(qVal[0][j],BUFFER_SIZE));
		if(tmp4.length()>lnQ){lnQ=tmp4.length();}
		tmp5=formatNumberString(cnvrtNumToStrng(semMobVal[0][j],BUFFER_SIZE));
		if(tmp5.length()>lnMOB){lnMOB=tmp5.length();}
		tmp6=formatNumberString(cnvrtNumToStrng(difVal[0][j],BUFFER_SIZE));
		if(tmp6.length()>lnDIF){lnDIF=tmp6.length();}
		}

	for(int i=0;i<Z.numSolCond;i++)
		{Output+="Solution Condition #"+cnvrtNumToStrng(i,0)+"\n";
		Output+="pH "+Z.pH[i]+" ";
		Output+=formatNumberString(cnvrtNumToStrng(Z.temperature[i],BUFFER_SIZE))+" K\n";
		tmp="";
		for(int a=0;a<Z.numSolvent[i];a++)
			{tmp+=formatNumberString(cnvrtNumToStrng(Z.solventConc[i][a]*100,BUFFER_SIZE));//+"mol% "+Z.solvent[i][a]+"\n";
			tmp2=Z.solventConcType[i];
			if(tmp2.compare("massFraction")==0){tmp+=" mass% ";}
			else if(tmp2.compare("moleFraction")==0){tmp+=" mol% ";}
			else if(tmp2.compare("volumeFraction")==0){tmp+=" vol% ";}
			tmp+=Z.solvent[i][a]+"\n";
			}
		Output+=tmp;
		tmp="";
		for(int a=0;a<Z.numSolute[i];a++){tmp+=formatNumberString(cnvrtNumToStrng(Z.soluteConc[i][a],BUFFER_SIZE))+" M "+Z.solute[i][a]+"\n";}
		Output+=tmp;
		Output+="Relative Dielectric: "+sER[i]+"\n";
		Output+="Density: "+sDens[i]+" kg/L\n";
		Output+="Viscosity: "+sVisc[i]+" Ns/m^2\n";
		Output+="Hydration Layer Thickness: "+sXsp[i]+" A\n";
		Output+="Protein Concentration: "+formatNumberString(cnvrtNumToStrng(Z.proteinConc[i],BUFFER_SIZE))+" g/L\n";
		Output+=repeatString("-",118)+"|\n";
		Output+=repeatString("|",10)+repeatString("-",lnPR)+"|"+repeatString("-",lnSR)+"|"+repeatString("-",lnZP)+"|"+repeatString("-",lnQ)+"|SEM"+repeatString("-",lnMOB-3)+"|Henry"+repeatString("-",lnMOB-5)+"|Kuwabara"+repeatString("-",lnMOB-8)+"|"+repeatString("-",lnDIF)+"|\n";

		Output+=repeatString("|",10)+"Anhydrous"+repeatString("-",lnPR-9)+"|Solvated"+repeatString("-",lnSR-8)+"|Zeta"+repeatString("-",lnZP-4)+"|"+repeatString("-",lnQ)+"|Electro."+repeatString("-",lnMOB-8)+"|Electro."+repeatString("-",lnMOB-8)+"|Electro."+repeatString("-",lnMOB-8)+"|"+repeatString("-",lnDIF)+"|\n";
		Output+=repeatString("|",10)+"Radius"+repeatString("-",lnPR-6)+"|Radius"+repeatString("-",lnSR-6)+"|Potential"+repeatString("-",lnZP-9)+"|Q"+repeatString("-",lnQ-1)+"|Mobility"+repeatString("-",lnMOB-8)+"|Mobility"+repeatString("-",lnMOB-8)+"|Mobility"+repeatString("-",lnMOB-8)+"|Diffusivity"+repeatString("-",lnDIF-11)+"|\n";
		Output+=repeatString("|",10)+"[A]"+repeatString("-",lnPR-3)+"|[A]"+repeatString("-",lnSR-3)+"|[Volts]"+repeatString("-",lnZP-7)+"|"+repeatString("-",lnQ)+"|[umcm/Vs]"+repeatString("-",lnMOB-9)+"|[umcm/Vs]"+repeatString("-",lnMOB-9)+"|[umcm/Vs]"+repeatString("-",lnMOB-9)+"|[m^2/s]"+repeatString("-",lnDIF-7)+"|\n";
		for(int j=0;j<Z.numFiles;j++)
			{tmp=fNm[j];
			Output+=tmp+repeatString(" ",9-tmp.length())+"|";
			tmp=formatNumberString(cnvrtNumToStrng(prVal[i][j],BUFFER_SIZE));
			Output+=tmp+repeatString(" ",lnPR-tmp.length())+"|";
			tmp=formatNumberString(cnvrtNumToStrng(srVal[i][j],BUFFER_SIZE));
			Output+=tmp+repeatString(" ",lnSR-tmp.length())+"|";
			tmp=formatNumberString(cnvrtNumToStrng(zpVal[i][j],BUFFER_SIZE));
			Output+=tmp+repeatString(" ",lnZP-tmp.length())+"|";
			tmp=formatNumberString(cnvrtNumToStrng(qVal[i][j],BUFFER_SIZE));
			Output+=tmp+repeatString(" ",lnQ-tmp.length())+"|";
			tmp=formatNumberString(cnvrtNumToStrng(semMobVal[i][j],BUFFER_SIZE));
			Output+=tmp+repeatString(" ",lnMOB-tmp.length())+"|";
			tmp=formatNumberString(cnvrtNumToStrng(hMobVal[i][j],BUFFER_SIZE));
			Output+=tmp+repeatString(" ",lnMOB-tmp.length())+"|";
			tmp=formatNumberString(cnvrtNumToStrng(kMobVal[i][j],BUFFER_SIZE));
			Output+=tmp+repeatString(" ",lnMOB-tmp.length())+"|";
			tmp=formatNumberString(cnvrtNumToStrng(difVal[i][j],BUFFER_SIZE));
			Output+=tmp+repeatString(" ",lnDIF-tmp.length())+"|\n";
			}
		Output+=repeatString("-",119)+"\n";
		// Anhydrous Protein Radius
		avgPR=calc_average(prVal[i],Z.numFiles); stdPR=calc_std_dev(prVal[i],Z.numFiles,avgPR);
		// Solvated Protein Radius
		avgSR=calc_average(srVal[i],Z.numFiles); stdSR=calc_std_dev(srVal[i],Z.numFiles,avgSR);
		// Zeta Potential
		avgZP=calc_average(zpVal[i],Z.numFiles); stdZP=calc_std_dev(zpVal[i],Z.numFiles,avgZP);
		// Net Valence
		avgQ=calc_average(qVal[i],Z.numFiles); stdQ=calc_std_dev(qVal[i],Z.numFiles,avgQ);
		// Kuwabara Electrophoretic Mobility
		avgkMOB=calc_average(kMobVal[i],Z.numFiles); stdkMOB=calc_std_dev(kMobVal[i],Z.numFiles,avgkMOB);
		// Henry Electrophoretic Mobility
		avghMOB=calc_average(hMobVal[i],Z.numFiles); stdhMOB=calc_std_dev(hMobVal[i],Z.numFiles,avghMOB);
		// Standard Electrokinetic Model Mobility
		avgsemMOB=calc_average(semMobVal[i],Z.numFiles); stdsemMOB=calc_std_dev(semMobVal[i],Z.numFiles,avgsemMOB);
		// Single Protein Diffusivity
		avgDIF=calc_average(difVal[i],Z.numFiles); stdDIF=calc_std_dev(difVal[i],Z.numFiles,avgDIF);
		// Write Output
		tmp=formatNumberString(cnvrtNumToStrng(avgPR,BUFFER_SIZE));
		Output+="Average  |"+tmp+repeatString(" ",lnPR-tmp.length())+"|";
		tmp=formatNumberString(cnvrtNumToStrng(avgSR,BUFFER_SIZE));
		Output+=tmp+repeatString(" ",lnSR-tmp.length())+"|";
		tmp=formatNumberString(cnvrtNumToStrng(avgZP,BUFFER_SIZE));
		Output+=tmp+repeatString(" ",lnZP-tmp.length())+"|";
		tmp=formatNumberString(cnvrtNumToStrng(avgQ,BUFFER_SIZE));
		Output+=tmp+repeatString(" ",lnQ-tmp.length())+"|";
		tmp=formatNumberString(cnvrtNumToStrng(avgsemMOB,BUFFER_SIZE));
		Output+=tmp+repeatString(" ",lnMOB-tmp.length())+"|";
		tmp=formatNumberString(cnvrtNumToStrng(avghMOB,BUFFER_SIZE));
		Output+=tmp+repeatString(" ",lnMOB-tmp.length())+"|";
		tmp=formatNumberString(cnvrtNumToStrng(avgkMOB,BUFFER_SIZE));
		Output+=tmp+repeatString(" ",lnMOB-tmp.length())+"|";
		tmp=formatNumberString(cnvrtNumToStrng(avgDIF,BUFFER_SIZE));
		Output+=tmp+repeatString(" ",lnDIF-tmp.length())+"|\n";
		//
		tmp=formatNumberString(cnvrtNumToStrng(stdPR,BUFFER_SIZE));
		Output+="Std.Dev. |"+tmp+repeatString(" ",lnPR-tmp.length())+"|";
		tmp=formatNumberString(cnvrtNumToStrng(stdSR,BUFFER_SIZE));
		Output+=tmp+repeatString(" ",lnSR-tmp.length())+"|";
		tmp=formatNumberString(cnvrtNumToStrng(stdZP,BUFFER_SIZE));
		Output+=tmp+repeatString(" ",lnZP-tmp.length())+"|";
		tmp=formatNumberString(cnvrtNumToStrng(stdQ,BUFFER_SIZE));
		Output+=tmp+repeatString(" ",lnQ-tmp.length())+"|";
		tmp=formatNumberString(cnvrtNumToStrng(stdsemMOB,BUFFER_SIZE));
		Output+=tmp+repeatString(" ",lnMOB-tmp.length())+"|";		
		tmp=formatNumberString(cnvrtNumToStrng(stdhMOB,BUFFER_SIZE));
		Output+=tmp+repeatString(" ",lnMOB-tmp.length())+"|";
		tmp=formatNumberString(cnvrtNumToStrng(stdkMOB,BUFFER_SIZE));
		Output+=tmp+repeatString(" ",lnMOB-tmp.length())+"|";
		tmp=formatNumberString(cnvrtNumToStrng(stdDIF,BUFFER_SIZE));
		Output+=tmp+repeatString(" ",lnDIF-tmp.length())+"|\n";
		//
		Output+=repeatString("-",118)+"|\n\n";
		// Electric Potential Profile (if generated)
		if(numProfilePnts[i][0]>0)
			{Sum=new double[numProfilePnts[i][0]];
			for(int j=0;j<numProfilePnts[i][0];j++){Sum[j]=0;}
			Output+="Electric Potential Profile\n";
			Output+="Distance_[A] Electric_Potential_[V] Standard_Deviation\n";
			for(int j=0;j<Z.numFiles;j++)
				{if(j==0)
					{for(int k=0;k<numProfilePnts[i][j];k++){Output+=position[i][j][k]+"|";}
					Output+="\n";}
				tmp=fNm[j];
				Output+=tmp+repeatString(" ",9-tmp.length())+"|";
				for(int k=0;k<numProfilePnts[i][j];k++)
					{tmp=formatNumberString(cnvrtNumToStrng(electricPotential[i][j][k],BUFFER_SIZE));
					Output+=tmp+"|";
					if(!isnan(electricPotential[i][j][k])){Sum[k]+=electricPotential[i][j][k];}
					}
				Output+="\n";}
			//
			for(int j=0;j<numProfilePnts[i][0];j++)
				{avgPot=Sum[j]/Z.numFiles;
				dArr=new double[Z.numFiles];
				for(int k=0;k<Z.numFiles;k++){dArr[k]=electricPotential[i][k][j];}
				stdPot=calc_std_dev(dArr,Z.numFiles,avgPot);
				delete [] dArr;
				Output+=position[i][0][j]+"|"+formatNumberString(cnvrtNumToStrng(avgPot,BUFFER_SIZE))+"|"+formatNumberString(cnvrtNumToStrng(stdPot,BUFFER_SIZE))+"\n";
				}
			delete [] Sum;
			Output+="\n";}
		}
	// Write Output to File
	fOut.open(zpredOutputFile.c_str(),ofstream::out|ofstream::trunc);
	if(fOut.fail()){cerr<<"ERROR in ZPRED\nZPRED Output file could not be opened.\n"<<zpredOutputFile; exit(EXIT_FAILURE);}
	fOut<<Output; fOut.close();
	cerr<<"Output stored in:\n"<<zpredOutputFile<<"\n";
	// Delete Folders (Exclude Z and LOG folders)
	string msmsFldr=fFldr+"msms/";
	if(!Z.saveTemps)
		{
		boost::filesystem::remove_all(dxFldr);
		boost::filesystem::remove_all(hydroFldr);
		boost::filesystem::remove_all(inFldr);
		boost::filesystem::remove_all(propkaFldr);
		boost::filesystem::remove_all(pqrFldr);
		boost::filesystem::remove_all(surfFldr);
		boost::filesystem::remove_all(msmsFldr);
		}
}

double calc_average(double* X,int Sz)
	{double Output=0;
	int Counter=0;
	for(int i=0;i<Sz;i++)
		{if(!isnan(X[i]))
			{Output+=X[i];
			Counter++;}
		}
	if(Counter==0){return 0;}
	return Output/Counter;}

double calc_std_dev(double* X,int Sz,double Avg)
	{double Output=0;
	int Counter=0;
	for(int i=0;i<Sz;i++)
		{if(!isnan(X[i]))
			{Output+=(X[i]-Avg)*(X[i]-Avg);
			Counter++;}
		}
	if(Counter==1){return sqrt(Output/Counter);}
	else if(Counter==0){return 0;}
	else{return sqrt(Output/(Counter-1));}}
	
double interpolate(double x,double x1,double x2,double y1,double y2){double output=(y2-y1)*(x-x1)/(x2-x1) + y1;return output;}

string array2String(int* Data,int numPnts,string delimiter){string Output="";for(int i=0;i<numPnts;i++){Output+=cnvrtNumToStrng(Data[i],0)+delimiter;}return Output;}

bool IN_LIST(string X,string list,int N,string delimiter)
	{// Is X in list?
	bool Output=false;
	string* L,tmp;
	if(N==0){Output=false;}
	else{L=fill_string_array(list,N,delimiter);
		for(int i=0;i<N;i++)
			{tmp=L[i];
			if(tmp.compare(X)==0){Output=true;break;}}}
	return Output;}

bool IN_STRING_ARRAY(string X,string* L,int N)
	{// Is X in array?
	bool Output=false;
	string tmp;
	if(N==0){Output=false;}
	else{for(int i=0;i<N;i++)
			{tmp=L[i];
			if(tmp.compare(X)==0){Output=true;break;}}}
	return Output;}

void copyFile(string inFile,string outFile)
	{long fileSz=getFileSize(inFile);
	char* buf=new char[fileSz];
	ifstream fIn;
	bool ATTEMPTING=true;
	int numTries=100000,Counter=0;
	int Err;char errMsg[256];
	while(ATTEMPTING)
		{fIn.open(inFile.c_str(),ios::in|ios::binary);
		if(!fIn.fail()){fIn.read(buf,fileSz);fIn.close();ATTEMPTING=false;break;}
		else{Counter++;}
		if(Counter>=numTries)
			{Err=errno;erase_display();
			cerr<<"ERROR in copyFile!\nInput file could not be opened.\n"<<inFile<<endl;
			cerr<<strerror_r(Err,errMsg,256)<<"\n";
			exit(EXIT_FAILURE);}
		}
	
	ATTEMPTING=true;Counter=0;
	ofstream fOut;
	while(ATTEMPTING)
		{fOut.open(outFile.c_str(),ios::out|ios::binary);
		if(!fOut.fail()){fOut.write(buf,fileSz);fOut.close();ATTEMPTING=false;break;}
		else{Counter++;}
		if(Counter>=numTries)
			{Err=errno;erase_display();
			cerr<<"ERROR in copyFile!\nOutput file could not be opened.\n"<<outFile<<endl;
			cerr<<strerror_r(Err,errMsg,256)<<"\n";
			exit(EXIT_FAILURE);}
		}
	}

string checkFilePathParantheses(string f)
	{string Output=f;
	int pos=Output.find("(",0);
	bool SEARCHING=true;
	while(SEARCHING)
		{if(pos!=string::npos)
			{Output.replace(pos,1,"\\(");
			pos=Output.find(")",pos+1);
			if(pos!=string::npos){Output.replace(pos,1,"\\)");}
			else{cerr<<"Error in checkFilePathParantheses!\nUnbalanced parantheses present.\n";exit(EXIT_FAILURE);}
			pos=Output.find("(",pos);}
		else{SEARCHING=false;break;}}
	return Output;}

string getBaseFolder(string f)
	{int pos=f.rfind("/",f.length()-1);
	return f.substr(0,pos)+"/";}

void chmod_x(string binFile)
	{int Res=chmod(binFile.c_str(),S_IRWXU);
	int Err;
	char errMsg[256];
	if(Res!=0)
		{// An Error has occured, capture error number with erno
		Err=errno;erase_display();
		cerr<<"ERROR in chmod_x while opening|"<<binFile<<"|END\n"<<strerror_r(Err,errMsg,256)<<"\n";
		exit(EXIT_FAILURE);}}

string nameBuffer(string soluteName,string soluteConc)
	{string Output="";
	int N=count_delimiter(soluteName,";");
	string* name=fill_string_array(soluteName,N,";");
	string* conc=fill_string_array(soluteConc,N,";");
	int pos;
	for(int i=0;i<N;i++)
		{soluteConc=formatNumberString(conc[i]);
		if(i==N-1){Output+=soluteConc+"M_"+name[i];}
		else{Output+=soluteConc+"M_"+name[i]+"_";}}
	delete [] name; delete [] conc;
	return Output;}

int countNumLinesMSMSVertFile(string fileName)
	{float x,y,z,nx,ny,nz;
	int analyticSurf,sphereNum,vertType,Counter=0;
	char closestAtom[15000];

	string msms_vertices_file_format="%f %f %f %f %f %f %d %d %d %s";

	FILE *fIn;
    fIn=fopen(fileName.c_str(),"r");
    if(fIn==NULL)
        {cerr<<"ERROR in countNumLinesMSMSVertFile!\nInput Vertices File could not be found.\n\nFilepath:\t"<<fileName<<endl;
         exit(EXIT_FAILURE);}

	fseek(fIn,0,SEEK_END);
	long fileSize=ftell(fIn);
	rewind(fIn);

	int lineSz;
	while(!feof(fIn))
        {fscanf(fIn,msms_vertices_file_format.c_str(),&x,&y,&z,&nx,&ny,&nz,&analyticSurf,&sphereNum,&vertType,&closestAtom);		
		lineSz=ftell(fIn);
		if(lineSz==fileSize){break;}
         else{Counter++;}}
	fclose(fIn);
	return Counter;}

string cnvrtNumToStrng(int Num,int numberAfterDecimalpoint){stringstream ss;ss.setf(ios::fixed);if(numberAfterDecimalpoint>0){ss.setf(ios::showpoint);}ss.precision(numberAfterDecimalpoint);ss<<Num;return ss.str();}

string cnvrtNumToStrng(double Num,int numberAfterDecimalpoint){stringstream ss;ss.setf(ios::fixed);if(numberAfterDecimalpoint>0){ss.setf(ios::showpoint);}ss.precision(numberAfterDecimalpoint);ss<<Num;return ss.str();}

string cnvrtNumToStrng(long double Num,int numberAfterDecimalpoint){stringstream ss;ss.setf(ios::fixed);if(numberAfterDecimalpoint>0){ss.setf(ios::showpoint);}ss.precision(numberAfterDecimalpoint);ss<<Num;return ss.str();}

string cnvrtNumToStrng(float Num,int numberAfterDecimalpoint){stringstream ss;ss.setf(ios::fixed);if(numberAfterDecimalpoint>0){ss.setf(ios::showpoint);}ss.precision(numberAfterDecimalpoint);ss<<Num;return ss.str();}

string* cnvrtzInput2Str(zInput In,string delimiter,string zFldr)
	{// Determine Number of Input Strings to Create
	int totalCalc=In.numFiles*In.numSolCond;
	string* Output=new string[totalCalc];
	string solvStr="",solvConcStr="",solvConcTypeStr="",soluStr="",soluConcStr="";
	int Counter;
	for(int p=0;p<In.numFiles;p++)
		{for(int j=0;j<In.numSolCond;j++)
			{Counter=p*In.numSolCond+j;
			// Define ZPRED Input String
			// Solution Condition Calculation Number (1)
			//Output[Counter]+=In.id[j]+delimiter;
			Output[Counter]=cnvrtNumToStrng(j,0)+delimiter;
			// PDB File Path (2)
			Output[Counter]+=In.files[p]+delimiter;
			// Job Name/Output Tile (3)
			Output[Counter]+=In.outputTitle+delimiter;
			// pH Value (4)
			Output[Counter]+=In.pH[j]+delimiter;
			// Temperature Value (5)
			Output[Counter]+=formatNumberString(cnvrtNumToStrng(In.temperature[j],BUFFER_SIZE))+delimiter;
			// Number of Solvents (6)
			Output[Counter]+=cnvrtNumToStrng(In.numSolvent[j],0)+delimiter;
			solvStr="";solvConcStr="";
			for(int i=0;i<In.numSolvent[j];i++)
				{solvStr+=In.solvent[j][i]+delimiter;
				solvConcStr+=formatNumberString(cnvrtNumToStrng(In.solventConc[j][i],BUFFER_SIZE))+delimiter;}
			// Solvent Name String	(already delimited) (7)
			Output[Counter]+=solvStr;
			// Solvent Concentration String (already delimited) (8)
			Output[Counter]+=solvConcStr;
			// Solvent Concentration Type String (9)
			Output[Counter]+=In.solventConcType[j]+delimiter;
			// Number of Solutes (10)
			Output[Counter]+=cnvrtNumToStrng(In.numSolute[j],0)+delimiter;
			soluStr="";soluConcStr="";
			for(int i=0;i<In.numSolute[j];i++)
				{soluStr+=In.solute[j][i]+delimiter;
				soluConcStr+=formatNumberString(cnvrtNumToStrng(In.soluteConc[j][i],BUFFER_SIZE))+delimiter;}
			// Solute Name String	(already delimited) (11)
			Output[Counter]+=soluStr;
			// Solute Concentration String (already delimited) (12)
			Output[Counter]+=soluConcStr;
			// Protein Concentration (13)
			Output[Counter]+=formatNumberString(cnvrtNumToStrng(In.proteinConc[j],BUFFER_SIZE))+delimiter;
			// Number of APBS Write Types (14)
			Output[Counter]+=cnvrtNumToStrng(In.numApbsWriteTypes,0)+delimiter;
			// APBS Write Types (15)
			for(int f=0;f<In.numApbsWriteTypes;f++){Output[Counter]+=In.apbsWriteTypes[f]+delimiter;}
			// Executable & Program File Paths (16)
			Output[Counter]+=In.SC.apbsExecutable+delimiter;
			Output[Counter]+=In.SC.multivalueExecutable+delimiter;	// (17)
			Output[Counter]+=In.SC.hydroproExecutable+delimiter;	// (18)
			Output[Counter]+=In.SC.msmsExecutable+delimiter;		// (19)
			Output[Counter]+=In.SC.msmsAtmTypeNumbers+delimiter;	// (20)
			Output[Counter]+=In.SC.msmsPdbToXyzr+delimiter;			// (21)
			Output[Counter]+=In.SC.msmsPdbToXyzrn+delimiter;		// (22)
			Output[Counter]+=In.SC.pdb2pqr+delimiter;				// (23)
			// MSMS Parameter: Low Surface Density (24)
			Output[Counter]+=In.msms.surfPointDensity+delimiter;
			// MSMS Parameter: High Surface Density (25)
			Output[Counter]+=In.msms.surfPointHiDensity+delimiter;
			// HYDROPRO Parameter: Calculation Type (26)
			Output[Counter]+=In.hydroproCalcType+delimiter;
			// PDB2PQR Parameter: Force Field (27)
			Output[Counter]+=In.forceField+delimiter;
			// ZPRED Parameter: Flag for Saving Calculation Files (28)
			if(In.saveTemps){Output[Counter]+="TRUE"+delimiter;}
			else{Output[Counter]+="FALSE"+delimiter;}
			// Protein Dielectric Constant (29)
			Output[Counter]+=In.pdie+delimiter;
			// APBS Parameter: X-Axis Grid Dimensions (30)
			Output[Counter]+=In.dime_x+delimiter;
			// APBS Parameter: Y-Axis Grid Dimensions (31)
			Output[Counter]+=In.dime_y+delimiter;
			// APBS Parameter: Z-Axis Grid Dimensions (32)
			Output[Counter]+=In.dime_z+delimiter;
			// ZPRED Parameter: APBS Control (33)
			if(In.RUN_APBS){Output[Counter]+="true"+delimiter;}
			else{Output[Counter]+="false"+delimiter;}
			// ZPRED Parameter: PDB2QPR Control (34)
			if(In.RUN_PDB2PQR){Output[Counter]+="true"+delimiter;}
			else{Output[Counter]+="false"+delimiter;}
			// ZPRED Parameter: HYDROPRO Control (35)
			if(In.RUN_HYDROPRO){Output[Counter]+="true"+delimiter;}
			else{Output[Counter]+="false"+delimiter;}
			// ZPRED Parameter: HULLRAD Control (36)
			if(In.RUN_HULLRAD){Output[Counter]+="true"+delimiter;}
			else{Output[Counter]+="false"+delimiter;}
			// ZPRED Parameter: Final Output Control (37)
			if(In.RUN_ZPRED){Output[Counter]+="true"+delimiter;}
			else{Output[Counter]+="false"+delimiter;}
			// ZPRED Parameter: COLLIDE Control (38)
			if(In.RUN_COLLIDE){Output[Counter]+="true"+delimiter;}
			else{Output[Counter]+="false"+delimiter;}					
			// ZPRED Base Folder (39)
			Output[Counter]+=zFldr+delimiter;
			// User-Specified Solution Density [kg/L] (40)
			Output[Counter]+=cnvrtNumToStrng(In.density[j],BUFFER_SIZE)+delimiter;
			// User-Specified Solution Relative Dielectric (41)
			Output[Counter]+=cnvrtNumToStrng(In.dielectric[j],ER_SIG_FIGS)+delimiter;
			// User-Specified Solution Inflation Distance/Slip Plane Position [A] (42)
			Output[Counter]+=cnvrtNumToStrng(In.inflationDistance[j],DISTANCE_SIG_FIGS)+delimiter;
			// User-Specified Solution Viscosity [Pa s] (43)
			Output[Counter]+=cnvrtNumToStrng(In.viscosity[j],BUFFER_SIZE)+delimiter;
			// Generate Potential Profile (44)
			if(In.GENERATE_POT_PROFILE[j]){Output[Counter]+="true"+delimiter;}
			else{Output[Counter]+="false"+delimiter;}
			
			Counter++;
			}
		}
	if(Counter!=totalCalc){cerr<<"ERROR in cnvrtzInput2Str\nNumber of Calculations does not match the number of strings written"<<endl;exit(EXIT_FAILURE);}
	return Output;}

zExeInput cnvrtStr2Input(string cmd,string delimiter,string& Fldr,string& calcNum,string& display)
	{zExeInput Out;	
	string tmp="";
	int pos=cmd.find(delimiter,0);
	// Solution Condition Calculation Number (1)
	Out.id=cmd.substr(0,pos);
	int oldPos=pos+1;
	// PDB File Path (2)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	Out.file=cmd.substr(oldPos,pos-oldPos);
	// Job Name/Output Tile (3)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	Out.outputTitle=cmd.substr(oldPos,pos-oldPos);
	// pH Value (4)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	Out.pH=cmd.substr(oldPos,pos-oldPos);
	// Temperature Value (5)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	tmp=cmd.substr(oldPos,pos-oldPos);
	Out.temperature=strtod(tmp.c_str(),NULL);	
	// Number of Solvents (6)
	// Solvent Name String	(already delimited) (7)
	// Solvent Concentration String (already delimited) (8)
	// Solvent Concentration Type (9)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	tmp=cmd.substr(oldPos,pos-oldPos);
	Out.numSolvent=atoi(tmp.c_str());
	Out.solvent=new string[Out.numSolvent];
	Out.solventConc=new double[Out.numSolvent];
	// Extract Solvent(s) Name(s) (7)
	for(int i=0;i<Out.numSolvent;i++)
		{oldPos=pos+1;
		pos=cmd.find(delimiter,pos+1);
		Out.solvent[i]=cmd.substr(oldPos,pos-oldPos);}
	// Extract Solvent(s) Concentration(s) (8)
	for(int i=0;i<Out.numSolvent;i++)
		{oldPos=pos+1;
		pos=cmd.find(delimiter,pos+1);
		tmp=cmd.substr(oldPos,pos-oldPos);
		Out.solventConc[i]=strtod(tmp.c_str(),NULL);}
	// Solvent Concentration Type
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	Out.solventConcType=cmd.substr(oldPos,pos-oldPos);
	// Number of Solutes (10)
	// Solute Name String	(already delimited) (10)
	// Solute Concentration String (already delimited) (11)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	tmp=cmd.substr(oldPos,pos-oldPos);
	Out.numSolute=atoi(tmp.c_str());
	Out.solute=new string[Out.numSolute];
	Out.soluteConc=new double[Out.numSolute];
	// Extract Solute Name(s) (11)
	for(int i=0;i<Out.numSolute;i++)
		{oldPos=pos+1;
		pos=cmd.find(delimiter,pos+1);
		Out.solute[i]=cmd.substr(oldPos,pos-oldPos);}
	// Extract Solute(s) Concentration(s) (12)
	for(int i=0;i<Out.numSolute;i++)
		{oldPos=pos+1;
		pos=cmd.find(delimiter,pos+1);
		tmp=cmd.substr(oldPos,pos-oldPos);
		Out.soluteConc[i]=strtod(tmp.c_str(),NULL);}
	// Protein Concentration (13)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	tmp=cmd.substr(oldPos,pos-oldPos);
	Out.proteinConc=strtod(tmp.c_str(),NULL);
	// Number of APBS Write Types (14)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	tmp=cmd.substr(oldPos,pos-oldPos);
	Out.numApbsWriteTypes=atoi(tmp.c_str());
	// APBS Write Types (15)
	Out.apbsWriteTypes=new string[Out.numApbsWriteTypes];
	for(int i=0;i<Out.numApbsWriteTypes;i++)
		{oldPos=pos+1;
		pos=cmd.find(delimiter,pos+1);
		Out.apbsWriteTypes[i]=cmd.substr(oldPos,pos-oldPos);}
	// APBS EXECUTABLE (16)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	Out.SC.apbsExecutable=cmd.substr(oldPos,pos-oldPos);
	// MULTIVALUE Executable (17)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	Out.SC.multivalueExecutable=cmd.substr(oldPos,pos-oldPos);
	// HYDROPRO Executable (18)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	Out.SC.hydroproExecutable=cmd.substr(oldPos,pos-oldPos);
	// MSMS Executable (19)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	Out.SC.msmsExecutable=cmd.substr(oldPos,pos-oldPos);
	// MSMS AtmTypeNumbers File (20)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	Out.SC.msmsAtmTypeNumbers=cmd.substr(oldPos,pos-oldPos);
	// MSMS pdb_to_xyzr File (21)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	Out.SC.msmsPdbToXyzr=cmd.substr(oldPos,pos-oldPos);
	// MSMS pdb_to_xyzrn File (22)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	Out.SC.msmsPdbToXyzrn=cmd.substr(oldPos,pos-oldPos);
	// PDB2PQR main.py File (23)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	Out.SC.pdb2pqr=cmd.substr(oldPos,pos-oldPos);
	// MSMS Parameter: Low Surface Density (24)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	Out.msms.surfPointDensity=cmd.substr(oldPos,pos-oldPos);
	// MSMS Parameter: High Surface Density (25)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	Out.msms.surfPointHiDensity=cmd.substr(oldPos,pos-oldPos);
	// HYDROPRO Parameter: Calculation Type (26)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	Out.hydroproCalcType=cmd.substr(oldPos,pos-oldPos);
	// PDB2PQR Parameter: Force Field (27)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	Out.forceField=cmd.substr(oldPos,pos-oldPos);
	// ZPRED Parameter: saveTemps Flag for Saving Calculation Files (28)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	tmp=cmd.substr(oldPos,pos-oldPos);
	if(tmp.compare("FALSE")==0){Out.saveTemps=false;}
	else{Out.saveTemps=true;}
	// Protein Dielectric Constant (29)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	Out.pdie=cmd.substr(oldPos,pos-oldPos);
	// APBS Parameter: X-Axis Grid Dimensions (30)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	Out.dime_x=cmd.substr(oldPos,pos-oldPos);
	// APBS Parameter: Y-Axis Grid Dimensions (31)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	Out.dime_y=cmd.substr(oldPos,pos-oldPos);
	// APBS Parameter: Z-Axis Grid Dimensions (32)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	Out.dime_z=cmd.substr(oldPos,pos-oldPos);
	// ZPRED Parameter: APBS Control (33)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	tmp=cmd.substr(oldPos,pos-oldPos);
	if(tmp.compare("false")==0){Out.RUN_APBS=false;}
	else{Out.RUN_APBS=true;}
	// ZPRED Parameter: PDB2QPR Control (34)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	tmp=cmd.substr(oldPos,pos-oldPos);
	if(tmp.compare("false")==0){Out.RUN_PDB2PQR=false;}
	else{Out.RUN_PDB2PQR=true;}
	// ZPRED Parameter: HYDROPRO Control (35)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	tmp=cmd.substr(oldPos,pos-oldPos);
	if(tmp.compare("false")==0){Out.RUN_HYDROPRO=false;}
	else{Out.RUN_HYDROPRO=true;}
	// ZPRED Parameter: HULLRAD Control (36)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	tmp=cmd.substr(oldPos,pos-oldPos);
	if(tmp.compare("false")==0){Out.RUN_HULLRAD=false;}
	else{Out.RUN_HULLRAD=true;}
	// ZPRED Parameter: Final Output Control (37)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	tmp=cmd.substr(oldPos,pos-oldPos);
	if(tmp.compare("false")==0){Out.RUN_ZPRED=false;}
	else{Out.RUN_ZPRED=true;}
	// ZPRED Parameter: COLLIDE Control (38)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	tmp=cmd.substr(oldPos,pos-oldPos);
	if(tmp.compare("false")==0){Out.RUN_COLLIDE=false;}
	else{Out.RUN_COLLIDE=true;}
	// ZPRED Base Folder (39)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	Fldr=cmd.substr(oldPos,pos-oldPos);
	// User-Specified Solution Density [kg/L] (40)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	tmp=cmd.substr(oldPos,pos-oldPos);
	Out.density=strtod(tmp.c_str(),NULL);
	// User-Specified Solution Relative Dielectric (41)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	tmp=cmd.substr(oldPos,pos-oldPos);
	Out.dielectric=strtod(tmp.c_str(),NULL);
	// User-Specified Solution Inflation Distance/Slip Plane Position [A] (42)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	tmp=cmd.substr(oldPos,pos-oldPos);
	Out.inflationDistance=strtod(tmp.c_str(),NULL);
	// User-Specified Solution Viscosity [Pa s] (43)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	tmp=cmd.substr(oldPos,pos-oldPos);
	Out.viscosity=strtod(tmp.c_str(),NULL);
	// Generate Electric Potential Profile? (44)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	tmp=cmd.substr(oldPos,pos-oldPos);
	if(tmp.compare("true")==0){Out.GENERATE_POT_PROFILE=true;}
	else if(tmp.compare("false")==0){Out.GENERATE_POT_PROFILE=false;}
	
	// ZPRED Calculation Number (45)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	calcNum=cmd.substr(oldPos,pos-oldPos);
	// Computation Progress Display String (46)
	oldPos=pos+1;
	pos=cmd.find(delimiter,pos+1);
	display=cmd.substr(oldPos,pos-oldPos);
	return Out;}

int count_delimiter(string Data,string delimiter){int Counter=0;string tmp="";for(int i=0;i<Data.length();i++){tmp=Data[i];if(tmp.compare(delimiter)==0){Counter++;}}return Counter;}

string checkWhiteSpaceInFilePath(string iFile)
	{int pos=iFile.find(" ",0),pos2,pos3;
	bool CHECKING=true;
	string tmp=iFile,tmp2;
	while(CHECKING)
		{if(pos!=string::npos)
			{// White Space Found, Add ' ' to folder Name
			// 1st /
			pos2=tmp.rfind("/",pos);
			// 2nd /
			pos3=tmp.find("/",pos);
			// Add Single Quotes to tmp
			tmp2=tmp.substr(0,pos2+1)+"\'"+tmp.substr(pos2+1,pos3-pos2-1)+"\'"+tmp.substr(pos3,tmp.length()-pos3);
			tmp=tmp2;
			//inputVal=inputVal.substr(1,inputVal.length()-1);pos=inputVal.find(" ",0);
			pos=tmp.find(" ",pos+3);
			}
		else if(pos==0)
			{// Whitespace Preceeding filepath, remove it
			tmp=tmp.substr(1,tmp.length()-1);
			pos=tmp.find(" ",0);
			}
		else{CHECKING=false;break;}
		}
	return tmp;}

void define_msmsInput(string PDB,string pdbFile,string msmsFldr,string pdb_msmsFldr,string pdb_surfFldr,string surfPointDensity,string surfPointHiDensity,string probeRad,string msmsBinFile,msmsInput& In)
	{// Current PDB File Name under assessment
	In.PDB=PDB;
	// File Path of Current PDB File Name under assessment
	In.pdbFile=checkWhiteSpaceInFilePath(pdbFile);
	// MSMS Computation Folder
	In.msmsFldr=checkWhiteSpaceInFilePath(msmsFldr);
	// File Path of MSMS Computation Folder
	In.pdb_msmsFldr=checkWhiteSpaceInFilePath(pdb_msmsFldr);
	// File Path of MSMS Output Folder	
	In.pdb_surfFldr=checkWhiteSpaceInFilePath(pdb_surfFldr);
	// MSMS Low Surface Density
	In.surfPointDensity=surfPointDensity;
	// MSMS High Surface Density
	In.surfPointHiDensity=surfPointHiDensity;
	// MSMS Spherical Probe Radius
	In.probeRadius=probeRad;
	// MSMS PDB_TO_XYZRN
	In.PDB_TO_XYZRN="pdb_to_xyzrn";
	// MSMS Executable File (file path is not needed)
	In.MSMS=checkWhiteSpaceInFilePath(getFileName(msmsBinFile));}

void erase_display(){cerr<<"\033[2J\033[1;H";}

string encryptFile(string inFile,const string salt,const string pass)
	{string s=readFile2Encrypt(inFile);	
	// Generate Key and IV from Password and Salt
	//const string pass="Password";
	unsigned char key[32], iv[32];
	// Allocate Space for Encrypted (Ciphered) text
	unsigned char ciphertext[s.length()];
  	// Buffer for the decrypted text
	unsigned char decryptedtext[s.length()];
	int keyLength=EVP_BytesToKey(EVP_aes_256_cbc(),EVP_sha1(),(unsigned char*)salt.c_str(),(unsigned char*)pass.c_str(),pass.length(),1,key,iv);
	//cout<<"Key Length:\n"<<keyLength<<"\nKey:\n"<<key<<endl;
	// Define Cipher Object
	EVP_CIPHER_CTX *ctx;
	int len,ret;
	// Create and initialize the context
	if(!(ctx=EVP_CIPHER_CTX_new())){handleErrors();}
	// Start Encryption
	if(1 != EVP_EncryptInit_ex(ctx,EVP_aes_256_cbc(),NULL,key,iv)){handleErrors();}	
	// Encrypt message and obtain output	
	if(1 != EVP_EncryptUpdate(ctx,ciphertext,&len,(unsigned char*)s.c_str(),s.length())){handleErrors();}
	int ciphertext_len=len;
	//cout<<ciphertext<<endl;
	// Finalize Encryption
	if(1 != EVP_EncryptFinal_ex(ctx,ciphertext+len,&len)){handleErrors();}
	ciphertext_len+=len;
	// Clean Up
	EVP_CIPHER_CTX_free(ctx);
	// Check ciphertext
	//cout<<"Ciphered text is:\n";
	//BIO_dump_fp(stdout,(const char*)ciphertext,ciphertext_len);
	// Base64 Encoded Encryption
	//string b64enc=base64_encode(reinterpret_cast<const unsigned char*>(cVal.c_str()), cVal.length());
	string Output=base64_encode(ciphertext,ciphertext_len);
	return Output;}

string readFile2Encrypt(string inFile)
	{long fileSz=getFileSize(inFile);
	char* buf=new char[fileSz];
	ifstream fIn;
	fIn.open(inFile.c_str(),ios::in|ios::binary);
	if(fIn.fail()){cerr<<"ERROR in readFile2Encrypt!\ninput file could not be opened.\n"<<inFile<<endl;exit(EXIT_FAILURE);}
	fIn.read(buf,fileSz);
	fIn.close();
	string val="";
	for(int i=0;i<fileSz;i++){val+=buf[i];}
	delete [] buf;
	string Output=val;
	return Output;}

string getFileName(string filePath)
	{string Output;
	int pos=filePath.rfind("/");
	Output=filePath.substr(pos+1,filePath.length()-pos-1);
	return Output;}

string base64_encode(unsigned char const* bytes_to_encode, unsigned int in_len)
	{static const string base64_chars = 
		 "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
		 "abcdefghijklmnopqrstuvwxyz"
		 "0123456789+/";
	string ret;
	int i=0,j=0;
	unsigned char char_array_3[3];
	unsigned char char_array_4[4];

	while(in_len--)
		{char_array_3[i++] = *(bytes_to_encode++);
		if(i==3)
			{char_array_4[0]=(char_array_3[0] & 0xfc) >> 2;
			char_array_4[1]=((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
			char_array_4[2]=((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
			char_array_4[3]=char_array_3[2] & 0x3f;

			for(i=0;(i<4);i++){ret+=base64_chars[char_array_4[i]];}
			i=0;}}

	if(i)
		{for(j=i;j<3;j++){char_array_3[j]='\0';}

		char_array_4[0]=( char_array_3[0] & 0xfc) >> 2;
		char_array_4[1]=((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
		char_array_4[2]=((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);

		for(j=0;(j<i+1);j++){ret+=base64_chars[char_array_4[j]];}

		while((i++ < 3)){ret+='=';}}

	return ret;}

string base64_decode(string const& encoded_string)
	{static const string base64_chars = 
             "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
             "abcdefghijklmnopqrstuvwxyz"
             "0123456789+/";
	int in_len=encoded_string.size();
	int i=0,j=0,in_=0;
	unsigned char char_array_4[4], char_array_3[3];
	string ret;

	while(in_len-- && (encoded_string[in_]!='=') && is_base64(encoded_string[in_]))
		{char_array_4[i++]=encoded_string[in_];
		in_++;
		if(i==4)
			{for(i=0;i<4;i++){char_array_4[i]=base64_chars.find(char_array_4[i]);}

			char_array_3[0]=( char_array_4[0] << 2       ) + ((char_array_4[1] & 0x30) >> 4);
			char_array_3[1]=((char_array_4[1] & 0xf) << 4) + ((char_array_4[2] & 0x3c) >> 2);
			char_array_3[2]=((char_array_4[2] & 0x3) << 6) +   char_array_4[3];

			for(i=0;(i<3);i++){ret += char_array_3[i];}
			i=0;}}

	if(i)
		{for(j=0;j<i;j++){char_array_4[j]=base64_chars.find(char_array_4[j]);}

		char_array_3[0]=(char_array_4[0] << 2) + ((char_array_4[1] & 0x30) >> 4);
		char_array_3[1]=((char_array_4[1] & 0xf) << 4) + ((char_array_4[2] & 0x3c) >> 2);

		for(j=0;(j<i-1);j++){ret+=char_array_3[j];}}

	return ret;}

void decryptString(string encStr,const string salt,const string pass,string outFile)
	{// Base 64 Decode String\n";
	string decoded=base64_decode(encStr);
	// Generate Key and IV from Password and Salt\n";
	unsigned char key[32], iv[32];
	// Allocate Space for decrypted text\n";
	unsigned char decryptedtext[decoded.length()];
	int keyLength=EVP_BytesToKey(EVP_aes_256_cbc(),EVP_sha1(),(unsigned char*)salt.c_str(),(unsigned char*)pass.c_str(),pass.length(),1,key,iv);
	// Define Cipher Object
	EVP_CIPHER_CTX *ctx;
	int len,ret;
	// Create and initialize the context
	if(!(ctx=EVP_CIPHER_CTX_new())){handleErrors();}
	// Start Decryption
	if(1 != EVP_DecryptInit_ex(ctx,EVP_aes_256_cbc(),NULL,key,iv)){handleErrors();}
	// Decrypt message and obtain output
	if(1 != EVP_DecryptUpdate(ctx,decryptedtext,&len,(unsigned char*)decoded.c_str(),decoded.length())){handleErrors();}
	int decryptedtext_len=len;
	// Finalize Decryption
	if(1 != EVP_DecryptFinal_ex(ctx,decryptedtext+len,&len)){handleErrors();}
	decryptedtext_len+=len;
	// Clean Up
	EVP_CIPHER_CTX_free(ctx);
	// Add a NULL terminator. We are expecting printable text
	decryptedtext[decryptedtext_len]='\0';
	ofstream fOut;
	fOut.open(outFile.c_str(),ios::out|ios::binary);
	if(fOut.fail())
		{cerr<<"ERROR:\n input file could not be opened.\n"<<outFile<<endl;
		exit(1);}
	for(int i=0;i<decryptedtext_len;i++){fOut<<decryptedtext[i];}
	fOut.close();}

static inline bool is_base64(unsigned char c){return (isalnum(c) || (c == '+') || (c == '/'));}

void handleErrors(void){ERR_print_errors_fp(stderr);abort();}

double* fill_double_array(string Data,int numPnts,string delimiter){double* Output=new double[numPnts];string bld="",tmp="";int Counter=0;for(int i=0;i<Data.length();i++){tmp=Data[i];if(tmp.compare(delimiter)==0 && Counter<numPnts){Output[Counter]=strtod(bld.c_str(),NULL);Counter++;bld="";}else{bld+=Data[i];}}return Output;}

int* fill_int_array(string Data,int numPnts,string delimiter){int* Output=new int[numPnts];string bld="",tmp="";int Counter=0;for(int i=0;i<Data.length();i++){tmp=Data[i];if(tmp.compare(delimiter)==0 && Counter<numPnts){Output[Counter]=atoi(bld.c_str());Counter++;bld="";}else{bld+=Data[i];}}return Output;}

string* fill_string_array(string Data,int numPnts,string delimiter){string* Output=new string[numPnts];string bld="",tmp="";int Counter=0;for(int i=0;i<Data.length();i++){tmp=Data[i];if(tmp.compare(delimiter)==0 && Counter<numPnts){Output[Counter]=bld;Counter++;bld="";}else{bld+=Data[i];}}return Output;}

string formatNumberString(string Num)
	{string Output,tmp,tmp2;
	/* Check if contains decimal*/
	int i,pos=Num.find(".",0);
	if(pos==string::npos)
		{/* Number Value is an integer with no decimal*/
		for(i=0;i<Num.length();i++)
			{tmp=Num[i];
			/* Find 1st Non-Zero Number*/
			if(tmp.compare("0")!=0){break;}}
		Output=Num.substr(i,Num.length()-i);}
	else if(pos==0)
		{/* Precede decimal with zero*/
		Output="0";
		for(i=Num.length();i>0;i--)
			{tmp=Num[i-1];
			/* Search in reverse for 1st Non-Zero Number*/
			if(tmp.compare("0")!=0){break;}}
		Output+=Num.substr(0,i);}
	else{/* Number holds form XXX.XXX*/
		for(i=0;i<pos;i++)
			{tmp=Num[i];
			/* Find 1st Non-Zero Number*/
			if(tmp.compare("0")!=0){break;}}
		/* Define value preceding decimal*/
		if(i==pos){/* Only Zeros found up to the decimal*/Output="0";}
		else{Output=Num.substr(i,pos-i);}
		for(i=Num.length();i>pos;i--)
			{tmp=Num[i-1];
			/* Search in reverse for 1st Non-Zero Number*/
			if(tmp.compare("0")!=0){break;}}
		tmp2=Num.substr(pos,i-pos);
		/* will contain .XXX*/
		if(tmp2.length()>1){Output+=tmp2;}}
	return Output;}

long getFileSize(string inFile)
	{FILE *fI;
	int Err;
	char errMsg[256];
	fI=fopen(inFile.c_str(),"r");
	if(fI==NULL)
		{Err=errno;erase_display();
		cerr<<"ERROR in getFileSize!\nCould not open input file: "<<inFile<<endl;		
		cerr<<strerror_r(Err,errMsg,256)<<"\n";
		exit(EXIT_FAILURE);}
	fseek(fI,0,SEEK_END);
	long Output=ftell(fI);
	fclose(fI);
	return Output;}

string initialize_ZPRED_display(int totalCalc,bool& MULTI_DISPLAY)
	{int heightBuffer=5,widthBuffer=10,tWidth=0,tHeight=0;
	string Output="";
	if(totalCalc>MAX_DISPLAY_ROWS){tHeight=MAX_DISPLAY_ROWS;}
	else{tHeight=totalCalc;}
	// Determine Number of Columns to Display
	int numCols;
	if(totalCalc>=MAX_DISPLAY_ROWS*MAX_DISPLAY_COLS){numCols=MAX_DISPLAY_COLS;MULTI_DISPLAY=true;}	
	else{numCols=totalCalc/MAX_DISPLAY_ROWS+1;}
	int threadLabelWidth=log10(totalCalc)+1+3;	// [Num]+whitespace+........+| [Num]+whitespace+........+|
	int progressLabelWidth=8;
	int colWidth=threadLabelWidth+progressLabelWidth+2;
	tWidth=numCols*colWidth;
	resizeTerminal(tWidth+widthBuffer,tHeight+heightBuffer);
	int df=0,val=log10(totalCalc)+1,index=0;
	string tNum="";
	for(int i=0;i<tHeight;i++)
		{for(int j=0;j<numCols;j++)
			{index=i+j*tHeight+1;
			if(index<=totalCalc)
				{tNum=cnvrtNumToStrng(index,0);
				df=val-tNum.length();
				if(j==numCols-1){Output+=makeWhiteSpace(df)+"["+tNum+"] ........|";}
				else{Output+=makeWhiteSpace(df)+"["+tNum+"] ........| ";}}}
		Output+="\n";}
	return Output;}

string initialize_ZPRED_gui_display(int totalCalc,bool& MULTI_DISPLAY)
	{int heightBuffer=5,widthBuffer=10,tWidth=0,tHeight=0;
	string Output="";
	if(totalCalc>MAX_DISPLAY_ROWS){tHeight=MAX_DISPLAY_ROWS;}
	else{tHeight=totalCalc;}
	// Determine Number of Columns to Display
	int numCols;
	if(totalCalc>=MAX_DISPLAY_ROWS*MAX_DISPLAY_COLS){numCols=MAX_DISPLAY_COLS;}//MULTI_DISPLAY=true;}	
	else{numCols=totalCalc/MAX_DISPLAY_ROWS+1;}
	int threadLabelWidth=log10(totalCalc)+1+3;	// [Num]+whitespace+........+| [Num]+whitespace+........+|
	int progressLabelWidth=8;
	int colWidth=threadLabelWidth+progressLabelWidth+2;
	tWidth=numCols*colWidth;
	//resizeTerminal(tWidth+widthBuffer,tHeight+heightBuffer);
	int df=0,val=log10(totalCalc)+1,index=0;
	string tNum="";
	for(int i=0;i<tHeight;i++)
		{for(int j=0;j<numCols;j++)
			{index=i+j*tHeight+1;
			if(index<=totalCalc)
				{tNum=cnvrtNumToStrng(index,0);
				df=val-tNum.length();
				if(j==numCols-1){Output+=makeHTMLWhiteSpace(2*df)+"<b>["+tNum+"] .&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;|</b>";}
				else{Output+=makeHTMLWhiteSpace(2*df)+"<b>["+tNum+"] .&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;|</b> ";}}}
		Output+="<br>";}
	return Output;}

void make_folder(string Fldr){boost::filesystem::path dir(Fldr.c_str());boost::filesystem::create_directory(dir);}

string makeUpperCase(string X){string Output="";char letter,c;for(int i=0;i<X.length();i++){letter=X[i];Output+=toupper(letter);}return Output;}

string makeWhiteSpace(int Sz){string output="";for(int i=0;i<Sz;i++){output+=" ";}return output;}

string makeHTMLWhiteSpace(int Sz){string output="";for(int i=0;i<Sz;i++){output+="&nbsp;";}return output;}

void resizeTerminal(int width,int height){/* Terminal Dimension Values are in Characters*/string resizeTerminal="\e[8;"+cnvrtNumToStrng(height,0)+";"+cnvrtNumToStrng(width,0)+"t";printf("%s",resizeTerminal.c_str());}

zInput read_zpred_input_file(string inFile)
	{// , = internal delimiter| ; = external delimiter between solution conditinos
	zInput D;
	// Initialize Default Values
	//D.id="NoId";
	//D.name="molecule";
	D.numSolCond=0;
	D.numFiles=0;
	D.SC.apbsExecutable="";
	D.SC.multivalueExecutable="";
	D.SC.hydroproExecutable="";
	D.SC.msmsExecutable="";
	D.SC.msmsAtmTypeNumbers="";
	D.SC.msmsPdbToXyzr="";
	D.SC.msmsPdbToXyzrn="";
	D.SC.pdb2pqr="";			// main.py of PDB2PQR
	D.msms.PDB="";
	D.msms.pdbFile="";
	D.msms.pdb_msmsFldr="";
	D.msms.pdb_surfFldr="";
	D.msms.surfPointDensity="1.000000";
	D.msms.surfPointHiDensity="3.000000";
	D.hydroproCalcType="1";
	D.saveTemps=false; // ?3?
	D.pdie="4.0";
	D.dime_x="161"; D.dime_y="161"; D.dime_z="161";
	D.maxThreads=MAX_THREADS;
	D.RUN_APBS=true;
	D.RUN_PDB2PQR=true;
	D.RUN_HYDROPRO=false;
	D.RUN_HULLRAD=true;
	D.RUN_ZPRED=true;
	D.RUN_COLLIDE=true;
	D.outputTitle="Output/";
	D.numApbsWriteTypes=1;
	D.apbsWriteTypes=fill_string_array("pot;",1,";");
	D.forceField="PARSE";
	D.plot="";

	ifstream fIn;
	fIn.open(inFile.c_str());
	if(fIn.fail()){cerr<<"ERROR in read_zpred_input_file!\nInput file could not be opened.\n"<<inFile<<endl;exit(EXIT_FAILURE);}
	int Sz=10000,pos,oldPos,N;
	char Val[Sz];
	string bld,tmp,inputName,inputVal,delimiter="",*sArr;
	fIn.getline(Val,Sz);
	bool CHECKING;
	while(!fIn.eof())
		{tmp=Val;
		pos=tmp.find(".",0);
		if(pos!=string::npos && pos==0)
			{// Start of Line contains a period, now check if line defines an input parameter
			pos=tmp.find(":",pos);	// defines end of input parameter name
			if(pos!=string::npos)
				{// Extract Input Parameter Name
				inputName=tmp.substr(tmp.find(".",0)+1,pos-tmp.find(".",0)-1);
				inputName=makeUpperCase(inputName);
				// Extract Input Parameter Value(s)
				inputVal=tmp.substr(pos+1,tmp.length()-pos-1);
				// Check for & Remove Preceding WhiteSpace(s)
				CHECKING=true;
				pos=inputVal.find(" ",0);
				if(inputName.compare("FILES")==0||inputName.compare("APBSEXECUTABLE")==0||inputName.compare("MULTIVALUEEXECUTABLE")==0||inputName.compare("HYDROPROEXECUTABLE")==0||inputName.compare("MSMSEXECUTABLE")==0||inputName.compare("MSMSATMTYPENUMBERS")==0||inputName.compare("MSMSPDBTOXYZR")==0||inputName.compare("MSMSPDBTOXYZRN")==0||inputName.compare("PDB2PQR")==0)
					{// Remove preceeding white space if present
					if(pos==0){inputVal=inputVal.substr(1,inputVal.length()-1);}
					}
				else
					{
					while(CHECKING)
						{if(pos!=string::npos){inputVal=inputVal.substr(1,inputVal.length()-1);pos=inputVal.find(" ",0);}
						else{CHECKING=false;break;}}
					}
				if(inputVal.length()!=0)
					{// Identify Parameter and Load Values
					if(inputName.compare("ID")==0)
						{// Id for Computation (for organization purposes)
						D.numSolCond=count_delimiter(inputVal,";");
						D.id=fill_string_array(inputVal,D.numSolCond,";");}
					else if(inputName.compare("FILES")==0)
						{// Acquire PDB File Names
						D.numFiles=count_delimiter(inputVal,";");
						D.files=fill_string_array(inputVal,D.numFiles,";");}
					else if(inputName.compare("PH")==0)
						{// Array of pH Values
						D.pH=fill_string_array(inputVal,D.numSolCond,";");}
					else if(inputName.compare("SOLUTE")==0)
						{// Array of Solute Names ,;,;,;
						N=count_delimiter(inputVal,";");
						if(N!=D.numSolCond){cerr<<"ERROR in read_zpred_input_file!\nNumber of \'solute\' names ("<<N<<") does not match number of solution conditions.\nInput:"<<inputVal<<"\n";exit(EXIT_FAILURE);}
						sArr=fill_string_array(inputVal,N,";");
						D.solute=new string*[N];
						D.numSolute=new int[N];
						for(int i=0;i<N;i++)
							{tmp=sArr[i];
							D.numSolute[i]=count_delimiter(tmp,",");
							D.solute[i]=fill_string_array(tmp,D.numSolute[i],",");}
						delete [] sArr;}
					else if(inputName.compare("SOLUTECONC")==0)
						{// Array of Solute Concentrations soluteConc[numSolute][numSoluteConc]  (Ion#1Conc,Ion#1Conc,;Ion#2Conc,;)
						N=count_delimiter(inputVal,";");
						if(N!=D.numSolCond){cerr<<"ERROR in read_zpred_input_file!\nNumber of \'soluteConc\' ("<<N<<") does not match number of solution conditions.\nInput:"<<inputVal<<"\n";exit(EXIT_FAILURE);}
						sArr=fill_string_array(inputVal,N,";");
						D.soluteConc=new double*[N];
						for(int i=0;i<N;i++)
							{tmp=sArr[i];
							D.soluteConc[i]=fill_double_array(tmp,D.numSolute[i],",");}
						delete [] sArr;}
					else if(inputName.compare("SOLUTECONCTYPE")==0)
						{// Specifies type of concentration of soluteConc (always one value)
						N=count_delimiter(inputVal,";");
						if(N!=D.numSolCond){cerr<<"ERROR in read_zpred_input_file!\nNumber of \'soluteConcType\' ("<<N<<") does not match number of solution conditions.\nInput:"<<inputVal<<"\n";exit(EXIT_FAILURE);}
						/*sArr=fill_string_array(inputVal,N,";");
						D.soluteConcType=new string*[N];
						for(int i=0;i<N;i++)
							{tmp=sArr[i];
							D.soluteConcType[i]=fill_string_array(tmp,D.numSolute[i],",");}
						delete [] sArr;
						*/
						D.soluteConcType=fill_string_array(inputVal,N,";");
						}
					else if(inputName.compare("SOLVENT")==0)
						{// Array of Solvent Names ,;,;,;
						N=count_delimiter(inputVal,";");
						if(N!=D.numSolCond){cerr<<"ERROR in read_zpred_input_file!\nNumber of \'solvent\' names ("<<N<<") does not match number of solution conditions.\nInput:"<<inputVal<<"\n";exit(EXIT_FAILURE);}
						sArr=fill_string_array(inputVal,N,";");
						D.solvent=new string*[N];
						D.numSolvent=new int[N];
						for(int i=0;i<N;i++)
							{tmp=sArr[i];
							D.numSolvent[i]=count_delimiter(tmp,",");
							D.solvent[i]=fill_string_array(tmp,D.numSolvent[i],",");}
						delete [] sArr;}
					else if(inputName.compare("SOLVENTCONC")==0)
						{// Array of Solvent Concentrations
						N=count_delimiter(inputVal,";");
						if(N!=D.numSolCond){cerr<<"ERROR in read_zpred_input_file!\nNumber of \'solventConc\' ("<<N<<") does not match number of solution conditions.\nInput:"<<inputVal<<"\n";exit(EXIT_FAILURE);}
						sArr=fill_string_array(inputVal,N,";");
						D.solventConc=new double*[N];
						for(int i=0;i<N;i++)
							{tmp=sArr[i];
							D.solventConc[i]=fill_double_array(tmp,D.numSolvent[i],",");}
						delete [] sArr;}
					else if(inputName.compare("SOLVENTCONCTYPE")==0)
						{// Specifies type of concentration of solventConc
						N=count_delimiter(inputVal,";");
						if(N!=D.numSolCond){cerr<<"ERROR in read_zpred_input_file!\nNumber of \'solventConcType\' ("<<N<<") does not match number of solution conditions.\nInput:"<<inputVal<<"\n";exit(EXIT_FAILURE);}
						/*sArr=fill_string_array(inputVal,N,";");
						D.solventConcType=new string*[N];
						for(int i=0;i<N;i++)
							{tmp=sArr[i];
							D.solventConcType[i]=fill_string_array(tmp,D.numSolvent[i],",");}
						delete [] sArr;*/
						D.solventConcType=fill_string_array(inputVal,N,";");
						}
					else if(inputName.compare("TEMPERATURE")==0)
						{// Array of Temperatures (Kelvin)
						N=count_delimiter(inputVal,";");
						if(N!=D.numSolCond){cerr<<"ERROR in read_zpred_input_file!\nNumber of \'temperature\' ("<<N<<") does not match number of solution conditions.\nInput:"<<inputVal<<"\n";exit(EXIT_FAILURE);}
						D.temperature=fill_double_array(inputVal,N,";");}
					else if(inputName.compare("PROTEINCONC")==0)
						{// Protein Concentration (mg/mL)
						N=count_delimiter(inputVal,";");
						if(N!=D.numSolCond){cerr<<"ERROR in read_zpred_input_file!\nNumber of \'proteinConc\' ("<<N<<") does not match number of solution conditions.\nInput:"<<inputVal<<"\n";exit(EXIT_FAILURE);}
						D.proteinConc=fill_double_array(inputVal,N,";");}
					else if(inputName.compare("APBSWRITETYPES")==0)
						{// APBS Output Write Types
						N=count_delimiter(inputVal,";");
						D.numApbsWriteTypes=N;
						delete [] D.apbsWriteTypes;
						D.apbsWriteTypes=fill_string_array(inputVal,N,";");}
					else if(inputName.compare("APBSEXECUTABLE")==0)
						{// APBS Executable File Path
						D.SC.apbsExecutable=inputVal;}
					else if(inputName.compare("MULTIVALUEEXECUTABLE")==0)
						{// APBS Multivalue Executable File Path
						D.SC.multivalueExecutable=inputVal;}
					else if(inputName.compare("HYDROPROEXECUTABLE")==0)
						{// HYDROPRO Executable File Path
						D.SC.hydroproExecutable=inputVal;}
					else if(inputName.compare("MSMSEXECUTABLE")==0)
						{// MSMS Executable File Path
						D.SC.msmsExecutable=inputVal;}
					else if(inputName.compare("MSMSATMTYPENUMBERS")==0)
						{// MSMS Executable File Path
						D.SC.msmsAtmTypeNumbers=inputVal;}
					else if(inputName.compare("MSMSPDBTOXYZR")==0)
						{// MSMS Executable File Path
						D.SC.msmsPdbToXyzr=inputVal;}
					else if(inputName.compare("MSMSPDBTOXYZRN")==0)
						{// MSMS Executable File Path
						D.SC.msmsPdbToXyzrn=inputVal;}
					else if(inputName.compare("PDB2PQR")==0)
						{// File Path to PDB2PQR python script
						D.SC.pdb2pqr=inputVal;}
					else if(inputName.compare("MSMSSURFPOINTDENSITY")==0)
						{// MSMS Parameter: Low Surface Density
						D.msms.surfPointDensity=inputVal;}
					else if(inputName.compare("MSMSSURFPOINTHIDENSITY")==0)
						{// MSMS Parameter: High Surface Density
						D.msms.surfPointHiDensity=inputVal;}
					else if(inputName.compare("HYDROPROCALCTYPE")==0)
						{// HYDROPRO Parameter: Calculation Type selects model
						D.hydroproCalcType=inputVal;}
					else if(inputName.compare("FORCEFIELD")==0)
						{// PDB2PQR Force Field
						D.forceField=inputVal;}
					else if(inputName.compare("SAVETEMPS")==0)
						{// Flag for Saving Files Used in the Computation
						inputVal=makeUpperCase(inputVal);
						if(inputVal.compare("FALSE")==0){D.saveTemps=false;}
						else{D.saveTemps=true;}}
					else if(inputName.compare("PDIE")==0)
						{// APBS Parameter: Protein Relative Dielectric
						D.pdie=inputVal;}
					else if(inputName.compare("DIME_X")==0)
						{// APBS Parameter: Number of X-Axis Grid Points
						D.dime_x=inputVal;}
					else if(inputName.compare("DIME_Y")==0)
						{// APBS Parameter: Number of Y-Axis Grid Points
						D.dime_y=inputVal;}
					else if(inputName.compare("DIME_Z")==0)
						{// APBS Parameter: Number of Z-Axis Grid Points
						D.dime_z=inputVal;}
					else if(inputName.compare("RUN_APBS")==0)
						{// ZPRED Control Paramater
						inputVal=makeUpperCase(inputVal);
						if(inputVal.compare("FALSE")==0){D.RUN_APBS=false;}
						else{D.RUN_APBS=true;}}
					else if(inputName.compare("RUN_PDB2PQR")==0)
						{// ZPRED Control Paramater
						inputVal=makeUpperCase(inputVal);
						if(inputVal.compare("FALSE")==0){D.RUN_PDB2PQR=false;}
						else{D.RUN_PDB2PQR=true;}}
					else if(inputName.compare("RUN_HYDROPRO")==0)
						{// ZPRED Control Paramater
						inputVal=makeUpperCase(inputVal);
						if(inputVal.compare("FALSE")==0){D.RUN_HYDROPRO=false;}
						else{D.RUN_HYDROPRO=true;}}
					else if(inputName.compare("RUN_HULLRAD")==0)
						{// ZPRED Control Paramater
						inputVal=makeUpperCase(inputVal);
						if(inputVal.compare("FALSE")==0){D.RUN_HULLRAD=false;}
						else{D.RUN_HULLRAD=true;}}
					else if(inputName.compare("RUN_ZPRED")==0)
						{// ZPRED Control Paramater
						inputVal=makeUpperCase(inputVal);
						if(inputVal.compare("FALSE")==0){D.RUN_ZPRED=false;}
						else{D.RUN_ZPRED=true;}}
					else if(inputName.compare("RUN_COLLIDE")==0)
						{// ZPRED Control Paramater
						inputVal=makeUpperCase(inputVal);
						if(inputVal.compare("FALSE")==0){D.RUN_COLLIDE=false;}
						else{D.RUN_COLLIDE=true;}}
					else if(inputName.compare("OUTPUTTITLE")==0)
						{// ZPRED Output Folder Title
						D.outputTitle=inputVal;}
					else if(inputName.compare("MAXTHREADS")==0)
						{// ZPRED Control Paramater
						D.maxThreads=atoi(inputVal.c_str());}
					else if(inputName.compare("DENSITY")==0)
						{// User Specified Solution Property
						N=count_delimiter(inputVal,";");
						if(N!=D.numSolCond){cerr<<"ERROR in read_zpred_input_file!\nNumber of \'density\' ("<<N<<") does not match number of solution conditions.\n";exit(EXIT_FAILURE);}
						D.density=fill_double_array(inputVal,N,";");}
					else if(inputName.compare("DIELECTRIC")==0)
						{// User Specified Solution Property
						N=count_delimiter(inputVal,";");
						if(N!=D.numSolCond){cerr<<"ERROR in read_zpred_input_file!\nNumber of \'density\' ("<<N<<") does not match number of solution conditions.\n";exit(EXIT_FAILURE);}
						D.dielectric=fill_double_array(inputVal,N,";");}
					else if(inputName.compare("INFLATIONDISTANCE")==0)
						{// User Specified Solution Property
						N=count_delimiter(inputVal,";");
						if(N!=D.numSolCond){cerr<<"ERROR in read_zpred_input_file!\nNumber of \'density\' ("<<N<<") does not match number of solution conditions.\n";exit(EXIT_FAILURE);}
						D.inflationDistance=fill_double_array(inputVal,N,";");}
					else if(inputName.compare("VISCOSITY")==0)
						{// User Specified Solution Property
						N=count_delimiter(inputVal,";");
						if(N!=D.numSolCond){cerr<<"ERROR in read_zpred_input_file!\nNumber of \'density\' ("<<N<<") does not match number of solution conditions.\n";exit(EXIT_FAILURE);}
						D.viscosity=fill_double_array(inputVal,N,";");}
					else if(inputName.compare("GENERATEPROFILE")==0)
						{N=count_delimiter(inputVal,";");
						if(N!=D.numSolCond){cerr<<"ERROR in read_zpred_input_file!\nNumber of \'generateProfile\' ("<<N<<") does not match number of solution conditions.\n";exit(EXIT_FAILURE);}
						D.GENERATE_POT_PROFILE=new bool[N];
						sArr=fill_string_array(inputVal,N,";");
						for(int i=0;i<N;i++)
							{tmp=sArr[i];
							if(tmp.compare("true")==0){D.GENERATE_POT_PROFILE[i]=true;}
							else if(tmp.compare("false")==0){D.GENERATE_POT_PROFILE[i]=false;}
							else{cerr<<"ERROR in read_zpred_input_file!\nNumber of \'generateProfile\' has incorrect values.\n";exit(EXIT_FAILURE);}
							}
						delete [] sArr;}
					else if(inputName.compare("PLOT")==0)
						{// Plotting Feature
						D.plot=inputVal;}
					else{cerr<<"ERROR in read_zpred_input_file!\nUnrecognized Parameter ("<<inputName<<")."<<endl;exit(EXIT_FAILURE);}
					}
				}
			}
		fIn.getline(Val,Sz);}
	fIn.close();
	return D;}

string repeatString(string Input,int Num){string Output="";for(int i=0;i<Num;i++){Output+=Input;}return Output;}

void rewind_display(string display)
	{// Determine Number of Rows
	int nRows=0,pos=0;
	bool SEARCHING=true;
	while(SEARCHING)
		{pos=display.find("\n",pos);
		if(pos==string::npos){break;SEARCHING=false;}
		else{nRows++;pos++;}}
	// Rewind to Beginning of Line of 1st Thread
	string upLn="\033["+cnvrtNumToStrng(nRows,0)+"A"+"\r\033[s";
	cerr<<upLn;}

void* runZPRED(void* Ptr)
	{bool VERBOSE=false;
	string delimiter=";";
	// Convert Input Pointer to String
	string *strPtr=reinterpret_cast<string*>(Ptr);
	string cmdString=*strPtr;
	string Fldr="",encSalt="",encPass="",calcNum="",display="";
	zExeInput D=cnvrtStr2Input(cmdString,";",Fldr,calcNum,display);

	// Determine Number of Rows
	int nRows=0,pos=0;
	bool SEARCHING=true;
	while(SEARCHING)
		{pos=display.find("\n",pos);
		if(pos==string::npos){break;SEARCHING=false;}
		else{nRows++;pos++;}}
	// Find Display String Line with Current Computation
	string dispLabel="["+calcNum+"]";
	pos=display.find(dispLabel,0);
	// Determine Beginning of Line
	int tPos=pos-1;
	SEARCHING=true;
	string tmp="";
	while(SEARCHING)
		{if(tPos>=0){tmp=display.substr(tPos,1);}
		else if(tPos<0){tPos=0;break;}
		if(tmp.compare("\n")==0)
			{// Line Break Found
			tPos++;break;SEARCHING=false;}
		else{tPos--;}}
	// Acquire Entire Display Line
	string dispLn=display.substr(tPos,display.find("\n",tPos)-tPos);
	// Check if On Second Column or Later
	int currColOffset=0,cN=atoi(calcNum.c_str());
	// When on first column, cN%(MAX_DISPLAY_ROWS*MAX_DISPLAY_COLS)=1-25
	int test=cN%(MAX_DISPLAY_ROWS*MAX_DISPLAY_COLS);
	
	string bld;
	if(test==0 || test>nRows)
		{// Determine Current Column Offset from First Column
		currColOffset=((cN-1)%(MAX_DISPLAY_ROWS*MAX_DISPLAY_COLS))/nRows;
		// Update Display Line String
		pos=0;bld="";
		for(int i=0;i<currColOffset;i++)
			{bld+=dispLn.substr(pos,dispLn.find("]",pos)-pos);
			pos=dispLn.find("]",pos);
			if(pos==string::npos){cerr<<"ERROR in runZPRED ["<<calcNum<<"]!\nDisplay Line could not be updated.\n"<<dispLn<<endl;exit(EXIT_FAILURE);}
			bld+=dispLn.substr(pos,2)+"COMPLETE";
			pos=dispLn.find("|",pos);}
		bld+=dispLn.substr(pos,dispLn.length()-pos);
		dispLn=bld;}
	
	// Create list of files to delete after computation (when saveTemps=false)
	string files2Delete="";

	// Define Base Folders
	// ZPRED Input
	//string pdbFldr=Fldr+"Input/";
	// Define GUI Display File
	string guiDisplayFile=Fldr+".gui_display.txt";
	// Formatted Data Folders Folder (Also Holds ZPRED Configuration File)
	string fFldr=Fldr+"Files/";
	// Single ZPRED Computation Output Folder
	string zpredFldr=fFldr+"Z/";
	// Program Stdout/Stderr Log Folder
	string logFldr=fFldr+"LOG/";
	// APBS Output Folder (in DX Matrix Format)
	string dxFldr=fFldr+"DX/";
	// HYDROPRO Output Folder (HP stands for hydrodynamic properties)
	string hydroFldr=fFldr+"HP/";
	// APBS Input Command File Folder
	string inFldr=fFldr+"IN/";	
	// PROPKA Output Folder
	string propkaFldr=fFldr+"PROPKA/";	
	// PQR Formatted PDB Files Folder
	string pqrFldr=fFldr+"PQR/";
	// MSMS Surface Output Folder
	string surfFldr=fFldr+"S/";
	string surfFldrContents[6]={"CGO/","colorCGO/","CSV/","fromMSMS/","SAS/","fromMV/"};
	// Handle Special Operations Folders
	string msmsFldr=fFldr+"msms/"; make_folder(msmsFldr);
	// APBS Inputgen Python Script
	string apbsInputgen=fFldr+"apbsInputgen.py"; writeAPBSInputGen(apbsInputgen);
	// APBS psize.py supports apbsInputgen.py
	string psize=fFldr+"psize.py"; writePsize(psize);
	// HullRad (Grisham Edit)
	string theHullRad=fFldr+"editedHullRad.py"; writeHullRad(theHullRad);

	int PID,rChk=0,status=0;
	chmod_x(D.SC.apbsExecutable);
	// APBS Multivalue (Provide executable permission)
	chmod_x(D.SC.multivalueExecutable);
	// PDB2PQR
	string PDB2PQR=D.SC.pdb2pqr;
	// Acquire Specific File Name
	tmp=D.file;
	pos=tmp.rfind("/",tmp.length()-1);
	string PDB=tmp.substr(pos+1,tmp.find(".pdb",pos)-pos-1);
	// Need to add shape assessment
	string shape="sphere",value;
	// Define PDB File under Assessment
	string pdbFile=D.file;
	string pHVal=D.pH;
	double T=D.temperature;
	// Define String of Solvent Names
	string solvStr="";
	for(int i=0;i<D.numSolvent;i++){solvStr+=D.solvent[i]+delimiter;}
	// Define String of Solvent Concentrations
	string solvConcStr="";
	for(int i=0;i<D.numSolvent;i++){solvConcStr+=cnvrtNumToStrng(D.solventConc[i],BUFFER_SIZE)+delimiter;}
	// Define String of Solute Names
	string soluStr="";
	for(int i=0;i<D.numSolute;i++){soluStr+=D.solute[i]+delimiter;}
	// Define String of Solute Concentrations
	string soluConcStr="";
	for(int i=0;i<D.numSolute;i++){soluConcStr+=cnvrtNumToStrng(D.soluteConc[i],BUFFER_SIZE)+delimiter;}
	// Define Solution Name	
	string buffer=nameBuffer(soluStr,soluConcStr);
	// Define Folder Extension
	string fldrExt="_"+buffer+"/";
	// Create PDB Specific Fldrs (use PDB file name not PDB id)
	// APBS Output Folder (dxFldr) Contents
	string pdb_dxFldr=dxFldr+PDB+fldrExt; make_folder(pdb_dxFldr);
	string wtFldr="";
	for(int d=0;d<D.numApbsWriteTypes;d++){wtFldr=pdb_dxFldr+D.apbsWriteTypes[d]+"/";make_folder(wtFldr);}
	// APBS Input File Folder
	string pdb_inFldr=inFldr+PDB+fldrExt; make_folder(pdb_inFldr);
	// PQR Format Folder
	string pdb_pqrFldr=pqrFldr+PDB+"/"; make_folder(pdb_pqrFldr);
	// PROPKA Format Folder
	string pdb_propkaFldr=propkaFldr+PDB+"/"; make_folder(pdb_propkaFldr);
	// ZPRED Output Folder for Single Calculation
	string pdb_zpredFldr=zpredFldr+PDB+fldrExt; make_folder(pdb_zpredFldr);
	// PDB Specific Log Folder
	string pdb_logFldr=logFldr+PDB+"/"; make_folder(pdb_logFldr);
	string logFile=pdb_logFldr+calcNum+".log"; //files2Delete+=logFile+delimiter;
	// MSMS Computation Folder
	string pdb_msmsFldr=msmsFldr+PDB+"_"+calcNum+"_pH"+pHVal+"_T"+formatNumberString(cnvrtNumToStrng(T,BUFFER_SIZE))+fldrExt; make_folder(pdb_msmsFldr);
	string msmsBinFile=pdb_msmsFldr+getFileName(D.SC.msmsExecutable); copyFile(D.SC.msmsExecutable,msmsBinFile); chmod_x(msmsBinFile);
	files2Delete+=msmsBinFile+delimiter;
	string pdbToXyzrFile=pdb_msmsFldr+getFileName(D.SC.msmsPdbToXyzr); copyFile(D.SC.msmsPdbToXyzr,pdbToXyzrFile); chmod_x(pdbToXyzrFile);
	files2Delete+=pdbToXyzrFile+delimiter;
	string pdbToXyzrnFile=pdb_msmsFldr+getFileName(D.SC.msmsPdbToXyzrn); copyFile(D.SC.msmsPdbToXyzrn,pdbToXyzrnFile); chmod_x(pdbToXyzrnFile);
	files2Delete+=pdbToXyzrnFile+delimiter;
	string atmTypeNumbersFile=pdb_msmsFldr+getFileName(D.SC.msmsAtmTypeNumbers); copyFile(D.SC.msmsAtmTypeNumbers,atmTypeNumbersFile); chmod_x(atmTypeNumbersFile);
	files2Delete+=atmTypeNumbersFile+delimiter;
	// MSMS xyzrn file generated for input structure file
	string msmsXyzrnFile=pdb_msmsFldr+PDB+"_"+calcNum+".xyzrn"; files2Delete+=msmsXyzrnFile+delimiter;
	// HYDROPRO Output Folder (must be different for temperature,pH,and solute
	string pdb_hydroFldr=hydroFldr+PDB+"_"+calcNum+"_pH"+pHVal+"_T"+formatNumberString(cnvrtNumToStrng(T,BUFFER_SIZE))+fldrExt; make_folder(pdb_hydroFldr);
	// Copied PDB File
	string newPdbFile=pdb_hydroFldr+PDB+"_"+calcNum+".pdb"; files2Delete+=newPdbFile+delimiter;
	// Prepare to delete additional HYDROPRO files
	// HYDROPRO Atomic BEAD Model File
	string hydroBeaFile=pdb_hydroFldr+PDB+"_"+calcNum+"-pri.bea"; files2Delete+=hydroBeaFile+delimiter;
	// HYDROPRO VRML File
	string hydroVrmlFile=pdb_hydroFldr+PDB+"_"+calcNum+"-pri.vrml"; files2Delete+=hydroVrmlFile+delimiter;
	// HYDROPRO Sol File
	string hydroSolFile=pdb_hydroFldr+PDB+"_"+calcNum+"-sol.txt"; files2Delete+=hydroSolFile+delimiter;
	// HYDROPRO Fit File
	string hydroFitFile=pdb_hydroFldr+"hydropro-fit.txt"; files2Delete+=hydroFitFile+delimiter;
	// HYDROPRO Summary File
	string hydroSumFile=pdb_hydroFldr+"hydropro-sum.txt"; files2Delete+=hydroSumFile+delimiter;
	string transferString="";
	// Copy PDB File into HYDROPRO Computation Folder
	ifstream fIn;
	bool ATTEMPTING=true;
	int numTries=100000,Counter=0;
	while(ATTEMPTING)
		{fIn.open(pdbFile.c_str());
		if(!fIn.fail()){break;ATTEMPTING=false;}
		else{Counter++;}
		if(Counter>=numTries)
			{cerr<<"ERROR in runZPRED("<<calcNum<<")!!!\nOriginal PDB File could not be copied.\n"<<pdbFile<<endl;
			exit(EXIT_FAILURE);}}
	ofstream fOut;
	fOut.open(newPdbFile.c_str());
	if(fOut.fail()){cerr<<"ERROR in runZPRED!!!\nPDB File could not be copied.\n"<<newPdbFile<<endl;exit(EXIT_FAILURE);}
	 // Copy Input File
    int Sz=15000;                      // overshoot actual line size, C++ automatically fixes c-string lengths
    char Val[Sz];
    fIn.getline(Val,Sz);
    while(!fIn.eof()){tmp=Val;transferString+=tmp+"\n";fIn.getline(Val,Sz);}
	fIn.close();fOut<<transferString;fOut.close();
	// Generate Temporary Executable
	string tempXFile=pdb_hydroFldr+"hydropro10-lnx"+calcNum+".exe";
	tmp=D.SC.hydroproExecutable;
	if(tmp.length()!=0){copyFile(D.SC.hydroproExecutable,tempXFile);chmod_x(tempXFile);}
	// MSMS Surface (Output) Folder
	string pdb_surfFldr=surfFldr+PDB+fldrExt;make_folder(pdb_surfFldr);
	string sFldr="";
	for(int d=0;d<6;d++){sFldr=pdb_surfFldr+surfFldrContents[d];make_folder(sFldr);}	
	// Define Files (Need to Ensure File Path is less than MAX_FILE_PATH)
	// van der Waals Surface File (from MSMS)
	string vdwFile=pdb_surfFldr+"fromMSMS/SR0.00"+"_"+calcNum+".vert"; files2Delete+=vdwFile+delimiter;
	// MSMS van der Waals (VDW) Surface Output File
	string msmsOutputFile=pdb_surfFldr+"fromMSMS/msmsOutput_SR0.00"+"_"+calcNum+".txt"; files2Delete+=msmsOutputFile+delimiter;
	// MSMS VDW Area Output File
	string msmsAreaFile=pdb_surfFldr+"fromMSMS/SR0.00"+"_"+calcNum+".area"; files2Delete+=msmsAreaFile+delimiter;
	// MSMS VDW Face Output File
	string msmsFaceFile=pdb_surfFldr+"fromMSMS/SR0.00"+"_"+calcNum+".face"; files2Delete+=msmsFaceFile+delimiter;
	// HYDROPRO Input Command File (Must be named hydropro.dat)
	string hydroproInputFile=pdb_hydroFldr+"hydropro.dat"; files2Delete+=hydroproInputFile+delimiter;
	// HYDROPRO Output Computation File
	string hydroproOutputFile=pdb_hydroFldr+PDB+"_"+calcNum+"-res.txt"; files2Delete+=hydroproOutputFile+delimiter;
	// PQR File
	string pqrFile=pdb_pqrFldr+"pH"+pHVal+"_"+calcNum+".pqr"; files2Delete+=pqrFile+delimiter;
	// PROPKA Output Computation File
	string propkaOutFile=pdb_propkaFldr+"pH"+pHVal+"_"+calcNum+".propka"; files2Delete+=propkaOutFile+delimiter;
	// APBS Input Command File
	string apbsInputFile=pdb_inFldr+"pH"+pHVal+"_"+calcNum+"T"+formatNumberString(cnvrtNumToStrng(T,BUFFER_SIZE))+"SR";
	// ZPRED Output File for Current Calculation (Not Total Calculation Output File!)
	string zpredOutFile=pdb_zpredFldr+"pH"+pHVal+"T"+formatNumberString(cnvrtNumToStrng(T,BUFFER_SIZE));
	// COLLIDE Input File Containing List of ZPRED Output Files to Run
	string collideFile=fFldr+"zpredOutFilesList.txt";
	ofstream colIn;
	if(calcNum.compare("1")==0)
		{// At First Process Generate Empty File for Appending
		colIn.open(collideFile.c_str(),ifstream::trunc);
		if(colIn.fail()){cerr<<"ERROR in runZPRED!!!\nZPRED Output File List could not be opened.\n"<<collideFile<<endl;exit(EXIT_FAILURE);}
		colIn.close();}
	
	// Compute Solution Properties
	Solution S(solvStr,solvConcStr,D.solventConcType,soluStr,soluConcStr,T,delimiter);
	msmsInput msmsIn;
	vertData V;
	pdbData Data;
	strVec apbsGrdDim; apbsGrdDim.x=D.dime_x; apbsGrdDim.y=D.dime_y; apbsGrdDim.z=D.dime_z;
	ion_Data In;
	// Values of Mapping the Electrophoretic Space to define Electrokinetic Model
	double kaVals[132]={0.0100467,0.0102119,0.0105752,0.0110796,0.0116896,0.0123908,0.013134,0.0139218,0.0147913,0.0157151,0.0166577,0.0176569,0.0188034,0.0199777,0.0212255,0.0225511,0.0240154,0.0255153,0.0271721,0.0289364,0.0307437,0.0328163,0.0351104,0.0375649,0.040191,0.043101,0.0463294,0.0501491,0.0545372,0.0590336,0.0634555,0.0682086,0.0734888,0.0793625,0.0855062,0.0923404,0.10042,0.109207,0.118487,0.128854,0.140129,0.152391,0.166888,0.18319,0.201554,0.222795,0.247424,0.27606,0.310171,0.348496,0.393386,0.448216,0.515471,0.595586,0.691367,0.8063,0.946936,1.1147,1.31524,1.55186,1.83532,2.17056,2.56703,3.02886,3.56545,4.18735,4.91771,5.74861,6.68866,7.74625,8.90856,10.1977,11.6733,13.3003,15.0485,16.908,18.9529,21.1465,23.4842,26.0803,28.7617,31.5712,34.6553,37.952,41.2729,44.8843,48.8118,53.0829,57.3256,61.7633,66.5446,71.696,77.0664,82.4539,88.0128,93.9464,100.28,107.041,113.991,120.829,128.375,136.393,144.574,152.889,161.682,170.583,179.556,189,198.941,209.405,219.907,230.397,241.951,254.085,266.206,277.608,290.175,302.604,315.565,329.082,343.178,356.213,369.744,383.789,398.367,413.499,428.207,442.406,458.142,476.654,490.169,490.169};
	double EmVals[132]={5.1634,5.07903,4.99584,4.91384,4.83304,4.75223,4.67142,4.59061,4.51099,4.43137,4.35175,4.27094,4.19133,4.11171,4.03209,3.95247,3.87285,3.79441,3.7148,3.63518,3.55556,3.47594,3.39869,3.32026,3.24302,3.16578,3.08853,3.01248,2.9388,2.86275,2.7855,2.70945,2.63339,2.55734,2.4801,2.40404,2.32917,2.25431,2.17944,2.10458,2.0309,1.95722,1.88473,1.81462,1.7445,1.67558,1.60665,1.5413,1.4795,1.41889,1.36067,1.30838,1.26203,1.21925,1.18004,1.14795,1.12181,1.1016,1.08734,1.07665,1.07071,1.0719,1.07903,1.08972,1.10755,1.13012,1.15627,1.18717,1.22282,1.26322,1.30957,1.35829,1.40939,1.46405,1.52228,1.58408,1.64706,1.71242,1.78015,1.84789,1.91682,1.98812,2.05942,2.13191,2.20559,2.28045,2.35532,2.43018,2.50743,2.58348,2.66072,2.73797,2.81402,2.89245,2.97089,3.04932,3.12775,3.20737,3.28699,3.36661,3.44623,3.52585,3.60665,3.68746,3.76827,3.84908,3.92989,4.0107,4.09269,4.1735,4.25431,4.3363,4.4183,4.5003,4.58229,4.66548,4.74747,4.83066,4.91384,4.99703,5.08021,5.1634,5.24658,5.32977,5.41295,5.49614,5.57932,5.6637,5.74688,5.83125,5.91444,6};
	//double shapeFactor=D.shapeFactor[0];
	double molecularWeight=calcProteinMolecularWeight(pdbFile);
	// Solvent Viscosity (Solute(s)+Solvent(s)) (Pa s)
	double solventViscosity;
	if(D.viscosity==-1){solventViscosity=S.viscosity;}
	else{solventViscosity=D.viscosity;}
	// Solvent Density (kg/L)
	double solventDensity;
	if(D.density==-1){solventDensity=S.density;}
	else{solventDensity=D.density;}
	updateDisplayString("M",calcNum,1,nRows,dispLn);
	updateGuiDisplayString("M&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;",calcNum,1,nRows,dispLn,guiDisplayFile);
	// Initialize MSMS Input Parameters
	define_msmsInput(PDB,newPdbFile,msmsFldr,pdb_msmsFldr,pdb_surfFldr,D.msms.surfPointDensity,D.msms.surfPointHiDensity,"0.00",msmsBinFile,msmsIn);
	// Generate van der Waals Surface to Calculate Protein Radius
	runMSMS(msmsIn,calcNum);
	updateDisplayString(".",calcNum,1,nRows,dispLn);
	updateGuiDisplayString(".&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;",calcNum,1,nRows,dispLn,guiDisplayFile);
	// Calculate Protein Radius (A)
	// Read MSMS Vertices File
	readMSMSVertFile(vdwFile,V);
	// Read PDB File					
	int numLines=countNumLines(newPdbFile);
	definePDBData(Data,numLines);
	readPDBFile(newPdbFile,Data);
	// Calculate Center of Mass from PDB File
	Vec centerCoord=calc_center_of_mass(Data,numLines);
	// Calculate Average Protein Radius Using MSMS produced surface
	double proteinRadius=calc_protein_radius(V,V.numVertices,centerCoord);
	// Calculate Standard Deviation
	//radStd=calc_protein_radius_std(V,V.numVertices,centerCoord,Radius);
	// Calculate Specific Volume (L/g)
	double specificVolume=getSpecificVolume(msmsOutputFile,molecularWeight);
	// Calculate Solution Relative Dielectric (keep 2 significant digits for display purposes)
	double er;
	if(D.dielectric==-1){er=S.dielectric;}
	else{er=D.dielectric;}
	// Get Ion Data
	string largestIon=S.largestIon;	// should only keep 2 significant digits for display purposes
	string ionData=S.ionData;
	// Calculate Debye Length (A)
	double debyeLength=S.debyeLength;
	// Calculate Diffusivity
	long Result,fDesc,Result2;	
	double diffusivity,hydrodynamicRadius,slipPlanePosition;
	string hullradOutputFile=pdb_hydroFldr+"hullrad_output_"+calcNum+".txt";
	string hullRadCMD="python2.7 "+theHullRad+" "+newPdbFile+" "+cnvrtNumToStrng(T,2)+" "+formatNumberString(cnvrtNumToStrng(solventViscosity,BUFFER_SIZE))+" "+formatNumberString(cnvrtNumToStrng(solventDensity,BUFFER_SIZE))+" > "+hullradOutputFile;
	string theTxt;
	int sCode;
	if(D.inflationDistance==-1)
		{ATTEMPTING=true;
		if(D.RUN_HYDROPRO)
			{// Run HYDROPRO
			updateDisplayString("H",calcNum,2,nRows,dispLn);
			updateGuiDisplayString(".&nbsp;H&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;",calcNum,1,nRows,dispLn,guiDisplayFile);
			writeHydroproInput(D.hydroproCalcType,formatNumberString(cnvrtNumToStrng(solventDensity,BUFFER_SIZE)),formatNumberString(cnvrtNumToStrng(molecularWeight,BUFFER_SIZE)),D.outputTitle,hydroproInputFile,PDB+"_"+calcNum,specificVolume,T,solventViscosity);		
			PID=fork();
			if(PID==0)
				{// Run in Child Process, next time fork is executed it gives child process PID
				runHYDROPRO(PDB,pdb_hydroFldr,hydroproInputFile,logFile,calcNum);}
			else if(PID>0)
				{// Return to parent processs, fork should hold child process PID
				waitpid(PID,&status,0);}
			else if(PID==-1)
				{// fork() failed
				cerr<<"Fork failed."<<endl;exit(EXIT_FAILURE);}
			else{// Unpredicted Output
				cerr<<"Output of fork() unpredicted:\n"<<PID<<endl;}
			updateDisplayString(".",calcNum,2,nRows,dispLn);
			updateGuiDisplayString(".&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;",calcNum,1,nRows,dispLn,guiDisplayFile);
			// Remove Copied Temporary Executable File
			rChk=remove(tempXFile.c_str());
			if(rChk!=0){cerr<<"ERROR in runHYDROPRO\nCould not delete copied HYDROPRO Executable file."<<endl;exit(EXIT_FAILURE);}
			diffusivity=getDiffusivity(hydroproOutputFile);}
		else if(D.RUN_HULLRAD)
			{// Run HullRad
			updateDisplayString("H",calcNum,2,nRows,dispLn);
			//updateGuiDisplayString(".&nbsp;H&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;",calcNum,1,nRows,dispLn,guiDisplayFile);
			PID=fork();
			if(PID==0)
				{// Run in Child Process, next time fork is executed it gives child process PID
				sCode=system(hullRadCMD.c_str()); exit(EXIT_SUCCESS);
				//theTxt=encryptFile("/home/handsomedan/Desktop/ZPRED_III/editedHullRad.py","783e007c783e007c","Password");
				//fOut.open("/home/handsomedan/Desktop/ZPRED_III/theText.txt");
				//fOut<<theTxt;
				//fOut.close();
				}
			else if(PID>0)
				{// Return to parent processs, fork should hold child process PID
				waitpid(PID,&status,0);}
			else if(PID==-1)
				{// fork() failed
				cerr<<"Fork failed.\n";exit(EXIT_FAILURE);}
			else{// Unpredicted Output
				cerr<<"Output of fork() unpredicted:\n"<<PID<<endl;}
			updateDisplayString(".",calcNum,2,nRows,dispLn);
			//updateGuiDisplayString(".&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;",calcNum,1,nRows,dispLn,guiDisplayFile);
			diffusivity=getDiffusivity_hullrad(hullradOutputFile);
			}
		hydrodynamicRadius=calcHydrodynamicRadius(diffusivity,T,solventViscosity);
		slipPlanePosition=hydrodynamicRadius-proteinRadius;
		}

	// Determine Inflation Distance (keep 2 significant digits for display purposes)
	double inflationDistance;
	if(D.inflationDistance==-1)
		{if(slipPlanePosition<0){inflationDistance=0.00;}
		else{inflationDistance=slipPlanePosition;}
		if(isnan(inflationDistance)){cerr<<"ERROR defining inflationDistance!\nhydrodynamicRadius: "<<hydrodynamicRadius<<"\nproteinRadius: "<<proteinRadius<<endl;exit(EXIT_FAILURE);}}
	else{inflationDistance=D.inflationDistance;}	
	// Run PROPKA to hydrogenate & PDB2PQR to assign charge to PDB file	
	if(D.RUN_PDB2PQR)
		{updateDisplayString("P",calcNum,3,nRows,dispLn);
		updateGuiDisplayString(".&nbsp;.&nbsp;P&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;",calcNum,1,nRows,dispLn,guiDisplayFile);
		runPROPKA_PDB2PQR(pdbFile,pqrFile,calcNum,D.forceField,pdb_pqrFldr,propkaOutFile,pHVal,PDB2PQR,logFile);
		updateDisplayString(".",calcNum,3,nRows,dispLn);
		updateGuiDisplayString(".&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;",calcNum,1,nRows,dispLn,guiDisplayFile);}
	// Electrostatics with APBS
	apbsInputFile+=largestIon+"SD"+cnvrtNumToStrng(er,ER_SIG_FIGS)+".in";files2Delete+=apbsInputFile+delimiter;
	if(D.RUN_APBS)
		{updateDisplayString("A",calcNum,4,nRows,dispLn);
		updateGuiDisplayString(".&nbsp;.&nbsp;.&nbsp;A&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;",calcNum,1,nRows,dispLn,guiDisplayFile);
		//# Prepare IN Files for APBS with inputgen.py
		inFileEditer(D.apbsWriteTypes,D.numApbsWriteTypes,D.pdie,apbsGrdDim,pqrFile,apbsInputgen,ionData,formatNumberString(cnvrtNumToStrng(T,BUFFER_SIZE)),largestIon,cnvrtNumToStrng(er,ER_SIG_FIGS),fldrExt);
		// Run APBS to generate electrostatic fields
		PID=fork();
		if(PID==0){runAPBS(D.SC.apbsExecutable,apbsInputFile,logFile);}
		else if(PID>0){waitpid(PID,&status,0);}
		else if(PID==-1){cerr<<"Fork failed.\n";exit(EXIT_FAILURE);}
		else{cerr<<"Output of fork() unpredicted:\n"<<PID<<endl;}
		updateDisplayString(".",calcNum,4,nRows,dispLn);
		updateGuiDisplayString(".&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;",calcNum,1,nRows,dispLn,guiDisplayFile);}
	
	string sesFile="",sasFile="",csvFile="",potFile="",mvFile="",zpredSingleOutput="",shapeMsg="";
	ofstream zOut;
	ifstream zIn;
	int oldPos=0,ind=0;
	double Rh=0,ka=0,correction=0,pot=0,potSum=0,vol_frac=0,mobility=0,henryMobility=0,EmCompare=0,Em=0;
	float Q=0;
	bool RUNNING;
	//zpredOutFile+="SD"+cnvrtNumToStrng(er,ER_SIG_FIGS)+".txt";
	zpredOutFile+="PC"+cnvrtNumToStrng(D.proteinConc,ER_SIG_FIGS)+"_"+calcNum+".txt";
	// Add ZPRED Output File to List
	colIn.open(collideFile.c_str(),ifstream::app);
	if(colIn.fail()){cerr<<"ERROR in runZPRED!!!\nZPRED Output File List could not be updated.\n"<<collideFile<<endl;exit(EXIT_FAILURE);}
	colIn<<zpredOutFile+"\n";
	colIn.close();
	
	// Initialize MSMS Input Parameters
	updateDisplayString("M",calcNum,5,nRows,dispLn);
	define_msmsInput(PDB,newPdbFile,msmsFldr,pdb_msmsFldr,pdb_surfFldr,D.msms.surfPointDensity,D.msms.surfPointHiDensity,cnvrtNumToStrng(inflationDistance,DISTANCE_SIG_FIGS),msmsBinFile,msmsIn);
	// Generate Surface
	runMSMS(msmsIn,calcNum);
	// Define Error Values
	Error Er;
	// Determine if More Spherical or Cylindrical
	// Define Gyration Tensor gS
	double Rm,Rn,Value,Lx,Ly,Lz,Lsum,L,asphericity,sP,gyrationRadius,owMob,concCorrection;
	double** gS=new double*[3];
	for(int i=0;i<3;i++){gS[i]=new double[3];}
	// Solvated Radius
	Rh=proteinRadius+inflationDistance;
	// Define Electrokinetic Radius
	ka=Rh/debyeLength;
	shapeMsg="// Physical Shape Descriptor\n";
	//
	for(int i=0;i<3;i++)
		{for(int j=0;j<3;j++)
			{Value=0;
			for(int k=0;k<numLines;k++)
				{if(i==0)
					{// X Coordinate
					Rm=Data.x[k]-centerCoord.x;}
				else if(i==1)
					{// Y Coordinate
					Rm=Data.y[k]-centerCoord.y;}
				else if(i==2)
					{// Z Coordinate
					Rm=Data.z[k]-centerCoord.z;}
				if(j==0)
					{// X Coordinate
					Rn=Data.x[k]-centerCoord.x;}
				else if(j==1)
					{// Y Coordinate
					Rn=Data.y[k]-centerCoord.y;}
				else if(j==2)
					{// Z Coordinate
					Rn=Data.z[k]-centerCoord.z;}
				Value+=Rm*Rn;}
			Value/=numLines;
			gS[i][j]=Value;}}
	//for(int i=0;i<3;i++)
	//	{for(int j=0;j<3;j++)
	//		{cout<<S[i][j]<<" ";}
	//	cout<<"\n";}
	Lx=gS[0][0]; Ly=gS[1][1]; Lz=gS[2][2];
	Lsum=Lx+Ly+Lz;
	L=Lsum/3.0;
	// Define Asphericity
	asphericity=3*((Lx-L)*(Lx-L) + (Ly-L)*(Ly-L) + (Lz-L)*(Lz-L))/(2*Lsum*Lsum);	
	//cout<<"Asphericity:\t\t"<<asphericity<<endl;
	if(asphericity>=0.5){shape="cylinder";}
	// Define Shape Parameter
	sP=27*((Lx-L)*(Ly-L)*(Lz-L))/(Lsum*Lsum*Lsum);
	//cout<<"Shape Parameter:\t"<<sP<<endl;
	if(sP>=1){shape="cylinder";}
	// Define Gyration Radius
	gyrationRadius=sqrt(Lsum);
	//cout<<"Gyration Radius (Rg):\t"<<Rg<<" A"<<endl;
	if(msmsIn.SUCCESS)
		{// Update Display String
		updateDisplayString("T",calcNum,5,nRows,dispLn);
		// MSMS Inflated Surface Output File
		msmsOutputFile=pdb_surfFldr+"fromMSMS/msmsOutput_SR"+cnvrtNumToStrng(inflationDistance,DISTANCE_SIG_FIGS)+"_"+calcNum+".txt"; files2Delete+=msmsOutputFile+delimiter;
		// MSMS VDW Area Output File
		msmsAreaFile=pdb_surfFldr+"fromMSMS/SR"+cnvrtNumToStrng(inflationDistance,DISTANCE_SIG_FIGS)+"_"+calcNum+".area"; files2Delete+=msmsAreaFile+delimiter;
		// MSMS VDW Face Output File
		msmsFaceFile=pdb_surfFldr+"fromMSMS/SR"+cnvrtNumToStrng(inflationDistance,DISTANCE_SIG_FIGS)+"_"+calcNum+".face"; files2Delete+=msmsFaceFile+delimiter;
		// Define Solvent Excluded Surface Vertices File
		sesFile=pdb_surfFldr+"fromMSMS/SR"+cnvrtNumToStrng(inflationDistance,DISTANCE_SIG_FIGS)+"_"+calcNum+".vert"; files2Delete+=sesFile+delimiter;
		sasFile=pdb_surfFldr+"SAS/SR"+cnvrtNumToStrng(inflationDistance,DISTANCE_SIG_FIGS)+"_"+calcNum+".vert"; files2Delete+=sasFile+delimiter;
		// Convert MSMS vert file to CSV
		csvFile=pdb_surfFldr+"CSV/SR"+cnvrtNumToStrng(inflationDistance,DISTANCE_SIG_FIGS)+"_"+calcNum+".csv"; files2Delete+=csvFile+delimiter;
		// Inflate SES to SAS
		inflateVert(inflationDistance,sesFile,sasFile,VERBOSE);
	
		vert2csv(sasFile,csvFile,VERBOSE);
		// Use APBS Multivalue Tool	
		// Define DX File Containing Computed Electric Potentials
		potFile=pdb_dxFldr+"pot/pH"+pHVal+"T"+formatNumberString(cnvrtNumToStrng(T,BUFFER_SIZE))+"SR"+largestIon+".dx"; files2Delete+=potFile+delimiter;
		// Define Output Multivalue File
		mvFile=pdb_surfFldr+"fromMV/pH"+pHVal+"T"+formatNumberString(cnvrtNumToStrng(T,BUFFER_SIZE))+"SR"+cnvrtNumToStrng(inflationDistance,DISTANCE_SIG_FIGS)+"_"+calcNum+".csv"; files2Delete+=mvFile+delimiter;
		updateDisplayString(".MV",calcNum,5,nRows,dispLn);		
		PID=fork();
		if(PID==0){runMULTIVALUE(D.SC.multivalueExecutable,csvFile,potFile,mvFile,logFile);}
		else if(PID>0){waitpid(PID,&status,0);}
		else if(PID==-1){cerr<<"Fork failed."<<endl;exit(EXIT_FAILURE);}
		else{cerr<<"Output of fork() unpredicted:\n"<<PID<<endl;}
		updateDisplayString(".Z",calcNum,6,nRows,dispLn);
		if(shape=="sphere")
			{correction=calc_HF_for_Sphere(ka);
			//shapeMsg+=".shape:\t\t\t\tGlobular\n";
			shapeMsg+=".shape: sphere\n";}
		else if(shape=="cylinder")
			{correction=calc_HF_for_Cylinder(ka);
			//shapeMsg+=".shape:\t\t\t\tFibrillar\n";
			shapeMsg+=".shape: cylinder\n";}
		zpredSingleOutput="//////////////////////////////////////////////////////\n";
		zpredSingleOutput+=shapeMsg;
		zpredSingleOutput+="// Asphericity\n";
		zpredSingleOutput+=".asphericity: "+formatNumberString(cnvrtNumToStrng(asphericity,BUFFER_SIZE))+"\n";
		zpredSingleOutput+="// Shape Parameter\n";
		zpredSingleOutput+=".shapeParameter: "+formatNumberString(cnvrtNumToStrng(sP,BUFFER_SIZE))+"\n";
		zpredSingleOutput+="// Gyration Radius [A]\n";
		zpredSingleOutput+=".gyrationRadius: "+formatNumberString(cnvrtNumToStrng(gyrationRadius,BUFFER_SIZE))+"\n";
		zpredSingleOutput+="// Solution Condition Number\n";
		zpredSingleOutput+=".solCondNum: "+D.id+"\n";
		zpredSingleOutput+="// Name of Protein Conformation\n";
		zpredSingleOutput+=".proteinName: "+PDB+"\n";
		zpredSingleOutput+="// Anhydrous Protein Radius [A]\n";
		zpredSingleOutput+=".proteinRadius: "+formatNumberString(cnvrtNumToStrng(proteinRadius,BUFFER_SIZE))+"\n";
		zpredSingleOutput+="// Solvate (Hydrated) Protein Radius [A]\n";
		zpredSingleOutput+=".solvatedRadius: "+formatNumberString(cnvrtNumToStrng(Rh,BUFFER_SIZE))+"\n";
		//zpredSingleOutput+="// Shape Correction Factor\n";
		//zpredSingleOutput+=".shapeFactor: "+formatNumberString(cnvrtNumToStrng(shapeFactor,BUFFER_SIZE))+"\n";
		zpredSingleOutput+="// Protein Diffusivity [m^2/s]\n";
		zpredSingleOutput+=".diffusivity: "+formatNumberString(cnvrtNumToStrng(diffusivity,BUFFER_SIZE))+"\n";
		zpredSingleOutput+="// Solution Debye Length [A]\n";
		zpredSingleOutput+=".debyeLength: "+formatNumberString(cnvrtNumToStrng(debyeLength,BUFFER_SIZE))+"\n";
		zpredSingleOutput+="// Dimensionless Electrokinetic Radius\n";
		zpredSingleOutput+=".ka: "+formatNumberString(cnvrtNumToStrng(ka,BUFFER_SIZE))+"\n";
		zpredSingleOutput+="// Henry Correction Factor for Electrophoretic Retardation\n";
		zpredSingleOutput+=".henryCorrection: "+formatNumberString(cnvrtNumToStrng(correction,BUFFER_SIZE))+"\n";
		// Read Multivalue Vertices Output File
		zIn.open(mvFile.c_str());
		if(zIn.fail()){cerr<<"ERROR in runZPRED!!!\nMultivalue output file could not be opened.\n"<<mvFile<<endl;exit(EXIT_FAILURE);}
		// Skip Read Statement
		zIn.getline(Val,Sz);
		Counter=0;potSum=0;
		while(!zIn.eof())
			{value=Val;
			pos=value.rfind(",");
			tmp=value.substr(pos+1,value.length()-pos);
			pot=strtod(tmp.c_str(),NULL);
			if(!isnan(pot) && abs(pot)<1e9)
				{potSum+=pot;
				Counter++;}
			zIn.getline(Val,Sz);}
		zIn.close();
		// Acquire Protein Net Valence
		Q=readPQRFile(pqrFile);
		zpredSingleOutput+="// Protein Net Valence [e]\n";
		zpredSingleOutput+=".charge: "+formatNumberString(cnvrtNumToStrng(Q,BUFFER_SIZE))+"\n";
		zpredSingleOutput+="// Hydration Layer Thickness [A]\n";
		zpredSingleOutput+=".Xsp: "+formatNumberString(cnvrtNumToStrng(inflationDistance,DISTANCE_SIG_FIGS))+"\n";
		// Undo Thermal Voltage and Take Average
		pot=potSum*kb*T/(Counter*ec);
		//cerr<<calcNum<<"|"<<pot<<" V\n";
		zpredSingleOutput+="// Electric Potential ("+formatNumberString(cnvrtNumToStrng(inflationDistance,DISTANCE_SIG_FIGS))+" A from surface) [V]\n";
		zpredSingleOutput+=".zetaPotential: "+formatNumberString(cnvrtNumToStrng(pot,BUFFER_SIZE))+"\n";
		zpredSingleOutput+="// Absolute Temperature [K]\n";
		zpredSingleOutput+=".temperature: "+formatNumberString(cnvrtNumToStrng(T,BUFFER_SIZE))+"\n";
		zpredSingleOutput+="// Solution pH\n";
		zpredSingleOutput+=".pH: "+pHVal+"\n";
		zpredSingleOutput+="// Solution Viscosity [Ns/m^2]\n";
		zpredSingleOutput+=".viscosity: "+formatNumberString(cnvrtNumToStrng(solventViscosity,BUFFER_SIZE))+"\n";
		zpredSingleOutput+="// Solution Relative Dielectric\n";
		zpredSingleOutput+=".dielectric: "+formatNumberString(cnvrtNumToStrng(er,BUFFER_SIZE))+"\n";
		zpredSingleOutput+="// Solution Density [kg/L]\n";
		zpredSingleOutput+=".density: "+formatNumberString(cnvrtNumToStrng(solventDensity,BUFFER_SIZE))+"\n";
		zpredSingleOutput+="// Solvent Components (Solvent Names)\n";
		zpredSingleOutput+=".solvent: "+solvStr+"\n";
		zpredSingleOutput+="// Solvent Components (Solvent Concentrations) [Mole Fraction]\n";
		zpredSingleOutput+=".solventConc: "+solvConcStr+"\n";
		zpredSingleOutput+="// Solvent Components (Solute Names)\n";
		zpredSingleOutput+=".solute: "+soluStr+"\n";
		zpredSingleOutput+="// Solvent Components (Solute Concentrations) [Molar]\n";
		zpredSingleOutput+=".soluteConc: "+soluConcStr+"\n";
		// Handle Ion Input
		In.numIons=count_delimiter(ionData,",")/3;
		In.conc=new double[In.numIons];
		In.valence=new int[In.numIons];
		In.mobility=new double[In.numIons];
		In.radius=new double[In.numIons];

		oldPos=0;
		for(int i=0;i<In.numIons;i++)
			{// Acquire valence
			pos=ionData.find(",",oldPos);tmp=ionData.substr(oldPos,pos-oldPos);In.valence[i]=atoi(tmp.c_str());oldPos=pos+1;
			// Acquire Concentration (Molar)		
			pos=ionData.find(",",oldPos);tmp=ionData.substr(oldPos,pos-oldPos);In.conc[i]=strtod(tmp.c_str(),NULL);oldPos=pos+1;
			// Acquire Ion radius (Angstroms)		
			pos=ionData.find(",",oldPos);tmp=ionData.substr(oldPos,pos-oldPos);In.radius[i]=strtod(tmp.c_str(),NULL);oldPos=pos+1;}

		// Electrophoretic Mobility (umcm/(Vs)) from O'Brien & White Algorithm
		// Absolute error is a threshold error value representing the acceptable error as the value of the measured state approaches
		// Relative error represents a percentage of the state's value (default: 1e-3 means the computed value will be accurate to within 0.1%
		Er.absolute=1e-12;Er.relative=1e-7;Er.a_x=1;Er.a_dxdt=1;
		freopen(logFile.c_str(),"a",stdout);
		switch(S.numIon)
			{case 1:
				break;
			case 2:
				owMob=two_ion_problem(pot,Rh*1e-10,S,Er,true);
				break;		
			case 3:
				owMob=three_ion_problem(pot,Rh*1e-10,S,Er,true);
				break;
			case 4:
				owMob=four_ion_problem(pot,Rh*1e-10,S,Er,true);
				break;
			case 5:
				owMob=five_ion_problem(pot,Rh*1e-10,S,Er,true);
				break;
			case 6:
				owMob=six_ion_problem(pot,Rh*1e-10,S,Er,true);
				break;
			case 7:
				owMob=seven_ion_problem(pot,Rh*1e-10,S,Er,true);
				break;
			case 8:
				owMob=eight_ion_problem(pot,Rh*1e-10,S,Er,true);
				break;
			case 9:
				owMob=nine_ion_problem(pot,Rh*1e-10,S,Er,true);
				break;
			default:
				break;
			}
	
		zpredSingleOutput+="// Specific Volume [L/g]\n";
		zpredSingleOutput+=".specificVolume: "+formatNumberString(cnvrtNumToStrng(specificVolume,BUFFER_SIZE))+"\n";
		vol_frac=specificVolume*D.proteinConc;
		zpredSingleOutput+="// Volume Fraction\n";
		zpredSingleOutput+=".volumeFraction: "+formatNumberString(cnvrtNumToStrng(vol_frac,BUFFER_SIZE))+"\n";
		// Calculate Electrophoretic Mobility umcm/(Vs) [still need to apply correction factor to mobility conversion]
		mobility=eo*er*pot*correction/solventViscosity;
		//
		zpredSingleOutput+="// Electrophoretic Mobility [umcm/(Vs)] Defined from ZPRED computed zeta potential and Henry Correction Factor\n";
		zpredSingleOutput+=".henryMobility: "+formatNumberString(cnvrtNumToStrng(mobility*1e8,BUFFER_SIZE))+"\n";
		//
		// Calculate Protein Concentration Correction Factor (in case of high concentrations)
		concCorrection=calc_Kuwabara_Correction_for_Sphere(ka,vol_frac,pot,Rh*1e-10);
		zpredSingleOutput+="// Electrophoretic Mobility [umcm/(Vs)] Defined from ZPRED computed zeta potential and Kuwabara Correction Factor\n";
		zpredSingleOutput+=".kuwabaraMobility: "+formatNumberString(cnvrtNumToStrng(mobility*1e8*concCorrection/correction,BUFFER_SIZE))+"\n";
		//
		zpredSingleOutput+="// Kuwabara Correction Factor for Particle Concentration\n";
		zpredSingleOutput+=".kuwabaraCorrection: "+formatNumberString(cnvrtNumToStrng(concCorrection,BUFFER_SIZE))+"\n";
		// Calculate Electrophoretic Mobility from Henry Eqn for comparison
		//henryMobility=Q*ec*correction/(4*pi*solventViscosity*Rh*1e-10*(1+ka)*shapeFactor);
		henryMobility=Q*ec*correction/(4*pi*solventViscosity*Rh*1e-10*(1+ka));
		zpredSingleOutput+="// Electrophoretic Mobility from Henry Equation [umcm/(Vs)]\n";
		zpredSingleOutput+=".henryModelMobility: "+formatNumberString(cnvrtNumToStrng(henryMobility*1e8,BUFFER_SIZE))+"\n";
		// from OW Algorithm
		if(isnan(owMob))
			{// OW Algorithm Failed
			zpredSingleOutput+="// Electrophoretic Mobility [umcm/(Vs)] Defined from ZPRED computed zeta potential and Henry Correction Factor\n";
			zpredSingleOutput+=".semMobility: NaN\n";
			// Concentration Corrected OW Algorithm Output
			zpredSingleOutput+="// Electrophoretic Mobility [umcm/(Vs)] Defined from ZPRED computed zeta potential and Kuwabara Correction Factor\n";
			zpredSingleOutput+=".semMobility2: NaN\n";
			}
		else
			{// OW Algorithm Successfully Completed
			zpredSingleOutput+="// Electrophoretic Mobility from O'Brien & White Algorithm (solves standard electrokinetic model (SEM)) [umcm/(Vs)]\n";
			zpredSingleOutput+=".semMobility: "+formatNumberString(cnvrtNumToStrng(owMob*1e8,BUFFER_SIZE))+"\n";
			// Concentration Corrected OW Algorithm Output
			zpredSingleOutput+="// Electrophoretic Mobility from O'Brien & White Algorithm with Kuwabara Correction Factor [umcm/(Vs)]\n";
			zpredSingleOutput+=".semMobility2: "+formatNumberString(cnvrtNumToStrng(owMob*1e8*concCorrection/correction,BUFFER_SIZE))+"\n";}
		zpredSingleOutput+="//////////////////////////////////////////////////////\n";
		// Define Dimensionless Electrophoretic Mobility
		Em=3*solventViscosity*ec*abs(mobility);
		Em/=2*er*eo*kb*T;
		zpredSingleOutput+="ka:\t"+formatNumberString(cnvrtNumToStrng(ka,BUFFER_SIZE))+"\n";			
		zpredSingleOutput+="Em:\t"+formatNumberString(cnvrtNumToStrng(Em,BUFFER_SIZE))+"\n";
		// Determine Appropriate Electrokinetic Model
		RUNNING=true;ind=0;
		while(RUNNING)
			{if(ka<kaVals[ind]){RUNNING=false;}
			else{ind++;}
			if(ind>131){ind--;RUNNING=false;}}
	
		if(ind==0){EmCompare=interpolate(ka,kaVals[ind],kaVals[ind+1],EmVals[ind],EmVals[ind+1]);}
		else{EmCompare=interpolate(ka,kaVals[ind-1],kaVals[ind],EmVals[ind-1],EmVals[ind]);}
		zpredSingleOutput+="Compare Em to:\t"+formatNumberString(cnvrtNumToStrng(EmCompare,BUFFER_SIZE))+"\n";
		if(Em<EmCompare){zpredSingleOutput+="Henry Equation Appropriate!!!\n";}
		else{if(ka<10)
				{zpredSingleOutput+="Ohshima Approximation Appropriate!!!\n";
				correction=calc_OF_for_Sphere(In,er,T,pot,ka);
				zpredSingleOutput+="Ohshima Correction: "+formatNumberString(cnvrtNumToStrng(correction,BUFFER_SIZE))+"\n";
				mobility=eo*er*pot*correction/solventViscosity;
				zpredSingleOutput+="Electrophoretic Mobility: "+formatNumberString(cnvrtNumToStrng(mobility*1e8,BUFFER_SIZE))+" umcm/(Vs)\n";}
			else{zpredSingleOutput+="Ohshima-Healy-White Approximation Appropriate!!!\n";				
				correction=calc_OHWF_for_Sphere(In,er,T,pot,ka);
				zpredSingleOutput+="Ohshima-Healy-White Correction: "+formatNumberString(cnvrtNumToStrng(correction,BUFFER_SIZE))+"\n";
				mobility=eo*er*pot*correction/solventViscosity;	
				zpredSingleOutput+="Electrophoretic Mobility: "+formatNumberString(cnvrtNumToStrng(mobility*1e8,BUFFER_SIZE))+" umcm/(Vs)\n";
				}}
		// Generate Electric Potential Profile?
		int profileLen=35;
		double* position=new double[profileLen];
		position[0]=0.1;
		position[1]=0.2;
		position[2]=0.3;
		position[3]=0.4;
		position[4]=0.5;
		position[5]=0.6;
		position[6]=0.7;
		position[7]=0.8;
		position[8]=0.9;
		position[9]=1.0;
		position[10]=1.25;
		position[11]=1.5;
		position[12]=1.75;
		position[13]=2.0;
		position[14]=2.25;
		position[15]=2.5;
		position[16]=2.75;
		position[17]=3.0;
		position[18]=3.25;
		position[19]=3.5;
		position[20]=3.75;
		position[21]=4.0;
		position[22]=4.25;
		position[23]=4.5;
		position[24]=4.75;
		position[25]=5.0;
		position[26]=5.5;
		position[27]=6.0;
		position[28]=6.5;
		position[29]=7.0;
		position[30]=7.5;
		position[31]=8.0;
		position[32]=8.5;
		position[33]=9.0;
		position[34]=9.5;
		if(D.GENERATE_POT_PROFILE)
			{zpredSingleOutput+="// Electric Potential Profile from Protein Surface\n";
			zpredSingleOutput+="Distance [A] | Potential [V]\n";
			zpredSingleOutput+=".generateProfile: ";
			for(int i=0;i<profileLen;i++)
				{define_msmsInput(PDB,newPdbFile,msmsFldr,pdb_msmsFldr,pdb_surfFldr,D.msms.surfPointDensity,D.msms.surfPointHiDensity,cnvrtNumToStrng(position[i],DISTANCE_SIG_FIGS),msmsBinFile,msmsIn);
				// Generate Surface
				runMSMS(msmsIn,calcNum);
				if(msmsIn.SUCCESS)
					{// Surface Generated Successfully
					// MSMS Inflated Surface Output File
					msmsOutputFile=pdb_surfFldr+"fromMSMS/msmsOutput_SR"+cnvrtNumToStrng(position[i],DISTANCE_SIG_FIGS)+"_"+calcNum+".txt"; files2Delete+=msmsOutputFile+delimiter;
					// MSMS VDW Area Output File
					msmsAreaFile=pdb_surfFldr+"fromMSMS/SR"+cnvrtNumToStrng(position[i],DISTANCE_SIG_FIGS)+"_"+calcNum+".area"; files2Delete+=msmsAreaFile+delimiter;
					// MSMS VDW Face Output File
					msmsFaceFile=pdb_surfFldr+"fromMSMS/SR"+cnvrtNumToStrng(position[i],DISTANCE_SIG_FIGS)+"_"+calcNum+".face"; files2Delete+=msmsFaceFile+delimiter;
					// Define Solvent Excluded Surface Vertices File
					sesFile=pdb_surfFldr+"fromMSMS/SR"+cnvrtNumToStrng(position[i],DISTANCE_SIG_FIGS)+"_"+calcNum+".vert"; files2Delete+=sesFile+delimiter;
					sasFile=pdb_surfFldr+"SAS/SR"+cnvrtNumToStrng(position[i],DISTANCE_SIG_FIGS)+"_"+calcNum+".vert"; files2Delete+=sasFile+delimiter;
					// Inflate SES to SAS
					inflateVert(position[i],sesFile,sasFile,VERBOSE);
					// Convert MSMS vert file to CSV
					csvFile=pdb_surfFldr+"CSV/SR"+cnvrtNumToStrng(position[i],DISTANCE_SIG_FIGS)+"_"+calcNum+".csv"; files2Delete+=csvFile+delimiter;
					vert2csv(sasFile,csvFile,VERBOSE);
					// Use APBS Multivalue Tool	
					// Define DX File Containing Computed Electric Potentials
					//potFile=pdb_dxFldr+"pot/pH"+pHVal+"T"+formatNumberString(cnvrtNumToStrng(T,BUFFER_SIZE))+"SR"+largestIon+".dx";
					// Define Output Multivalue File
					mvFile=pdb_surfFldr+"fromMV/pH"+pHVal+"T"+formatNumberString(cnvrtNumToStrng(T,BUFFER_SIZE))+"SR"+cnvrtNumToStrng(position[i],DISTANCE_SIG_FIGS)+"_"+calcNum+".csv"; files2Delete+=mvFile+delimiter;
					//updateDisplayString("MV",calcNum,6,nRows,dispLn);
					PID=fork();
					if(PID==0){runMULTIVALUE(D.SC.multivalueExecutable,csvFile,potFile,mvFile,logFile);}
					else if(PID>0){waitpid(PID,&status,0);}
					else if(PID==-1){cerr<<"Fork failed."<<endl;exit(EXIT_FAILURE);}
					else{cerr<<"Output of fork() unpredicted:\n"<<PID<<endl;}
					// Read Multivalue Vertices Output File
					zIn.open(mvFile.c_str());
					if(zIn.fail()){cerr<<"ERROR in runZPRED!!!\nMultivalue output file could not be opened.\n"<<mvFile<<endl;exit(EXIT_FAILURE);}
					// Skip Read Statement
					zIn.getline(Val,Sz);
					Counter=0;potSum=0;
					while(!zIn.eof())
						{value=Val;
						pos=value.rfind(",");
						tmp=value.substr(pos+1,value.length()-pos);
						pot=strtod(tmp.c_str(),NULL);
						if(!isnan(pot) && abs(pot)<1e9)
							{potSum+=pot;
							Counter++;}
						zIn.getline(Val,Sz);}
					zIn.close();
					// Undo Thermal Voltage and Take Average
					pot=potSum*kb*T/(Counter*ec);
					// Electric Potential Profile
					zpredSingleOutput+=cnvrtNumToStrng(position[i],DISTANCE_SIG_FIGS)+","+formatNumberString(cnvrtNumToStrng(pot,BUFFER_SIZE))+",;";
					}
				else
					{// Surface Generation Failed, provide NaN values
					// Electric Potential Profile
					zpredSingleOutput+=cnvrtNumToStrng(position[i],DISTANCE_SIG_FIGS)+",NaN,;";
					}
				}
			zpredSingleOutput+="\n";
			}
		else
			{zpredSingleOutput+="// Electric Potential Profile from Protein Surface\n";
			zpredSingleOutput+=".generateProfile: false\n";}
		// Output Zeta Potential Computation results
		zOut.open(zpredOutFile.c_str());
		if(zOut.fail()){cerr<<"ERROR in runZPRED!!!\nZPRED output file could not be opened.\n"<<zpredOutFile<<endl;exit(EXIT_FAILURE);}
		zOut<<zpredSingleOutput;
		zOut.close();
		clear_ion_Data(In);
		updateDisplayString(".",calcNum,7,nRows,dispLn);
		//updateGuiDisplayString(".&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;",calcNum,1,nRows,dispLn,guiDisplayFile);
		updateDisplayString("COMPLETE",calcNum,1,nRows,dispLn);
		//updateGuiDisplayString("COMPLETE",calcNum,1,nRows,dispLn,guiDisplayFile);

		// Delete Computation Files (when saveTemps=false)
		string *deletedFiles;
		int N,Err;
		char errMsg[256];
		if(!D.saveTemps)
			{N=count_delimiter(files2Delete,delimiter);
			deletedFiles=fill_string_array(files2Delete,N,delimiter);
			for(int i=0;i<N;i++)
				{tmp=deletedFiles[i];
				rChk=remove(tmp.c_str());
				if(rChk!=0)
					{//Err=errno;erase_display();
					//cerr<<"ERROR in runZPRED\nCould not delete temp file.\n"<<tmp;
					//cerr<<strerror_r(Err,errMsg,256)<<"\n";
					/*exit(EXIT_FAILURE);*/}}
			}
		}
	else
		{// Update Display String
		updateDisplayString("F",calcNum,5,nRows,dispLn);
		if(shape=="sphere")
			{correction=calc_HF_for_Sphere(ka);
			//shapeMsg+=".shape:\t\t\t\tGlobular\n";
			shapeMsg+=".shape: sphere\n";}
		else if(shape=="cylinder")
			{correction=calc_HF_for_Cylinder(ka);
			//shapeMsg+=".shape:\t\t\t\tFibrillar\n";
			shapeMsg+=".shape: cylinder\n";}
		zpredSingleOutput="//////////////////////////////////////////////////////\n";
		zpredSingleOutput+=shapeMsg;
		zpredSingleOutput+="// Asphericity\n";
		zpredSingleOutput+=".asphericity: "+formatNumberString(cnvrtNumToStrng(asphericity,BUFFER_SIZE))+"\n";
		zpredSingleOutput+="// Shape Parameter\n";
		zpredSingleOutput+=".shapeParameter: "+formatNumberString(cnvrtNumToStrng(sP,BUFFER_SIZE))+"\n";
		zpredSingleOutput+="// Gyration Radius [A]\n";
		zpredSingleOutput+=".gyrationRadius: "+formatNumberString(cnvrtNumToStrng(gyrationRadius,BUFFER_SIZE))+"\n";
		zpredSingleOutput+="// Solution Condition Number\n";
		zpredSingleOutput+=".solCondNum: "+D.id+"\n";
		zpredSingleOutput+="// Name of Protein Conformation\n";
		zpredSingleOutput+=".proteinName: "+PDB+"\n";
		zpredSingleOutput+="// Anhydrous Protein Radius [A]\n";
		zpredSingleOutput+=".proteinRadius: "+formatNumberString(cnvrtNumToStrng(proteinRadius,BUFFER_SIZE))+"\n";
		zpredSingleOutput+="// Solvate (Hydrated) Protein Radius [A]\n";
		zpredSingleOutput+=".solvatedRadius: "+formatNumberString(cnvrtNumToStrng(Rh,BUFFER_SIZE))+"\n";
		//zpredSingleOutput+="// Shape Correction Factor\n";
		//zpredSingleOutput+=".shapeFactor: "+formatNumberString(cnvrtNumToStrng(shapeFactor,BUFFER_SIZE))+"\n";
		zpredSingleOutput+="// Protein Diffusivity [m^2/s]\n";
		zpredSingleOutput+=".diffusivity: "+formatNumberString(cnvrtNumToStrng(diffusivity,BUFFER_SIZE))+"\n";
		zpredSingleOutput+="// Solution Debye Length [A]\n";
		zpredSingleOutput+=".debyeLength: "+formatNumberString(cnvrtNumToStrng(debyeLength,BUFFER_SIZE))+"\n";
		zpredSingleOutput+="// Dimensionless Electrokinetic Radius\n";
		zpredSingleOutput+=".ka: "+formatNumberString(cnvrtNumToStrng(ka,BUFFER_SIZE))+"\n";
		zpredSingleOutput+="// Henry Correction Factor for Electrophoretic Retardation\n";
		zpredSingleOutput+=".henryCorrection: "+formatNumberString(cnvrtNumToStrng(correction,BUFFER_SIZE))+"\n";
		// Acquire Protein Net Valence
		Q=readPQRFile(pqrFile);
		zpredSingleOutput+="// Protein Net Valence [e]\n";
		zpredSingleOutput+=".charge: "+formatNumberString(cnvrtNumToStrng(Q,BUFFER_SIZE))+"\n";
		zpredSingleOutput+="// Hydration Layer Thickness [A]\n";
		zpredSingleOutput+=".Xsp: "+formatNumberString(cnvrtNumToStrng(inflationDistance,DISTANCE_SIG_FIGS))+"\n";
		zpredSingleOutput+="// Electric Potential ("+formatNumberString(cnvrtNumToStrng(inflationDistance,DISTANCE_SIG_FIGS))+" A from surface) [V]\n";
		zpredSingleOutput+=".zetaPotential: NaN\n";
		zpredSingleOutput+="// Absolute Temperature [K]\n";
		zpredSingleOutput+=".temperature: "+formatNumberString(cnvrtNumToStrng(T,BUFFER_SIZE))+"\n";
		zpredSingleOutput+="// Solution pH\n";
		zpredSingleOutput+=".pH: "+pHVal+"\n";
		zpredSingleOutput+="// Solution Viscosity [Ns/m^2]\n";
		zpredSingleOutput+=".viscosity: "+formatNumberString(cnvrtNumToStrng(solventViscosity,BUFFER_SIZE))+"\n";
		zpredSingleOutput+="// Solution Relative Dielectric\n";
		zpredSingleOutput+=".dielectric: "+formatNumberString(cnvrtNumToStrng(er,BUFFER_SIZE))+"\n";
		zpredSingleOutput+="// Solution Density [kg/L]\n";
		zpredSingleOutput+=".density: "+formatNumberString(cnvrtNumToStrng(solventDensity,BUFFER_SIZE))+"\n";
		zpredSingleOutput+="// Solvent Components (Solvent Names)\n";
		zpredSingleOutput+=".solvent: "+solvStr+"\n";
		zpredSingleOutput+="// Solvent Components (Solvent Concentrations) [Mole Fraction]\n";
		zpredSingleOutput+=".solventConc: "+solvConcStr+"\n";
		zpredSingleOutput+="// Solvent Components (Solute Names)\n";
		zpredSingleOutput+=".solute: "+soluStr+"\n";
		zpredSingleOutput+="// Solvent Components (Solute Concentrations) [Molar]\n";
		zpredSingleOutput+=".soluteConc: "+soluConcStr+"\n";
		// Handle Ion Input
		In.numIons=count_delimiter(ionData,",")/3;
		In.conc=new double[In.numIons];
		In.valence=new int[In.numIons];
		In.mobility=new double[In.numIons];
		In.radius=new double[In.numIons];

		oldPos=0;
		for(int i=0;i<In.numIons;i++)
			{// Acquire valence
			pos=ionData.find(",",oldPos);tmp=ionData.substr(oldPos,pos-oldPos);In.valence[i]=atoi(tmp.c_str());oldPos=pos+1;
			// Acquire Concentration (Molar)		
			pos=ionData.find(",",oldPos);tmp=ionData.substr(oldPos,pos-oldPos);In.conc[i]=strtod(tmp.c_str(),NULL);oldPos=pos+1;
			// Acquire Ion radius (Angstroms)		
			pos=ionData.find(",",oldPos);tmp=ionData.substr(oldPos,pos-oldPos);In.radius[i]=strtod(tmp.c_str(),NULL);oldPos=pos+1;}
		zpredSingleOutput+="// Specific Volume [L/g]\n";
		zpredSingleOutput+=".specificVolume: "+formatNumberString(cnvrtNumToStrng(specificVolume,BUFFER_SIZE))+"\n";
		vol_frac=specificVolume*D.proteinConc;
		zpredSingleOutput+="// Volume Fraction\n";
		zpredSingleOutput+=".volumeFraction: "+formatNumberString(cnvrtNumToStrng(vol_frac,BUFFER_SIZE))+"\n";
		// Calculate Electrophoretic Mobility umcm/(Vs) [still need to apply correction factor to mobility conversion]
		//mobility=eo*er*pot*correction/solventViscosity;
		zpredSingleOutput+="// Electrophoretic Mobility [umcm/(Vs)] Defined from ZPRED computed zeta potential and Henry Correction Factor\n";
		zpredSingleOutput+=".henryMobility: NaN\n";
		// Calculate Protein Concentration Correction Factor (in case of high concentrations)
		//concCorrection=calc_Kuwabara_Correction_for_Sphere(ka,vol_frac,pot,Rh*1e-10);
		zpredSingleOutput+="// Electrophoretic Mobility [umcm/(Vs)] Defined from ZPRED computed zeta potential and Kuwabara Correction Factor\n";
		zpredSingleOutput+=".kuwabaraMobility: NaN\n";
		//
		zpredSingleOutput+="// Kuwabara Correction Factor for Particle Concentration\n";
		zpredSingleOutput+=".kuwabaraCorrection: NaN\n";
		// Calculate Electrophoretic Mobility from Henry Eqn for comparison
		//henryMobility=Q*ec*correction/(4*pi*solventViscosity*Rh*1e-10*(1+ka)*shapeFactor);
		henryMobility=Q*ec*correction/(4*pi*solventViscosity*Rh*1e-10*(1+ka));
		zpredSingleOutput+="// Electrophoretic Mobility from Henry Equation [umcm/(Vs)]\n";
		zpredSingleOutput+=".henryModelMobility: "+formatNumberString(cnvrtNumToStrng(henryMobility*1e8,BUFFER_SIZE))+"\n";
		zpredSingleOutput+="// Electrophoretic Mobility [umcm/(Vs)] Defined from ZPRED computed zeta potential and Henry Correction Factor\n";
		zpredSingleOutput+=".semMobility: NaN\n";
		// Concentration Corrected OW Algorithm Output
		zpredSingleOutput+="// Electrophoretic Mobility [umcm/(Vs)] Defined from ZPRED computed zeta potential and Kuwabara Correction Factor\n";
		zpredSingleOutput+=".semMobility2: NaN\n";
		zpredSingleOutput+="//////////////////////////////////////////////////////\n";
		// Generate Electric Potential Profile?
		zpredSingleOutput+="// Electric Potential Profile from Protein Surface\n";
		zpredSingleOutput+=".generateProfile: false\n";
		// Output Zeta Potential Computation results
		zOut.open(zpredOutFile.c_str());
		if(zOut.fail()){cerr<<"ERROR in runZPRED!!!\nZPRED output file could not be opened.\n"<<zpredOutFile<<endl;exit(EXIT_FAILURE);}
		zOut<<zpredSingleOutput;
		zOut.close();
		clear_ion_Data(In);
		updateDisplayString(".",calcNum,7,nRows,dispLn);
		updateDisplayString("COMPLETE",calcNum,1,nRows,dispLn);
		// Delete Computation Files (when saveTemps=false)
		string *deletedFiles;
		int N,Err;
		char errMsg[256];
		if(!D.saveTemps)
			{N=count_delimiter(files2Delete,delimiter);
			deletedFiles=fill_string_array(files2Delete,N,delimiter);
			for(int i=0;i<N;i++)
				{tmp=deletedFiles[i];
				rChk=remove(tmp.c_str());
				}
			}
		}
	return 0;}

// Ref: 1974. The Prediction of Electrokinetic Phenomena within Multiparticle Systems I. Electrophoresis and Electroosmosis
double calc_Kuwabara_Correction_for_Sphere(double ka,double volFrac,double Zeta,double a)
	{double Output;
	// Solvated Radius: a [m]
	// Zeta: [V]
	double exponent=1.0/3.0;
	//cerr<<"exp: "<<exponent<<"\n";
	double y=pow(volFrac,exponent);
	double y3=volFrac;		//y*y*y;
	//cerr<<"y: "<<y<<"\n";
	double b=a/y;
	// Extract Debye Length [m]
	double k=a/ka;
	double k_b=b/k;
	double ka2=ka*ka;
	double ka3=ka2*ka;
	double ka4=ka3*ka;
	double ka5=ka4*ka;
	double ka6=ka5*ka;

	double R=1/(sinh(k_b-ka)-k_b*cosh(k_b-ka));
	//cerr<<"R: "<<R<<"\n";
	double Q=(1-k_b*tanh(k_b-ka))/(tanh(k_b-ka)-k_b);
	//cerr<<"Q: "<<Q<<"\n";
	double A=R*(sinh(k_b)-k_b*cosh(k_b));
	//cerr<<"A: "<<A<<"\n";
	double B=R*(cosh(k_b)-k_b*sinh(k_b));
	//cerr<<"B: "<<B<<"\n";
	// Integration Setup for computing I variable
	int numPnts=500;
	double dt=(k_b-ka)/(double(numPnts)-1);
	//cerr<<"dt: "<<dt<<"\n";
	string tList="",iList="";
	double t=ka,iVal;
	for(int i=0;i<numPnts;i++)
		{iVal=(A*cosh(t)-B*sinh(t))/t;
		//cerr<<t<<" "<<iVal<<endl;
		tList+=formatNumberString(cnvrtNumToStrng(t,BUFFER_SIZE))+";";
		iList+=formatNumberString(cnvrtNumToStrng(iVal,BUFFER_SIZE))+";";
		t=t+dt;}
	double *t1=fill_double_array(tList,numPnts,";");
	double *i1=fill_double_array(iList,numPnts,";");
	double iArea=calcAreaUnderCurve(t1,i1,numPnts);
	//cerr<<"I: "<<iArea<<"\n";
	double trm1=1 + R*ka + ka2/16 - ka3*(5*Q/48 - R*y/4 + R*y3/12) - ka4/96;
	double trm2=ka5*(Q/96 - R*y/48) + iArea*(ka4/8 - ka6/96);
	double trm3=-Zeta*(trm1+trm2);
	//cerr<<"1st term: "<<trm3<<"\n";
	trm1=1 + 3/ka2 + 3*Q/ka + ka*(R/y3 - R/10 + Q/10) - ka2/40;
	trm2=ka3*(Q/120 - R*y3/30) - ka4/240 + ka5*(Q/240 - R*y/120) - iArea*ka6/240;
	double trm4=-Zeta*(trm1+trm2);
	//cerr<<"2nd term: "<<trm4<<"\n";
	double trm5=3*(1-y3)*Zeta/2;

	Output=(-trm3+y3*trm4)/trm5;

	return Output;}

double calcAreaUnderCurve(double* x,double* y,int N)
	{double Output=0,area=0,xIntercept=0;
	Vec2d p1,p2,p3,p4;
	for(int i=0;i<N-1;i++)
		{// Determine whether to add or subtract
		if(!isnan(y[i])&&!isnan(y[i+1]))
			{if(y[i]>=0 && y[i+1]>=0)
				{// Both Data Points Above X-Axis, so ADD area to total sum
				// Start at X-Axis
				p1.x=x[i];p1.y=0;
				// Define First Point
				p2.x=x[i];p2.y=y[i];
				// Define Next Point
				p3.x=x[i+1];p3.y=y[i+1];
				// Reconnect at X-Axis
				p4.x=x[i+1];p4.y=0;
				area=shoelace(p1,p2,p3,p4);
				if(!isnan(area)){Output+=area;}}
			else if(y[i]<0 && y[i+1]>=0)
				{// First Point is Negative, while Second is Positive
				// Define negative area
				p1.x=x[i];p1.y=0;
				p2.x=x[i];p2.y=-y[i];
				// Find X-Intercept
				xIntercept=interpolate(0,y[i],y[i+1],x[i],x[i+1]);
				p3.x=xIntercept;p3.y=0;
				area=-shoelace(p1,p2,p3);
				// Define positive area
				p1.x=xIntercept;p1.y=0;
				p2.x=x[i+1];p2.y=y[i+1];
				p3.x=x[i+1];p3.y=0;
				area+=shoelace(p1,p2,p3);
				if(!isnan(area)){Output+=area;}}
			else if(y[i]>=0 && y[i+1]<0)
				{// First Point is Positive, while Second is Negative
				// Define positive area
				p1.x=x[i];p1.y=0;
				p2.x=x[i];p2.y=y[i];
				// Find X-Intercept
				xIntercept=interpolate(0,y[i],y[i+1],x[i],x[i+1]);
				p3.x=xIntercept;p3.y=0;
				area=shoelace(p1,p2,p3);
				// Define negative area
				p1.x=xIntercept;p1.y=0;
				p2.x=x[i+1];p2.y=-y[i+1];
				p3.x=x[i+1];p3.y=0;
				area-=shoelace(p1,p2,p3);
				if(!isnan(area)){Output+=area;}}
			else if(y[i]<0 && y[i+1]<0)
				{// Both Data Points Below X-Axis, so SUBTRACT area to total sum
				// Start at X-Axis
				p1.x=x[i];p1.y=0;
				// Define First Point
				p2.x=x[i];p2.y=-y[i];
				// Define Next Point
				p3.x=x[i+1];p3.y=-y[i+1];
				// Reconnect at X-Axis
				p4.x=x[i+1];p4.y=0;
				area=shoelace(p1,p2,p3,p4);
				if(!isnan(area)){Output-=area;}}
			}
		}
	return Output;}

double shoelace(Vec2d p1,Vec2d p2,Vec2d p3,Vec2d p4)
	{// Computes area by shoelace formula for 4 point polygon
	double area=p1.x*p2.y+p2.x*p3.y+p3.x*p4.y+ p4.x*p1.y - p2.x*p1.y-p3.x*p2.y-p4.x*p3.y - p1.x*p4.y;
	area/=2;
	area=abs(area);
	return area;}

double shoelace(Vec2d p1,Vec2d p2,Vec2d p3)
	{// Computes area by shoelace formula for 3 point polygon
	double area=p1.x*p2.y+p2.x*p3.y+ p3.x*p1.y - p2.x*p1.y-p3.x*p2.y - p1.x*p3.y;
	area/=2;
	area=abs(area);
	return area;}

void clear_ion_Data(ion_Data& In)
	{In.numIons=0;
	delete [] In.conc;
	delete [] In.valence;
	delete [] In.mobility;
	delete [] In.radius;}

void updateDisplayString(string dispStr,string calcNum,int updatePos,int nRows,string& dispLn)
	{// Restore Cursor Position to top of display
	string setPos="\033[u";
	string clearLn="\033[K";
	// Move Cursor to Line Corresponding to Current Computation
	int cN=atoi(calcNum.c_str());cN--;
	int lnPos=cN%nRows;
	// Move to Line with Current Computation
	string dwnLn="\033["+cnvrtNumToStrng(lnPos,0)+"B";
	// Find the Current Computation in the Display String Line
	string dispLabel="["+calcNum+"]";
	int pos=dispLn.find(dispLabel,0);
	string before="",after="";
	if(pos==string::npos){cerr<<"Error in updateDisplayString!\nCould not find current computation."<<endl;exit(EXIT_FAILURE);}
	if(pos!=0){before=dispLn.substr(0,pos);}	
	string currDispLn=dispLn.substr(pos,dispLn.find("|",pos)-pos);
	after=dispLn.substr(dispLn.find("|",pos),dispLn.length()-dispLn.find("|",pos));
	// Update Current Computation at updatePos with dispStr
	string bld=currDispLn.substr(0,1+dispLabel.length());
	pos=1;
	for(int i=1+dispLabel.length();i<currDispLn.length();i++)
		{if(pos==updatePos){bld+=dispStr;i=i+dispStr.length()-1;pos=pos+dispStr.length()-1;}
		else{bld+=currDispLn[i];}
		if(pos>=8){break;}
		else{pos++;}}
	// Replace Current Computation Display with bld
	dispLn=before+bld+after;
	if(lnPos!=0){cerr<<setPos+dwnLn+clearLn+"\r"+dispLn+"\n";}
	else{cerr<<setPos+clearLn+"\r"+dispLn+"\n";}}

void updateGuiDisplayString(string dispStr,string calcNum,int updatePos,int nRows,string dispLn,string guiDisplayFile)
	{// Find the Current Computation in the Display String Line
	string dispLabel="["+calcNum+"]";
	int pos;//=dispLn.find(dispLabel,0);
	string before="",after="";
	string currDispLn;
	// Update Current Computation at updatePos with dispStr
	string bld;
	// Update GUI Display File
	int Sz=150000,Counter=0;
	char Val[Sz];
	string tmp="",output="";
	ifstream fIn; ofstream fOut;
	bool ATTEMPTING=true;
	while(ATTEMPTING)
		{fIn.open(guiDisplayFile.c_str());
		if(!fIn.fail())
			{fIn.getline(Val,Sz);
			tmp=Val;fIn.close();
			break;ATTEMPTING=false;}
		else if(Counter>MAX_FILE_OPEN_ATTEMPTS)
			{tmp="";break;ATTEMPTING=false;
			}
		else
			{Counter++;}
		}
	if(tmp.length()!=0 && tmp.find(dispLabel,0)!=string::npos)
		{// Find old Line and replace with new line
		pos=tmp.find(dispLabel,0);
		//if(pos==string::npos){cerr<<"Error in updateGuiDisplayString!\nCould not find current computation."<<endl;exit(EXIT_FAILURE);}
		if(pos!=0){before=tmp.substr(0,pos);}
		currDispLn=tmp.substr(pos,tmp.find("|",pos)-pos);
		after=tmp.substr(tmp.find("|",pos),tmp.length()-tmp.find("|",pos));
		bld=currDispLn.substr(0,1+dispLabel.length());
		pos=1;
		for(int i=1+dispLabel.length();i<currDispLn.length();i++)
			{if(pos==updatePos){bld+=dispStr;i=i+dispStr.length()-1;pos=pos+dispStr.length()-1;}
			else{bld+=currDispLn[i];}
			if(pos>=8){break;}
			else{pos++;}}
		// Replace Current Computation Display with bld
		output=before+bld+after;
		//	
		ATTEMPTING=true;Counter=0;
		while(ATTEMPTING)
			{fOut.open(guiDisplayFile.c_str(),ofstream::out|ofstream::trunc);
			if(!fOut.fail())
				{fOut<<output; fOut.close();
				break;ATTEMPTING=false;}
			else if(Counter>MAX_FILE_OPEN_ATTEMPTS)
				{break;ATTEMPTING=false;
				}
			else
				{Counter++;}
			}
		//if(fOut.fail()){cerr<<"Error in updateGuiDisplayString!\nGUI display file could not be opened.\n"<<guiDisplayFile;exit(EXIT_FAILURE);}
		}
	
	}

double calcHydrodynamicRadius(double diffusivity,double temperature,double viscosity)
	{double Rh=kb*temperature/(6*pi*viscosity*diffusivity);
	Rh*=1e10;	// Convert from meters to Angstroms
	return Rh;}

string update_display(int totalCalc,int currCalc,int threadOffset)
	{// Restore Cursor Position to top of display
	string setPos="\033[u";
	string clearLn="\033[K";
	// Move Cursor to End of Current Display
	string dwnLn="\033["+cnvrtNumToStrng(MAX_DISPLAY_ROWS,0)+"B";
	cerr<<setPos+dwnLn+"\n\r";
	int heightBuffer=5,widthBuffer=10,tWidth=0,tHeight=0;
	string Output="";
	if(currCalc>MAX_DISPLAY_ROWS){tHeight=MAX_DISPLAY_ROWS;}
	else{tHeight=currCalc;}
	// Determine Number of Columns to Display
	int numCols;
	if(currCalc>=MAX_DISPLAY_ROWS*MAX_DISPLAY_COLS){numCols=MAX_DISPLAY_COLS;}	
	else{numCols=currCalc/MAX_DISPLAY_ROWS+1;}
	int threadLabelWidth=log10(totalCalc)+1+3;
	int progressLabelWidth=8;
	int colWidth=threadLabelWidth+progressLabelWidth+2;
	tWidth=numCols*colWidth;
	//resizeTerminal(tWidth+widthBuffer,tHeight+heightBuffer);
	int df=0,val=log10(totalCalc)+1,index=0;
	string tNum="";
	for(int i=0;i<tHeight;i++)
		{for(int j=0;j<numCols;j++)
			{index=i+j*tHeight+1+threadOffset;
			if(index<=totalCalc)
				{tNum=cnvrtNumToStrng(index,0);
				df=val-tNum.length();
				if(j==numCols-1){Output+=makeWhiteSpace(df)+"["+tNum+"] ........|";}
				else{Output+=makeWhiteSpace(df)+"["+tNum+"] ........| ";}}}
		Output+="\n";}
	return Output;}

void writeAPBSInputGen(string oFile)
	{const string A="RhC+5W4TrLog9ppruLei7gsFQ+jsrhs7Ga1gX/YF1+WvdDXSAh7vJkkZ7PM0Dg5ji2WFuBlkwVm3IIfexJbAR469OUihs+HBaNql6t7fqcp4VcR8/YIt8EaTTs34N8QAgS4cI5i8O+MW3SlG7ICjlPqIctKvAjiNHO1iVBnZ3WH6M0N9WslWiva9ATfp1rYGRA+BW0ibF0iSeY0nqRcnLO2vDAO45zxmYsz5hKb0fjBjcWK1Sj6y+Ct55kfF/5zhnJZI95IS2F6H9ifg+e8Fe9Bf0bt5bvXL/yizEmYfu05kZfkDLfRPZva6HmlTqIl91tSzsE6CbQwzBNSdo4DvIrs36LMZEbfswvONNZAL6QkciY9SLj97glWLX8LSkN1Pl94wwRET/+SBXutXJm7L7vIk6a3aHOzdRA10f1M09auISCIpdBWRr5st/mxoiFuKOKw0uo6rJSFkE3kcBXzB9wTQLyWz/zhbdRjbUwra3xmUUHM/BaDPIWT0w8TD7uCM5uBa+/6hPWzOyZf6BfP09ooaEoFc3vOAJzVsqzMPm1SmFlamdIwD96E7q4/kXHNAWUcqcz4wv3AXrNrseuYjsSwsZNwssvD87vYK3mYG7Ayqra0PA8MMrY63H9kKehgP/nirke3MJZiDd+PRTkVdUQo3oRkj+bThytT6Uvp5+pTuYqVUeNv+IuKauWweEArZnLERfHvcF8PNsHAH8V4TK/nGSJsyqwacYh0B4RG/W9InfzFwBsKpr/sQL79sVvPB/Tg0zN8fdUzn1YLjXKxqwJGn8RCU9CmgOEaneg5Y7xgf2SK67yUcn81DfhLBRYMUHvFBVck5w7aiTnDBimzrR3dWPZvq+4U3IBfM8CzdP4L/GfpXHZh2PpD8d04KeighAa1o/d9CgYPhU2QgTnsfytp/Fn1ORZx6CgKGJCAo9V91r5czsRDUEWzAON+pe2M5EA/pOtwYtjdmHNoGYNgbGcGWUtwS8EMa+g7/txgE+oGIc4oUxQUQz6JrMf791twRGD/Ehw0as018vfPRbq3Tk2KRBgljGkklalXToCebPmMVPt/rNCqwo9DYbIG43QEZaaHEYeCKjOXkk05F2teRgWzdlCqDkqnx423NFMbvHqnKBD7OwNnOg7fE0TMxnyTAR8HQlmYbQhnzuv6jDM04V4UFrBFRCqjE/Uz2KRxZBs/2Wq1toaHuX4+cREHLhJZG8TV0EVWpTQj6FzB0CacaYGRgHJHXZt2YGW5/Wp3ixlebIFj0ssB0EMQFoKQFPUN2Mc1MDmaIptyS+0d0KOW1oTx8QeGgoijoFxtPQ55P2HcTsyxZwdOlpJ1kKYx+ibEsuuQS6E+5o3dox6A5x1xWuDGwgaAmN3xwuSYEdo44ctnvmRIiI2AKM2vAefjpRN+ZbvmVt/pdbWOZzfq9tbtJdIJGT3l/FYIrdlAL3AE5TkjjzNfv5JdufjZC0Egta4y1elYeP/gUFH78v4LvbCYQ5Z2owclD4mkO86aMHMNc0Y3UBwtWVLmruCPielEhoQeKJEdA71BGp2tmpdqYxjK1goHiLG7xQJLMeOCBOryVs4yR8JRiU7E/dAKO0N5pRuN7m8+rao4raC09GRbLCVFRKXea/gpVXSxNWRbOxqv84VSleToD9dIdkVebUEpJneX2HSofSA+jRGhJnhv3iMkLNHKgrKL7IGyuNR4/VX4tzLQWkRGQ4z8bCvXZBzrmQWllBUkmQpoLZ2rfL1cdDiuCwGjPyETIOo3tReaNhEPbD3KpXZr5/VghIvHCeNLKOoT88tI+PVoAn+WtgWOqFyT/3o9o7/Iy9UaKbzYhFoKJ+OB3GZvK3C1uhX+wULYjo7jbYfwKQPzKsqltuz8Bk7RAeQOToCEgCaYx7LjD9M3cmZ6YdM47BBXD/0rAXgzx7Qp2BL85ITi2bBtcTlHTITVSYuG8K2FaPlPqGUVeTwWPEbofbUOgLOKPc7OMTfNauwcToqJT//bRN6W/un3fVjww/ijdraFQltg8bpeI1UvlW9PJ2Ts8IyTibTB3rDkgon/+Z7EV3i7JaQHXMquCrTVvalqdfC2ijU2IMUnvkauGdDn1nn1OC80GDllguo4u2kqvK5mgdCM21VliCtfJRKm1K8Pm2tF+7ADTfWpICnl7XxJMW6cHhEzdutbLxGK3bQfrI9p5GCQrNnZVG49EyYbqxCriA0cfR+9lxf6NK7g7oSi4zsd/cfuhrHbgMcubB+Yc0Vk0DUfwvTrpVBH3AWIQlZhOw8NlNVfaWh3dqyhJIZeGGUrnsyMWeStM0uMW0jz/h+5fd5ULEYssIMAQcOnpOHRt+/o0p94qMd0UI0I1FK6M7oKOaS+kVM1H6D9xqe8xAnGVyfWwiEr2QY4/lEqbSMmQFx/W6uECwcutMOZlKgAy5cMGzn3X9Sw49A95J+fuFaIpxJaqcDBhidndhiVQnlpXyesJwRIiVVBi332fRB4SDL6qpvSVCXwUyirDrf+gcZkj7KP6Em6daXmq1rrG2XdrkZdb11LnRHrxC3ohDC2pcS4cN6EpTCPtpQE0M7npqRhUgk1P0gbtysxTRcqk39Q9iYYxVhchS3SXCVKGZoWhxp8sNxi3xsncmZQtWhhHoryAI+Uix32Ri38wfEdRCSWvmEG3vGk4lHXV79ca0a9kIgSgDmmwVhhg59Lg63EQtYFWcScGu7n21QoRbiTrglM2gYPhONCEnZB8e5ZIOyGFrMa1x4WRItohVzzbfAn65L1S7mrAN3KKHczAh1Z0JORUmgPgQnDQcMIqhnlrUSVFRg4NCCfRzhlmZvXUiIhwKupaEw7U2WWAO8w/tE/VW7KQhQr9e6Glz2feq0aLXgzR1aJV3ujths4SXrnFJlYxd4/tGjmYxJmzNwdezaRc9jhC1sAlVMZxnZEgkv9Pz6zE8XHT8beUNAvZix8HgzfKeLq1PTz4rve2UYfmhZMDmZYVh4OVsRTwsaNQUJ4AXfb4qZ+EeloCSC68Wx5h9qt+JjnTewp4u9KSSqLe88oD5l49Vy8FdSdBZMnpB57tKqJHjn5wpJTonIv4aEGH6WqgWsm3qHBchKXp6ZbrxG0aS/OoBUgzqrnRja3XBjZh2197RtA7/lHDHX8lE5GlRqIV/+L1P10ZUqO4rccbSzFsrjmSv075Q9ddZTulWT0M1eT6aAQmuiQgP0A08JkcdTs6phke4sOWbqHm0zZC47Ok/SWi06nYsyIK3gAnjdy5sXzlnXO5o50eVQHQ8Av0BoNWSqQMvqngonh+R8cLrn6bndOGZsBccpq8z4fWNYeegpH1/6eig1fzrpRAe/9g7uZvvORtX4nBZJdmT+L7i6GUDBRYGYzrk89les4kcsIlFUsurJrf9YWNj6HfTH61g1C8IpIOTyedNzYsgr94F2JWIY6sGfUH2SIgZuZVD/wO50GPPUahjcn6VxLcUEUNArAwJg4crgxrzUZtsVzGZDaKGNvjOiWk03ZhRLkJ0GTST4vQJH782PAKird+lYbfYLqoGSM57Uwb1witOvRXp5CQPJBi4Yr8Hz8QdZkDomEtNedCnN4O5cVGlrtXUDDiTwGWO/N1NOVIK2Rbyjx0Bk1hrn7dif1YloQCYeLGsCFlLY/4ZRK3EGV9sLotzQKZ6qkDIrzH2qZinSApBYfGJATv0Oqkln1yHBpWjVlKjrwXOwa1mtbyhGb1J4r1CILJ6thF6HRZnqLQiPtXtPhvDYiA2+lz+Yijr6JaShxpX0gHgCpm23aMo6S/mwdsWuKLb9jSZVsMzYxcadtWTytwAHXMq85D0FQr9k+8pXgW89nMXkZM0hexA1sqWXL/kQLcppgusvdCyWgjM+efW/Sc7hI9gnH3/vp6MH5ysN3E3AW3jOA5HwzfwCqNr5IZEZGtXNyOxLnBVi6RsvfJeHU98RD5ylZk1VQYFrcax3Hh9Ft9YLHbcTPm7BoGksPAla5kqqmjkjScm4/cW1ReQ3oIL2ahYVdK9BmoyJ+SUbcipL9KzmRa05qufJVMNaP2pZ4P2E7CpspaMOgqQagCGiwfqOHMYwNodJTNyKB6Xu6w4pBklwxrvxTzg+72k/t13ATD7eVyesh0qtTwtQgeAxtuV+KVVk+6298rjJiu8SJkNVJb9CqAhs5UEfT0+tqZpR5WkMlRH3/QRhXHOIfxpSY64L2hWb+9/Ts0wa0JI3jpOzinNtleEYAblekhtWxkklUaCVt1rB1G7UIRqWirBYXbM9pQ2SS+uJvReFfFRu8YxuTzQM1HVPCgEpNvH4OGdAYAl5S3qqZ6jDD4M/jgZ61q3HhhfkylbOdTlX0v4omOSjOLFfsEp8UVSu4glWpDQkDGwLUNoxDoOHzbfdtD0ZbwMwTN2AkqCbma5rCOKMutyQLHPc30i3xeYWugycnDE9Vl5vvLBFjIwOLVxD2L7c9yxcp6BXQ4g4U2FLEpuhkkx36hqOxYXwo/Hxb53bv/4i28zrUlXzFpyO3/OoIJxlCOnhmr7ihAg/J8egMFcr2eNICr/NAz1br0HwEAJEV4p/02PlaoUyi2nLyAExreUDajtoTu6FFpPYnq0wUe+bJJmCoW7l04EufRbr7EAD1u2wQodz0ljwVH4vol3/h7Z+JmA1rB+AVEbTFFzf81Auk37L1vJ/xyI4f3fIj1BtnxWIGgvkTFIUl+dtP/fRUrGPQgSXZYkzsBm5k6/p4jY9NDClVfUgepA5fIx5AHFPcFtFkYI/n4zJGs6lL63jCrpzKoKJRfXhviW635m1WBQnSC3AdHtURlcDumAM0kAZVZ/n82LWJnuyXnITOLCDhA6rP1kEfko3Mhdvj7uu3o3dzSG+rAe2GJa30vhF3GAP7JN4qdxjVhVNUR00WTGJbJsRqwZ9LStOAcaJPvnbUMrKRSVC7Ze38AjkDJmAOydCTFgtN3f0aj5UYWkE1pZ/IY0S1v1LuBvPUrcHRU6owO+Nz1Jp8obfp4CtCTdQP1qvNJlldjWHF37E1B04XKngbGoOUWNPeszRmyEa1V5pxDho6UOB0fWOdORYjh91MVSg/40+NnlfgY8ZAkIv/SOvxCkrnge3FUbiichR2EmbDY3u9Bjzp/leiw+mGbm+BGKISa7TlWHydH/tpVoZUrMh/jEhYQ7E9Eq/xQQsQNofvdasYQ5HVDwF3js88TF+m7yfXHgaFh3YHYrlvXgnxcziUi21Jx3TsFu3vZTwGGi2COm+h8UWYwimyVytHUzhRM5XlE08b0DAFq9FUZoqYNe7rqo9w0VC3BXGt2Zf2M9JRrVIJ8a2/wDkkaJV3BSMH2K7nQoHG/T+6cO3EIfzUvmIjLlmwHs8tavsbQOA4hg4+surazTajdJYvNM+TOGTcJfOjaS1oPusSPLAqo+yANSVKizaseAuqbHsX+P3P4VTtzRHKHAQLkmdZffzwuJbHNh03rv9Jy7vdQhKF8fjUdbsQp8EDcl2eDmNe/OgmkPdgg7pGl+760tQHCXF1K7d12dUyztR7xg5mJEX4o2VKO812td3h/1urxR5AgkfpmwVSpiYD/Jw/OLS5Ws9aioE+CP8d+gp0Msb/iXaaow8UvFhcVrhKitw3FReh6n27Z04Fw15dNnwhdaqIH3YK4pi/Eb6PIF+pjR1njvaQzqyu1b3Zhd6oZLFnLKYFcY05bmdEC/11zyjagX8+29HZ5Z5Xr4BrDkZ648xbcWCntR8Q2ABvNUx6MNl75dzg6+mgByOhAcoRGus7na0xdW9Qrnzs3LZ9AD7Zela/BY38roxUVA348JzkpmUNwLPY92yuLb6qohG3wH99HadnVWtixn/hTjCJzgAhqa6ESJrCGO9QFyc6+7hfpYMWZnirFN2GT09rUAVHVMO+tsSRt8RE8r0Zbg9vIvEnYg96p35oX1PnzUuQqatMoTHWznPKlDlkX9ZjeZzWvfZYvwmoAn6FPy+qqi2Fkh8nsxPb4Sn+LBGdD0p04Sp/WAHuRakMG989evW3AJhtE9aqArs973F3ovV0tLUSYYl2yeSg3mGawfHtIQ59HEv5Dx7eALLxVzJ8djBM2B2hiMSHnyxAccmpaBlh8M9+iObP5zC/OqMxjTLtb73xmboMsCMsEmro2xHuC4ZpmsFyWxt7A6Y4vZWvzUmhKwU3GtK8igRV0BDrD5QYI56V0lsaNpeWvmSmHKIL8rBXxEjZl3BQNw/Eob57xlMYwi8j2OogoSetSc48UH/EubFYz6oWrQ5+YMypvs0ez+qrNxjdDi5biTWTfX8WuMOxTACCeEgNjl2AQWNgixKwz5+aaC4AVZDMU0iQO+s4HqL5Vyz8BiIP7CRtf5l+Q7Gwb2Y01zrrFxHRxc07JKzHmJUFEqJc1JlySmP/Q5Ci4F+yPUbnLh8W37XZZiO5HgCBzF+4FkA45fJ32dfKW/a7fdLr7KfWnH0AsiUOD6DJrZtfbcEh0g4R7ECZk524ArZcgc/4o1ZVLUThD5LRUBOsmX0BgO/BXLUFMYtWVQV7TyFCTA/zsIBui/l0L0vGaZ9ontbC6GT2rNLpCFtWpOP+Us1zXl0tdK0jbawUTDWH6hADDHXLRJBT8cJLmhXyi3UrqJfO2uAykMZG7+PYMl006NJXo0WjNyRgsCPGmMqiTYixxixhQlZq1tSVzH+nOQUISBs5K8DFR3EaY3syBa5YGZFk2yMXyhb5BfLssLF7IeoMvsnLDIvDIyxQzhsM+sjZwIavYRJc8ueDyk6GWLTacl/arYNkYQ8hgMh7sL6bHd6/QUkXo5ucjxZKGrWSCjKYkDZJA2idIbelVHQ58dAe1a7JyacrAcJnnBsQP11L8Wvb3/UgYgTv0Z3RVU2cIvjG2bEAALmLMYm0KbjaFCGzgwu3NHRRyMezPRuKwEBX7bFEyqtBJgsOimk5iYAOo+/+zyR0Oq4XYAsyUMBLYlQ8ARnd0KgEDukerFp2Nc0wYjebOYd2ELDt15V5EX5gvIGnEOaQmTGVCE5RU2QOmuSUMKrrJKwH5TaqfieWEqtX2Ax6fnZg3m+W6SltlEwMalFTv/C2EY+k/zJwMhp4CPPNOTjXKiiQ7SuKX2tQyVJcgPj15Ncd6U4u+PkDQtEJz9GlIdparfZ5LFRjGDvDS3laCDYrcePRYPi7k8ZGqybdTgCbC5vOoAOO/HlzIQcbcdL+Q+vIzbkXem1bNHNr8OAzH05/Bs82TuljdRYWESzDlzHXMVAKaNR/tgvG8Gtcqq3O6fBdj12NnH2nm477axWVgPNw1WKKVzBxiSH5EHZuYDAIxTJ311pR8bA6pyEurW2Woi7pjcqNY54D1GU8OT2yQhyJRod6FNLQIk1L0LzwG8NT/lu50vN9+6aAhemI8JyUORjVtmP3hnIMyi+BuYaAQtNxOkS6+qERvvBCffIcILTZW0XBlWm6GteDkHk50gObasP47Gl4gQL00HDKvLnkplc+ye7BYn6NocP88AWjNj0NolsnA8jQeLI7X2DBF7O+yVfaVGJTbgb/06pIkgo+JCYYQ2gXnJqcO4Eke36wrFgMQcIKsAgItS/SucZrGx2BvvV+jhaZnkCQV+6ARjK1EOo7fBE2eMSDPxwNJYwtNEr5p7AVd/F9ozmJ9B7FPC1P4rq6lIdpuUyoAEU6hg21mknnHq6PHa9gzXpQpNgvgUzHT2JAKxOcVPtX9/4PjWuEfvTHuGSoxNUasMcy6NJPu6W3xLXVlVNmLJz+9gbcI/GJND3ex/oBOT4YnXI08j4PGQIufGYkzcYOA3KCmcA2hifkgvPzQQ9yN8VbtF8KmwV+E/NEf8mL01VfUvjAc7XYCu/rcKV6HqY7oK/q/gl/nIEbosVLzWsO1l9QnLT9iTQYCiL8CfA18aqWsXNKOv12MnnIprVjrdQjzX+fd34+2rdZ38dGAwHvfGt80gRPmz1Isxac0Ol2uqKv7zmaZska9rSEoBk8lkCb84O31Pkbopv2UVyYSpbg7rKbKODGxNC8A1CKLvhoqb2cdBEayXuqEKS95MFS6GAqKpQPmcF6MGAUiIG72ilUtWKSo54bIXVkdxz86qk3DMfg1xHstdtvtuIpQej5jelAJQJjM7vD2yYtT+LRGffaSfPMt4kWLQV8q1WOCbaYPZP1QstF+6Ic/hu7Hx8muLe65Dwnqvv8AG3TXdu9/wk/Q4wMNoExt4aa8PvI8K2D5ouwGyG9Xtmh0+lfg/dxgGy7cgdUE7qPgJwtCg5GpMZ2O3E0lhaWsRsNeLnqfik+7arncA578lWlLpRLJ6esn12M2TXyiejEGpog9E6Ui36aS5tUl6ji6wFe1lh2P5c6eNOjCOYXitqHZwm76r2cZ3ulnxPxNlNdrfiW4AkL3ZQyRqZORZe0fphKsp6OFfluR/RoeIdj2L+SaGllb5DOxKuIjclAM81T8FcTsfM8UEoSfaTnfBJca2D0DEa5G6DRAYNMIX+6SLrVN8Oeg+9Tcs8MvuCpv5owNsGYVOCssSSWYBGzPJKaK+WgQAko7AZz65Ss5v1bQKIWQig9KTgqEc4RW+S31ly972uGSb7xTgHxKW+/mtVQ9AjTVi9Bi5KJlzVOn0XTWloRNflHuI/n1YBOwJ9MA2/RtsdQsByfqeNgztyqBa0jSdH1CnHfM8kTQb/se579d1m/tW6LqIlatjo+M+DZu3NA883SRv0xrODjvyrYexlw/cCH27Z5C9E3dG4PW+8ad1ehq6mok6STLE3Zv8AvWJI8ysqr9EeODMVNLcE7WAFWKhRsjjAEMJP9nLFFmx4TKGBBgYSfmqEfBiEpwfldRjTlMoJuTXzNU7PXlZ+1OmI7bb+tiGhdo70Air0tkSgDkD3eOgG/FK8E7JaHGKxu9kREh1VIJGRHXx00APd1dEIB4wo8Z4WGQLE8vSOoSSgtVnfY7AONpUHz2e9Ioc4zQ05jMs5I31Lv+6X5rA7MkQ7GGZM+lyZG7bgpyLShArntOYrCEb6DRDV+K8WxaA+Jv5kA1FLaOD5JPfYnfJDTpEo/SHBFlenN0PYsA32wG/0KrMNLpCroR5ccQ9BL2sodLmlRHEamfbGWq4UhhggAUi+kmSOvWCvRvy5uxYdqQ4plLk9m1hE6W/I1fWZF+U5mtwrIsr9TD5Nn/ZjjVGjgBAGnpVdNker+wFcWRATd/nxr3AbHLAn+P10763haNpWkfles8ANxu3rHB76wm+sED+HvYo58WFpxT1JaV4UFFp5Uq4WBqejOTg3zSpCdVYigVl/5i1du6sMtOTXcn0AkKCn0OnbFcJAU9OQsRwQbdGagjaZ6U7IMKkvwXJOIw8W3TFG2tR8dnVzWnljt+n1B3jZqBo8FO+1N+Cug0H9tE3KFOJiQyAgaETKqYe6RZoVy1DdOc2s5XwWmpEhV9P3qqJNoh6DD8pPox1MmxM7kCRngkd90i380zUdgO756K9sEICek7lyrKdnBbnAsJGnkZ1Wxe68xm5Otpy2TalW3D7ByK36niVQyBJrpVESC5lyhn7MWrS/tZ6VeurwEDDL0sWjr39aM2Ikrt1pd0ghWBekUdY+PQb6YcB6kR+c+PwUDd+pFVSt0nzRtdTeoRA7yRw1Tfqjntk9jB3pgGogl42TP8tbUyh1Cy2KZ/zJuFwy3dG5esYkpAXC483CCkCByHS4mP+3Xjbj69zZhhSUwSuNl8p29rI4lzAUNNA2oSfxvnGi8L9asI2h2DJDNiqnxA7wIg3nSgiSKOVNBktXE0f5qkDpj+eYCFrM+j1k2GS5AvsSNtAjWuxX2WT98dpI8/sqdVWu324KjPZkDz/l/TQzRPmGAIw9yQgLachTLhHzqfKRG9ZLntxIhkDXejDNOh2R12jiu+ivMllFrILIhCWP29fmlQkATW4h9zXibAATwmBScfGNloQd77EX9RkKtjTtJDFl36HXajDq7YXQuL8ZUmVVh21QQB7QI7nOhJss9+gsbF93rupn4H5Uj2FjVodTN1bRHUZjPGC07kHqz1+QhYJMnAjFDluqaixqns4C1jVj1G6dXFJoEJA/niTI0Uy987UqB0zBldlwip/1nHvg0AHwIVzgQ7WOYn/yh3oxeJqRz+zUe+ERafYcoL6uCYkp/8WHMOptji6hB1k9S+xXeGjJPBZinSyU6qSYkeiktaLWLvdWW9XC/lzuA1Hqynti8iggnKky83qSYN6RDw2UvV6V9liaFgmmXdZisGTJ9UWEQD7ulAyzfg8H0r1u0c3E+ACG477x0I/LO6+Ljtx6Vuorq21MvdVL6BeEdJdgI+V3VteX7/Nj98hJHjaujlqa7afdRMNoOzQvVEvLWEe3CkTvla36WOYgPgIcbIMPVzPsyGaGnuH0Gl43ZpRWwCV46gcraG4An3iPZ8yX/cb7URMzZ7rrOpVgD/wqCAt7SqJ0j3x2QsYCLgDhY0nQxbc77Vcgiiv3gHqM2OYDhXxmXRck5UlCa+FlLJfwDlzn4u2j345cB6Ug5Nc2rzDdFT3Subni+r0Sw8ozYAOeaAIWqASlU+H/F42DaLm5ru+5o37C4tA5PF9arQsMEMb5s6H128qNO4R9tlDoYQqJzqSV2MbeokrUZv1wB2VgMY8Hk+S2umn9pPHwOXVxkPZIXbfrxMF290rUrkA41AQHbHEFK1mPLs39sydzXn0hRtdQAZBz2rPoKiwhemFXubkI7UHXLMrHqafOjeP9eMGTAmvlOxEXedGWamwUz7OdWKq0BwKzDC/V4s4wrcL9uTm5sEwufbH3mZ+3VvNCxenM/20N7Bd8pyCLSRVj7xkg2PzmYo0QgnWQZ733Gf8Jp0D8LPUgO7lQ+AhIcKM+QEp/wj2fET+67+r7+hltOnDJKIu7tJ/h/ySyPJZ6Ly1zrePKhNEazQ5VYF3fjkTJfke12QEnEJ33fqNEQ2tXbnJRfHKbWNEzOKP2X5dAZWwVDhCJQ4ZwbiIYuFOMUx5ZNTV4WDJO1Vll18gCqvPQXCpg6RU5VN4rU2vXjorFJK1rhngjJEh+IbMAM1HebYZMe38/lFVAoJzOfaMf96Mey6rm1+pHbPAFMcGSq/T00MW0Qm9U7BQ/5CEL1fWd94FGwQ1LYaH7jz9+I1/gQL7NsxkD0oUziYv4EDImavT+25OpITO32Eqi5r5BCV3cz7Cx6/fyDsNtlnPiV0WfelKma0SAsdCFDtPeutVUmBMTPMj8VXRKNPg2VdUkFbDL/e2S0dGZQdT+KBbH3kayP+fRy+kT6sd75WbZr3gx3gHC05AacAYL3gZIvhYR3DH8XImMa+U/fRY2z+2d0pgTxWtPqlN83eU8ou8Lw4jT/6hXJH89Vy1HiUGedyJdY1uzwx9lkCjC7hrv4tpsiI1kZacvjptiNDs5S4vteiIGAg5v3Q9cUq1fB80v1dUVPSboe68AKDjwvmqwJJ7J4Xpcj2+N4vFp7dXFPjWqReF5o1IHCzbxLh+jH0jzmo5nY+f3OBMoqyHsT0yZhdx7Z9XE5c6wtj6+1hFdIu5QUsvNk80tKJ7E6gBjyEamWhskqcd5pDxojpLTayGL65hj02qMWE5LOhnarr4Xgm+URveoaeZUb474nE3TsZ2ck/hu7I5PhsmDfNAHtioWuqaDd+j/ZR0p4J4KpfiVyr5IMnG/bNATBDafOm8U10eoqDq3mblL7ApnuhL3qG1POuFv+2K+2vHpWedcLsoThEfzkl4ezHH+BqLsUauxpVarRGi835OElH4A4h3FgnGfzbhxzOzlc7UpRVKM5D0YAsNOrPj+0MVcn2rUpQ9kH9mhrXq9+TyfouTjBfbmhOBYQZnjMFmvdHMlL1gbYR55H+/NW6aFTUvpgW1o74O0saVaIZRcLZ1WoaANIK2Fcjc5P5ome/nK776CI01YLWmazcjKmhDF/3hwmqfI3sfGs5b5nAvUVc0Vo002FsdPUTGgL7jKuWfVzzqbrf36sKFc0buKSV/mE5D7qXTkTZvTmPB+L1WgIo+8Azn3SeqT0e5IFg3Y/iBYTOhDJMFBmgWS93c+wgCdwfgTWtFBrjzmxZSRVGAdbZrtm8i01mBvZ50UnDkwS9v62mfIEUjPhwWNinWBquTqwchyv1D0LxtIuWvKW6T/NFXkYEl7EFZI4mqTbOtukSwt7ZRvP52XV709xHT9mENSPvYl6lU9P7YaD2xThxNp95Cck6wH8faWowMaLgA925RSfbz5UBDY5jEWwDviTygA6IHtCh+ejZej8El/yOHhnTx/ifovY6+0/W9UU0WWdYsKg+HBMZ5TPG9FCFq6DYcp6iPkpvROZLTAJqwW0MHE07Z9dp2S2jksrINpPpTDg5EYeY6XDJ5wBI+454kg1UoMiZazgXHsrpjq4uajlHhpK0EqgNWiwzcLiXuK7zcqgQTDP3X+SpbHOCBFqAb6MSHqnXeyNzDsLDRq4A5x/wRyzfFJiBc+o2D96aj1zqzBUDf4i7fJcXYxa+qZf2NV5PniP1KPXKee9rWm35Fti3i25tzjWE+wNYf6D8kul31SAvlQqlIEaARJeeWAuE2DtOkjIYosT29/GtbTcCJJ8IkKJ2kfc5ffOA/sCxoMuaSiE8hwdHskyW+Ooh8HsXf9La0rL5jGapXJXgjJdm4zaYl/vAgSRze5hLpvTs2GaoxZ0sJsqJL1vlnHrCQVC22zS9C+lhhuqfn+e3Fpn8cJ4YZ1SuPhaeIv57IPsqmPJ8YvkmbJWCARXI+kzSBsPOBRsSLeJ3OJ+2aPmaWHzhZlYSW6s2KxymEZdXhUWoQpJV9zNOcuTcv3qblCosVOglQlFvWkhGqzZiRD0H5OboQBdm6+WwOlifvSnRHDdbZGBmFfqobCNhQqZlHb39GQCJw2su/FO94RPTEVTvgRDjF26lOavlaxKURCA00jhKf+GqkgCKZ51nwd2RjNBjYly6VGS4HObdgo9HsWLYusq9EICbWFzgSDk7sA5qNPM3QtCwriNXSsKXF+Me6cyRPNmPcIr570Y9lKYypfhcbb+ALdWz0VWDc7gYYU9ONJ6JdyOIRFtZztw3N00ItZz6F7OBphq7YukDmKaERO/TkJ1GDkKPTumVheqTGLEY9ww4CEcgMVz+1H3gFFpzHeYpdr0NpmbIP/6F1c/nIGEika0YjGahX0P+PMo/Mw5dpwyJbEbT8xxFoho4jCN/T5SwRF0J7+mn1w6NLuRGAf6ARuKQd1AkVqEUh9IPN1MB48A3Z9uOjHHL9Y826CAqcsphfY6e5uIXPOfWVPN6Z10Jdjf5AllPvV8/z3BjBfzqEt5TA+lvfWqI+Q3/FugpUfttGPV47HvIlAiy5tWPZroazzehiZasaBjp/GBbP88H+6ntq8uZ8q74O7l//+N+gw/yl8Ph9QNYl4/ENj0Ebs0+guMlKWqHkIuxqbKRAh3vTqe7pp2X/q41DrPNNfPdnaBje4Y0+OZyqapfV5nvPq0M6aCYfcPmbbVGFJtVHK4oc08JDlyGDGvICNlwWy9ygXLpzaFJixtpUKUn+7dPIaljT01oyl16K6UaOQ/M67csHP53L/5qaUw8yfYoAzkNt0vZi4UirexNgLYrD1xxsWGkmho1rONrbboA2ZzkyAXy9P5k5FGF1B6WwvEHwIlW0MYRammSjQ4GfIhIQ2X1xAmWlDgF3FvBI4DGfYSJkn05XiGIpd7nrjOkEoCkqxmA4Cwq5FVNnpPBEVmLQ0FuLL61O/YfhgXvaNYQdJ7mu8bY+g/Yj8lFiLT01tP1yF+jNFdwel5tA8MrPAqUp11QVFYQWFCXpO4rc9Xam8sabfFu6A8+AVzSxIq1n195us3X3fL8lG86a5yYwqAyY2Pfo2xGztIqg15n/LS7fyHIubgcJRrcpjRh9oE01LDa2IiG0jRvRQtJRYOjF1+wlXEm2T8X8sGSbGJONqjW0/ZxY8gLl/wArX0SR6+Nem5T1m4rPvAp0TcP6vdqrb6urt13BFuLa9WglWyFzQOHRhcSq+UR3MEU0zkcmodifVwiaEU4eInSoHhkYogXOAwxCKLnVTne0zoOC5RubzsQIaG0YhAd/NQEeqxq608/kzJkGs/Eu1T9wd0kJJ2xs1ebkiTDit3aVwkYp6vsVW6j9eBPPeGA4iAXhjwGbNwek7kHiK1qP+QYKDIblnSI8guVWuV9m472tHqTN/MFfGCCCh97rHWqpsz10FdYrf+ODwAGe6bfzPWWa3/v+aTUNyX8O7NpbKBlV497ewCFw4DdCzVd9rBug/1FhNAbl16O8yd5ZihZOlFw0OIu/xaPeBO90Rp6CWmsedTjyjnkCUMd47V43k8/6vlgC1p5oEgN2RTyZg/cknConj6mYTf2d4kjX3jc2CQI5Qa9ERxDV7IMqXJN+WT8uigYEny2Sq1qCcEx4qvX6tF/UZa4QKDJC/gEJzCp8Qe4s+2ZRbbXnMSBQntNuzUYnMH0Zromu4zDGxBmsbrziE476QU/+b5/CWuozrNzjdAQ6/qK/yjRI29wDR/BZxM9S84ug280uyea4hhlRmct/2sahZcIBxdS+7AqnTEjQRus4bA/SAs/cbEi629a+D3yjF+zxZaP5qqXEH1KcrPyP8K+LdK2K0/IFhyTUKFEFLzVJdigN9vEX/WVhW0JBc+r+8CVuXYca8In5bnvxsUbT/GN1Wk5JvftSA/c3cfVzfpIwQf3TfEo2PFlGC4P+ERYnWPEBwYoUdsK4NUNPm4u2R+h3BWG9eFpwrhypAF4Ll2HW/wVWOdksbuIIDe6mRvutyOGURlBKbx+l26AtrI8NAVZFf8GbSCPx0q3WCBaRyTA5TtoVHzs0pE/lFmlu2Y2BFW855lMOEkA6wnFFQ+Kj5+NNb/Tym/82vyzMli15+pGFmKrboc6M+ZX6zYiWSkde1ujXS4sbNYFHu0jVU4RP362VqrXM4JYpJ+6nKr1dPxTm1N4RNtzvYBcRh1qwldSf1ixdaPoZzLrY7741Ls2++r4kynOYMkHyRgcCRlnGEJhtrndcHYYLzMlW/lOWjvIb+5m6Dce1jDMUfq7cpRrGArQ1q4VYkiuHo9AaOVZTX81VjyWwfnq61d+lKRfX+qatnsBFl/1wByrj72ce88eWx+GxdyHbHuoGSqlrUCOjGH3rxdCwFEkJf7EJNFsBXIkBIRORAoufukJ4Zj5WJy7HjXwyCGB/Hz//rzL9mql1CuOPshdYxDOdiIPSriXrrSwuTVLkjAZNfB5xUUj5x8LEvagw39ZkOwqD2SC8GO0/kd5WcSmTKWWm4XMENBBgj3kqt/L+5kW9tRfjnWYsQ7gaF9hm+m1zejeJw7ijC3QggqjY8BaWxXyVRfowecU5PN2CEhRMDlbUrGB6YKVaJB6ixI+QTt4UOm4YKuuoBHM7bvtx70jK+5aV+INEB5DHsV+qi2Q8iQkB7WEF1hHISsmdXk057g4AL53D3Qx5OSr+U50hT1we5NUV/Nds5uOioIhGOgse4d3/G3R/2O+vOQVNNaMgG3s3H71aa9kea4xaFlqBLWJIslwcB4pQTrOEVOz4NQHOW1YHNtB0ZQEFhKx4njCeJnbyabhbOcNH7lgtyKUvy9AxCAv0aTv5o2KiQ3dIkcnTgq5KqJEgf2Z2WFOT3oBO1WDnXFt22K1C3rkhVaerloyKsLDDaFH0z0UP/uWkq+2ntIPdvBVu/qtOqpmvAgXgvuzGBjC8UdFKhOBjHmbT2vNg1zgleViLbvagalMzLEc0KEtvUhoA9KoGQ3jK3JMCotO5+wt3/bwH6No6iR7q9MyYrV0sed2QZYyzmhfeiHfBFn+ldd9PP8pUTIgg007Dq/xGjuhPKYkCmSa72nllF0BKNti2vQHmMMuSpTwggv37Yl5JZ/7bKHHRADEc6Wihbr8bfUhFKyCkTRP/5uGgW7wxAuatA1QMHoYBzZBrL9wHx3RThYCUMDsjK05FsXlSUBDH6NAxS5pIqSD/OecYooTgdjOHzoZ0SCDHW2VWBLwm1VNhiHkn9/k5B4QiYFQZizhAkXylxz/wzZ+rjL2aAnyiVoPl58+oFinlnUpSptxpBCWMujNf5f6fPR393W0QZZKFp1nXx2iFE+iX0D68nJ5YfgcwQTrWjeWA+8dwjKFT5+4eta2B3w1HOtTziq9SpZMvYiJljlygQC6P6XXQCplYZ1HxF6iEo8OGljm/spKwj1szl+uYVHTO5E51qV1juFkVavl4r+y1IY83k+8kqZT+4Y32lEYc7q1LMJ+E/t5b5Ob9YNRe6wmk2YqLsS2mLHG4tA7K2wSw2liMPKzwBd6Nlvb7XXdprdE2ganEz9NbFDV02QxJGhIRHIM0UAphK1r2eJUEpeTdGj/GjcGITHwJ/iBa+LdBLnQFkCKygEytbwNvWJ4DuMMmKz7PO0Tqy9pp/GXSkmAQMNF/Blsw0qErJrq1CxcqvrJIVm3AM/4i1ywm7CvQeddsSG9O0ysKloHZvoNrE4Lk5eWT0dAn6jJA76IYtHL8BPo9VHOAobfO99nnrov+/lGfgo7DZO9+6WUD0r8BBwJL0O/sD+U3Xv6xcmDc9lJme3+5ZsN9sNj9GeXQigvr7BK+jU4gKI3Z9RQkZR7Nvw3RUWD2cZFRNM9M3Vga03OlBVxeFwhFR+RHN/vNtv6geuQgU9t4CMwpGM2BSm8Mc1VPa/otDfsMxgeh+mD1BkfkrV9IL1EqnwPDTh7KCnAqp/4W2D5/wckGmfqiXEZOVCEAYH5JzU2gHei8mMr2wj2FEpnI7DYxve8RQD0Rb6M3ma0B18QB5EZw6Lx208LGi1N19EEOcr9V/NEOeYJr7yit6ZgY+xDkiBIPVldvIRsBIsZ1CMFz0lUy9OK2/n1hUKgvPTulBQZglIJX8tiI/Z1tR8Na+W0szav2bC/4Dae/kVlmgee0kbTh7JaUNBo2Xqg/Duij2zAhWwoVfcSZvl1adZ8siPE7Ibs0wXJsfVLYS99/TJEr3M6zyS6E8Yqo4YxNmmvj0OKWMu1ikGZ1EW0H4M5PS/tpjxh3LEQHUYObHwFJy3dkQn/OnMKetUE3idGR8ULqQANspl0ThQOlNQq3yADtQC5+8ydhZdj0ZTz5TYUFb8lPG2pqWmIBpD4NuaGARV5BFp8hUSXzqqxmLsW6x8/0TqGfciCdGcQ2k3CaHCtHwvzjlD6IzLkzCqEEZyJtKUAmpcxRxQ+NMM989k4KltBtNHLXvskuI/1KkpvWAwqgtD2dBQ1vgxcDCqxSTzO0ipXjnasHNuKX0trBG6XYfuXBhfmBJIhi/NNKhNd9DTmGwTLvXsktcdMyzjwSjtbUdvl+UPgpamdVALpMGivL/orvVcyCdKx79h60DDBJHJ8K0p2I8MLI8sh4FBWKS8YJJjaPA7vpDL70h1VawH/77W/Kc2P3lFpaUuIDQpsCL6afFt8MUyYYO18/8j9wZ1slD7INxDSZjwhhsaZP49fC4M3FQ9+Y9zZOLYnDSd21j6T50kglnpPC0gawad7fKWeI6jQyPgMMfxo4eQo/kJ0k40fWX+z/fnEJNpheX+NB6AAY752uGcQ1ETnH7kCcHUfDw1W2HsX/jo5hTc1UiRAj2U6mDXCyVbumjUiHu1tvV6E+LaUBiNTvvihEhHuTv6xMyWrxQvh4TdsHFZQHRVKZf89E9qBtjA54W1onvT9lpXAi4XF51XTBaMlQITdwu2xfQvFzirKrcbxvSn4Yawv5d2x9de74KD5IRegwRJ16T3bF2fNq7dupNnUb2ld9eoOe8XloIFbONk4rRKwHGfnbVT3z/l0Sf3qVmz644Wzp/4UjcS2NAb+FT3Lb02+cweROtZ8CTFREUT/5KqcSFUQEKw0vfdF/KCg51s7EQgY6IWdybaqNlYkdZeiWeVYo6MzJZCVcTxmeLjqJF4mVAYVokEwXhyRtcagKU/IqOxpPxppPMxvudxXlrpTGT3bypDXqi/LLcR+IBeWF3f62XRzSWieIH4s6+AOno+hTZWTcfs9M4PXm8spSoLilt6IkuqJ75HOO03ulPUCwTpJgD9jVJeQjTE+mvPKQyCK/LzgHMfYxmPs7xsB8ztEfI//PHIxSM40lbA9k+A/S2GdnnHwDX5j+3e9S5YGKEyDQRPkbhvPmu2TT5PEdN6Iy1zIuhalnfq4n40/JRZBZ55nglhXApayE4pm5SkjMfY0gVxIMt3/BxqbtvCKiIvNJbeAwVqPmT97WWjz7Ab5Ao21ltj0sw8UQ/ajzYgQDxIMvfEuXMN+Z3tb7GmOgm5w/0f5XpeC/bGwHDIXPmpTn4XadRfhX3zDQr671y3HWuIVcHTEmU7O2hC1mCld3qBEBFJjGhPbZVoPLaMk7ugUviULzcKVEpQToAffEFPkZOHF5WoAX4VFbls5NZuwnh1IRGIXmNDeMQAkJCnwyAfrU44+mESkAunaU/sDTjqel80Nn6KS0UrpS1Kx+WG8WSNeIRt43mu7Ftr0vp3NCbTVsHgiLakSkmTFGCUE1AzatUM/7bxEHMYVIabCJwdiQZl9sBbnL3BcoqyZUcJcAvq9z989TEXhVqFMlwclOzCj8trSGcU7zHyNEHGbbcg2CCB2mDAtHyBJr3K+S+/WFn/vicPycw6VTdtwf9Db7lcmHIzyJN7RBpCUOyqwymMvn8nmXi24u1o+VfTVTklzfNYow2LLjB/XfE8xdVTcP2cbOSvEt3MMcHY2M36B1Ue3/64yKy5YBB9CWmkBSn2TLjX3DHW5byFN5JS4S5SFQUaF/Foogzu9i67q30pfh0kV7I/Z6yqwgma0F5nvpvg81/51StjH0AYYXbUF6CTGxXnn5QkPAEXithC9LC7dbaG4yYUUWcTHF3zbXTKl8ULkU7zz4zt6NiWgOplK0zgYV2v5XCZydARK7kK0gsNZsupBYkQDh79zO9t1avb+cjxEiC2kto6XuCZA3fEPa8kx0WIOGrdA5IYA5/mXALEgUU5XmjOeCW69dr67T+tKVm2lv19a46I/OYBPr7iKa+xQKONUwYAMBD62Rb0U9Phpf31v7gj+BqSIQG77poKZFitxt4RSIewzNq5/gfVyTolAodH39TuLr0nNZZsrr3UHeRM9ONZYraBufJXELZbzzb7HBJf5/pc/vfu1FudBNREiuGxH7uoLIaJHGIz7K+ZnLfdA9teGkdkNPTTIq3HhgB8TZ06t8DgsUO6UErFa0w72n5zbn14FDS/jEVHkgA+hBpL/FBJXUq0br32IERkSpBvBtDvkwM6+IjMNAa/NHP3uIiIuNpkiVKimYv1JHxlgD0hiPYdm5PvEby70RkvQ3daFG7X963nqOcBInw39G5vU3uN0OKYhUn9Elm9AqzE5DQ7AJwTxxuVv+m4IGdTQaI6UfbAXqyXDOqzPovkEK/1RF2H0XpyEjCf7BB4455IxSZx6i/BGmBGxuk0Hkm20pJd9ur/7dvo0PP/wsltbO594oVXdID6jCuMHpXfdxqbNRhtbJpTrdQ7YtcME35VLcjKZ8cLGmn8Xl+Drz+sCVf+gUVM4GwL0knTAfsdUIX//vVe/UddcGFEEu63MIBVbettg3y1FHJ2/haPfOJTWNPkO1SdgI4uD5lGpcB23ZpyXIFz41ygNsikTrDhsdjIuuvgY3phI+QiAYGhHkeqR9IwNadXKjlvKdNlSXbg0bMftXXD8qLWCHj6namQn4Rx3ot5t+cHyf4MjVutfdH3YH188cm5Tct1xLNqkKxIezuTL533FRwE+7+JiIaVyCAqKeiq1YNDaS22ThSHJlq7ia2OyLwIQ8mtLp4H6wBM7pOiogOU48pQX/bpLWhxfGxscbWpT+ZPFESvBbAgCceIhlHgZPy44R0iaJf9K05WfVyqHZNgPuiHw7lVsf9PszA47i4o82MMiBm0Uj4dTzHWwARlWTqV6YfctaTup4n1GZNbxzcUbuw1Eruhep5iGZ9XJjYBakjlaBJHAuiUHCGb6h6DkVY8/JiQB7PrnzR2DVcDBJ3szZcKi2VfEA21YHj1JtmSuPsWKwKhSgSIXH2AP7Bz4Ukl8sd2Phed6qHlqQQjqUU0lk+55DQgQOezxXwajxHtKdZFcH/DMwHgn4aJyopj0gLUmgSbA3+8CWzTkdgxoUPDgN5dGzn/4NnrVAVMtNdSgasTXON0br5OjWYvIYskYxzu0sfrdQidL0Z+OEOr023uZl3MqcJet657ix81XMYpZD3WVyyKe4agTGqYi/ORqWhF0mxEfNSSoqlOZKTYwq/a6DlrG2DVzv0KhtaLeeJWcZ3nIzQ+1k0XF+uj9t/a9HaNKU4EXip+gKc+kzJzsCmMVZvckfaiidd93cvMfZWXg6MkgpGBNPKykNMBn8cuNBpYB4MSHrLb1NwC2Dzin7wUCeidsBp954e0+Ueb+u+sRfH7Fgk8A9VWj/4MBgmW6XKxwp1D5DzACUaAL2XQPCgJwb7khO5KQN/b5xwHr4nopA2VMcLPH5gTb4eBgLc9nhbwkVNcSppVW5QcO7Ilq8Y18rfFi4d26vaOkR46OUa9Oag2swwGdOQY8nC+KVptOjv8pCQEoKaHw57F0+dr/WYNYBhm+x484qstWRE7ywuybbamrRfykyV9mPXXxe6pmwJj8ByM7Fnu1/5GtASsb5/di0p/2UNp7wXe07/wD8epjiEW7FJBaChx/u1Kd8VZhcZC4thM2RrA/hZmhGoaFTtjS5nPlBSrgJ7aIort0sA3kyhWNNVVFePwds/2MHrDgMP/RJMOW7as2VMNWOLYnYJ19kfRyu06WMWapA1RRxZhmF+VtklPcPVT5VPRrUaL5/dk33kNwTfh5f4Ct31M2BmKnUYtBBoFP6bvureo5uOBe6/r0LDjCDah2VSkkrY2civ3D+8kjRZ7nJ+lZQ4/4Tji8EHVxDFVSIH5fPe5bpsbz8hOd+cC99mAhJpqgnXaLOYr1fSFXJK+Rp2cclx3fdDHydKNgL37tf8F06gS8+4G5Q2eMPvX0+LWABar1/h++ojmGaCmL2lixX3xhgQbOGYXynyGJPbNOZrNvajoDiMcIr2Ks2AZH/q0rrPDqU4T0baCflqkIURWSB9h/D0dQqKpB2P4PDzNX+R+O7hF2bkjwnAhVqVhd9QIm9NBlcLjbr9ZDg4ZGxW3Ag4upUp6+9nz6Pw/zXCLwLBFDBe6ifwXI8wgGfMv76jRYfSbCC6tpsP7TVla+CCUGOsau27x2BV5teWveBkknWqeyow/plPnTAF19VoI6zgabMJJUPj0/m1ytI/iAV/b2jCfLuQ1O6CiIudVEvcTeoWx5vSHP74r70Vdi3ZLDQJGXbapUQd3R3gXN+8c9cHZVJSkZFMaV44vOBXeUnWNqYbdNtChF466Lwx2+Otvy2hnHs+3MaUsUGNbY/sLazX2QPMEkpoA5S9R5anYaWwp2sMJLZHS3Xh5vNFfFJKCru9Nz+Qq6o6dui1OCMSyGv08znNv1uq42vvI7AX+7iy7qLwW/v0ZD75v6asmtr66iewUBomSwDlNmy6jazOoYBgkNH8ZWlYoSCw/CyrypK+YnhbdXCnZjmy9inauCCvaWyI/1j8dTQW+jIVFkWawYTyF+klSj6EbcXphHDcL1mEICtHDIO/VLwoqdE7lLL1zXIGHe/K7iRgVGbQ4l+eJEfIutdayz1gPApuhkwSqSz//XWlqVB/zEwn+iep7zXKZMjuBydE0U5wZaJemrIKJOqYIXQtJR/p5O4f5J0tIlzUzDGL5UHzurtPF8MUuKkq/cod0Hh5dHUaclQQTWJpCNExw9GvW4B2x/TEmCaWNTzs7cosQuW7bTepd68numcm0p1xVZQJGS5l5nsiphR9axBL6/vsdV9gar1JH0Kx9c34qExUZ3ce1TlNvYFws7Wd60IoTD9AHOEjGqu2ToMaeTrDsHymFBrE7g751t8x+BkXG10rxh5cqqQaNHjNR1RT3/4lLQFyGP0GZk4ZdPedcJwm7xGQ3C0i8zJobVpudD2rBSxMIJZh0mc8d/2a2fpudubVF3ugUgkZIP9Pwb1fKv8C4p0xTyoFMZQV1iv5Jy4OgKkO5weW+azJVTRsaXblBvpjylhZNs6hhBv65txrlyCbC02dwX/A9c4cTFUZfp9ZcnsExJX9PVUFc2bBzwRfsXi+PZfWP/8y0k2AO++Dx1wpbhK+m2Y9cnTrRSdXVS/D2LkEpKyGudop6fqOK7dSYczjOaMUmjCkXqn50mkvFgKbyq5lSp4BS3IQY3ZIy6L3v1pq/iMP0HD2JV4GSGUUjFUhnxnAuqAjE333QbxrIC4fRhrcM93sUtT8tAGC33otMYmR04HLJzcthjvtx7MpRT2rqaVAJkPnRmsc7WRa9EBpRb8jYqBr70/9sfm8CQZjp4rVP4s8k2vnMfB6iIHCD4xqhxGKw/nTctsGGs83UhQJvIuR8drZmO2Lw6B7+B+bZntq55WflfuA4AKIWceHB4FIFebzmuFfc/eRvIuAhrh7eyAlawtth+EfBYX+9goAlX+263WqCEMCngVGJjh0xscihwE89FtsHdpVw2vvYnGwjvUWXvnFs2hsYRSI5opmM8E3UtaLHziKgcm/qbefSbabOfGEKFinJKeF1fMP66zfJSDeAdI0p7ka7NdTPn4oRR0jUm+j7PPavoI8Etwn2SnJJ5vwj5wexxIK/Q/52dB63sCK71hGc7qKG4Ky4q1obfkx1NG/Y+wtP5X7M+LZ23O24ka20fCsKjiq0xmgEey9Al8l/RwcIxkBdA2JIofDVBnZlDqEpCUB0VlNlyaolPrbXIQXJIbr47Mv9UqZyDAdx7PympzBMdYwaQM4IAlWWGz7SmR5DRtWuSjypU577rfVNFZyTrdsH/sDobIE0nYW0h3QKWN1ZiDjamHXodky+ePyV7KOtZ9MPvdej3K/TSaHcHNdAqbSRN/JlvgO3TdtVI//eR3B52ksu2U6U0JEKeoWk9cwpko3cwq1rlAZvnddQ5jrESB+yqJMPQrYH9GMBIL6C2p9wxPuzEKSY76gkW4B7mKTJmOc6hZ3SLAYDC5at/uahbUvIMTzyqSoGsYbQO3Op3X7VSiALUvwyysBfSSS89JO3hDB+JtoTpOHqKvaRrPwf/Idmn+OjUV/8ET454//V7UizDy2LHmBH7Wp5J6crvNgrLJkuFWamo5DBvMFGSRWfCd1dc4Mv6arT3AwKJ6PN+LVkJKnG9TfxcFl7UtoC6wh9m9Zy+XJMAD+whSMVWRQs+zNe+UBEyO5x66ipdZb3txrKMehGjehsIEWDLhXt2HB6rqpTa5a3KOIRjwgUqfjIvLmRe0xPRNURmJcP6vM32NJhKt/XzhYwFUw4FadrGk8kiBtcQ16W2e5riHNO7JabEF6YRSWMmN7vO+BVyuYI3LEivk8eDiimXeU3buDqN27fKu4Q3KaOctc3CXiEDHooRFbEV1s9F0y90AidnXASHtgUlFPLkmELdGp9qNA8+rX+VhN+Y+Xp2J0sDnImnpb6X+hOgW8zY3Txw8CzMRSzhimC6zde53Ygmpz60EBUKzjnx8guT67S6Dqm65Kmcxn/KqepNgNhL/A35/KDjFuYZ5tJcBCmkuC05n9HSG//NblPpI2Trn7nDvEHK/PJQpJySrCdDwWnS+nohu2tE/Vj2uXkOzIvd5JZddgv1QHYT9vdCaPCuVcY+k314gQfbFq9EeScl11NAoWxXbMtz+ojifKz8o6vr+j4qygX79XNnYvB5/JoLDQZ74YjibfH4GKuAz5Bilm8JEDSzQgQo5RKD5zICzrxBIPEM3O/J37F/kFBeVYOnlgBFM7B7UevsXT04qZdB9ZTKLt6ed1xs2T3aUT6X5cUDiRgz9jHcNpDq2GWA0hi8Ho7AT+YPGJa261ytwazsSsfqxpbtSsgI22e2T/N24bCED19Re3Y+Omx3HKUGYLXSYZ2OtnhMK+7BPBcNb0j6sqnuLunYnmEfFBxoCRp1zRJ3aXgDqu8p+I/ugkwD0L/sW4fyEQqRgTIybg0cVrTKytqUbNFFbNpVud3ofKQdcwdIoTiOx+WQUNCXmkBL+hVDPUm0ngGYeMDocybt6sjmieAxws/U9ynsYMI2vEAnNZk3hDApdqdn6V5mv4jiP51Imx+AIucVitqfcqFzPn2SZojeA+xjTGw3vVnOkIQTPVMvXydQ0rcBnI813ptUvTIVnDwv5C81jB1/bzysRTAmTSqQVDHSDcy4nghe218LFEXGDpFsQyMsJ78yEh2/Wd/2NzcDmjSwk82YAmWRFpvXSk6vwES6HBEVkBR1081RAu6KxR6TfvsBw/ojbKrxgSQpcdttkiLw3HYK5XJL1vfTNaRnawh/HJ5UFbYptzm962E/rq1O7jHuqN/v+A6WXZKQuahPt5LJsxdYSGomBx+9ZUZECiLP5Iq5WEH0AEKmt9Lspvg6FanszmkEII7kftZJ4FatSwMLSjyhktzDHuZnm1fWdZcVIL6KXmypc5lHcHT5aQRGF7qxBi+sow0wNDMzg6f8HAaLVIkyu6GWK5oer27H8hVzEwVCBG43qX3k8ALsHBfozYBNQhz7175tYS3R9pUm6+JOlxcvJTOmn36m4tO+Cwdc2CA4NnotvcrsFrGhT7MzAGEe5EnpOv1quPIfkW6Kb+ZTxhiBRzUBa2DmA6KcYOhh1DbRT9hhbglc7wi4lkULVS4/dLkVKxyws3OjxNmuR0x3sfXaP+zqAWCgG/vMM1BgRNyUCGXm+QNOq+Xb1uwjdgnEqF/2JJIG46g2t7Nv4TvUr6kInwIbfFoMYGqf9PU6c/64tGG5gLSdoQFaaEwQenhU3QzbGOIRM72XmJPv8NeqH77QQzgkLiLynUEccWRR/bnugyZIIIMUQ7KW5aMtM7ZS+XsAx/B0PsKcGctMSdzJqKTP8xS2LNvkx1qYqJQPdIxc79PyLGfJu4dOfH8qNTO41Tjn4kDiOKS66ALb2Xli6g7Rgzi594MjW5h3lD8AsMchSFu4sJiAv6ddyTkSNYNWih2/bQXipcZD5nR633bxG3UbyckjpNEjJN23RaY+CkdexIusp2rkci3+Lcs7BNm7mrR2q/498V/swB8gROmBdcYIUIaGuiodHb+UM096TnOwdlQMwaWyDl1+6tKyzAe4fNg7/rMD7bKlYtTn9LTp/JrAIL5jA4kdZMIyMBA/dPJPLrvCjdYy/SdKWHQ8c4PKeKeHJXc3tjNJmWPlXGAirKjjMEh4rffKLWux74QGbAPc2l/MJLB4+ofhXoaLbanWnFXxe0mW8NQt+w9oTuoETkIu0z8OjbIVlSKdQwz503yNPUdRgx9P6vf0aaUnJb148flF9mslqBT2DAEG1OUIUrV0G0XAcCQYtbYVeAnpIyMqr6omVEBKvYZ+2rtVcicjr6VtrcqhfVhlcTNihoGoWxQ3nEUWh+Dw/UnQTJAeXMqjVzK2uQ4a9CL7D1tNzUdFWvcRJ83NKjOtJRf81rXbnTHy8pWZsNMtxJWdxGJmkwxIZny0hQ4vwQR1bYPw5AnmUl4mi1eWzzHxP6FN0Uv3hin+6zs5/SfITq3HYTQ1JAw7Kb+WL/MLamfPzt60JGtru+PV82X1ej8OzxnvJUseZX3tmCIGG5JS+ipDxSwZTjgfrDOfqpddqcw7r4ZikCwYhZoOVFGwIBjELggXSEx21aNeqJq/93Gl3ecG1UC7uz8vdCzbbfJLBwK2plY+G+NweYPJ/boKO0TRLrZum7DqH068TUI1zHmWG0zY7khZFjvi5E99eiQdxWavyOPvWsVd2swcEvwWNfcD1yJEzdlq4VblQ3uCtn5EWmlfl1TOUCm8YdpHiBTyEFblSdq+ML0oV8mUI/9OidRL+ebthOkJd/zn6rbG+F4NjMyNX+kCwJCQ3J+AOazwLyGjE6JNIsdrgGoUIWYlC3DC4i7Jhrvvs4Z8xL5YHU32ZrV1CsJCiO75XXcHqKERWpkr6ghHBm58eXNEQUB+cg56qDKA2h/xOpO2vTOYdcaQgZwrWa14Pjspv6CYyW4SoKp1XTC+ZEPZy1pcMrdgregHOYnntt2o65taQ/nUsdUqPFAP/tbMMDneQ11o9yoKRGelkuJicDBPCAqgtdcwpUv9ukIWOeybPwWDCIRUeQWGg1dvBgS9iiI8mynwBq6ONeRwIqCPR9+YzCp7r9fYUkAzCw9nSPJvBxDeU3wlNJAqG7s6CedBqVghebN+QjqQ0tZ8GmpKxldwZsUV347S93e4z+jBuqpTf773f8Cmo1jaLkxblKsC2W9kdVADMUqc9mIuLpmEDWMHUhdYarlHSSGZehUlr/NTitkOCFAbeS5/vePuMrGJ41UT+ZMzcDygUlsARGtLs74oo6OM0uk4Z0zeYeBsyK16HamYXo7eQCdnJvP7SUZynRWhbKD9vqwwK2YHbe4n0hKgdp/ZNSuJYGqeGCkC8l/o9PId/27+jRCKWPQRwIE+6QskvDnHZRh4LyrLIzhgVdHOF1/fbrL7EBDVUTc7jquSauQR+Y/D2z4SBnIEr9693YZ6wSLI/dwjDSJ8U1EI3vlk4tnxvPYWsuOM/v/GaOO9AlK8g1rYs4Pw35zoqp4dDuGZhMwF6PVQc5yLm9K9O26YkSoEieK5Uo4Ytj5zlQ3tysQYmnvhWx5KFWH2giVk4sYrOLnDf6XMNhZcCGq9zaoJ6ZSxczKeOP9K8XseyEO9/rULtwSVo9TQ50odmAqj1/qyVxPQVdzAKhT6TOSW+8UJH7fc82yRYmD5A/Of8lW2MCYgASlBBsvMK1tJCgLx1rrPF3YgSe1cun7LAnhTHseIHRqvBK6tGcjX4IIhU5K2cnlPpKbBySuqlELYeVKqUZED7ZftmM9cmxfGg+aKCYwpMXMv7Mai+Fh+aRX0+WczIzfNz6+Ol9fh+HEP1X564hLQElpklTKVNXMuO81W60e9SBDBRfDZTx9Y72t61uigOI9AhPq/43+CNN8E+kohjnB8heMnVBIOrXVonuyIURiftqC74AT8pjAJ+6AqAgHDWDbikvG8hlVKlyLDddeZ+aIDbOUXX1oeAQGp/nAPUDDovzyiNuox0NsvB8qLmlRCLvMO0mm7/5726AKIpqF2hPb2pUG8a/v3xRsdu3MneZfuwUQb6dc+5DtGncHMARs8k46cnbcJ9chxWiHZH80cO6fQ5Y74gLVgv7Y28/BGylX/H9E8DR6Cx4Zb5J6c6VGx3vwkQ7J9z+v1VNv11Uh7ScaZrhiGs/t6Mk3A/sjXETbX1BrF9l0zjw3Ug2NhvrQYdqsIBSc+9el0ka4R2Ke7v3xYLPKwb7yXkate3kAYxxlRUjPLMORYAsY0AUQ40G0LJwqZwMhtPTAOx8M9E1pTD++TG5FfyWdXLLeX98XvF7KmAbNtMBzCTNzuXyAsTAVTaqUGKbZ81sJCzc9SohyLouvp2JDuSLgnpZDKUC+HgUpOY15WNP9h4sGcxE+0eNvk9EjveGi0XpeDB4jbvbAKFYNcyS4H7gduK3OTpoTzfgYHDDHX2RPi0UNMyKbSPERJgkTLahsqh6hMrRArttE3xNP7787oV3QziqM0oeceA3e5CCEZhSSKSZhPyzqYfRm8eequE0q5YFOJEu3rbepmHDPd3OD1WLhR/vHFWfO3h+K2jyy+sR29fK1U0bTvuoghuwpnb5C1US0HVX1Gc7TEwQuzQA/QrUDlNHkAv5yKDHRCmqwr9lcziQd/tVEBW94J8XeHGOhyPcbBPe5ufrg9gjSuKJG9HY3r0fRg88NrITAqQMkPqW7pulRHn+mhGKDNapBJHJEG6rUEKKOQN4prLDqWiNZ2c/aMjKCegOYuhthTT16CHIKddkMdu2WkFULYZ6CiypkIaBbT/zt4yZfPHkOM9Gkc7E0CngSl7AR9EhQaeNV3VcHM/aFHYJzlvWiSEoUOP9seICa5x9vQL534Zq/N41ODzJd/6qQuLmJJMu3kYgNBwiM9P8Pzaxo7IZccBUAUc01P1SxUJVsHAiE21zihpC1Jei6to/yo4D9KRrswVstVPNWdT6NaCk7kCDMGt5s3AderGKs7iw/FOKQRKJK87UHLlPxyYLsjqF0WDSeSEYZMCayTVjnfmkRCtNDHwVI7Pc8KuELdFItrGv//AVnWsymOWM0GI946MTewsIX5NFkXiDEq04nCXjSzKYIQyb6yGEXOSmuxpyBFOSLN2hgTM6/k1e6npneLyIAqJAwscUtlSY41RU334cGoRC6ZdLFdQlip1lN+vILP72WuOB7IFGaipD4tn2lJhwPZaVRe2X7LFecHBwCkcRiGNTLWKji0/IyMTQRS3cC5tL68b3bRPEYTCpFAD+QxKRSoXAuNijQU8BFkv1UCLckIjPMfdV8wCgvj4w9j2xBHqphGL3AdfP0+FlBRglJxDv8/+rolglaA14ydNTzcLYAtkUYOR3+n8cJJAxKRYY/ywlCrrQ3Rjvb59LfgJ7+1SgJHIxdFQcQJbtfIQdrqQoOW7WKRsZG5Vo8SxosxSjW1C3gzydpzXankUCPbEJ7f/srs/IHxwUvdv++ldxY570WVpzqDqgewD4QAvFW3gPz4XEnqbxyChvmyNszgm/fSXPuITUGaC+QwFuOIEgycsjuuNEMQOEGnItrArZjhse9Zv/kmQnDq1t2ArqnRaETR0nh6U/rgvppH2n9yviYMUy1MdXm/XLzhN4ySD2CetfNKKKIoxlQphEj7mw97SU/gQUrPMNBfGHtXDKh1wCMwX44hGepVacSuD2Nm3GoyZkcZAnBodTGdd2ZVyfvlaTDtYHAlc+PXbBQGviC3Q6gioFlb9WAZ/BMgecbEGUoQfOGuvWCsRJ4ziUoZwhUZElfIfPk3CRN+0jlJgcUlFzK+Vu2AU8XMCNKGc9JN+XDCeeCGB/uO2cgRpPlZYsq0FpmQdmjxMOSdotFf/8g6UGKeDvCLMOlBub5BPsuQbaedh6ZbZGb5DaFTRPqUrz1X6UZYSMziHOIj7H4XQTqZwWJFVZus+e6KqXVz3v0SpJ+944XaYDdgv+hNrZVKcgVAtxMaCGWj4ltDmySrkSsl6Eui8B0WTrfL6Gjl2dznRDj6LH+jeJ8SxL+vkpcmXEdoZ3iEgkY6TYMWLOF5wlurIbYl56ifLyiYjWCcVLLO1xcWHPnkoKBWcFRKy/vqag1bZmJk7k/wNXdg6vkKf1yUECEP1H4mAebPxg9+KVAS1pU5IGZ2Ao4uGdM3+rtHSeE8BIr00TFHuT6BfbYlqa0w/pwBytL/GJmz+2zQxuxOxSKtQPBCfXlaaCpruQ0yxygcFnLwfWbxtwll3S7exEWHdHfp755Bh92Zcaav216mF2tl89q3D2Te4jnEupMctDyCiWlupXBbMZD0Lm6tAkxOze+8tDSLXY/dD5lkN4kB03XRcVZKFGo3dXDfjW2lxvXyvCxlx9BNOgCOEkQVQDf7TkvQiqLBWy5Usnl/Gmkc/QRmjQr4QtAI55OpYftguwI/pzc0O/gNH6C7gox1GTbHR2cpBqeamOepMqjSbD6hKC6e5ABHu+ZgCKUFdtF9zBNS30f1fURxKQGKSNiAj9lFG0USoBipJdqqzXstjMiNPGPfwTuXukdMXh9E5w7kBuYZ4VinfkusPFJhG5wzpIUNVtiDs7LuKemmdCsRyIiXvtHysArHIgdQQyp/Pxzgdl1utkZJn6oWUA9vx8my+3gkAsyiPz4I7eegdggfeiUKkUnMY9QnL7ElOrauMSHai72EF3BrLaXrmIXIMHbBRpuXPfV1wPlZwrzTpA7ZydTKz6FwV5EVVCJdF1wV8wnISoOaRF6jtslhTN+Dtgq863uPRKfJFnXTQ+1pfTu6R8MwCKsc5FHhxoDOtKMW6XBXhtTt8nwdJc+yaNdohPJtiLuRsuobCl8/z62CCvTnJFFTVU0VAe4UMZdX7o0fSUrNuZSi6i8y1vtB5f/SHq7aXwkz8MAdTWNMWi+pxywYYDtx48LTz2OdfM+hLkeWpYEi5AgYVXAtmyvXnL/VQwHTegwwFYnvpWB0SKY6pzlBqHiZlvi8yDCEo2fYcRNekeEvWZhpm6/M63bDpavzlt8q98wgnYJRCYRJEP3+IQpK6vU5jSuODIIqrs6oYyN9YnYzPJihs2ZgVdXMOtdR820lRgq6s777UaeuOL73xd7T1lfT2sQx0NBYyX1f8M8pN0au2njgNtWXneN91I/WVZO6FC5eSPoZTN3UsTWT8FmodcQPhASafr0ua2PkjMkETZX0cAvNIiIebSXiRpTSke4qYpQq7rEyuexsqPkxMJNEP9mRRbwAd0aJRGboPLHu+w472////xjaVnzn/hUow8kj3if9NIFsqyLFKb2WkQm6E8bKc7pOpmeBKbj0wPiJShPQswSb38j1OABohQCaJUO0cImgw+g5C9iOUIX6L/oXOv3JC9309XUF4cwUQt8GcLzeURxJgjdoEzEhJawRhVxnAlKWLitapGeMhNRoySiZyAVXN3SMyha7hfzgapvilCFF+MIh+EDWsG+0J8i+8GjRCXHf80u9EKCkVVsybIgkRt7zUYRKsLWRQSE3C4Wnvw34noyCfvX8IRrkrA4YPQIDfAafwcZHQ67pvQhxyhvaB/SwKau/SzvTqc6gQrBhAh92A8bZhNzCge3DKthGwCqB3uf1Pdocvamb/leObLCIw965KvN9T+YtJnFAhwSvGuUMyrTf35ZEr8S9joujhCRDjk4AGckqVhqoAzAJ5t2Tfiq3tRj2+xBgutO7S5hC+ghd7EMBmqAlwyORf+6zjZPgh5SMrVX0kA4/UjvxZ12AdiQrQ/JvXDOlBwBYc3Pav8dHucLXC41P5rn7lxuTO6TOH3jIn7xomHD5rCAGeTupyTsgucAhByyVo4F8qFrhiTYhLhQz7fZ2ubXOWnj1wUzj65E5vHn/Zh/N2L8RjfSr2RyKQcC6i9zkGVI8dZ8RLON5apn6FUzv18EaWvSM4UYCNVu22YG4mvul7lIPt4LbEK8FVUYw9rkaGziMPEBfYCLtTq9ypFu+SLzlDQa48E+tcKERZt/dR6+cvnAGpPEDHaXEV19PnM9cmlZjmtcd1+Ua2ushoCi+YUEIHF8vxKwNZYJ6kvoVmqY6k4EQiIEJowbWqQqda2Ad5H3dqEhaSBhY0YiIGswYDyKwgDM0hTQB97aNQ9nx5h0ICRfMbeybFzBSQwAzn9C78RH/JcI3FDWCSN5N+DqT4W9N0gQctdR1W50Fwsg/ht4HeYWoznqoIaZD6sMGVQP/z7k0/o8+wdanDbB8/RNfRWrRnDtbr76ReMpNGGEDAEILv2EbpMgl5tSbdCmtE2dRnaILRW8qOFDbsS3xwP2fghZMK4n9Mlo7DUOgAXJJPrrruQDAfaIWzAdrk5fntRKJ6nh7gEeE36vMXxwQfi7ramI0PO2xVolO01FiyC1tvEkxRBmVJWzJlwLP3Og7B9lWQXdD8rAyMtgskeasBfF8hCpexacq/0OJR0qs7yzR8LUsKYLPpfkc+JbCCRjnvGK9AVR+1Vs3V0yTin0YNVF/KI4aiJJLqYIO1Vtl0OsZ/OtSPaQJ0NAh66xLWsOtSoALnjHC6cvcJ/ZJJhwIk5H+bBlxe0SRMaGQu14KO0mDDOpcniemP/loDsv8eTGzz7UcbmhM3egO17rvI7Qxg8AptNwtp00JVhIcbnDnXW8igwPruVVABuY+sZssKNHh9zQUcXL6aaBD0oglaA2YYfBk5j6+wNIrK1jMkBbHnl/djJBcf53lJaR/BB73oQwRLQ0lxPbA/TAp9KwM55GRh73HgrOEv/XsN7wYdMa8B0f8FKu1AZD3t01BafiVl5ofHDCftMf7CZBRhzLnAcbc0nIzvGdsAmV6d2K2ZA5/mY6Jwtcrvec8zts1PM3Uo5rPN4Y1NdiPncZqsje5TKancqVlwOcQddG0MNKFNSmhQumtTzPTlblLe+xoT+crqWFbiTMoHpjHiNAYLMP7hCxvIh8N/YWCoYJJxdMLULX8+EHJ39s8slc/iPI5OAlo3lu/u6tWPlA0rwTeJvi3Ggfxy+JsZCLi4Exl1DMavdsxoJPCS8opHDlJk4O2Hiks7LE5UbdcDzUKhNYEVYA2KioHD58BiSLBpXvDzZ0HGDCyRj1yPC9dVWXSbUD/72KoXAjHFJ3iyxJrU4Y11cv6vSx2pPQ+GymjAtSiZGTgkn4ElHiEp8t40BhzaEJzUwo2vEheuwh+KRtWWaqkUQxdkwXA+M9pCMmq9x4IKIqKy6RMvkcuc++S1A1+I3B21B9OFjWmElOrhWyjNXqxl7qLI7Jnjy07OlqKMKdifPrZ1ENaNnRifIu23dtBnp/qt6Tw24VMmW97FA6Qp2cKG5xsuR8MlZNYg3BhJBWP2SIxRbHJql8BQ0niaR654G3szzAGxlux0XMa5ILpqwB+QLxOKg1IknT+7HvmbSRqGkl45yaZT2eymRfNkT2m5CaDPDbcEG2pluCJ7VkBDdq62W6gGE2A5c3NEi8B6nEDGOOcC/vjIRtnocKT0VOnHqeTL7HGB7IehJfxQZDUviCQO6HlG90JQnP0euMDIqe+Inl3fFz2OjStuquaeT/NxRpGJUpbiM9PGjQUSdHoI0DV8pqksLNf40roqOaMN99+1P1EZzKydC2JEkN2Jowvm7lI6KVG6/mO7CPUGhNPamauQs2uX60WW+K80wxfO4WDlI6+wgfKvBcMaELHJmTtw8oF0XjQGJ+n4zKIhk+H4durKRBRInEOKWyhJbGvUgHC+GeIPhltZzyhU8FGRQj69DOfZm+oHk9M9sSKSJQS1URKGXHySVTFnK/eUbDxpqqgxR+gkcsxEiKCHjFsF3A3e+uHEXOgT5bsj1bY+N/nOu9ssJo7sImlVMkglpTfjK41D1dWPOnzXsOHjClsSI2XApFKIs0UJM+vdT3KAiEIi+6E6dohOdp8yJEpTMCBOFycPR7jz13MCOioV0GkVKmhxl0aOed9OIACjfBx3TOQJGe5vsUt2ETs2u/TljUv0t59Bm3zY7bVltfJvVo25XReZc3U24zaBDE/DKwdpW6OI2NkUyB5+XTVXb+xMBfOdEI/h3XGmwF1WlZKRdnKyKqlZTLId0+pTEdiJculNG7yF28MbrIBYq2sFhR6h5MEscK7ukxt82QAoDuvTupv1ccxZu0Mn+Ybv/RbxEJSfF/mPADw3zcGZvm7GC4l5Qve54ooZMhEJ5QMlpMI5pvxqfMuiC/NMEuVxdsvYVqHJyLVem21lbQoRrw6iBbyqVfIp0DAkPactxrVlcwqJhbdf8b4ZiZmONcBjk6yww3jviX9xzg7G6r7R+ydGyk0/xGR4yYaz3ANRj+CyvyfR3WArAesyNJb/oHDxlx22x/iVs/yNX3KzUzEQnmVHn3E7Iujs7BpC48OWl1ORaPlHnHyCNeRNvUfttzewKaF+BBJ5OCUdtokBYWOMM0Ysq1Zn7Sr/j/U2ovnFZMG/4PKbXODM58aa54uc86fsmXojZd1Gprb2dpViz3wJvpBP2mnhWprOzjcNHSAqcv85vFDw5BpxnIJdhbPQhkI15blz2WuxFXyYZfyORY1jnDXGmxbzFVNWtDn8ZouTPzvS5qcydD3qtzcvEz8PLUdjH5n0ccg8geROvhFdfp9u++dBlwsdlc7QMtD0LYkmIkLwJVMB1vT67muMZ3Jwm3jIMwLWFhOtbujhYowmUkT34XV+TzRVlkYNyPdbwPlNW6MNq2xr1d79ik/zW9FYoUO6KviDWRnNJkrBmwth7J9b4B8NuFfy727DPxDOcLKycpjMcnDHsvtWpMAX2nSnh5Zc+s1QeQ0xz+uYA0NTEUGYEj8H6mdaeuwOGlP3okFBt/0WMNzyNSdFydMuYRw3I0CMEPeg787iVejIgkxDz+s1Iw2N/99Itkn6BC16USVo2My2eRTtwu6qj9zXjvvyKJwQtEKeoVKiMA+2noT2xyrBZuaNuYox4MhUvZngNwScq9qjYM6pqdt0DNCbUtXBdX0IdN+uCDS9FGt43MYncEHvXUppteUDmLq5KsSkBxHwsa2PGCvMlStxSylt5wmZXQgApwvuSD8Sm62cpaqHA9c2LbmJHTSrsIsPqRL7K0LOsi5Bg94rDxyEUPww3Hd/wLgK92miFBLSUDnW6dg0UiX4K4A4MWRNO2MCw8zkCwmZCIOOl8vjsI5mIiZyOZIeUI4ZhkNFHmGrX2NoKIvBJirv5W82OmMNnf9JfhG3t5U3KPmJiY2hKj/9gFoZiGJtwsTh+4w5kTE1Fn3soqpzB5x+UpP8t2kjgwEEgbTu+azit1EZABnCDsQNR5NgwBQ+RlJ9eZCc4w3ecu3uh0CTjYqs5wp2azDnljIHLyc6baxVst2rjXg05Zvd5PINlJcpwkO7PG0TB4FELEkONsgAaCYvGmQedtMI7LSatcxlFDoyidnD4BgLNo5WRLj489GWO1KM39/4LJgCoUkIhIsphw8zeoRBSzk2/FcESipAACnk/qcBvyZOa8pbkiskk73aWttFkY8CIBHXHwyf4PqAi1O4N06NX9c/tiw04E6SFtqO3fYDjo7tc80f7X74aBPGZkkLjzdOQ7ouk+siezr5LJBsm4mKM2qk446IWiPV12/mkXcY9D7UXJCbiL449CuDzOT9JRNDduuzOU7tWIOQRlfrkW1D4IziNn9Qwch9RM9iSfJf52pjmeghKF7h8SDH26K4D5iRjM/6NReOHm6T9SSxnwCZ+7OOY7o4MG8Sh8ZPUArPAfpDovjBCcFPL9+2uJD2+nCu9jOZtBsWNU42q7kIx0cHZrXjRklqSdQklbApPWx0RxMHn2bs9SEzafZvVoo2HWvi4QoDNhT3s2dNsO7lhaHcZA0z9cR4H/gswuym4PghzpTzHcIQwDRp2dDyiH8i4t4UvJFmQQhhMhjPs/YpTr9Modm5tzyTqZ7PnrxWkSPsnvq1JvLhgRZkw54uqcu/LcCr71YDcGAapcW/HbK8GShtS+QoIWHqpFT915YOXT+n95Z54828ilnJqBwe3vgJOgFgYohhZ1Io8K6a0bAHUnM5B3qT2zDFGtWR2mooDofBX8gbl2GdkujaidpzKRNlwxuxZ33oUrdVbw6dAufVH1N3/IKM0rT3c64cEOxFEbC6CH5pZNz+XMXxIqHUUSO8P4B1+lh0cxWbzyecboPXlbsPpNZ8TMTGjWv190mP8L1Ev5s8ASoROlLKcTHH3Qqn2DIQ0e31eVa0TXIY0b1j2rwLyLTH8aIr22YUHT5K0dWpSV079SUuzqVOR0CJ8h87ZamTmYnM+lgtRFfScUAgryeqO5EgW+pGNLdIOJSTLprKUhqpdJLZc2vw4oeoqf9B5PnR9Srs0NmVvu5iIlyv8XUTp0FdxcqnzseW1SKCpmdHLCsVZ6DEvaho7ZUI2+cWgr0Vfk7T5BM3TdGMS/qqFmkxBOhZOz6EwdhqE7ojRKpPIbNDRcLXl1JCP6w8DquYsnmnIIZIVTsq8ZocOgGSJ6e0euMdVO3V5fWWDwDg8JqLkn4cVSGDGUwKIE2cogxUsGYZSCgnsTrYhvN82KLHknvVzhSuMn2SRijJB7uGLmgt2Q2565quZexjMDLreaK2xjLgASKRfxEqjMLq/l/aUiDVBfp8aPmJUnCThzZLzpqb721QdVBpuLrl0msQPWNPBUVasjTuNw1Viytx2gmPgVw/0/ZLT/aXMqFRFof8baLYzDHidzJMV8jehj5LyZZ4oOaCwTctv5GNGnxEMtBRb4sllVLEecw1Y1aJqU/7jUj0tDRgOdA5cT/w5hXxOhvrHW29iAE+kw8u8hCE2QMQY7agvmr1iWjIi46QPfg+Rq5gSBEdVq0IosrqZXEdAdhrtyTTgvCUqiB3vweXrFTHrPuL7I3sqUuz1LNqcCHw5hJCGP1EqTYMYDH+h0lx4pSOfSPPL6TxycwfsHtP+GkiNN6uoooOjm9Oae5L/YYYM9XTm/Y1CGVwHVzK2udOH78ACA2I4ceIZCOA3GT+J+FIV/m/NuhtQ5xs0suMWBP8ez3b5wRsST9eIXmpDi0vprx+Ha+Q2YDuyysxyEY6rv8mWPnmC7g8WQhYzQ+qpWcLooyZjpoYZ5woFQnN4WnZnZnY9rtkLX5psrWMg27ZBMVeKXdrnbGF/59id1aXhEb1M8Mb5oQYFxFLrSNg/ZCXmg76hi48jf+krR8DNDrxi0vZ1sDMsA0HQ8Cnomvkve5AK7rB5z+Gd3u+NLpqXVS87/SDl/0rNQ45ufQuzgkATWrF5jSBpJRCadmZFP6P57LMR18egqu5jA7PbJbfjMCU3Ey18N77rw4wlMsA/LIBnZw2/51nO3N8Y+mgSJF8ygXk4fccbN0RUsjCwElFKfplTVVRmf+Nuw9I3nU33u3xRAi3RLVtgKKgYFiV++A5vxlmUWgskpF/BAuaB6AAQ1vSv+pI8VSCKRtXKcVgFACS7gI2ffgMBCyV9+VdircGouo7RI9tzxd0o+cZJUqAyvPGmdoRdRc82i+scVHJIlFQtQdjrmvmQiHilyWTBFI0TUOdz1dgnXOiycEYp+QrhegzGu8r7hMy/065p+7SddqrrxUV9jtCwD+fIqBXiN4F9ANMmm6gRqxIhKLiCratgbzKhwum+Ekhw+1gUQE5VO550Vk2P3eBteyYgMZP9glugd0aJSXDDiGeZBXmObMkiZSW74Vmwx+pTryJGuVWhx95esBK1Ia5EboOpdpaWmNrYb7/07NN7kr/7je6YApf5a/YUSkZdlgyyitZ0ATO2hBA7FSfUVZTQp1zsPme5cGBq1MDhyRK66Wfp2JRPBU+7vyZn8SP83qi7hI5RLNDEAUvj45A+/Wf4ipKM3QvUS5LSOtGB7q6PvOgWcXws/QNd19dpBz7sZYktsSZvrbJxG8NTofboWahm0x3xFZMU6VJ17yORupLjjnTKK58XOhUAXmHleUFlmh11QwU6kS3g7p5UIMX29qeRyl+pfcvNYlY78N19Mb8cRnk1FCPn1YcgsECncDmCd4666EAUH/xbYKoB2mcr1PlPP9psJoD7zv4GoGdydxP+/CqrAUzhBkd8SVcwuN8X8bZGakJHvHyTSJqACJKDvLGj7Dm39aIqH1pLffTM2YTXESplnzX/fLJhXsGx2jBLTtwtV6cI1l3uURkwECLLnkV3e+OcfVNkwAQMLVwTplbIBM6cSUV3SYS51VO0GKo5hwJA0CjplMx6AgiJMoW9p/fvi3Jvhqamr6eFHhgLpzbo8OKNyPUH3CF5fzkIPtj8BE0Gx2JM0lZxRGRcWF2CLVhK1QaTTsWFl3HFD/Z1QfSM78+JRamxtGK2JTWNIoW7Wb8O/8K54kIKS+JlAu/Qw1IYFZKX8nzYXC552o3QpfHz9AVLF30mLYYZg2BkkCDh25dJIlwkE6mcB/E/wjhgJV9ZqV3T0ZQS6j0v3HnKqLha6U7jwuBjGBEQBgOWi8FUwQTMhpJs4A2B/w/uigDx6wC4/LWgSJFvl5J2kIkHpj0lVHQqSO6WMqSVZ//j7UDHXbeGNSlXZAzOMhzdYTLHVqfWHZnqTiBLYVvoatDzElzlI7Z84mzIPuJm2yH6nYR04BDwWX86NAdR38SSlNJyabVZk0TYU7/lEN7TReuKSDMWOyvo10ov2cQiqiQ5QGdcPhKwIYHPWUT2D9Ovc3joPs39R/OBf/5RMf16sosvCvMvBC/JB4dTGi959JtQaYBvoI9/4J0ZqyHHgr2aV8Xka8EMkSSPkajocs7rAS7zkahc4Dnufe5p6ZIQKK+sVgG48fZvkmv+4O0UNGWnoyFN8qApOqDkBhJ7P5jCezSugdDFpobBX49IdHgCEVUrWxfsLB03j/o2WCUek5cyWSGHGd+3RcAGcI7yQfpTWf8vndXvdTKVgwH3pNSqVZ0/sljOlcciWtCQ9101bS52WvjPR8vIvsVxyktHbWAEh9mOdYh02uVaOB2JCHO1GKNdELBpI5+mb5Kil0T7+6Srg5+M4NkbQP+UMLIlUQhaImhBUCIDRxcTiwQCmdHobof3WUZ8ZdmUS8u19vwxaPUdTlj+qj6VR8RASL3XuY0jk+hy6uRDoxm5psBxkqFNSjISGxAHYqYJHY/fBSV6fPLcUR4hdUuhCjXHJikOAQhcyL394XT7fFUda9SIbpK7B5ljLUwMcklxCv50VPyM2y+1izHCJAIZqaTGJBz0wQgGRwrM8usoqGNesaIogE2dMAO0gqJvErfkq4t07vzwczYcJows7YeTE8MNFue+i6dE0HlCLQuBH6UM2MC0XrIpjkDnPCJewjNps7ySHM3dJt9FvyjpuBGZLc4545aSaklo00IC0MvSG5Zpzv2oTkb+jXCNfMnYaBnDJY0Z7cKE/YiS6BNsTpUfmbXCqudVxXZTUyf35m7KszpYAcAvBRVxgYzOmynOQ7dcrEmSbPlSKODP2ufbTGNrOas5ydMwmXxd8SM6pZ10b1993zkEMPiDLctBjQBg5wHMazRu+fQKpyOOuwCMTQEvpxGQYWPw1KpYMqebKQW182Pru/AF6NzDEFNrSd/HWBjmDcgzuBQ7cGS3QAFb1QRIUgzlwSyi4FBot747jrrq5lcvRuabtNY8znra33RYquvyAgWJZUL5l7zhTrH6K76plXoLUdFgvud4xaTmG6dJsNKGJMJjLD7KWqDG5zY9RFgm1R0y8cxFwLU8sL6b68WO6/mzoFMj5fPb2Ju3N21po1geA0nDiyzDSB0U61O147Vl1Jt2LY3GbGTvyuuQID+66Mt1qk9CdnxaEt/zh/o4+dA72iF4fgyls3F66siUzdjKZtWrYokqSxBX2VCqU7cTcTWmdMmrjKYFp/QJ9lvhSPa/HGA5fqFBbRjXeRQksIhQdC7IIRChPkUzOBrbNy8V9hdOf6JqOlvjsGgGWbk3G+/KDuglGdoBUTebcDoLNSOa0gjggn4CCTAGwuYcKkfEkHuq+KLxUXaFE2sPOnsstRxumb4kO/QsmHV/W2phohlCj3tJwzAOM6pptyO3aLUx5f70+JRhbVDax8L+cfCMwY+S6Xu4YFOO4M3A5rlE6Tat4JA14ih0Ty51sb3uGdP/Gg4d47YiXIo0ibI0LbrFll1J1OtL0VwTkbdNs92jxU4nvTP2EPUnbxzHmDRKp6UoHnHSx+syMLgdILgvFX3mTm/xokj/iJUSW44THU5UVfphXPRer6w6aM7MQE2Sy7XItNjLu1MqezfIQpIrVFt1RB31AmLwW7Hjst3Y0xg2EAxcm1qXayMsHdhDQcYip4h8jo4bEOHyD9vZ0IBD/i3GwX/38qZ92yQYbeX3KXpLKi0BJ3m+cgurWoHpbktfxb4RDrYTdhYL6O+oFR8XFgLqrkzDiCil0pK0fvD61SCarpEYRIczQK7qdUZbGSyWhOMa8apaRniZMTC5zYuL0FUr8xBUOZ0fRyoVy0aJEJ6yT5Ttf5qcMAMddpdW+8WRuAUjSL6OQEpsUdR+v3G1MwwFh5+TBXcxoxdiiCtz7NOX9DMzr3I6gklmh/rKRroGst0usHaku4RxcOfFAGWCWtLtNjAOAiPsPdhbjiCHtM3H9qyzOh5YMYZEFh9rumwNYpYshq8z8MsmyN9+wh+bmOQSb3evUvYFHtXYdMeBS8XQxTc3x65eLv86xTUsSggO0oBsaFDTWHX2W9Ko9x95osalqttOoXZoVQG3awyV/P9VIyuM7TZqPh1a08OWCweqYrwVAtsQEVvPOCjhiLpmKIdCpCnaNZldxwuzSJYuuIynGopuUscIGsL8ODj9Y5Cc+LD4/pHzAYNtkC9wflPAsFHfXiU6b4xqeIU6xliWA/UELTb6MibOUQGntTzdVhPdccgm5fNLcLrTMbv/NhTE54XNl9pzR/PAEwQ7feLQ9rtKw8YASq+ypC/9r580kSYov8wnfgi5HvtCj4/EwHml4voHkzJSPPE2Z7HS2gB8UpKGTGI0+ReuVWW/qM5Q7R6IUTvdr+DWCaZDazSxEmOfv6Ed3tXyUD/rs7G4YQ7XwXaf6aJ9cMqJoyLJEKClV3I8NPjL6MBFPmOsOPZxoOG5eIJUiipw==";
	decryptString(A,"783e007c783e007c","Password",oFile);}

void writeHullRad(string oFile)
	{const string A="Sz4n+IvIwQpFq4KqnxiqT4ZXzaqBg2O1eeZz4mfFGrJt7MKCubBhfFnV7dcOKUScMjyJSBaqEgNr+YEcgca0rTbvktqSIMNA893DeRX+5FwwvGgL9qqbEXyLJPMpI8EO+v8m/DwDpvY6OdBNCrNWeGyGYAJzYy/9biEE94vf+ScJgeg6L3CIuW3KYti1nZQQpeFEEdelb5gIRlw0j20OvporPaQ1FvnLUPJwGUrsi1Lyaisq+GNeDaUuCjrgcHsIb9uj/+D90nQIsvOln3KHnR6dv2c2lH+m75bV6NiGnXqKk9ykbRxMhWeJGjGDasqvq8lAh1QbO/Yrm5GoDeLBaFpcfU61aflnibSqPfuLVwB+FabDuWjU+8xB3Dk5mUTXICOk2KehANXa+tyBkSqeSygTvdDNRdidufwS3YxOIjV7An4Ni8o/QRLpL/dUbqYAi4cxCgsfUkVDAxQBMdg3mr4hhIGAMmtO3dV9dMDzdfQyP8ju3EA3DXu4wzLQaWmysMH6DoS3r7mS1vvqcPcKh3JY6PbEOqLIyEg/P2XUzOwknPD+b0WY9da6islhzsSP2SrcpZrxdcb63swOd9ydZ5/WU/ErZ73yct0W9lUWPxn/X2+k31uz7yGfKp5rP2ZGRGMT5yh+fjV+DUrRTQCnbZzarvMHJDMh34/QLCGYdMZbMfT0E412TtwuZPwT7ZnqJ4zrrQWeFV81KxEAkyj2yEA42pW42p2551qZVPSJPts4AcExF6UynSPGNHi34GyQabxv6E/RYQ/MiFwmuUOA3aCqUiJ5uqy4f4FsX015JttjPyKsJo1HstU91kF+rP/72rQXqZfPZmOYXS/wJLEawOpM5lLi48Kp5rxd5LrikbVyepR8UkbIJb4spAexYLaI9cuU6gYmrX41NXa9AACX4RJZdGW4oTbqbT4NRq4O4guEysHq4FKoeBheYg17PTsH0vDiwK2HzHsWYnSmpifFizzY7wLXVykFqcvDGpWB70eoTkloGM9ZmVbSoop9ll6F4LHnwHU8yNky+9WoiuJX4ryqxT0ranHBlCyb7k6G6MJnAkaQqPX/fiDQ6tmKxD9L6AaPvZwJ+o9DqH8hKOKZ5m7fsrRzIcSMHDLfzo9JoeGVACqvaeDTdBXu5pSXls0xf0ZtYe9ka4EI1FnbVdyvpL41zv5DkUA22xaLMLwpDCl8gnegykWL1lTm2XxLJzp7KNTwL4iA86uJG+LBOF2Kd0K83jeaMi1Dsq/iZ5L4WAW502iHezVQMSWfmRbRm98AH7h9Agus8no234NkA1aAEhb+FszSv5cw3Wn06z+6N+rOlR7ZBcbMQt6Xj8kgPwDMn4fvJcgubCWbL8pvSuiZp9tSEeWmR/tS4BZcdEnlnDtimkrJXM0B0qCFVNKLL+6XiMAgxx88A77X9/cO4Jt1p90fcRlNJkkorcpCwwK+pXmrUFNoLLYGFZ6FupzqQ6JENDs8mgyE+nRClLokuhzFJBS4TTti1VSaeWHG/n+XaYmcj9r5CFrqVwDZaCopQ6VJck6+dqYcfGuOdV6SDBN1pMUL7caUbW3HVqDGTWFuUYzGNCp7wY4/86FjUPkcQdi9nILbzb2rMwx9wXwPz5CWNnDLOjXxhrdRyfj78ZjmR7+eaUGcz+wb+shjGpNh0Fd2FBm55g67J4+HHe3VegWpMCpWLNS+MMSM4NJzF08w87tDrzq+nr46HPbQt6oKPuMJXDNTjpsylDSMmhvk4UzFA+e07k0ZwgA4GYDxhDqM2ozpGr9Qh7PF64MYmfPPh/lHQ6KchdvAxVT49QzbRCC4DF/yDTx7/x6QJ3/DdlcWNcfvY1cssIzX/V9kP3FYriCsdIr5Diuo6DXnMGyMsM0AP4nG20KfFOkwhBlgWy/db7BTQkjE8VnA61Z7UhrMcxqyMpbTUr13Gb3sD7sKwQZfg8uWSCP9klsGFaBQ39Expu8ooZme13x0kBlR0jJn0U69W5zEPzAYD9Z/jVw1MVF2cKChYiTUvJAx1kILj2vGDGhwCeYdzDth/4czzzkFWPdPg+kMJ/eicNsaB9ClTYjCvPXv3fP3sESnq+f5D+c4VkcS/rXFrNV1JfbhxktuK5AlwatGDniRtRsTLB1lKEYv+KiRBybD9ObTzEWLd1sna8Rk09e6lupIm3NZ+Pdr9hBE/XcDsUZ+cW1r/VmskiH3G6oX/f0ufxhVSQEZ/lHphKT3XSXPXN1A7WaeWxHpLMJbLMQd/Pn6TqEW71N+kmepUphAhU3PG7Bo4/kudDK0OD1uFgQVF/4gM73mJbFPev8P7DZnYkPH3NWkjzOum20yV2GHPkSYDw9MK1Mc8n0nY6TlWDMcX7SSaCS/3iy+SYjxmmdaUrjBmaoxfxgu4dsVQxTEduVzywb9kfWI0KzFWkcWtISLBSZhmPbG32RVTAc0TtiYk0pOMwdMRWr+d8jjo5O+UTU9SqjWYWsf9n0H8Qi97KlA0vzYY4uR2Wa5bsmaZfoFcxiXdy/YmxekPsw8vcKv+zO2Je7A+FMSCi42fcj/3G8Uw/VPQE+zE1d9Y/EknpejiUYgDf+T1y3yrXTpwbph1TmRxUBNnbwtlqGa/w7Rf4cZ2WftOrStzp5cVgIVvCI9NS1kxSt+3x4fdfCkAwkHBiFjBmcviV4vBMMnXkUOHptJWW5nncdIP4OxFHk/KcSCD/tLXzCilhfFN4gdfJoCxPM93TjiidJ0xPTMxjMMJk0BjU1jGJVLqB4IrXPc7/a0zXavGMNhLjMqRwgxo9APGqe/S6i3umfi0womGdfanBnYwjucumTsPwRo9Sxc8MuiSDmt2XA9gMcLEuAzYZGg5IK8HniHkhsZHM/EU9GR0mHIUAkjvQFuvSr3/Ci+lTK3UcEdHDsx30pjf52PBPB+GvhJEaQoy6V6pmjwu5fY0k3lZLv30VfQBE+4OmzO+RC8zKPaz6o2h+voY32HSG2+8DQl1S2mItU5RIbX8cyVzPTV2to7TWzhbyj3oBIQytAbJ2a2GFdv8GaOTFLF4fhKGw78+48TSQMZcF8iKy+epqWfHK7FTPS7pT7N1N8+w3TaUXCQj1o+AyDcfIyWXvt7AJUcnvT/C/xIo0OOvtC5Ur3phPkxKUST7EkFHR5ltl45f8KqCICIVm0cxxgxkN5u+bAY0UV2GXH9qRkY1QExpF70u4Fg48BUQr/1vGj/+qBWmUmBY6AD1oLpfc0P3fZKyxGZ6Wnd1WTyeRmtp3HYCFYZ6au/9j0fAS7i4/yQY9DlnpBRZo6N4loerXmYiqelQ4KPKwX72GDdyihycafMNVPZKwSO9ZqaZntYL/vQKsfvPFqZoTkMWq+X6N/96egbbSIdQrDtJuf9mMVYRrvjbh+bbs0sP/7R72YVvz+wmgHUOhYC/P/jr/YSx+QSTLJBy8y8tJtFk8KB+2eK+ibQtJbfq0SHFwKHEzv2gpAqWjdEDCixX9rN3bCZNYx3+mdqUIyA73aM9c0/iP2zQMb25MBw86P6jpVUIboU16Ydye4uOTKxDu4GgrIM2NLzl3pZxRB5bJzXq8gVdhK7qfXeYCfHo8GfvrU5DlDpLof8zS09Nsx4n/mt8ja2xOlwiOjmnt82OU0QAj1IOmGBfKuo4a7aLVbGRgZUCvpWu/81Ixs2+xfuWcO1ozEBPV5++lH5foV5agm9OfKZfXo2lowgRq12jaBHb1ZBi980OKoZwe4njxDV/yDrGVjkV4W68G6p9BIjw1s6QrQJqgRU2LABoN563pNlNvnJGgJ3aU9v71jLfb9EeE1sje3Eq/u5qPc5owwTdxcpJp8TQydAKiTbIfKNuTtmPLbpGrtXoKWQixvj72YZtOadO7lRzL10+RpR2C5X2Gnb9nLPEhiUUPerlnViag2t4Gs/jhOZyCA8uZsMFnW24k7br2+jl36eH0QhJQAOwzBHGzUOyxspDg12KjvgInPTwVZp4uy74ZBegEHDrIZs7k+4pQKy9L7+fTXKwRh6ZSno6TQn8fJQF6gojiUCGSKwVRUQjIHpatOWpYoPZvE8S/w1Dvkx/BnNk7LYUtja+KHluZ7JrYRn0zXxIHAQJkB/w1xdWAO2EnxGEv69DVkDwtBNURFro3c4fJkc4FLi7ahxJCFt3EhbkfWfQ34kCGcs5/r8gT3KOmEz7RqWuszZmvpkXwHeVWqSEol1u6GtWHbwUjFRFDvS/BesINqUy808vrRR0+mTATNC3sebJkQ6mCj6RAQgi0VedpenQxtTUvPG5aOQYNV+y9ZlOpPcFbH0aeyTGyVKMMghMSZMLeciHFjNe5Cm4UAumR1njGeBa7OHpY3IQw2FpgWaT94rs0Lv2vd+Se5WnOhIVcUAa0VZjRBJ83td0DcS6/Gqagu1pEAgJOHuQFPYaVny1l5kdQNSSZbD0NPwje/Pu/UpLf37E/WD6BO9mRzVM+XjvXS7yT561WM0KYDtHOwAgzM7bAYRaDLOo6lu4Qyuf+O/zqIEk1HrNko33fbqCSndYyhUTOTmcsNlm/ZSknRwe0W4tlqQv1DbUxl80JQ1MWFfTRegu5MAFr7XDGzFncPLloW5zn7lpnQs1uAS1BlVmg3lWkUchdJ0ngic+o+XKCfdJJih6ubeKSoNF4b/Y0n5OOWZkz1rlSCYvhWem02Sxqjia5ToGYZpMbmy85K6GVPUT2ZEzCRNhXnogZCpYkk3uy6sOarnUqc9XvFwERlbI/0bSMAVQ791GaoopDs7wml6N7bafv0p7KfkZnkxyAoYcul3GFOcUm+nYRMu/3p2BvlUeENLugP+rhHg4TZMQpTvaM+8++a3CPjT7RdW4oD6iFV8UZjOSIHGlGKPDXCx7vveabQgl6Q1ksEfmMT+THcJWwSCqFeNmtzm05R8/7InMnZKq4CSpTiVHzbcjUbzisKAXK+Cpz3Abwlofc7YTTG8A0dkqA4uB7lclgNho2gZPG9IcNc/74d08AMgxlBKMe1CjzdamP2I/0b1f99niS4qTwaZlUnYR2COElR0T207pMEvvDRbK0p0RGVzITb0jww6qdQq9b7k92k+l7CWnWniAfu7/3bm+t8XkWjzRTTMZsChg/KfekgDXpkdRlpDcAWeh/GW+1Z8PbsLhEh2Y06Xdb6cabB3h1Oc/KLOuuokixUh0Wt93QT25RE2eskcQpTRav2zse4ymEavYhQvGF+KF6/Vwp28nLFXOkRy1/uhiMo8i+gVukMS1LfWs3nmswn99RH9ZUh76mSTZ+bf40lDekL2DqDA2m8boRbYDRLfoGoVMO9S5tUoDH3QcLSSwJ5+ShQcSsLVRQijWxg4GEceyGkyzLg/EUYCMtuTD+FDXeOPWQZR4iDTkJSZpEzZFO7QKjNs8SxdywDrHep2BD6qmsTaV0p4bWv48vmXHIswlyzGzIJJkr/TAXJgfRiJERbDfpRrMNSLioZmcajiXSGQlwj7786ras6p4VVzmHcoiCKWkfXRlzrbznapJYT8PJrv1zwnWmsqhDrtfcrVWVf3Iz9ktrRFoeh1D9gBJP2aNLsrIc1AF87oiZvo0g0jqzNzxK1zbnCZj4UgPpHcbwRJ6dggwZq4vhxEBUHiionSk32ocQE1pT/O+Jh/dqQoVrEhI4lWOncIOt43FIh90zTlLd4YIZV5RXyjECePEBGyTp8Em/QAgwQCAgNBw/Nvo+m5VLTZ82lhbmU/LYTqnaJ1yIIcjkA/it+8kNuCMtuCY+wF6y5FNb/ZAaSeyuTwUOI2t+qp2Zq4VpZBA+xyuhPPCfUJcf+E1ep+QnF0eVly9iJKD8FSM86jgOqh9d1qm7b9SeYPopTpbLXnhMh9+NYuo7sgZz52CZ4E8TsKcll9EoPTFn7JL3sIy+iywX4L7q6wdqJnfoDNKh9n/UxGL8YFHDJuh79hqfrSu9UWED16VjQ8w6Xh88LYXe+PR8nzoj3itLtLmd0Nyrh4t8E3QRNZPOCS9IlkHo1jGbtvDmqUf9B52ukp/fpMpe+TdLE5Wy5KdeBDN7UnQXmetjXuXpjqnomRLwDIVhbr0RI0yacL9Z3GpJ6uv/taAk2xceGatXvgZnu0LPlIvRaz6JteY2JDiSWdj0fvmEZ1NDV8cnWOuk4FrD9opDmL52wA8yrM6UdigzKqV6quGZEDHu7rcy5c+VMTE3rQbwcrBT/B/y6MAZN2a5Z5BDNfHbwVpfYTd8koZVyTUS3HbLr0MdI48zwQNasvZS6I5UcnlifKDso4cq99gmCkSxhEbVV8pU1/bIJacOtpEFelDkKgCKU/Iqtq1NyHRhmqqAMEg1HMTeqVKl7T9R0YmjfAPwZFbdrwVAq4KjgfYiTPJa1lunHdr4ElstwVhAxWYozj26VlKwGnGSIlT40wINXKZ2jvy8jxNrkNn7bsvUyKJ6azLOkLGJ5cicHFdgAuKQxAzFJXhPs1nbn4Y9mCVQ4CQvXiVY9+rnx023iI2Mp9RF7AOb8I8d/SQEc7TabKJPq/6Dq35wsZqPU+cp2EyckOkVCgif37EPPZPeuuphpjPAWyPQHiHb37iHW1XUjgbNJ+mb3Qi1Lsu9rKI6VU+2YuXjqwdcpLS7rqOQwyJwKCSDZhoTY8bSnPPK6PhESKk1mvDeym6diC5Is94WXSpap7bjO49HkCkCcMmhKTez4jItWTmOPcK7RHmwnrlQZozQcyquXvpzCdN3ms5yjx0PzgEfyhXxwrDGZTxQyWwlzPUSY7MajbLMSPg/x23uV5J6z/MMwQ7gRSqhzS5v3mx6JFPtkdNe1LuyNy6zr314ADpXEcAqqksOvwzT5L8UUuqxTEy+uQXLIwUWVVvXMHYYaCxP9wpnc5AxajW1joxZZPyVSloFs3Srf218EayaPEfTjApvSMkIxyr+G9RtvkI3+sDcMSRBWoDYUHt5KQ/c+Wvw9wA2+gPrXtgY+Nhn0ghTZz5U9CP+9JY/zr/gc4P+fuRROjVC2xnVrPQA4Mzk7ECv/RUIZRooeGlCNOEpyKJ+uOQtcLV9A8Ql+WkVZkEq+eGtewKk98v40Er3q5KHVJQxk3g0D28jQpkh5HUKnuiA3OMGc/8LaREagMN6ZTOg5m7LJ8rOiBdlRG0movtAx6co6jqmAkq3TQtwKFp2bMICdYzZkhCFwxfR0vZFHbUmKdcG//vFMDVV9npHnKqZdel+ml1Hh4NLjklNYSduzHPnbDdVnYhtno4nVkSM66aRALor2KJq4sg+mPiKXoFaxjAhvZYtIw78FGWEKOcMt0OgBTnhJMY5DnvdyVKjK9jp5EZLjQqu6OVYO0+gunMMNrc/tVdcjdggYwprO2nkZaH011Ii2eqwHHfRnF9d3YF9X1/pNuP53Ol60HFSDfgXdNsfRXWqFES3fPCbXYaG/T5LTVaT7zFFbsnYFZoU7iUTG5L3fv8Tx1E5VL89xnSDwTvi+GA8WFyz5zdRdDgtNMn7R+5EBkxV/35j1UeEypoNFDz8BpXYFBNEuTxjzE3c8j1bYfGRtg75ATy0WHpVJ3cyBjkpzvW/S6yiIJmLnYw7nQKytOk0CfQi3DcjVNgg988Fh4HKONEw3p9x6dutMOSdVzqJJy0TdxZg6H3TpGswL5YPNfsZ3z6uRgAExYWQ3K5+wFMsLiGh5m273hp7sDSuLo+/NT5dYI1elGccRIy12y4I6ukDW8IblIG+4GOdzvjbLSOPROs0KYu5ow+R5JpRa/MmplCKW4AUrW2ouGM3yylJosxrE5QvvtGxpzh+5zPsm8Qj1jBl1VY0xKQoCZzOUjbJreYkATOQPVFxkgctP1mSriOKaNx6KIZVdK6oG/kMFc56G2n659nxDtAvSvA6tBsK/I2Wg8t4kGpxDz5eDsdA1dOH1itbG5lPzR6Ljv59IiNYyvVfI66QQwFyyhQTal+FFCof/PJNb0vhWil+igy07sC07oCjfVoIroUU2X0SJtqz6zeNf3E5JI33GK0ix+DOhW76BC5mFaHgEuVm5/dbp2X6MdJm3yyMBpByrWinTgJy+gFg5svmWTH8MbUy3AcILa7iJ/ncY5Nfd1vgdBIl5w4dHp0+2gB+rFjN6tSD/aKBXT1mxTgpfG3+uNgJFQzHw2IZ7HaGijlfGb0f5F8CMbPZKZ++M3jRkP1llggwr7jJMKf4fTmCw27BhK1JagpKSkvW17jbuWSrg8T5FDqZXcbPetM3TFZT7HvXOVHG0ceULPf2Kvf3Of2WiJ31Bid+8O/Wrq5PMpf3LkAbzJ0JuAFCaFApcLwDGJhe8OEtzZC3X7cxPYQZJs6jGEYD3aPH009PAMlivWxm10Ieh8mnNv8lYI6v74H/nzv3fFT+IhauTgPHIgB6ubdC4jWZhU2hHcaWtKVmxNNjlgfiiBmmwlttz71Q/zZkmp0hYjKZIhT/9/deGWpZ7b/fqEwwZKFjsDfgtA3Slfy+PsM9ZDZjp+lWPgWuel9IsW5PpWpzB8kI4kS/TihiVjIER3WqWEIqOhl7H2VDkqQ3wz1PoX1it2PUSpFIo5mlwe9pR90HqXsZw68po20FeHYWPDhaU7MaCU0w+fsksOaMRuJfrR5oRZnaaMC0mtT54dmm3HaNhCU2XmFN2vq+VB5bbsCkKtD1JiYaEphMGsngiRxyx9mB715l+2Hsvk6Px9NtTFNh/3gXrX2SaTyjwFNeH4dVEZ92Z24TYYvY2ZX9km3VSdOTxAI5ZHC95ORXOSCL2hs1+62KRxSAsOpjWcrLOdDqbiaClKd/4S99Cm5athrRnnIOJHzDAcMeR7p1fZAhyKE/VoeG7YrAcW9DYo3KCTbamSObzDW/JMNiYgcIldFjLWevsFofAyfacpw90k3E3J1mRB936XrUseEve5aNykmpYR28COfd5d0Ey5ZyiI0tv6F7i7LlJ2+JB9HUH4HMeOUnsfRdh0UjPIIpfxgJPMh7jK0kV1kbrn+5HApMEM7GDC5H7tNSr3KNT+6+wu4Jla+ZNOh3tFFbq8sRVdyJqeG9zddO++Yz/cbQwJ8Hpg9T4MbJu9p1tCagyvFz8uN3Zearx6SBmPMp/C7scPfP8VrG1t6xrVfBUjZ7m09S24JgeYidWLbDzoaswmljGhYmvOf91KND9SdOf+y+NwyxWmOnkMY+fB6rHSYGihcRoUKox2sefNEWA3+/IS4BoVnV+dj5macNyD4O+Pb0P7xCnrbcts2BlaMo7zpb3o71fSTzk/KB1tgszRyQSRzZQSVFYrfvUXjj/2l7oQwdBopdcF8sl4bw05RnYUtwCVNKjY+UglgGAzFmnXsDYQCFvhHgnZgx+FU0jqEsVqa5cRwfP0Hw+mBWRJNFrBCQcLBn03FkupZZmZ8hxunXyfaYE4K28iLL4NzBGMbid9AwWHvQPOYj1ajNu3MYsvSHAmFvcl4NRIkKQSKH+5alF2/Jd7l2WO0d3eCPABhq/2K82ANQaw/qgr52LbTPPbdSfg5GvkZ8ZFFc/ZKfZ+zENj0M7/m0Q0W1FbVaISUZ6XroloJUmL7/laFagnmrqBh0pGmydF/QQH0WTR49+J3Nce8s6HNUUwJ1zNcvWdZrd02BC7L9EwagfxtfJqXEXZ6xIIMw5xPFlDG9Udso5As+k69uAbkUs/0wcmnHs4ESBlv26CsSiIroWX4PFaKfexdbWIdllUQ8gdZLgl1ub3rzn+XQ2q1ICWl3G4TpcrXF4OYpMmBTcEdiNYMb8Zbpmheoc0nhUJbG8UUWMdsOqPZbBZ/4ZtQ6Q11fKteK9gcwTy7sV2fuEbyko3J3fNaeY4wfBBTAAp9YmJRbGey8zt7NNUBQcCRcEtmoIX0Mve2J/VcXXFucDljKiDjFdyNGqhlODhobLr7lSreoH6gNemFASGW30tEgUX8j4UDTTqJe0JXd2y+JtNeeXrTZMIZGkmSbK4o6ch23e1qlhG21IDPzkV/nbIX9Llixq6xsaSo4XQ+eQdB9w4JXmasIZ5XVytu7S+b2S1h+3RKED1dgQNGWpx99zcMGuWcPwI6h6QfOEZ0bi0CXvuO2Fot5jgDIV5NmHcA4Lz8biNlFYMSRQX9NSWhjWblVaxEGgSLv06DkjmwOsCU9QhSdKhuKrSWSyliLD7/SDFC76vM5WnddU+Wn/A08Do+IMzDeXUtjWZ6Tfr/EzS/foMPe/MXJox001sS4j3myMrHbWT89fvN1iOnBqdt/1RkJQNjUloCyDDnDjX3ILdtejanUYe5xmgfpAPMO1cbACjGydWSWmohOat/qxCc8eX1rnY4iDg7x4a0qplgVSclRhk7A9q+PFlZgMOIK+Ho3S486L3cWMYrnY0mqmjdjqJUX+wWkijJzjemYSiOgGd0VXFFsW89SBQAr2ue5iYTu/g4gIWhIW3F30Og5TUbiFyoOcR2l3OSlEnZdIy1WZ8DAugLSATOpVtwk0WaXt2mV/OSkGNhKje6ZxfqkyJ5lq6Uwk7FjtaOrNv8C9pCfD1+zh4nWfJ/XPXDemgSj0jQB+5VeFTripu0triRKHyk1vTbjWXwIP9oqqN49kDgEqd82pHxem3WKspWDg+bKrjvKEahljs0KlpFpui+Mk4cJtxzbR2rOK1nBM6lvhTSStBonVJJNLWRfTBNVAHKAVTv/H7nvWahs5qVRQbjDZPaz6Et4tLhRiEZ7NE+fhQWcpsudxmeP9SZbUfI+2seCTHL36WuRMMYBtqI0PlO5/8u3nDKMcfOrkwNaGPoqFVtzi+aSJRXzx1FguO3MeNiceplx43z4pGnPadbCBeKw7rW3supRWLbn+YNQw2bX6w3uT3cWoF40xUllMctR904oC3nLHWKG2k2XqgauN1X6zmOxT/Q8WvqRrt3XMPrVWB8ohQnYQfRFB2wuCVknIyg9DQ7QNHDonCT7CPrETQk1uSyw8lKvGJwywjZf0SN4Raj+X7KaHPAKjAbjLx/d09ITbR8paFQVVti1NM3WZr2jBkqvgUlGuSeahajnONxW6wXvCOWxxffvZvGbqXrO9ykJeqjDtRtk2r7Liz88kq50eJ/WMdmYlDyRTnFYroLEaycBIoqaJB/rbfZAEW/2+I3H4LA7juNnFtIScTKsPLUpvsIX4yYI8uBlv3PnBPvvB5eE3T24vPMqftz5hKm58t5hE63sQzSrpexKV24N+RGN8NZUU7dA98lPb/VK1wC9K+2sW76wjwGBL+q0qYVNbUKJroeQDAzQaW9ovYva5UOPkVile6NK82qhZ0dWKehvFjyApgIYlCOhKvxEism7UQ3w8w4+w58EZ+Z+t+a+3c5oGi7QRJJKjxpy7UvH2WZRamEomjmV6xqwc6rmCfs+7PGZowWZcwUw22DxZ6/b3mnEMT8ZLz9qFwjFwl1PR5rQONyuoP9OHa/mR3PR0/RbQDGC8LhlLdeao9QszHy3F3924LArUx2lREm/2dRbt+U1eBdQdwYBlsh/CiH7UB2DmADPR0b7JVSSnI6EHm7+G60WDP72wciP+NvsJs7/KDvXouWhDs4yzjQXRDz+04v093QVqK1YA+Kj7LJlrXjGF5WxepNZw47tZaNDERkpill/6BpoPP9PgLFUjFmCe/OQiz3fmPykioStryytKdUEkeZQEJdkoQlNg4Ejq1Gz1Wr5ouvqa1qRiPlcYXq1mf1w3YUiV8ktMGPOC/vH+JvJg2dPQ0tn9shb1A5wYZ1TInON8hPjLR5YpUtiFCNyiJE2V/m5olwRCdvmzjBj4w/0JEIwFmnAQupx80zj7SBNo5O/aJmeyS16Z4Ubt3XXqVRHO+eHzUFwp8KGW7AnXFW4cllsXHlAdirQf3u/MrY9PmxOAZqet3f8pBzZaXQrPG7to2h24Ea6USRS0XO3MUybrnqO8mHSczqE8ioifUUh6ZDsMh543s9QYrZ2jw/tcr3YxN73LlrvfoKmBP5Yj0MZbnfkOxYPTNafrMurz4UCltdNF66YxHlhcTDwpTChH88GQJo3Tsx/crik1VgHZ51A8bFwcp8U1LrgbdXw+5zIhsISnq19hrVqbxZCz4fwBH8NroVO2AWq6jCW1s0b0tzFpa9iqo+6wpvQeKEeTEuj1z1TtD3dd8C6F/D7RoMy2450OVBymx9l/LSFz7VvZiWJZYGVxwYxcD5EK67NSCvzFo0Ux8ThGhSVm7F+/APJUM91nHxgpMN2WYhWJ2hCPZevuGWON7Jt6fVRcABBBFgsQ3tFHskY3R4hlIEIpCWL3bdGMmRZjOBphIFwTb+u7xQSDSHnthr6RboG5MGCSuTWj28JbGXC+hZPkBvNjBMS5Bnnm85lQTVymN7VlPA1+1p9FrTzp1PqWTQT/4xVhCUef/7fVsl7SaytHrZXwNhJEF3EUxWpFi4c9bTGfZ/nVpy6eorLy8ABOS1lZiQKr7sFVoSICg/gS2A7dveMB1VUJOchZrk3BPnSc6iOH0ougqx8Y7AyTrMUrdgga5amZNsBssPo08PA6g0tb5nFBamehOgWIKkeELESwSGoBKaFodmNqKK2nWFd/2Bu+3d3aYoZJhF9EWPOyLnDzzDVMsWIsKt9alZIqhtbbasM1g5dugA4rmuu/aJa2Hy8zU52KLEPnwyaIQ+b0aBhsdwrijNysNR66quNXNj5bWuGQCGa6ArZMgqqbNBTf4aOfqqDaogvbKtN5qdu632d+XhuobNOnTL2uzOQfXcKa4w+OCbyhGcu/Kj8YLmqomiavjkzyRBmlUfGl9xnpCEDDPlwVsOSnBW7LlnlVYzL8eIayGCcLmTeeYSVv7W5/EfLTy/qgotWmJH84zPATIiScA2GAokkdHFoE05lLsDByK8lLibCpXSlI61W5bHTnsZOqZpHl4vVaZcZVguDPQsIoYbv5bCDWVVtIYhRuDe5LkaUAtu2Xi+zIKxFQd6jN7hhafwL+IBl8ntxwBzABojFm7KD8x7MacebJbpXQqxzRRaELPChDYycHgf4D9Wm3GfjF9E4IgceO3y4TizCr41YGJO6BNtmew1EazFcONHW3CLX3XasRRPYELiad0ulf6eBb/MFaCKprvSzScdyOLDPjW4CoKuOh2NyMQSvHvnDqNB2vGtg5YYEBqKKAeSeZZQ1ro6caQG0gpiFgcuLJ8v+L0q64rx38zrb+LO7Kn2uSGoQcsLKGj/d7NaKqg7kOCS4S+DeFU/bW0iAwmePnbTXFC2FUa39ZwTOxvylZOUK8u6Mp2jF/LgT8bkALnOOparMgWGSNN9taTF0s0nxxGOS7k0zgCZLyW5Bil5sxRIHGYgIT1MqDJsZarShedc5NqUbG6l62scxq2GEWihvdO/wZn1n6h6+94C24PP+vEDHEvjgdzu4UMjEFKoUtEzRsbx1xr+G4UIp/785L/Prz23I1+34ljwqO6dD2bjA6wK2gEVT+LBD9KmO5inIiy0tSxYHcaWFCoMqrDoPWdY+rZLRui0lPqEtTSBjqes7cmVr9iJZSSuuB43+bEU0fPRVOwD9q4Koar4MAsm3WSpaqYH9Rkmvj2j0AQhRHNqpSoHREti8fE+aySiNvi+dhsiyDwoi5J2OocIGHgJIMOrWI0jjVket/MkSeGZH8QF59DoxxiNLwwMKe5SPH94a0gTo58cavrz3m0O7OD0IA+RVMNknX7jvwnqOGUlccwHgQNelpaoxBgYIjozYo8B+j0YoEbsJDVnWICvARMJY/UvWk1XeQ+SYOaUTpTqzQwwikEE4W6Tc34w0HMl6EzeGOygy2KGxuQCBYSDzWDVYtpKJxWpnvF3hO42nKqJTlhcAwAdT+xfuHBgX5qKrMWrx+sTm2r5i5l0rCGw0KWiAhxqqOiAYy5G/yZcu7fGxPlXP+lgCviTStXbrp+TRAOJjUqdMnQ6zuxMyrUgD0mf56Q43WrhT30ipsezTlpuqT5AhT3VlezD9uscBOOChHzJnPgR9aNWJvNbuxe05O5PHmHbiGgvHyZsyQd8c7JhvU+HgRwoRpQNfPnQRGbGOt9S5cdACENZTmyKm2cwfNmoo8WJ6uEPqA7MTPge14sayOylFQkZwFbiDdW+uJznmLIdlR7nT/J30BbfLmMy6cWCkKcq33tQl14C51sSrKm2Z9Xe59vkU/F42WNd4Q+OKxWH2tTWrpmdF42r4kEWmd1R/yhH2buT0hOIF24HcKRy4+4jsT7ny8dyDLGyF6jEb+nx6PcznYLHPJi1TtUJN4bT5Y0Be+8z4zuWFtexfSwhZ/F1vnObBezBkB8+CzC6toF90PX8bOixb24whhTwkrb5Uq662eY1ZtI7PqZec3tGCYpRTiY12M8xdUeJNxjBWMboF4Bzz3J2LWXHeonDUfVW37rHGv6jIJyAHW2gBOdMMUXxzvacXUw9cPqpZ9Ev3dVv7Ys67xP4rlSC+5iBzDsJMV6dRb0BvNPR7gvqoh0YHqwQytBkzkSKwoeWbMxHNse/IxvYBYw8eDWc2mjgtfE/jVvr6Ol2UPVBkdFEm+4hU7cQ9jx5yBJqCC8ds2KuMQf+exGPlxUJK+tqlLQNU6P4QxCSd+BAE60Esr74tkUhNCF/fIXr3cANKIaaQctbav+Wpq9nVBOZlfC0fgnjRV3E+y3/grf+jhVKLO1++0CkQlyA02MZBsPVa3D0sljVuOYRMuwZxCHaFuKsFOQVYtXRXwB5Jtu6l5voLFTCDiVswpeROwZPuUJrgX20wEvVB+cv3EbqCLSpS+9xp08/FEPpPNaek+rIn2ieb9f7OtiLQSr74AwAsFNtJGTZwAwRtdxnapfaWDyJmjpDh4rTBF3EiRDSFA8w3EYFOrCpkIyGhi0FFjwVpcn/a4r1OFY3C2ljAYym7jOLbaBGjrmYEXHrkgEsSG/9pqbjS75lHm86i3tZFKW/bG9ZpGrjts8TGQimAITnjPvMVQ4PZYNM7rCX9J1gmftffzdUCZyGZdmhOmT8erSVJDd+MaA25M40ee2ROECZIc3BgMHT5cuXYQrL9LWwLfaY1IHvraVX4W5qmHrHPYq8lSFOrT/a3WYUqfggN89kiHPenIN5ZnqWDIawLddvbniK5hkxf5JJlECbK7XjbChtHYT9+4irH0b5KG/KZDgW2AHQma/7mlAEZhnj3idxUyVWzrwf/ZzK2WZFaYUV1kcRydBDEWYpsN++ZeH2RTIK0WV2h9Rr0xUEokGiZGO5hbX4lqY3ycJn3hfoFQbigmPqPeMNr8UYPdB/ja91/dNtsSKAY9zWG+n1+YCTEOP/AO0XbNMlUXEF0r/v6hcM0Gwfo63KIZmipGsvlMmMl19aou7KVKLXRzdISbbR0QtFoe0mG0mwa0AfvfzjRSSoTkMv6V+c0RSiUopoOnzjERd2uo8CKzGefcLS6zDvs2OWr1rwER+2VQf7Dy6HnA6YF41hUPDHBifnJGfHECVZ5Ce0XfV4Fau1O2SJJmbD7KWVGE3JRHlsJle2XN97D+CUCtzbfjX55XmS7dAVPob/qRpD/uqF9DE5S9vdfIzbb92t34d7HG49PPY9Hmn3vzhv6uubzH2kT3qD3QUgtCWxw9ufmJL1Dy2X5VuQ2qPXPGA23Ysxw8S0or9xRpujHNTwGcMUkKsk/PnO2sfXeTg9k0taSBQ/4LiJSrXjVPFKPi9g1Saqx+ZaxzugDckQ59cbz6c/QCgcTJvl1VhSRKdmPkg1OJ7d0OUEA5JBLIxNCOnJ3v/YYb2cFd6nNM8/M0BqUM938GeHkJBAB4SOlDr/MoPHXezt6ofwbLsy563jSKQ+umNhRq0lpUJ5knNQ20PhbeLZQZOFPaLA+aryS/BBYq92GgH0fntDsM64r65ntXOzLNUxlI8bNqTv24EZ2atLPENCEMNjMNLCVH2NmwymVTt26V4RXaMyA5lHJV73iKzbxZVhsBVG0LfHhCUf77TUwo6nRRf71KLqAiYO11QQIU02bSAr8Gz5/6nYjiE1XWFTa08D7nqitcFk8cxidgV5rYo7GhhvWsvjV82uhmO9DirOk20nw0bKfGsn7M1EJ5IeA5lmv3J/zChomqxzOWxN5+D7twa7YzqqED8bMxSsexfJihXsRQFMNfWY723LbJG79V3q4XRllnIX4IfiBVlaBYcEn9lBLyQeTZ5S3a7Ss7MCIwJtm2+lUADjF3MUXM4CJRIohOTKwqcFf5aNP8P8ygtgq7alKVM65e4AHmanDVd4xdxZQPbtD37pUnmBkknqbUu+XBZ7WOVkZzW7e6GNLJ9gU3PpV70CRtNqj3//nRAisPyf4ysfy944ssdtEK8lVhwxB2vSWqh+L4WZzLeo4wQ8Hq1HpF+YQaCGYkyksC0TcK2+XgOywqUqoqT7vUee6dWGWaVVIzroXMWqDISpWjP5ndgZoX9EgF67E+Rwl7buHxaTUgzRigQ3V3ZjQh9h1NqG5CblSJO2N9zfj5cWm6ObzOJJTKibTsCzEzCiwSmvmSh0bh6ycdngbzFZ/8q2sksBrZuJe4JqKEPtWTjQzpoTpNf7UN+OO0NwfX4dMEJV+MNPJCgicwCGpO4Qbi1LKm7srjOlLWVKJf5F1WRnwvt9zvKgNi2psXug1Yw+Scu2mVUUlUWsb8k+hcA2O6Y1tLNe9MmaVIAA3oiSOC+vAmq26JYHAwP4UbkFBzoCdzzxgH1gRwJvHW8/l/FzO2gcNZFqVzsU2NfMTVWEdCEsTPGRXOe4No/EbXxxIuACx7wcx/j4RAE7nzDMGOnYPOOqihcwLLGW3s1di/TfF9eYGx8dgcwX82EMlWNdNRfM+HkUwSFi16J0QE0iVqaliXGXkPzaMG9bwsK8/gw/b8WF6KzON9YoXXyzvmEJQ+dAQ6DTM1fAWLP3UhP4N6MUj/j8y7W7r2GesshEpUM4J7VviiRRCiiYg5ZhqNwiOsaWDryVHorY4V58MY0Wa07Bw+bXZGoleVmo1qL8GVI1seC9rPjOrD5w2kfi1ebR+TajjxnF4Ghnc1FXro7Ly+NmWcb6ZQuSB0VFbpov0/bQSOjnRrLpidDf8KQDqWdhTJXgb/KwzdVwBYRMVv6Hf8Ax+d6G/ugA8Z2thC5tc2uHvwgT1fpM8uFN01CKjEvcAChqJKZunFxzN6uGxXvxRZslIdQjXBcmvPwyYgM4fMnc8hnq9Yyg2nvt5JUsDgkPzWxUmf4lW8iDd/e5t2T2nxUNIBPPfssyGAMlGzHDX9iN1MX1G6VL9Wm1wJkllEmceKLkwum8yIUmEafeamYpy7RvpQ5sQsvoLDiZq4bUW6E56dwAjUBWEASZG3Ezp7g0AVsQochM/GHEs0h3goXzqH4dsrfasotAE2qbeXkyg16bjUwEqsS3EDTQBXZn3cfqVGJGJkwPjXGWeGfDQH9xh4PCseShNUGBHNEt+Fp6NUg/St99kQMNUd1uESyW05mlo87KtWmxGQERyPoDCZdL47uk0qGz05lP+S6IhkQotj1I5t5ML3GpB2krXxP8DA9tRS0BbfqnWep11cLixBgfjrcoWcYMcSm6uYlhkE88vrxiZyIeHFra1M4PXSHtI5MO6PKkMARJU/wTlZy+51F7kb7BGLKroQsubS9FqHdbnzgfCUHlwH1exUu3px/DxQjDkjpGrS2BYzPXhO9fhYZPypiQOOpb1rGumBT1ML+NOBphH1VyBlq273q3crkF7KdnzOxuUDBPGGkyHlvIw+f4pM19cUAqIB32OKwMFc8GbOd3iCdUnHgB2T/4cXDKsMoQerdxOT8KecQzVnk0UcD2CFM9ICGF3aBMWgnP7GZfpfXDIXqVEAmKBkPBinhL+cEbptjJhy+iIEheyjTHlBoiWI6/wKpdHszKP9OCWYSuNyhw7Icb2k2t8TVsY5zyIT+pfxKsWwEOb5rXsGbK72Zyrn6N+mJUjFVbJGgl8PF0h5XuHJxUnEhbqMZs+JK4XcL4lBmYV0ROe2RtCXOP5fPjnpFB2mdHE6d2LSd0jZHd2CfKAGGRUmIW8R++M3d9ugqRxN/XA8SonSrPlJZV9Mna1QL84bvWpHVx6qwbR93TcGsRdn+Sm4VvuW2m/RQJ7LKZnyJcs+6i7EdmworDyeWWhEp0zXYg/SU4erOPyEWW7qpQfxiDbrFC4Ss2FBMWhUfYYOtYxBFJ8wZbU84kaZF7M6qscit8RwgAd5TfCkZBBP+z/J8G4GHhaFsyh5krfGm8lMuthb/BVkwJEZlRUGm+JC+cNltDfjhMSRcVDHgOF1XLH8fvXqW/4zRd57/Jv0UV144Zw/WTF7jfJLPGegs0381rxFm5SlrTxYtqgEnIraL12O9kHf6hHgELXJnytRq37bzfgvfvGe1Nj1/7IHkFzPpFoDPqqS7e3U3UR2KOt0c+yP0J/aON6JYeh34T/AoUj/JPb5gVyj0rTykOSb4Vpl17eXIjCCpu8i8Xcr9/FuiFdfTPTRHCznYJw5UFpZdZbsBsdnkiEfMBB7JrENVMftQbzWJrZkA9Dw1nvoV4kTOqGRKN15zjiotrvbwkGOMUJGwiexj9PZ+WxGmiWnHooJks3sWmovqRoJ+ab2dCeAvKeE6Z+aixdOPCg5Se765FSWBIEprNQ8JbWxKrGGEGGHjopzkdW6ihcFmntJ053NHmb9CVQulzdQsRv7HbGZS8d5r1nVXcs9a/BV2VeIsewIA9GIwHfA2dsM2RwcvQmn7RP2uBiEgPvikmeMTouiqSf9kZ/ibcGwEfUikEsmxSE3HwGTwDgyKvzH8JhIG9grGG6U+GHpkJQuBmkn/7CTfB1ljiYn1AsqnQ9BtNLR1bKvmvFYYbUhLY9N6T+SYosRBOkOCCwwaGsy4hnlLMHaQTRIcKN8DfPK9JD05HfikmaT4pDLIcu+NhBINcZhArVWPw9CRJ5TZKMX+8YPy8ln+3+iFhp1Q86DRKVtT04bn7p5LcHkh4gyXtdZyIa528UYXhP1tkLQ92H3vyL1dZhFGogLqLnwau1Po0y3mbo+Rk8tX9QMSPSiaNDsWWFvNmYUC1uekQhUV785Klv3N/rBK6Yo19dFqwJt90SyEOQ9bYw/QvpfyU4ePpYzWSVrs5ka8SYBz7DqytY4WXqsEMMG5A4y5MR49FDTNf7Rpbv2wI5mEX+Cdu5mtGCtIWwLwzjmhXmntRQjauf1DZBfNrC9qouHavrth+NNBlxmQoIgNrCYnpSZjqVjw4qKiQQaiqgFhUcrCsR/CipfEEFMHxg6r4ydz4QJaMNDMkR3Fo9QSGZn33+VFDSqV7QF74OFq66F/8pltfdwG1EK7TE59rqY21PWo8Fi3NzNDTJhqcVh0goVlRHG5+uVwny4SVcHGD0R0E6/nGIFXmsXyO1hTI29TASDqnZg6akD5d7YxgFzlWS2NMU3ZTNao8CarLS5TDrDv/J5GgphA1xT/iZBcoCd2fX7lAtsUvXd7+QIgO6Vl4Y5av+gQyWVn5fmfwCy6xepBsOnfcAeFYS3zyuO744ihaU3X2j/Fk1GsBXRmz6I0Oc96VgqQ8n1O0hbccrJFcMzAYRfv/d756l4c0HeXoDpw5Bi65pkEY5cZzfCpWrQXtX752iwU634+IpeIOP9B5UuyjLS16sEUXVLvliHqoZCeoCiMGm3OtYz1t2bLRQvHDR6x1OIypAk0PwBF1E23eFQeiLuxMb5mE9PuuqcmYEdF8cjW7N/fkwSwWvgPIl64OXoY0LDLVTwvAv8KEIeW13XRkf2Hw44O+EUCXZg4hbTBeFTdmIjZB91elGIi/C15YIyAbY+G7vJtxZBX+lFsBj9GWkV6mnchpv416A2n6Br+DZYtt4B21BGa2wP0tKpqhbyceVv7av4BO5TUQWt4nzg5aLpC5o1IwCmyYEoNJPEd6K1Kf7ibwXKtkMGLETDoDkpyJsDt1vrx9yhk2ubnZ6QsL2PcAtXr2GBDEdsGW8/nrCLD4jIU1i5Tkt3TNVnrx7POUZS8X3kqhaxzkSw1RFdAUxWfmuD53YYPSNY0kKfHDZTpWz1901qCRC8I01G1qSV55kDqaATr/xngAYmQFFYiiriyjsFDDqGEDT5GjwJLHpv6xu/kUaH5o3LaNg1rY9xr24irAuMVUBpQodlRxcQnKcYu6L+0FqGAbVbo+VVMxF5fcDkY74eMXyMjwBt3t0ePgdKXTjaRLade/psU8TfrG3YBBndg53n6RdnUybW+kRnNFd9qoPgWng6Qvw7haRjC2IRf1s4NKAl2M2dYX1PazAC6l99fqikh2Tgrw8ByIT+FP6/LSEZg3aOrphdWE70jibnvHXJpggkFs7KuVrbM101gy5A4DQ4qXjO3YqFRM/0c//XVK3zyEvYZYtR0XR8wOQcPY4vHJMzepoQ+EUUJXHSRIso1ciSicvwjwNK5b863ldtgEfFbxZQxeE2gMQE4OXnakgA7oG0Di1rNmfAYgSaFuZsnMVr/aDQq5fGLB48Xc3Nfgc84ZvcnKwoYVz5tM2Vk9NnLahp/pDTenO66JC3fpfYahutTe+we58yG1IwL8ZYyKBE2C+gfzdCimqGgi5FM+j9ihbMJg0cQ003KCYUIyxyN9DavHcH0iK6+pRDhB+qrSQvzU5VZyRbkOqVqgYKNULVLkw1Uuh60tarf65f0jbYkbRbruN4hBMZ4P2nxY0uWDawWT4IkWcT49sMfmsgbQnvggoMBXQGgQD2eOugyIa5EaJgmOTkdShaRKVqQWUO8D68WCwwEjOVur0QegYE5aaeKuCj5KNJPAUke/aLS8AO1NuUdJu4+bFmDLmdybcxI6Rxjh7JXL4kFo5y7Ep0oyAP+qY3PjhUsQ6BWrKBB148LOJr+Oo6XjITH7VkKrlzZKCBLJuC3gocfGcp60PDoAo/2LTgZUyn0X6PpudpoCfCFgNbguzrzAMx2/dE/m/Bmnl/BDfGXk58c2biTXE/ZYYQ8bFvHIxGHS7YLAjawkefhAchPCrqE1Tq5diMd/sYH31h35F5cOJXId4i+cKn+tAjh20akbA4p//p7TPkw0BiDbFOttqO+DTKnm4TkYmvC/sH0yrdAqfmA+Xv2G3Ae9P/U2qA7G1g6nDMFCAuKtDn44jhdUDaczs7/ded/Agt0fwLXUN9M+1kUKKQA9ys/lVbww0skNvn7RB3t/KDh2RHKuca6JwcamBizuxzZRqmHL16fr8Hi2PjrVVqVtybbK8bWaUHrdazd3la5OSwNmBZIMIoKGs14H0rZWn8SXSRUyjtDrw9acT+pam5OiMpLZTdA4P1Zg4CQd1cx0SP+3JLC9Ujtubf4+60L/5uwBskXrUT+KM8lSE04hIHcQMRDLCoiS3NX9XQ2SOkyFu4kGUHjFVbQiV3nAxFnvp/fUkFS064LDJdhyH/jTNlRBDyYG7rV5bYzhtKxrUATQw56VHGTTtJTUJ9pv8loJIJ+3aLZvkIGwznbk+RJDfrCIFo15T0WulMyt/WeOUT2e2G5Opx2Vm9BaTcrVYuM/EyBXne4CjR53A+Wd/3Zg3Ghg2nnBrWDdYh5bbf1GgoPt2RagpBuMKUKv/iXEgMajFSQ0oWB+AinrqwwvU1OQvxgKHhLsHy6lHQ9Jfm91fl1Ur/ywTk/xIfJRXzv6Jhg+9f8Cc0NC4/danu3HD/A+1w1elyOWW+4yYXlbG7VRWJNnXxkma48Qn6RY7dR4gp3DeDDOXDrvI9JKfbgAgWAjwQ0o3RVOkfRFziLLANM5m9XHDOinu0xV7IAfODUF2ooGalG9pLI2p0ekz51sG4KO+/q+YGN9PBBIddaOWBsIJlIAaORYCTInfxiKmKHyeVR4lG7/rSo/n/2L/3ITXM8QxErGxzM9QyWR/EwOHxgVgxnutzU+j+VVjtpg6DASFoVDLD4An9lAjM8LJsQG6OflHKaLK5mII5P/lWSLpVEXickaPh3Pnw3GoqtrBT61qCPqXziRtqWZWO99F8G+eTrr/FFlpg3qAozvapVaTCM5fM7TO9w35OUKRoci0Kpas7Uwo5e6USFvbBhfdi+FfzP784azvjYiHFLyCgbfn2Cvl40/hS01xUQC6+pz3jqJoi1NGU8l/YZVLo6q9uN6io/eaOkspO9eQi1mUZwzxxk9r60lPN6JVwk42njDmSQ0w18NoLzO1uVyBC8Vb9kBlGWsIZBjxhojcOsMP+3gU5kSeO0iH9F777kPPcLeudyC5/TL+TrgOSMDyt6cQahF3WqN/+4mgjrcRtUzxBfOpDxcyF2MbkYY9GBPBH21Jt8GdATSF04+8G7FpahyxoSlp4HroJIyGppy+jPnVzY7AOdbkQnvASjwYgZmj8UhJPeOY6liydDmGmiHz8caE710Zn3XXEyiYxSQcggrJevDL5WKMtsmVYxuzQik9frc4zrRXni/rt1ZAb9qnG8jrducdtA3EnatFf7/SVgAKKGlXPlxJdV9ReFPPZ+NRyFWjSMcWSPfOM1t5Wrg+g18xf5vpr781ylW3xYw0MGMPw0hdIa+pID92Jl+lQGCQmmQLIc/NN24ld4344IXO447fAptKtn26E1pyNjR6mOx6nsRFSmYyLoAlddsM5ewlrtXPF/0rBkee2JawT4PRCJJ5f8HksIYJpD7d+vuXtE+1/lPoC5lAzkzQEDRPReXACbZrH3uGm+srX7zzVW8kuEHSDARIAjVrRbfTObM8HJB9w3c+VA+8ZVZmp3goCafgLj02ySlDdpc2aSAruENrlIgH4ZVrkFkrm1w1R3FdaAlSqWQKRADJ4mqEzwv+RvIJCRh7CHbfisnH7k/FtLPmj1JHE8OSmVPHJpPldXVmdadQBal2rn+yVLsU8DyjxipnXXcvSAdonSvqQKE44b2pksbe5VrrFc4Hkje7FE2zppfgxgcQdIelQdsIbD2FmdsNbU0O+j9W6VtXt/G4tJmItiTZgqPcpQdHz9YE0Co5Jo9OnrKXX/46goje+PjJEycb0WiGMDt5sCNs68TzE0N9xKf86ySClINqGeViG7iKIPuhrAZdn3bIW96sMFy7lqtPdR531GMIL8FhPzpoD6quEu/BDIBpCD52C2wADRdwOaB4uftsmJOvTrvNVsp7ubIS2nzejY57xAuiG/9jpr4RaFT4rfVJ2Nmbpy6VQ/ibjLbd3fF2nEKyw2+vZnCJtRkL1LxX1GYlpDDy7xcNX1aJBY8ZlTFWK0NnnCxyZqZI8WhfQdeT3rRuOqyy19m2LNlw1UDRYzBcohRk6y81ESyy0EPzLjSa2n2qLWthfKs3OnO3NmOOjx/18s1Z1STtXXxMrZql8NHJsQiQI9tEjLZazTSSmc48pRiJKUIpXsRyCnvNhKtTY9bVJCa/VG22XHIB/xicDrRGGBUPBQUJY2BA6qbodgbgDZ8pNhKaRD581vB3NYBDWnhcdWp0NulX7f6vEf0Wj0jbkxUPaTIuGb7K+uA5WtHsSFZ7efvcVSaU9yLNgtfgLBrXD39n+BY5ZjqhvXvAR6kGw95+CR5GCvqo/ceaJbmBHK295FtxK1YLEyYDG5o3qVwAwWOf7IPg42NFwnbGgJJHI/v4fZjnwbSnc06fr+xOfP1I1f3nZtNkDgUGT9U5Q0IWNOGrVRE6HYk2sfL/YQ+y2fwJCvHZXyfbJePZLTqMWVZBy8/JNHTJlhPCSzmZ0AWpNhhDbo/J3S5NULXuPDdCGXhJ+kWv1y2f2iI2AiU5F72Fbsfhy01lCFVhvjaXwVc9yoz8mhSlYNPRn1hgjnUBTtbvklYGvYvt/4bVd4xzxINc9J6dAy4EjSOduLTmY+c9Rz3Fakaoc8KvXEWVlj2EjyoGk+vcclmWy4mZhFHUKoEj7kCb/BKzTDPgyDmkzvHmhxqUqcD5DcinlnlcR81r9zwkiqGdzlWJl0DNiZSsr8rNo9GSH6vWA6IgGgGRCjY6C3oB9b/idx8dfPPP1gIyTAwrixkPvioNRh+OYofVVh6uj1sNaOE8w3DVuKwQx6T10debFzG2+OpbKUZO9B+eL6O7Zm8bNCfJOLHBgZ8W9yR13iJcs1lYva8ODhDnQgETndOazAuHSmYFbC8KLXwq4PSb1AZIvw/9LCVRVKPzn9ZOwdEWfCXKx3nO1ZNKtwl/VJcEy7INKb+EN6ZcOUJ3WAbYSJmSEkB0xgmeHG2y5QF/godykJXE4CM4zopMZ5gRqQ3oSgKJ24CbeCYbAad7JY3438OPLX8JD5eIsd1QIkRC+fEtb2b9gRcSOAPbnkyURj4yd9K1OCPOq8PWZ8v4eGFI1V2s6hsaTw3nG42BYCRVpLphD/P15MH7PhTxGVAd6VAAJ68xKyjZKgrE6HRJ/HGvi0v/Ax7AswZN6f0rhOrTj/wpj3txIgTsez1xSvJIXORhmtG7frACml84rJeQ+7J2/Blp53egN3t9l2uea1IRyvKQaJp75hzGGDbxyRyNOh73vy8N3bhQyxHTr4TwZa0H/B9mrogFni5/rznxV6/zfzS7reegb0KGWPGRYscAr5afLQfIsfqHDurFP8BLCrFN1sEdRDLHTXe4uj8orpqMf+U3gEMtHhrJK3RrRtlyymq8I/dvxiHzqU+QH4YE4zimeJQzunzzlfBYsiaIyteJVQonsEQ4OEFB/PSEF2ze5AwVEOrDjLKUpmCpC3Dhgt4G5GWXY7bfrVI5M3BWdqtxun2FK/ACsV+genTpJC6zzJMmVGbluqvGhnZCcGPZ5R39B9J2vP3JXJ/fGZpQVVlop0WvqCuU4jhpIOpcKAD25qJDp8spKHaU5gvBrxPccpzMrEMKlWDxnALHtNXfAGWAnDV+hXtaK6uqC/DwHSpqM7VWyr+DRc0+w+Bxeldxvqib5zvT3YiBe+YGrv2ymuV6wzsfo3FQZUL2yvjgKicOfXhL4EWEbw0/LBzBZA9nK7QDnSXaSRGIhJs4iq9ZhpWENN09zrCio2q3hhYIqotDuj7BSYqBh+KYsSZFqlyDL8ytBiQKg75cM27+9/7A7Hfy7aVddpiJnBHgZLAYLZ36eYwpeBgmiTl0hxnt7sxlV7CzGKrlQoUDwJOtMu4hzxMe3LtSlzuTjfRgX+reBsNburYVvdbDLRtf3ZBUDAQBHjXc5fXUeLL1RMbsrF66G6bMSL6j2l+WtNogLGuTiJe5XmUl8NL64h9ju3RNlLlss0eH42bRp/60LA/mlctnl+T1zijBH9B85o6V8yGTWlF55mgfqBG74DWsoflm4el/DEiJH73P4kw7CjQdGqgJ4yKo5ofZfQF9AUeko5Avc2ENAVjo0Ml+OB2xT09fmMMU9SAb8B7y2BsqxFKNI6FJje+xVbMxAt0MrtMNZreEIDdxKBPUViLmET4E7pDkyssHOPUjDFxnPheGTK98b+5LQZWVFqQJh4s+cy2CDBiprp9nLMYUMLNdPOjSiIwEogr4l4Z4UZ4gEuycD3GrCUZTBjw+SrvynUgFS16eD0VexYjQehSdY07L3fAU+S3B9YMEgAJIP7KpchYwSjqkRHs52Xy/flAMYoem6bCkoedellpQIDvwyt1qdgVrKtWaN3lRJhJ2Nb5/Fas5Ppgc0aGBDbpp2uqPDuWQSJCBcbfo53ZCElVs61lzC4y41ipOgFk1XC+2H5VOFzgz5wCyhCGeJkUrVzAY7njjgszgIQm0Rkiaii97N/k9uLXBHH1WA/M86fE7fPGeqK8pUA6nlKPeK/OhtairuFtqS0F0wMyOoRvpRnKZh4CIbqUyOf6lsqEiB+EYyi0hkrZnNxu0VlwZUIMR1ZrAkd+fEmepYaPUVmjRUXSddBIvFcQ5bHKnfvajRuEQwF0zQzZ5SyQFPunXDwfTXNlf/b/KSEDlGUTcPAGA16AAqN/eR23kJqsFcsVDPUjF4y/3ELppS8Pu7jvXHHuRasuIyMW++hBABdrCqwUXiCoHgbeZDAZgL2uOt+anknDhNSegaTMp00xDHXkexarVYysi3SfKnf8JUWH1j/fLqEYsZhlubaZJ2ZSzQPcin8jIeE27zsJQ8bM/0dLNWADHY9cMr+X0gHRmEydOJbEaGfvbtgm1aeaaci8IeKoXlyKHQdqeBtdvRBTVjZ3lxo2JQZZuYL6Wq+7FuAEdZ2QMbwPrVPz61w/MCJPQS3gseVYghCgBqBUK+9FZskvHXYI1V8sqoJOMTQXJegVRCfWKHWiFT+OIZXLlaRLc9WB2diurs0NGK5BnCk6gpzwD0CYREJ6M+vD6xbWTqFHMECug81rfi6aHwV+IZQ+RURmC183V1od8RY1XRZUCuvDP60dG5hGRCggeGcQtGFR9tl/OJHSm6wBX7Iymyq8qO2aBM2lwFCz6+OdJ0xbXyn0Q4GniGjPvYRkMPRGR/uV9TnGGtNy8L/3cDb4Pi1F/WIhE10pOuZ5cxli8KX2Brhd8JMH7Y3o4M98qyrmRdZSeXvHarSbhOQTFdC+cKICtL+zelTdQxHrsTLT2W/AE29uqaqLHdFy6Wn0qsxoT3qTuNMUWdawAvRUSURCyEAQM2CRbijyZJ3McXw9vXuziZB7pdONel7cVGrdJ2HJ1A4O4QKeUr+i6s3Bk4lhzIF4+jBDQcHjLsNIL7Pi5SikUtfNmmAdMYVk51bHwGQqbV051+1bqSRoLQUl+2RViuSjNtFAwOx4QQefaEyk+Cc6QgHV5YV2ThKOay1k+8QcGxswD5waTK22ncFHwuRENp1dPw7Qy8xr+kWBez26emFdXHpnS6f5FcgkuioYpyTB3zh1nrUyMVfaP1PkQy4iM5Y6NTYrN7kiaEI3V5KZnbl28lRjlqhOdBKbCOKfz/yS1ap5Q+l1aGz8a9myiyWdRaTOUerE+3KaoAR/K/4haWZO9sb35QFvRmgdukz27nHQ5QWOUbBn223tfXQjUspsEofP9NaYalo8fdNpqMTdLr+EeCfbh4bwWLloDU7Oy5d+GNSmaCaawvN/3YsqW53oomFwGiGJqMtsj2jwdHNOgZZJpcz76ww7hrYlt62ArULyezl21Ftnwyy6VL25l1Uv/kklxmTO5EB7tw6XM/7Hth7ggeh6ov8Zr5EminsW8CxWEVwesnMZAfSGINSVx2PBXZftfVdttbla5ORU6QifNWyWw2EKAjW96eHIkHqIJhTe6YBDH+oK/zR1QMH4C//80Ud6pHi3ks3y0i/Z31NNAc3IwfYrBR7ExQ86ITOOvXrFhTn4BlBhIhkjAgr8s4MfMulyZbQqKCNnoPLCFqlPiIOECnB3OUY7dYRwBfhlgmz6McF06VrxGF3qiYjSRpn1CuMGZ2l/o1FhGZNupCsQwIi5Ulpz9jfIAzTX2RxrBQDQqZbEyyHa5j0hB1qa9a7pklQzqm91/0I49PVqHqbRdl7ifBxbIcnrKQLtkBM8whWz+XUjKvdadqs3ohyOZQFLbcUvL8qcCsb5EVoAnCo26gJIA1kO4a/sDSatVRkovFWdoy1vhCO5qkWEiEPFcMq0zX3rMT+scc7Qgispu58Sk2UHzJqFGhD8IXn7xk8bi0eDvdBMtv7spbB5F95MJkK3tIxWO8S6DMz2PfIxV9B+tfOhCyCxSFgmKIcX9hfqShHrp9LL7JELOwLCPdDOFk8faq8EJFMgsDKN2RVgultO/wxkSYxVrLIioYiaw5VCstShkGWeH/3wVRthnjbfVH+ffrMk4RBVD+VSZ1ZeTD1Q0KjiObhlnx6IcaKZDWyMGezkUwTKE0qDk6zsNsdxWc73ksVknd4dqapHowq76u5XyPqXOkMHUilwixsmB+kvkk4lZvgrGVf8tTAsgvSrZ0CweVfOLwZKYf0sRHi7poTqyMcTcfRHHirP4bxVdByv2K58fBJIFlhPI9Bj2DaVwI85SGyGGyRPCSd/7kVGvYCpxiS/uvNrXplsi7R3B/wLK5EfVQ5dah8xrnvNe6e4outNxhgPWwyAfSbxavECF9clK5TojD8nHm3x8Q3RHbtlIKnitXQ7FF1Ee1DQn97dE19eh4bavnYPsfK42AUUB3nbuPkiGdplFgZAIeD8b+rHVirCkWh7J4UpHz/HQfMRjTgv+5gf0qwao3RUpKd724ONK8hxDusUbg25r+ohgoBDS+1BWN1gJ2dPgJnUGbnoxDKE2seArV67t483uqY4LBKFTFjHyD3FHYfhfDCt+ZqndvsfGGxniISkm2oaZ0qY1WZ7TSFssbGbjas3QQFdTTGxlHrKKGHzvkhHg++iEtlIAoulX5wHJ5EYIzTr62o2rIE0ylyEL1L44vBBOzgoJ3XB3C3Y6OBT8FmntHD7yzHu/RXS3HrRecmjgzApmhhsDUZUZluJI9zZcWGE1w+BRK7V6wDhzHgRvS/Mtk79NGbKJ5tLzg0uDSa/vjeDw0OA6HzzQV6/mTEYWuhBCLydVlEGehdMvj7qhcUaziPCpwN9CNnre3miiZuN38k1+bxolX5s9Br47GRU4yqGkAkz8e8OHoVv7bqB8PWpg7vSXPEjNr6Z2HvS1SVH5C3a/nqaRsOVOQ1i/XgLHP/3CqCcwcGi5eFBBf40MgT94DI1JwZR2/25oNVkcOknhu+KJq3omugz8ezEsHQWwKOy4e6qZCSTHFwsNO8frjwt+7wt31ytyHEPmh4fW7HW2y1O+dS0qYS1wq//cGtLUyVOjN3rfEaK6cCzalnLoPfsIRYj64JK/AcrSF9mDqhZSMJBnHO0ztnxILqOmwBxh6oAiZq6TGGisXSHUIaI86XFpIKZu02LcF2ln8W6mf3hHXZoGd5QmNKns/0n6sItvbk5ZAX04EOxgOFEeZnmbimFi4/FIJ9kzjKonIca9F69BPqVV5w0dT1NoNHs1Hp18Ql+LyzJSGUMYADbBz+qy/gTWx9bFlZWF+aoQgucB9k1UnJy/AztAO3WAlGdsM2prmbpq7vD/DW6YeDktbFkN4kghOQYTRZoebOKZjAI3IJEG9mckmMB+fXuezv1bppxxtdNBZ/k2aFNePsEMgtKusSBHLIBmB8Lwj9/2U8GmMqWjRDiW4GKiaTnDdDchth7Ca5hjdUsifzgZWVZOtQsZJePxSglcbn9vqVDCQau9zT8ek+1UJvMBAOpUj4aQnG+NCfQL89iVkJFjyF68QpzKkUDEYVNlhFKNeZKqv+Kk8cYrSmmKM19VeZfk5922NVppGqloPsvV8feO3SNOCjMj5Z5jYgrxMCxn81AmId0aKM7Vlgd58kdc0XTV3oUI8BuORF66rFqBcF/CMkGAyDWGMbfaPv/Ui86nmxb3+OGc1ULco6XU8Ph+9oyD5GuNWeVkQkqbmwVvJp8n7XQBPDSCRHKBsM7f9rTYDDTnbEhg316IXRPj/hWEvl5OhgNzCpqRG8uOuQkgNJ7t6YRYX5LaLIF1Lo7Yq1b9OYBnfBvPtW0rE8Zv3CgtfhSLNbl9TplgOZpkwlG5j8YGzE2zmgbmTrr3PV456ID9MEXjAAXxsHs83EGwQArbcCdtAF0IRdMwwvjzmNsuoJer6IlArIBTGbUnly9A200P9pTYLltJc/KNTZlR/jQ40gSuga6KX07E7WL5kclgdKCshkIlIfczk6UuaC6upskdLRj2AHOGAIYQXUdzD55jgNGDAf54249wL+c6HzMfoVmD4zquDOqZ8V7nVkFx6hgBE3XR8U/74lxE3FKQYOFj2F46X/LEPaFXI+djCpGp0Zh2VrkwOU8ke3W+jCflnSXBPwvXrpxLXOTSunbBUj1sP8nlriyiBi1HHiF5R9RiyRQ3B7J5o0nKxcXd/BS52KzfoQID5LE9JZk+3xZsrGE3ZFaDZiAssHjkiNFCCwmPQ1WqOfJEhE9ovQn4xzFPrW6MlVM1g/NFagNYmfTxmYIfrUwLSa+vJP3rlTEkfzL3sm2YyAkp8o1AF3J/Ur35b2VbXjsO6Scg3rOamCN+MdNVDo8lp6hr02oG2mX4LksTZzzhAn8r83S6y5XRufPEm9X49se+4SKlMHh29tGHKyGliAfFhOJi0JP2crmD+soryHUdfHd4Fe+agat1/ZWqSg4IW3URNIVPxrNQ85af+jNq/rvQbbXAdjZmxJxeTBfsYM+MvnriN50Yar9r23GVDfGJpsxBaRrivdk4B3I7tWrOL+idV20+TyqefiaHfOGazHGgEvx5AHpN1SKyX9IRFlw4fxVoU/JFGi25yrvjDKJHgP4ZdoVmiRbItioEbmGaUvFOl2KtdKUbOHUdcxrcJqbJVzBCPHbfFEyUr2nhpQOY8dElCTsU3xdRYENyy4Rxo7hsRJZyCFHYy59bpZVy/xVCqG8jcI+nzi7Q69+DCr9k6XLofrUXVoNXlWvJRNCMcPrsTONwp8p8XZEfjmK2lF8DM04K14q7prlxs2UpQxBtTS3IEujL3A+fAFXf0ARmc+wJGqImZ0I7I5erpz1tlUcV4hRPeWEhKU+OHfMN0qg5SYAZMwfE8TQCefTSRWBOMCxvx1FP8pb1ugxSECXetysb0cZKTILyMEXMQ71vCwZk2NFBZumnncJEb6a6Lvp1kAZCvMj1BuRLKS6gGAGuyaKeH8QrlO5tg70dEnR2IGnZ5a8Z5qg5yY3hxxoQTaEF4rbBsWJRjJzVpS0WXhNy32/eYqaNK4ax29NMJ60wWdbZBCJuYbnz6RIGhwz/UwNwPvEQD1mRZBUbQaXegj2o55dj1K1sgWlfmZUCJcHhVVXB1Zq14jet4+JbICpW0Dg7IM3rxVClcMMzzpv2L0Q/vgsEewk9B7TZwDAjmtQfJC9PiPDq9AXQo0NHYUQ1FGBDS+n6cg+Pq2phq4DMRHHSpvBTxSeDNtr58pNMcmbPSBjUSdhLlgB2t2xCrhZ6chnxWD8ppxqmuo4PuqQBRYMe8sUvoUjyej0ikdr06yCwoWo/z1yJ/2a3+uL/sPFT10/RZUgHVk3z7UFK80wcHJyHi3uoXtYRYR4y9skuAG+lUcpAXSkI5plSa+48jMl6kOlpBmBlD1uo6pq4Z0f3t8Iy1QnsRsAexPXGKM8UcgGMe7lV3WnCeWRIE/+5HowUPVpnfeYcYUbVKND/ev+VHb8txtQaQc0i21At8x/hbRbUnF5RwO9DBzW+icw0gw7CJQWa8auTlsVorfIoerzRaPS9SgM0MwK9sy8vkWa+JUC6f3DAZNDEBX144hIyex0clw0qAKEQnY2Hybna6yvJdNyPll3R+4ITsuSzsImhlQLryLprAMGie/0xe9Y6Dqn0MmxDRentHZ8p1IMSVF9TI0IXDH2hn0nJw5aaPO2hhI5PmOGIAp6QbE9oHMB27i5Ra/ap3eDnYtejMB/QG7CP6B9WsPpr8L1VsFyqPKHGbOtbXgJCpmie6F8It8iZ11x9GL9yzBNQwjcypafPN+eoqLF6RCmTbH2JaqiO+wpTwD/aMTwkDt+s7ynHF4PQA2OoV/wTVMs/1N1kI+87sRpX4e/ARDg1x4w6vQj2CNj6U7jwUwF2aSHqxeiM1lJ0GgQaUlBdhSlYlca5GsXWXM+pwsGyIvLiNBWnvf7xkf+q4S70aqPaSFBDup4D0jZljcWCWEEoPE5PgJt8InrAxL4f1/83cuoNhIKgNthuJ+HCUlaHXKAfMrkJa20Cl5z/xU+L6ZX6hG/K18PwLcH0aJkPEJ+oU8JI23+6QhISKmYraMW5A2nG7tml/lKoA0v5P6leYUTx/L7niHdbS4vINeB1QwVZ+2KGhTYe1sp8voplpIrj831CxKhQEXFgU1E0dhv3VKSXJuQg26PpW4LXhCuDbyH/lI3yxYL7OZZUPJvabQ7z2kAMcX8Wl2UW7K3yleoVOlQhBJ9YI/E6DG1LRWoRDT8nVPkANwYYurcVwrHymJN1Ft/Dxy6s7b7uC9YddPKuMBR0K6fPhYKpB+gXbyGai2Fvs5nS7hEwJeViO51HYljJ3fAwIv/xGwwFVdsbTm0A9AeG4qIYL0FxIO6eugVXGrRNKQguAx9Ux9eyUFedDufWpIfp6WiCDVH733whR7ZBueLS5nK41oLf62oWfGi8TS0zWA4L+kTKsl7Sv9CCF6sk3fKbj03TC488K0nzm/F1gq20jvPUZTQdOpkoAp7aFZ46eDYuJ3LGy1r1dtjXA9shZAxIVtFjXP17edvlkmIUDyVVc09RA0FoETWK2uyFoyw6njJqwCmtETv98+YqKNGrgPg5JgXLNy7AxqbrYocl5iWG1nIiTWwPozcALERSVibhiqzyz5LvOkHxdSNXqfzQ0Je0obxREeJisOlPARFVnCGcPYzvBE7hex2+BVPfG3WS+/Etr2PJCOnEBZVI+CVzZNxbKHth3A83tMJ25ynalb44zthXvRUu6Bqf2ypH2YTIhDwe351ncPw9t6oEWPhf0ayA2VpHCN341jBlvt4bhs02F4xUAneeIwtAOSx00YCkv5aY9juwKyrBd37Tfx79zq0Vaj3Auvs8nDd/EeeOokS01m+6+ZurVgxdah9wZUzN8uce2Eop5EtQTjitBB4c1qdN/phJIn9O2V4xjKKmCHmYwXHyGTRx9QGqA8upBMVlcyX+NPLnSiRxg4+P0A5HG0/2i+3pETp7Eoz2YSaDsayImPhAFnueBhGMAMooOieS3QoSQJvpsafELx76Ao1xnaSgIq5igZ9XKLZ8F19YKSdWgtc6o7E2ahgt6Pcn2Njf9T7+kj6hf2Q/qClQ3vEAUohCQiot0ukrwbAGhI8EmA/WMeM+ScsO3TrWQyzqKydxUb2DFjEj8O1F/epDi9ALVydYydl1mu4uiYwAjZ10nFN645FdaEY2zg/34rbfsKN4jmfl1ZyIvAN913os/RqZJItc4hyK1KI5S8yUaNTttmMsf4gIcHC4FR0oWbn6mSPfRDy9riXiSGLbwAR/mQXQVnliUv76T/JAwLW/gwdTrIao6tN7Etmye1ToCm7qDdaxQtS1bFnT/2ZS9Eufnw2aZhYST4pVglguGO7ZAykyfRk8MA3m/opuXfy5kVVJPu0BjLV4S/PAcPbNFWGj4im63Woq6ygoMTEfJJrOUr0yZ+CK6ZbrBeNI6ZZKxVSCMOfgWh/fVRD8cuO5TWRna+jqC69QxL3Y1SMOA4uh9XrbdoSpYrLOaI98wdnql8g2TDjf1BPPzZw/887vZUzm/6QyFSEvdx6ukg8LU+j3IgAI8g38W74KkH3WbBWs9n2z7Hii5sckMBk0VPU+2/YaOV4/bz97AZ7ZMqPcMnajpG5E14gw7BobTQY1NRbJQQg5fzekscnoNL1h2pt7ZS1I2CzMkaWsJNtyo9M9n4ueHs9e2KEu5r4XnWMzIbI/Yx+FEa1bgZINCuMgn6m/y2eE0Ji4kFJjVc9zTCeFAo0HF8T0c9cJpEBw8XjSgVwrAQjMVaV0FhLjEF8DowMVLaJKCfvayBkl/CZKsvlHSSpN3yOLgwTpJA2iFUiGMMk67FXARUyvOMHLcGJbr3uuNYkSgoFd3t7GfjD+aAzJtV92Du/3G86Wt/6pLWCt+BYZG0YGiZB50vahR5JlJWdEJz/yvmRO23eeUoy5BzDFwDGu+dxmZGVJwOrHLtzDMUhTf+ZqTisKvY8wely1nzm0X2T3/aj/snHh0pZkfFPTzKYafbtXNAcRPNJd2wdzqAhZkyrSbgyc5yOK82c6RZEzzRCXVmMSneV3AV5tYUxqRbhT2kSSASCEZaBtKoanUsr1SCKpCPet6GPeL986loyC0KIQhnhOrDbSh85Ld6CSsHb6+IhY0EOTcGur5K1co0gmmNNu3Cw89D+jXbPT2U20uCJkhKuXHVVAf7kfUvAs3mWU9FWwRgkEfshkbWXvZTQFPSTMuoPJ0NaDWcIMGYXj0N6THJXDvZ0q5SOtkr7nIUcyZL5CJV3NsYMDBBV4EY0/zc0jDAadW9XvoAASKfelpqHTqooq/MRae5IDqXTXfAH0+nkCoYW7tXCJLoUtaF+evacAPYpqvjpkFXZMHz9oAstG/r3xQQQaCPJMshpRAmmGB6EITfWpFmdSmNCNEvwuiim5wFD5JnlWpO2LNbFA9yFDUQpxT0ZwiiUYHaFS/5TZ1zwmB12NODtX8KfSlKRgOsNJm9WaTFIavJsrRVjbCH0TNu1OYP/UjAEeB/Cs21NeOV1ok69gugjXcuzo980ak3v3OSCFuQRR/iqYSBpSDLJP6nOIXuadCt6CcrB1n+AcsTPuQj8Y0PryGW7fHWOM/DY2+F4lr3ZXCUABL77iHVxfLo76zLCKf3L9HO9TTzsNv/EqG5bDyKLBydq9gzNOOilqnkSrT5f7cBLv49mriHOwyhEkbARgNX1ZwQ/6SDzXE2NYf6sNZrT/I1TCIJvL4JSLyi10czDyHeBdpehYVXq1YREh7eH8LvUok1dqSjFpwyhfwdHlb8Qew8ogHk0jPYqMMRW2TRvgIozYjIJFHXLkfP7ATjJjqqZ0tEHnSfbBSSUsiNLj+qNBSHriOdHqOK/a1Fpxw8gXNPdlbpZkRchsIXq9/tNx079iMRiGm0O6ldIyfnE/4qIqy2MHAkozgzZEQoUr43DbMnVMkGHw5k0wJAjdHetyw2bvSazh1LYC6S1vq4asUmCq9Oqo9IY8JeCMnn5vs+WVvRSwjr7AHV4zVa9HPOB0nNleM6d35Yn79/1rm+pgcK+ysN252Dud27qWDF2p2bTHfjk5WhoHmh9JZ0SXwFttSNSRWKM+7InmcxXeOSytYtbwKIrpKllnVi1MIkgDDxJvH/yv5jVGRfwtdW4tm4hgYVz7veIoN1quGGUTrvyt18QoqG8PpQ6U9uVu8pMatEP7fuP5zrfDUtuVy2wtSH/4H2l7+6nsoOl62oz3UFEq1Kgv/bzwXUe+7hRqNSct6BFrJjjRmUvEoo2LqAHZpujacc+BDmuV+r2llhp2mB5qKXgcMtBu8SC9STw41U0sQ4eVwEZlc6W2BkNErhwvDZg3aPFdDCvPMpRXg79FemC7536JPfymrHRNZJKnDEDEIj0TrziB3Cym7xTW1MDwPl8Y1j+ObamuKp77HUY/oayXAuEd+21LdX6QHr/VQd/3xdp7quyYn4wgMVsT9TC08au0wWcOW9K1dIi41JMlx+pYyNhLUOpmJ7ZB2n4tYnqTHouXqkCyRRpMBhlkVbd43ZV5vPMOpSjM/JT/zkyQBhQM5zzYqmIXOZayQXBv9gIKE9EHpc2WggENc4n8U0v0mF7LYLyF3lNyWsdpkKvUyMdgC9BEDtTLG5p0XK4g8o0iBa1zTEJO5SKBTyeMjB7y1yVpZ2jnXnLjoB+bZl5AgNL0f2rECJd2EYQVTypTdyM8CVsqK5JjtP0TtY6s3GqgqyXKF+cBXCghthDzvmTW+7vtsuTaj/2u/4/hVDWIX8r5XMTdzEwLYJRY3WWmCr7IgI0kJO9gHAisUAy4RIwYFVUWeMLrZh9G27YMALQ46vZji0CfyeclPAgaYHvX8sVPGa37CwO5g7qeHHqa+3ZIa/o5PrY1qb1b1ya99jLhEjKSWd44s9x442hapDhX38w8Un+vNNGdew+rGKlXfZjT6AI38pCkwAylZOwI+7bbwfeBNGWg4JV7B5mNjwuhr3+dRnWtYqolTe3oh70UgNDyQ7ti7LvI86AK+ESFsiVnTkB/3vacZvdawkQGb0Z7HrHDZ9hYDvcraKp0c9ng4ZAbJWVKtBjMzva6ad8tlfRkU2P1V2qlUWar23nqqLOM4EU12LtJ/RshpOVcLTHnRhAy03WCmLFsga4naPqQIFJgDeV0ni1+M6jRc2Ty1u9f6CYG/+3YvDxM05GhavUjbwafQNMUY+Ow6nxIb28VqSwqtgNBhCJVC1mtkN4S/Jsiwoh3iu3OIClx6W1kyyBzqVNUh0cgFO90X+iGyWZ/ZPCIh+XapX2Nkr9Lz0pRbINy7ksPv33WaLizummDPdePVRpg4CWVxly5UZHj5SyXMxRqwoEKsfaNlcxP4ay2SMUnnzbliv+7Bw8AlvNd0AR6iiKACQFwlcuZWSFwGSx25qjuQVI2QKvTxyN+acZhcEdhpKu3sRywlceohcjSNuWEDz30z91S33SKIaRARL5RKTFcJlMZ2GUWnJ4sTedzy/urp3JOafLyfnt5KFJDfDkDeK6m17jRd8oI4YURtZfGf6mlwHme0wklm3WVB/4xyH6er1lpU1wH3DcHhVheSV4I++7d2dA+gujQbKBTxWeOtx7WwYZrSt7dpavsH2mZtc7OjyZGSaEUPbLlVUC9IkWkvLQuRUJE+uhKpSX80uvoVX8oA6ecKDCBUUMsuIKrzKwLoNOVTXnP+P0mmZj7SyhGZsOnFA42weejgLStcpk3wAoZ6YrhHptm4bwu1R/U9vYHvsN4EkfGbhr4Du9BLZGBys1At0gVUdfSBoVfhAwdQmZlj+unotJq5s44+fUduePMtXBqcxcBELjcH8u6Tp8jlcY8aVQuoY1tRvJPL/p3UJZHthDRFCkbvXN5+k4qRVZVMJYp/y0MCgZ42hBSaOjacbUt0kPQUHiyTAHt6R6SAwgX2eHSQl1B3+fScgqob1Pm8vIyADMk2iLktktg2jSmX+LTOUkcuEut6RDxk1eamD2nQp0OSOMO1J8NdbPmmaeWIVjmJy3ooaTx3iZqt48/7T8cuKJ5ps4gynZk28GlCR5lkbhUmti+giVRV6Wk1XKnIp731E95VcsBt2dFnuK6PYRNqiJlD/3kJ3odR6Hi+yoS+jpIcfZIuiz5jyvWD2eowjwBxWXJRkEivst1Tm9gKMufgD5a+h4PKCWGpZ3Wbw+fUR7CiLGTxHWWAAAhDb8BVqWdyBNXF5LYt6K8N+FngS63jCELhEmOaGcy0kMr2FgrPh3GyMtZWBmDCi8P30BMz8EdkJZeONwZFEkclSR2LoeI1IvXK1raxhugMSqzYeQCWCfYSmcksDOE81LU/JgNC1FL056IrN58aUthUgcLIQmuzfLAVR5zmeZf1bfAqO5D8QW1N+T9Qh5Fcqzr3MEsL0u2BMx0p8HWEMpd8j4qQUYpsH2FG4zHShnLdv8OvBeHTulFA+s9fYd1TjItA/YDuFU0GaqgAJKOrq4KozGUZkit76ay2Vdxg0vjv4/Unl+UstziZK3lKQEipmrku/zCyAI1QT++q1wbkBDij/bD2oZ3xzVsYWbd7pVW34xwdy08hPSBOgSjNUQzya2IQBcoQBtw7TzQ2275TP9KW927o9I2bS7Oy6onAQm/RCY8vBI/6BLvNhMxo4uKZwNGf7rVJOdjbedgJjzukiwInE58DLyyqgPRmd8b4SCZhGEf180MbdOWQ+sYzQoeSzC7b3RtDjF/MwGdZO8AQjAbJSm2GHgDxprVBlnkamAfTd9sVGcZsZsLkOc6OUorOA+LViZykBRZFgwK2BVx10lTUwNtjBbndzooimLBzsIq/a7oHHB52kHgBdd98zx66Zt1e3A2W8hjruYlDroTMY2EBS26Uir0XUordlcXU9tnbf66GTLPaLSscNnRFO/aiKU+t7oOfQ8z2591xj2EHd3/pxQY6bGwjcQ3RobNF1Q6q9j4Xw/10ZC/4QTUrxRwYWI0k4JnPfTjgetElDoTzn8UFVJqCByReydpGgsh+NSfceWkuLguT8wJsaERITcsGtxZajT4iaoy1BqNRpJJu6+OTANX7yZXGkzZAvwFTvvapxrJkd2gMVwdRpSKG/uxnT/hve0vzV9XzChCA/x29dgaFAwIh57gmubYfth1itfq6DbJYelqjDMDs9LoiNpoBYlW8hBtXWov6b20EoRZYgx5Z9QTEeZCamDrZyJZ/DG95xWhz4BNaSXTOQxxmMWXXBpqF8nKT1qHY5BPfN84R1YZRLWTu4WZ1miNpAzGhkpKLA8zTC1A6LaF5yIAJoCJlfpeHjwIAfGiLGsFvx9zbmHA2WYefIWkR6UoEbJrPivWMbuddlN0qAvCzVPZOlaTAz/btPppKYGInmmtczDfOmbpFo3ZWl6EdSmz/YHKDYFAOllu4mG4v01WtlDpD4SGauJxOf4JgjvNLjHz3t9QdHd6r+e4xTBrwHlNRVIecTgfj9AuD2CCMZlNDX0mjk81rEy9i4E+aTxwjLD19Jovncpx/w5JFdAsjvqVeJNzx7ZBG8Azlj3aBim5g/nKTW/2ideUMNbvYv+WhRLcCJiSnqgs/6w/oPgQyffH/oRsZW8yV53guNcW3+lfyUT5QRrck0Q+k2Y1Afn60suQ1Vjb1w4i4/uGkx9VL4B+f7U9e8RaZya7ik2ztL2RGa2i2y/6h8CR4D/VvQHNx55gAOY1l+5n+ORhGRWkxsFzXEEgG/I30eXUBgqekUdhCbwlUMCpKnagLWfYvcP/YJp4A+qU2Tsr/PWBWW/TZ2E0A+20xH+98K0BWpOrT+1sWGy3CCalc59XLN0PAmB6Md9jJ8iTSRjItQvpJgobXK4wZIHv9QG+W0SRggdw3N2VxshySKNENtjEj7L9GeFCD9n4X32DoigYa3Tx/kKzvbynY2nnu3Ousn8smt2EtEaFc1Wra8JrKBQ3ClT0FVprHyiRJXESoR8d4nIWL5oJWpvE8WGsS/2tktVqMCQDcx+p488cD3qGmJS/P7GeGW8LAlWC5ACP0lPBiHl0R0lI5xxhKOhnLne+EDL+NnNSQ6IpFAZ6Nbm4GQIH2ee2E8Jn33db7dYHeINvdLTTnGe4EwhByVs3RwTuklqKYI6Li/ibupDszwMPrGaEvyl/d2sm0duOrOjrUa0QgMCsI4NIqXqIoB8Cn5AYgD8dkeA/XPob/Pi0/6bTYf0CiPtzT1Wq+QYk4obd6eaKBiNM506AWjGNnPndUmfji277Gf/3K5R/z5uCj8eLV8dqFfesbsvZRmYmYlXWRB4bxAAqef9MXmGt95q5+WOARW0/Ng7+75qtuBn83ZgEd9Y9cxgxIWqrIY0XVUYBVr2V0ybbm2pbMJ+DQz9XGNboLe1VIp6irO9I+UY9xN3OfkA7bjNLiNM5XmXSKl3V91rnvm/TyZYae5u/XwWMiicrDUf+g7scOUfLtlt2qrs3mshjm2w2TymkLS+DzDtxT3ACEBdRV6mZeFM9p1VnBGWvT4aJyJe1nsEgcPN6khWeYFasBSJbLR28PsTpVa9tl7yWuBTLfvkpVX/HmWi6ezx9h/qz5Cos0yyCp71ieVdTkgBcPNu5X3F6fxyT4gF69ulPOVSu/6E0XrtEixwHHnoxlai+AQBTIvrw8j23mh5fNt+dYdONXsIrsQvHRbcFQQdI4oJBqBnPLPL9+096GAh8PEhmSs/OTWUphkKNelDkS+AOsWCTBe0NUOXQuS0dkzrKioTFJYbttlIZsud5pgacTD99HvfN0numAo/mewDdFx+rJdpy+ZcxWhwP5rVjuHq59h7AaskX3nKM/T2nzVwvq/qQUFFQVgkH2CqL2THLpzySRRqu47DQObsBfqDRnoa5/17xCWY7EW8/J9yUY1+misBDQFmiupnQSGA4cOL9rdCj73NedVtBJkv6JMz2MTYMQftpMm/XhKqJ6nmK2C89S6sat9rKfjrLKWD5LU+7ryG3dRuKIX7ihciv6bKSS6yCxzlX4NiFb3EVVDhxlvdvlN9zplmIo7ErThdXINd4xhSoSZnsoQbpWmNnnmIqvdeNvEIE4NY4rGrOrZilwcWQrFEKpzrxsePR9DiIR2kARG8wYk6zOeRxn0WxsxOLhXlEDGDv3sRdj1duNWiWZzAlfHNPUHd9J8aLHu0rsgMZtM6sb04hC1Al/sicL1Pw3WL0l1JjqTdPz/yeN8btJ9ldezBTjEjm/82rDmeva4Zwj+XMBE1IUSgzNt82emt/M5tfiHkOvwq1XP+Nj2o1b/rHVEdOzLQUXXHytj+9z0xs5/TwEs5rRLoAUOF2MXtlkCLnnxWGa2Ftbo3h6GlfxkHe4JFE70pKNSu+Yyg0r6t1/Qx3MtMWqIemjrWXViy92jgrKwDSpLLDpJhIDpxdEumthROXPDRD/NmUBfp5lHV4Z1R1rCaWsxELCO2dFpCAVVux5srgv9E+VVOu0pQKINVTt1rkg505h4iH8RbEtWZZTHX4pNeos9pNvSnYv+lGNDJ18n/K5zG9egH7stRnwL1nkaPzUtvm+AZkg6LB6hpl+iHnVvX5DarIlg9lGWEvg73eDxfQ9I4vNuN7XNVy2GTAwXhAUmsnJLEFetoB3dVxsgX2dZVzcjhd7qM+GzOmJOsJGdH8UyuLrUDoIpsEbI+iouyY+07ZahQ7eZusm1CwObJ69G9Fb/a8Lxe4i78G+pYaklcePKjpalvoVL5SNu7X4IDxIWB4ljZH/jASowhKphIgEfbLkk/NQ0c6rq9XD/y5dHsMbgKZ4ZPLXrDeuBfIZuj7bCs9SKjN4npEcBuagsEg3nK9fkpfvNntZ2LlJXPDy506KcwwQ0I0NNCNSpSC4K/PJODqLSf5+PsWpnGhevqv/hx+qhbfV5ob407E4Tlb8/rusYhRe1Gwh4bMB7dExaFMxqasfZkJ9H1Us93jc0bmdp83MNg1hntTWpf1J9ErDdUOiA+dF7A3HlXrbLVxIKjP8GjClpa4y+5QJNEOJZv+a1wraA7KLnCn4/X+Q+zpoSUmzOjCq91A3kfDoPJDEHeYEGwJEd1Gowfx343WTR9QIER1wnRog8P5Kaqlpj5UAoNLz9BxbLiiq8KJdd4eos7xhVSzeL7yGpqeDTu5RkHpnrX+L1HRYU5kfwUojlVAAVHPtscCArtY4D1qkhXNc4wVjRyRWDYqPE8Qw8OfRdvPbKlcuzDqnD5OoQFvDQ83MVkr0BYUXxJJUsRO1Hc1baUyjgB9oE+UzLvTWf3qcEJMrcuAhZR7F3mjGLi5a9QjDiTRWDwtzelfXhoSAITRPRZIX05qTKzvAauZEAyNiwmRTrLTujZkG2+8z+R0DIorb2Tig/uC5WUdJf+bprK/mFA7n+YOWi+sJyUo8knGIzSjEDPfF1oIwXVN7Xj66SHUnDYvNd6b2fZrfVyMPmJwUTRJRxfSl8pEKhWfyB+aue+BGigVCaSrvDR1mrHiPm7gldRZKiWQ566hswIxRqhFXcbxpiCVHnHK2daU4Ws7oPBh/1PAT1IJXQ6N98vzi7MZoInPmd7Z8mjzdYdtuUcXic4OyJ9XagvaU5QzTLHaSkEz8OnB2Mpm6oSKLxS+meQtHO29BQ0/hTRWBeirLaOHcDawws5fCoQhH1kdJO/kyzMofpsIW9fRWDRJJsPihCjXQOIQfV3DQ56Ep7xdWCDb7grvlin5XMOUXPPNmcdbg5Flv3KN01fWS40eqHQFlsomP5AoXctiqymm08TJIs6qvV2yCQVowzh0BBehFuPI/t5K/W3e6SLbRMFUE2qYZtv2Altu3KsaXyxKad6KUNw2F4UNh9t4wsjiJMUj5bqHZAsBpRUMD0oTmzymi4A6dBfQEVzffuym+/KeF3PkRdUFQX/AazxwW+c7LNSafHgS9oBchunLwiCPBFVTb5YQrBplnpR5msq9XrhzemKJAUuQ4aRcErySfB+ftEKtw0V/t5HiTNP5/YUJCjgo/6UKiVVoiL7gdORlB/gW0itZHxDlesdXxW94mNuKCDD1OhsF0ITCzuX3CecwPWGXlVj9c29bOnsbQU5QSNk4XoJ58E+uxrP9iCR1ZjQQq4EYA5/sy/tfdNVlyZsM1LgYZG4DsMZ8C2xrHeKBVGxhAY/O4zFOD47gZ+1MKu6Z8TIkHM/EUUQpYP7FCTceN2BKCxp0mxFYaK1TF2aKK5SxK3PagxA5ZZ9rOTdIT4x/QFzGNYjTDpxqA/dYLdHYdVWKZ3Vz48h+kXa8clwK3OVF8/sr8d9BOpkrvPZYb6Xv5takbtj384xU/GwIv/9pEAzjii+ta1x510yAHnMd9B/e+7Oe/LRlDvyJNiF5X9HqCVah0j8Q8v8iwTKOA67UcBYnXkMc0j1SKMzNVdDqp6O1JfXQ/2d/3KoPjP4XGuK+QSZsHS35fg/1OoIDDV7OMQfq8lODq56YR/m1saHyvWgK8oszsWbC8qkCW1hsiz/+yoHha2yVIfLl9lzrGF9KwpzWSbqabVj5UQWgx2L2U5JBLk0DXJPbcFVmnxHmbGHvwXD1nEbM3aMzVi6/0EaiTiwblBlVVTh6fx1M7jyCuY30USBaTKU9bfIJP4flY1";
	decryptString(A,"783e007c783e007c","Password",oFile);}

void writePsize(string oFile)
	{const string P="Sz4n+IvIwQpFq4KqnxiqTwFXQdEu/OYDBem2V00V0AeuScWSSUhPPw7EzV5Y68vE9upZKnBU4Cq6va91RGC4NSd6jeA+cIzyI6DbJDPytkTiu+EcM+rYXe2M4J1kcf1yiclHpNFPXoIVcpK7KTt2tbXQNDjx3d3BmPt+UudsFCdFrwQxInC5kZw/Op73BlEELXFQ8AOb4ajQaw7oREQF4ff7jDv6NB6xvh8amY2se2DcxAewXr+SWkN+9JsaEhP06gCReFwklAzl/FNfluDR5A70FJ4+hOMJJ5V5QDEKLOtzWb6tUWerG+wJyjBxdTuyx5huUmmrqMHB5xOo2AdCWRBKSSEQo0S9X2k3b6qn0VchqnagOvZGKfjy/+iY6ZjCzwEairFBxYj4CmiPfb4C4phFfLRREv9HVaySoFlWZEYi75dVMMOJfOQCnG8efb9ehZIAxRMRMz3hBsIvCGt7CmrmFbyZkoZFO0Lxhr5FjhzM73mfmcZQn6XQj+LaHmUnW9OdmeQFdpcYkKEIWs5EV+vZ/lKPPGj6ijs4V0ped/xX+RKrzHRso3sP5wFfRdPyMS1oatIRX4rUgocmsnEvntmwOgmFYnhTrqtmOLKWkVB9/KXIVk7U7DZAzfCCVSwG15adkxIIIukVuXMKFC07iV6oH338VQLjkWH9Bi5/QQXUBMgt7Se1FprCNmDSBp+xl2SNf5bLDJ0YhsBgZ+7x5JgmNYTj2DSwM+PrpcqLt4rYJfH6O9t+0RDKRuimE9RSCme3MTN9j21PsiPo/3DUteN6dExo5EE/XnUCFzTvB2zHDEzpMqOFeUh7rMz5gsbcTMH7UPCWDlfphVojZLQQqPnY/A0TYDfF3l02xWAM0BcLev0Lin1LFYp2/+CL+5QyDawqP1v4KlGS2auw3BcuoJ0fDuzQx8rdZAWeN0QrT2LSgr+zU81FBjVFtExhuY49UO3ovO7j3dZyZxizz0DhuwEV8Qd9v7M4Z4polQIDXMC/MmP4fz/nP7NTskfFDxgVCWrGUvZwRWMG9Nb1lVU9O5x1/+atWd5l5VUHkKF/NCwec36Ch+7QYknrmpLCZNzoU/0b9fGcfhO9JjAn+NL+iJcXM3WFR9/HI14GI7OfcNhdT6/tjOK0+CT7MWhPu9gc2rSKs8CGhxL+5iCaCIQvUtV7MqpBHGmfwfPi8BjLET7jj2EyGZnRtiod2ftQ0FldYNd78mBQAq1aqkGCdSf0zRkUwkSf4/NufQz+vLq1UHPH3GVdyxlYrbvXa+xvpBIOozfdmwNYLouLHruECQxQopW1Plfq9+7B7qrJEBmTHKeXBlqoEVPEcOf7laaLSyH0oJjn6mZ3E4eIGT/RJpGpGWxIYFI74OZgbhMCKjA9FQGdU1xk1klaTGh4W36R4p7tnaqQd3sAw/wmOO3m2uU1kIV6mhn1jKhk1j97FyiqDmV+J7cxqfQhMgvf6slQIEnccRfoNRmHE3Vmbr7DqKF6ibUEEHPF75rmjs4479xwj4juElcXF8pKAFimbHq/NkPckvjfe5WEpdFmbX/WG/urB8Tqzx/FBG1co31aSvE4SJAI8zOCIR7w5WeNBYurclsn80e9zDq96ZYJMsY0x0cbjvMPmJ2YGZpFKiefG5jLGtGpsiTlKB+m2pY7nzfn+dhn1/hM1EeTSRSnv+Ns/C1i9B3vLo7K81FHO2rJ1Mjp3PJ2xZ1e5/wbrilkjGvUT7dnzioDmDhHsVrfA5/rmz5egSPupyiAxs0Yxw7yn2RXW/efP+hijlFZLm7G0qojkU7KSeHwFB/x503C7POTwwBzjygf1vBcwy4riglR5Y5ABzS73ve1EumIe7hUONaW4JvI3ZqTV9X+UfdTjhzsg9C1Q2qok1J0dbx7YP+IakTRS6q3mllv5tZMkErhIVeWTjo+04WTK2/SJ6u2e8pBd4ZgeD8cNh5YheYILU5X3DAlvaDfnWHJ1KMF0+TPe9UuBWzp7464aVFaQLQRRyiL05OlYYhNeU7hd6K2sLsXsOCsJICgGyA0fxttUXlwS1ADvWD89mepw1gRlhKpa+3BNPf1/T9MqbgXmhTrEQa5EPZhdjw3Pm4Slg0R0d00CNI3qIutmPQKYgIqlVx8TO+DrwTDFIYPeAHrTw62AuGVNIRyzp5ySIQEDHtabXqVRK4ueUqckKmMtJlDzlzfTJsL8P3cukDZKWdrbXYfQpUwTgl57o5SfHYwwUprOY6sEDqFEOt7JCy2rkOQlKiavsttfTvKl8HcK12/S6py0yff4gEzx4ayfp1Mb5CIblDu9C0lazNxOcTdxkSIZBxIcogvFp0RaCX0azovinOCdUJQtbsZ3i/RkvhQuhfmPcSyA/VwXW/0kC01D9nuYqFwl2L5u5huSPqdHjLWdPEUbwwY1mBRgcX5PHY6qsHN0WUVvJFvgTnMWxWtCXMzes9+YGfJAllsZg5tw1/lVP5fWTKgss29lkQZF63vd6RkOfrenWoaQyAVw/RGFuLTn3HxNvb/YsQkOikgZeDdUHGBbC1Jo/qwVZuwX1BdKIpWuB5PNj0vBut82ANyKFOwHZJJtDIDOFwCtEy4Tl3Ejl8PV/oICmA5ZX8+OgoXIf0y+DBKu/hz/o3xymBJwb8yKvEEp06hArtSCjB+IJizjitTNRsk9+3VolQX39zh+/GKw3mbxmxq8hbVBVEiSEFIJptVEYauwucaVZSfMTJi+ylGkypyd9BiWH3KyFnd/KS9/lj4I4UGQa2oqpGiyyyY8ygBqbrzenAxOtlKSD7COjOm4TKZxKCEiG3bvBVXN3QYomdSuiIbMdQSGkYKtWOQsMGKlIGEftKourzx43XW+Y9bRJNgZ3vHJZMOY/gCl4PCHXnJYmh2kkytqeIjHfCV9y2+fZhedbF9+gEZaD8GJa22kmCzaHJXfAXvLm28z9mRAY9aXC/3Daaw99RgkI8Yj4vVc9aTI5yNvEBllVLLJt/Rx0IVCtVJTnpRAeIik8vcVhLb9Y1B60dn003WG4bISrls7u1yG2QbC/M2xODQcnQxnvuvMP3GdZ9TjFXLY/4448Rzt+7mcRhIlqGx2pMGfq4dpp4mI03Q3NTvCBM+2pSkSuZuAjTv6zCBOnF/XV0iw3N4RhdyIn4Vl6hP6KHDybj8NyOTNiFeWMdDHQe6/fVchcZvlChxKmg+13bO6CWxyFpxNqb4pF3Kjc4BsmNLHg7hJz0CdYb/7gVHd7MdH+LH7fo+h8MqBNnkGBbNXHsYUYYEZzzr8YZdl1aYz05cqNdLQ6Z0wYydwgKW2CD2dQV6WF5JMAqZm39RaGIHvIcku0d3JbeSj/SkOZUvvN27CCKftWUrtCSeaM1I3noBwX6ztUlo6L9FXvVtWpX8SrD3cJomoqOaLuDqK+bGAbh9IELJ6dmpbfKIqA7A9a2r3KDLa2HteQb9M+cf38dgcMjJEyiXJV+Id0LQqZ7ZBGcA1Wf0hAvQIwAR0RG8QWn3pT9bV4o8ujDZSXNnN9HUfqmkGRsM+Mc4XnthUJrmzO4bGjPYxHIsPLxdx+EokUujB1VqwPkLWjzqW4qwshEZa98CxNWtChccvlZP6HedLL14IUIFdwYCZJnXfLhJs7u2Hb2vfSztiyGCY9n+3iP2sjmM/hAMIh1/UJaZVRevLfM2+tGPUBH3CiVfb+neRx2g9OmsnQ7PEpcgakZ15oJOmFTF/THmVQxXi6tzAGrFKlAKOdA/VlBvY/6JeUFWrwdCIzrTsjYJrMZtrFFOo4+K6EsIqnL/KjPaaXjMD7oAHHPBibavNm4LLHF0sYsQCVzlKrY+cBh7XMLVjsKDTPYHsLCmdDZg11uYdRLDK8ciYi+7kGz6aIXOdkiyI2ySXTIJ42SJtAq9c3P9Di3L/GPMfG0cjRQ+ouiI9QVX/PhVKgU2Cib1dQW3Pmw7BiLBCxbR0mcYEr9+TxXY9ZVBipW835RnvqfX0/9lSHOhs4ovk+ci5ebhGrzglHNqYnrpbQL3eCeF+iUqEk1pXf3umhEQlt6crdSeJbZQrbF0HafBMeLN78Gs8U5N6rdYAF3IjXY9EBOJToKSIhdsdGqPMMZih2tC0u1Q3ejqlGk6kmMhkmC+bTriM6nEvNsqNEXeLXGEgcXfATYM8/eTdvmfKI/NZI9PjkLGKR7Cb3T2IK7eR22oQnpjblwNI0+eBNTQlPkPXiNLTBzCSu71FRAD3V+Ckoi6kOKnmKGGB8yGbqa2Nu/UOwrnYzvh/lo3YB47thU5IWOJHf4zS0YhSw2g6cofCm08WdGUIOAiRas5Z6A78rlpS0O045S2I9cz5OWYKLlGrNOpH9aHkL8+iHHnQ2tIQQfe7p1yKRoiROIUnjISMKtcUM7ps/QQHNYyKO/iKLwHwNgTWpGIrJJ55iXHut1Vjuiudq4V5eG5FBdt+3xVjaAkoHQhfjS5fo2FW4Ae/ay47uJ0xkLHmqZsC19DPAFEXOztMkJBIq8cOgnpLND1W5Cxvu+E6rB1hIjXg71TllBOuYB3d4m/6m5SKsZ24p8jxy381BupgNNFcPvQcQ0TzPh5M5yFz0ozHUBRwWzZKP4C1A6zt4o+dgCoe/jxQ2JZqBMWn5gMTJ95Lmy1p+To8KhQrcAsThhiCibAfGHA4JuDzhxSrxS7Mx6TVui4ZIp9Ih0u74jr0uaY5+pChaNAKyETOhIhRhZW3i7cPIbOyMlS1svjTJ4KM52IOFR5TlP1eGBZZmQWLftknrQcZ0m2QUS1IVE4PZWGraLCfM/PyBuUAxStBrJwsi3K6y83KF5TdeJUBfvtT1iGQcJzC4RbiT04PJ4k4/INWrgRZMyBYGg30vIF/7d3jP/WOEQFcfaXN/r/Hjmd8qmhx22bHUwYb6CFzfxCF0UwfGJ8CziQQI0iyQzUEu4SWaNxshQmZoH0FKTGu3VIYSTqIFNmixTBMNDrXUg7pdmt6mRkU3Xnn22N4o4e/xIzTbi5vf8EUwtfT1m8+8KP1G9xn53cJUvDWmOnnkNfSWiauOgIKGnNzMRiAUIDoPAgvM6xeUeyzOTu7J2pAu61nDn+rMUzSVmVCwjEFruXpcd8REkfQIFz7PV5HLHayi5mSmZDrnpVMMdA2g9MIXVje4VOANPOwM5IMBQXrirhS1o0fx1XnduxfYgEiQiMrAP7nmM9QA1RRwVe8x1Je9CmbTEOJ5fCcIPLdK+gE80Mwzn2+frmsMhQkIY321CyNXbNivh+nA81OL8WeJ4oQmI++4Wqgf/+GS1ZrMHnRylenwd2L+5tBIImnn2r3OrhG+ZR7+uSWHuvH18sghH5abRwgpStrCrvEnTJMpzyK8RQZ5JD6rtM00TBCsW5Ow1Pdkl1J4dUOvGNqPqAMMtLDPkFkveDvuifM8M/Hj0CMHUOErR17lPc+4sYNFzLrVGLMZtuZOWBl4vklPdRINrw0VEDztOoOY1kJIcQEM9n/WFuxmoueZLdPY0lUvTkIDX6WrQMBnZbRVu6l3EHc8KFDT/qdMsl7FZQQLx3haMDU377mjZjeuYXbw753NusMP7MNLw1Pu8k7LFz/PAHnFKE7v85/Ojyz/AP/9G+YlLfx5KP2YUSZ3GprxngdVLhJ7A6MfmFLJAW21nEhu4mbiBi8PW4jyRYqcRHO4ysjnz2H9gvhUAr2VVN87eq3vs/IXZXymu1Fb9NcCC7hgnQecRjq7pfIMJM424unRfXxcJ1MX2MnRFeOMeYfXrVAmU6q2qjPgV7ve3jlYtZrLfFPf8fWhdQKr6hncbQ9Qzl80C1eYsaqLDwa5R/FgR05clM6rq42DTaWxlf1dknA+THtRWaBv7EAiRkP8cl+l/zjIvViUnQVa0oHttquh3TJkY7I+hXFRb2hnYkgFbWuGuIdJ410HY5Q9WzYEQjmTOPEVFubdvKYvlxTA3vkFXiChryaIfFCmsD2ptNtoFPx6YfrPd3BOY2MGPbVedGtS0MxvJcYoN+Y9vr04jbmg/9G/pu3ZiN3kPGsqTU7dWZMSR9rzaEgGKxQU9c8VoNbBz954SAsPouSxBd9rFEKF+kcHdFExPiHtYaVpF5iPIom95xIIIPAd6NwJqiunsmOnTYxO8Sf9P9mUWRaIjs2yr5dv97jPIedWHWBBTaVqiacOCflhmfHKrKhJkSB9isL/KEyeIastXIJVffJ/YKOFfDApLRySXh4D5FsmLNw661eKI/4fYc9mCTLHp4d0rp/G8i0VznNUNCrmkaWnbUj5sjyVXhgusw5NFiYf3at0n9ysW6+OT+mXnCHlazF9eRc4b6bC1hV6Duk7ZmhBgWQCeIRkcZCSHXpjLd8rr5SmW3dNPheZwipykisSNFjfYDiN5L2rXMDLWauhcjL9fgZltXHlKBKlEu5vE3DrHajErXWDwHIXi3ev2cPBMmkrwxRy9yajoL7Ycyd615mrf0Su3QpRq02FpKfv2yAPWCBHYsygaQipJTpgcZuILzzG4McqbKV4t7XzuaYdgoHiwpT0XvzZqj/v6OIvmVgYmSSejk89ppJD74Bs0ObLrkjxx8NCAtBgj4b8wa2SNCNF4vHHUDIHrg+sGwQ6xVSTr9dZNqh67w2Y01hDtgyYP8kDqavfehB/zgdhtqyL4klCea8QHiRxnFYKllTnXbQIObH8/dwep9IDPZdbkFbxKOj0f9Q/hYRJWHaKSpfPww8FIJOuYOK50OlybR/H2zZt3E7k+48NMJ71cckL1MsyYU6wTI5a0Q3R/YqlKWquHZfjMdPc/FD1zLsliUKYgSD9TzXxBfIF6lHPmoKMuovtfQfQvFt2VhNfaXbsASB9mnneKOl+X9pu87wH62OI4eo+ZVdKJRBISKoF+qQ9g+wsYfmmSNuTLxW6+mRkBoPVCcvtjJoa2kaqPqskFKtQ9Us3N8f4dZagtePsoF8DAil9aoPWBhoKePcj1/nP2AnSochgniflAPasQkWceV1PeR2Cffek9JeX0/lD5BalrUFcHSV9NH0pTkI72HJzVVIUQvRyLFPWAobNVVumNdY8nnaCHq8m6pDQaxquB9/zd9RRLD+gLSlEg25jg/qQmcX9N8nWkwAy1/9dsRhSq5tqUgj0h7tDWafNKQASwWt2inGeznqevqdRPxHFtbzioBqwHGJePPEbSVVO0wmRKW03WVnb14m50ATSEtdmuttycBWPAl9W2fJoWnQfVQ5l2Hb/6ZFWiRP2B5Bovy0F4x62voqP2YFOY5UU/0NvkL69M3eXUE1yXQjRZodk8QE50+h7ADBRkQM73/UK+n/KEKONF6WDJEiayqOi43zJZhVYQ6YLVmzTr66tdpc+ffPksyi4TBf7aiuMjNynzVtgWInQxkzFPJo2rgA2i6krRANsf9ijr52IsbKGdUkrUU8afz5a2ID9LuxHIOoRWGzRtXmBirpkuoqyBDa3aYzIcgwdPJzD0eL/rri6vYKiGha4/P7e+5cuQ8ysGM8gia3WgMM7Gnq9re3pgi2MRXRGsBq+GgwszjYYPp4lD6t0T/kIdgRwn4p+/ND5j3K2qL88hT6lFkkVaJ8o1fLBEuXtf0Mpsq8BNeDDQpN3tWbqwnbeRjtQhbLceMYAXMgEPVuSz549OjafWsVxiDRlFzFetoWSZlFi3eDib9JLIsfK1Ujj7+LqeE8i96bgVBNC1oSKJUx0vEPy6bkbrF6SxaqD9wf6CTK+dxhttmniQu3F9DaclCZGgP6/l7K7kcMg0zyWdY+C8QKBzAyClv7O+0s5Cq66xknAgI/PSjdVqPWfzlyiuJ0HHGqSdgA3FMr2DqSOvSu0D0ogENIXrEQe1xqyCyCcy4iW25nyg2bg8t2PlKg0I04XyOd2jr2xwBzbZMeARHuVAEluFP3NeRk90+/dcwLDGxKyLdSIyahZZGcvSn/78p9Tf4v9qquWQkv0KrWVYti1e0Jj+aFJpObefroBCCu6w6VMGMykpvlXLj3czw0ywLARADw7mDDxgycy37x/kDoRVlNR4LQGoCmKutT82FwokbJy2tqB7O/Lks3M1kayTxXBE8RE6YPFkbzZ6q+OA7BQMJlUQHqteEVuWzn+oUPidTJYqnplIrpzedXTurA3si0pBJG1SS/QhSPXO8MzEU7RjWkzjbZcHuKJnIOLDJX+MWh3E7Q51jCfwMxsoFMiaUaEkpZfVn86xmDcj8LHNkvZmEyrwPmRfWnVwsi8aYFi59WZgh6VHpgWWenGJQAAreFXKGYVT7WsnBd6g3JscdiOT27PmUtl4pMpQC8P/0WQs7h1IZLIomCeJDKTHLwmadwyakk7oduDd/8t1DcjaFPSXs+ysBsOMWe9DAhvciGTRlKOL57F4bbSsaaGeg1Kcs2UbW6T5GUb6KQd11FSleKXEZckotfzsIcldsufYYIz4izt1XrtELbFtQzZbBLNJEFjsO0KpblS0hXzJ80LyyZXxhRD3yNWiInAcrncNxRqbeyg63y0wSzp0mM6AzDrdcLlVTLdMwdEvJzv8hARI4ZNbKdIsXnebgW8g4qLA669DUpObLXPEKKVGa3XrGzHqO+NMQvzr7gpGjRQpOpYj73TXhF7yXdROhMAG6QSxHX08Lfxsv5HA4ZBcXxgs7liTwzYtciid+qtOgmxa+vbSztbUymGw1beGvHV0IRWNerb58epqhNMc71mf8e/F/JH2mw64/R+fbryb0Wqx1psiaqF7mvctzQhUUqnndV9UnsXlbAUx9SRcRsbGiZiwyNXo8G7yzKXg+r103TfwwQUcfGQ7dxV0JgjI1QlrzuOq4+YfhVX1TuQsSZThPM24H92K2uHi96FAcIZRi8My/juHu2MYbk0daDhXknl/8eT9wSYCeRlM3J15z8ogN/RGCbP5V7VMyaDlsAUpU3rxmpOy5mkN5/BUS2NnCUBNf/A4h+Od7tDZImZL5M0XVhx7z1afH05w6gigpbQ60ZdQXkWe2/tIob68wMGvJjNJtf95wkZpcaecbAHilHRVMpnn11rZ/5KYh4dQB2Ze/LXle6XYlcylFvLCHYqnWJxU683Z6tojeTGYWhWFVyKW90JA8pnrSQjuQPwsF/bKip/o1NxQTrL4AD9pu8f1zzOeHKodMTzr5nQcN90WehYn+l1vSyNuNGXiNiyeNKwZjsee0ViWlEOCRPYZu6WyNo1Rbyx30JXN3t5iiP/qWR2ON68MGjtKvOET5rnE+dBToHttmKdzuQ0H7AzF95oXr5XJzSWt/3PWngrBXeCGhhqFzS1t10dR+4Yh684n+SlmIpqV7CBilgtq5B2H/hyAsqavRGWkuanIDkbue+5szx/ErP9zEz/a8tAYnGne6oM5aXyFVxYvBExI9BEIdpHqPns7GbCQolQmCxU5dk/MprOw7peZ6kZacqODc5u19OQbXvLAbrqqldeaLl0AjmKYkvE//j+ZO6NnsoIyoczQbD/H5WgeVyp7IMmRXDtn4Eh/kMfD7KcIIwubJ/QOW6jtqGLfY3WO0YQplZpOtkrMai8fxkdqVp9KQvGsYXV8MSB4rH3F6EMlKvPkCNeFVvWafmzxVz9aB4nQ3AqtGhNr4ptw75s0I8zikKxhtDw/vUxAyMbj9PCrE0FRmjLUJszTwc9osG1/iCXD9MTATTb2DREVfVz9m+adBdtOJXn1sLB4wgWgLmCn7NPzBrWik4tXVwdsQ77Hlbjwrc2Bc9KvtSei9vYtsuTYG0Aqr+8iFWuloULCbo1oi4FVgrXcgYweiRq+jKdSfRX9g1cX7h8FYe1nb3XGPub7cBCvlocILiyuT+WEJFSO7dY11F1qjrSuL7TV8YKlFsf1dAmdHWVhk/OG8vjNwv4WRy53GTjIbgGTbUW1lz8dP0BjQsIzR34+t7x2Db0Vq5+S6wjn3AaX//ZEYEc77DLnXV7L99DdvGUQhR9+ZGogugxhvxV9YJCudeIIgXFH6Dl1byadr++qLBeWG7Ne4YGigZghWj5jW/1BoNQhCwLL7iDxtOOa/AcJ6y9K2NoU5yFfzzKlnuPsykBeKV7SRfqeoKxpkDrVaHUHF+xj+F5pSlhniOTydcZ1q8acz9kuClsYlHcZVaN8w8CNlwTJjbQjyrV1bFpFKzmbEcy4e/K4ccq01sLUU2E4nmAT897WHv1AZ+EaFSP4aeZ9vZIEJoT2xNuGNHMtYOJEb+YGMUuITvkWPctkPbxePqTQPDJ53nmQ1KSPPlGy2ckGlMk5Dk3Y2Qm2llBhjPmidokXfx0qZFMrm/P4PL2G3rGPD2O3diyjz/qke00Pkco98RiF1jzo+hC731loQ508N27jOMVZ6HSnP+wNhpmt3GcePRsRwLiXtYwOCGVGIdrRtX3ypaScIXfxe46nHwanszGIZByhgRLgqOA00waf0yvzH5qPV6jIMZmwUbG1poZrXX0tYr1z+cQjNBzOuJJsA0egdM6yz0euVV6VPOJdyWiFsSl8NLzWspMpNG9czNcvXU3WBhDPfcquInHRQgS2arojcwQD6o7BOQHVQkzL75lABjwsagGYIXt7OoYV3yhNfCsmKyU0Aq63ADuWJ9D68sqt2v87uYJd4xWN6iWm+TdVi6NFrbqQVYnFGiUYKfuMq09K0EJFxyZ9suot/iG+QLLElGXJD3hHHFVAVNLtC4dDBZgtwmufi4KTSjVcX2ShyqnRri2e0fVhtUbL8LzM0e5rk/6VGC6XWK8e4ZUXn0CK9jt4cWU7jnyy/l7MHICP6lm/bczpGCAZe30ViPFZoEMY8/1qmhS4mf6WW2Yjd960Cag38jORyWVHkS/vk+SERq+49Yp3mFchK+RS6eLIcPorxAqSmRisHhQJOJhvbCSt1wpGp6fZlUkFuNzA3U9+ehizc21uojQ3EDK2oOEqleFZfyjt021mc/mb73/TEPKysESGD0j2Cbdbp/QhzmuFrPVcjfC52URB0rCYPvGeSKpy82P0EYh8WZfcrGxK5spWQ+tAY4Fd11P6Jd0l7zH3Ibx5hjIoF/BFnwNnWUF8GbrVEb9hIKwzme9zKnx06XGuGrJ6Q9QMpowbrKY6G8RV/y6yISKWH8wLHq1Fs8WeKFa1duJzqP18XKGyvRyRaL+sjXIg8B7Fyh7cxks3lb7szjrQEgE1nh+XfG4ykBgOo3LHLSN7vXsH3ryPvXwynklQuWXua0udu38N7/mUEMJf8iVyfVKHeBBE8/8ZxcW/Q2dHM+tKFwFJAaDmoXldYIHz6mQC23gQ2D5aP6jEreZNhCznu79Omn8CmRn5VxRDRaBFt+L6u0JVSToi/RQBTOEV80JSZSddo+bIYus+9ctABsHJIUpInj4uSkBpqjMVRkToPNzijHP+X1/ddz0QLsQULf/iCLSoW/CpzswqvGWeKwI9Oq7UAWDtuH2Vmq5DnePfW9wJCFpjUeQF12j7LnPVxgxrEmHoSqrBzqooSpUvROJVTGS0KF7sYyr4ZeUdCjyub82kFj1lFMp5E6+e/V9mjhvZmtOWG2dEGIb0dsxDAOIJfYibzdxJNkIchMuhdTLO1Ojc/hptyLVvAH7Y+MhBHxOxOE3ERL2FrK3KAcl5CIQVHDGqGbEHpclyVVq2Es6s9bvUF8KuR43KziEjphAjJN2B7X2EvVcrhDPnElHakSP6RcjLX7NpZyTUdu5ztgssJP2IKV8EIsw/5cx2l83a7tmQ6XJLtsD4hPK60XsopmuLkO/rJ4cN2Ux5EoQMm7k0RTTUUu38BNL9ts3VF5QI4rl13a8LUSvf8l4zuEIiSWdDi2jxQX8Rx1zOevwuVUZfH6o3e7GVVF13CNNF7eV+Kr2Zmf4X/5PZDHzEMlQxcfgfplelDF8fhUWRDbuLWO/gCuqQk/qzo8/Jct6XoAH8LVLl8wQZXhBarqoHsPwqSjBWSJ0aIUTU1z4bgQ21TjIv+iV9Dqp7EFMGI6r/1WcLJ+fUsJ1wn1bFQlcz/oSXFjvuBs1wrr8VfaCEi2ln28lZ1RADI6AB5V3807USslNVcTsllZkLm8w+5WilvUHhu7X3U0wI2cKIypUcRermwj0uWjARZOhRRnPlj/TWTUIz9h5V8g67fV1qsO3tSSVI3Yhqpi3oJDY2N7mfYPHStyJ4HLrZDyVE87sFJx2+0owiA8lsq+kSHomd6MX9oqlD+uww/AAy/qEe/QEW72LdGFrK9zgyBfh4BO3yo8WSAtLJuDmkGyzh5V7ZVrMbtQ44hOjipi2i7GkH5wAq4538Y1xAIBg9OC1tTznE3aGnO0yAQLj0C2Eky+N1SkB5sN3W84KpFwjxCpmf3IQO6kBBNDXO7czFer/MWMU4XFh1kd+3gGp2CscUIlSyE2Ojcuy32D28aVy2hFLpC4eol7frDhMhfY2bGIsjFNnZ044N2Pr43YuiCvGNj7h3Y+czf1P4fmXqhILVYOuOKo5XfG5ArFiK/H30fgctgD65ub4J8M/gHFsO0VceFi1thiiQZNCZjoeGuO6ivmOHRIKMt6EnMcoyJ4sgrOskyNi8NDCdx2xrPeK0TDEDIMh4SuUZ/LJYsrp8Cw/NaJOYEIoHd0BTK77u3B30MOJaLdTFy5qpn1RINR1MBh5tUse4NoC5LTBh19sB816jQfEbl7YccIktkwSWknKjpR0uHGw8tIJvzpqQn5s+ca/H1w2KUaQHuKSU/A+DIIdT0v7KLcZmBIZ0JozcNRdvW08xRUAoseJSiuSvg3wklJHziHnbvMSM/G2gGcos8Q8yeHF7u6yyIDBqWHRYcunjwMtnfgo1qGcTiL7FBskEX6abt7S7HEYg1wRAjpynQZqNm1QEs6d6n/mjNm+DaRRWxH2qkVYJL/5DzzM/3H38kjsXiV4SLPOk3n9f4K/vmZ/c3vqqeuL+ZTp7snBExp9W4yTOYTKkIbd/QWyOgMWr4Cbgk+KXr59bLCPkMiKkk0330HZ7urEDDyvQwWphtT1b5Ao5UFm39NNhlDmfm+b43K/zlJ38XTryAzYdMOpSz8szbfXHQB7L0h4s6aaYfgsPKoxrV/eOnE6N2rIXPR21XXhLvbbXjNLhozDLuutCn2So+773mhgP/lzLyswEhSMk4ssb7om3reuRgRgD5/QruAJy1eEWPouY3lN6uZgSzY/gDyzil5MKq+k//I7GjohItTdUEErIS+xBo9sBN0ahLg3gAP5StRUJk3BX7JukQQVnXW6qASqcpozpyt6g/B6nd5zw3X5FVuL4M8oXgX7OuwhGRcIBUd6/m7mB+57m+b8D1RrVvMOtCk101vUtjwNVUyEzhwie65GLpl6/bj7kCHdN3DwMUkEXkUNScUQyM+v6wDMBwWL84cbshIIgC5AFM/tULrWa7bd1j8UpLcG4FmrYNRnDNfDdH+KEAVDfNeLELHucjxZY6R3+39WJbJIfD6nYbXNZGuMRi+xgnM/zs4z7QLaBKp0m5ThhmT4TMiPomQQOMt/2vw4+rPWe777+dvzkUGPcM8mKQQUBMY9JPjuAcVITn8xk7CCoTEhJtDaxQkispJUXQ0fEVG4PCOaSxbnPrSq0RX1ESm2tkgWsYt3gvAQBo9VUOZl3Vte4+uDB60eQRyAJ6Mx+2Iba1X1BJq9FLRoPaj6KbxylB4lK4d6EeSMZms2WKvxE5Yl1IrSp/44iVi4UEJIkLd3bfvNzaHgmfbzXhNv/8Q6mvcU72KBjSVQ9Gty9mJuoqbdgZoZkH4Zi8PPQlDiAaJ7WgnYwJQZprWqODrjIwz1dH05MRcg8SnGtQkSzqwPaawHRchEhs8Y45rZj1z4wv1MLEDEC2d4yhtjWRIxX32XwYbuA+MfIF5inClPUAYAWHCtAQX/aelcFF5zMaikuUXXBSyMJh8VuepmwMrJTTGKiQOP9s+WsGnh2MF96RCgo+ytke+e6pZYqikE9P/byX/w5+B5Gqr8z9qzDYtId0Fgmjs5W7Ax9kkbbgVrrgGWXA8ibh4EfsnGF4EZbzP3Eljdgx0FtQ91r34UdQ5i6n/5eo76LSiusMmm+2eZDnpujX7WkNHJokav2FITqqJZL9UGnOWCgIFIo2Vb9jGIHhZqmRg/qrJOG38sMcfjNFU1C0K1oBujhJ2PRe9zIwU82pueeC8rbZ75eNmXBrJVXqHgj6RQFfavk1+mb8/drtabFdLOmz4U8QJVPbzfCineIicGxY5d+vhJuPYDDT0GopeJw1UNAz1aohLNf+gCJqVMrWr9GAfFuT2ZN03iI1ikdk6Vb3O3e0WLrsuUyFPR+oFQlyf5C19exiWMCNpthTY1cWsP3cq3mII7pqdrYNcSHhDQsgelW8ZPkwWjPzVAlKjdBmFLsBvdntKUvciaeYC+qM45pU3revzOYIjQKyrGa//BXzAoTuSBvv4eSIYQ7SzpqkXcvgHi42pkNoHmWyaXpglLlFgcAKUxVtlz04s1XlxJ7LouzFB8C9dg2sK9LlVdb/92Ec3wq6KsF5s5mDeXteNr43KWJw+Z6X1hPtw8RW4Yz0ilnM78nm94rAdpo6SXBcmzcwWtbBRKCUxmX/8n6ELelUpySqvKf+IUN+nPlspMS3f6I9aTOqFGemLGo2LDLwfDZ4zTW/8jjnEJx2Z7B/nHkMforxaT7pLVZFxxRcAam0x/mC7mOy38npT04xMYiR3vEWVwUPlcIb62Hvmp55JKCIsQD0zut9vI9dmuzh1K3X4OgH2SPSnSUZBpCifh8DshqsfWYAEtZhX+QwH6xYHzf6uW4blGd9oCC+BHS+6ilrSElMAyjUHvy8H7KwdpKthNiVNkyS0fbcJ7A3CAqBI9VAao2lK8eBvmIIqGbTW2VyLmlmcQ712Nu9ctBpSYpBV+4EhhLMwz1ZhSL8OtYVa4Sztiw21jjbIxr3Q/Xe7e+eEm3htmQs/Ko/zQaHBquZ6UFE9IbOsC+xU8T3SYlSs8vDimv6xsM1aGTe5leFpoBWIHah3BbuqnIQNAxK11QpXN1xy9mpDM8B4P22nDaaGc2wTt4svp7HpgGJPJr+i2PzFuMWyposTh2SGOVR9e+WjPYZT4H8TU4teMPFCqaYTmcKu51A0eGaEreGxMNK8+SzsFzGoQXUo4+sV/gB9wrsIAJZKoQZtCLwRI3ZxoovFOEMWu/4jj7+D+LO1UVGxaD20eCXvDVv4o4fpiirk3450WVIWrNY2YSVvUWKlErX8sNne8K3hpcRLld+ni+HS5NaSojjGV0KA1VX+ujPEWkuDOqK67AcN6bc/W2Z4WfszA4g5jWJQU6J+79VVDw0ZQnZDvBahJRumfbVbQPjxIAzHu1z5qVzvjjbljqke6tEtX8hqW5ycoD7i02rOsgFfdKDDDRCsP/c0QjAVmyQ3m7edhx3+LZagEKt5fozpeAOnQ9P7s9SH2AIyf8xD6vx+T2SBazMHCThZ3Q81ponD3Il3EGQO50TFUXRKZYcvlB7ShVn7jXfKAQoOHpZJii9naOwuUWE3tSZ/1fkixnj681R0mp/WxClVZ0P4+COlMw3MR5pEA3G2YrqNyZHXqwvX0R6SsgD1/eEwZcWDntJ6xUKy4oEkWgDgghAMliyWkGaALdW/inbzeXdVVVFF5P1qnC/E1GB3T9O3JX5udKSXRVhnutuOFMKZeSHJmr+spdM33MageJo7LjaY8pXlBbDdfR08PaqMoLIJAlyMrOPEjtLJDsN8Rr22FW7asr7YrgTCAJ/VOtTeYbBwr9Xoeb7/V9FpcoCCJVMQnkmLfm90z0YKzeK4ZzWVqGMZPAwR9/gdSiEA3CaxkQHAMzXR92ga5er8mLtmagkbUdzeVuoQyi9kRcLroXuN+VfrMiTFr/1ehhMzBMFQ8UnpamDsiw3QfhYKaz1wT0vH2fX4XQ2X1FSFmvwkUDNMebPwXXorcXhfIO38ZRhIrCShjCFk+MeROLQgzn/81FRBuINNA1moNpw+XsvofoBkN2/273dmoY4BZWcGgnw4jREmkY3U8mx0JXrHfWpSATN9FFHMczwOOjVxjyMergXJZx2qrt1Fw+cLFLLsNBSluKcjRjlzNphj1KqW9DU7+ihHv5i7ALku+cu7yuzCDJ5sExPhpLnk1B5Ej9ajklvYTXsRzK6kY/xJWaUEOEY8Siy1UiSb2V+dsJ+uIfDnj5F4OsP0xvJH4F4gxCnYxtQwIEGNiokhSqal9UJN0n/wDymMZaXYF6TJCzJ7pIO+Acp3fF7Inj4Z+/113nAVkrr8Rvl9SvFefNjJYJXkyiymoyX7zK7o1fLH70gBmdP7svFovIGjjqSwIaXncZ2424218OqE4Y/EVA+sBQjHRGiZn9bvYAFrmu/iYXRqaEoxN5ew+cWrliCJ9L00jv12H0H6+IKKIkvFGuYhuNM6wkNf0+DFYo7/bRqQKpqoKOtNDNeBwMngGZBtrtbNoQANtadefGS7YbS7c/DrwUzppuHxQEmEJkLra1dmA5XdhRsNdftlLLSFvLp00pR9p+dZCAFCKsqDqQHhcCR3rnnHWM8AZ35pzS7LmYU+vKFqUobj2qJgDaPZFX+5a8WrvbzPKOoLkGoS+Z0amd/0eipBuAUKTJL326m5mGKL0wQOq5UmozQ08PckFzs+tUlhHpChZPNpVc/0qG7FZc7W68SrWMhdzmKGarsCRmynrbTux4nW0RdygELs5b3WkOP9vlm3w0cF+nMxPdkeui26U6MP9E1S6KhKG6mnTvzM5ptPVeJWcNUZlbjQaMRTc7e+WLKT0H50q9LTRY66NLuVP6lAWlMLlRZHI3hUclbnHAJu9X1NiIAnansP68gETZBI9GAw0vfbaLjWWN3mLhawB9oAAqqKuUSDipyDfhSGLF8lIkuVdDPOUvkILfNJoZgTE84j+rkra3q0CY+yTbqdp4tHlrFzwiWdQXRRJ4eCKtUTB3NIRHXmtOiWxVR3bZIEN3KpS9oAUi1kijz6YHOvaDM2oSup2uLg13UMBZ41bCQ4hgQoliuo8aWuoQ88O5nRQ2Lff6yrY7Wm1iZgbq6m6uVERJ1pG7z2Svtynv+DCQr378vIQn+u3AdJHb4w520CHGwRn+xMvfs+LeosJmxqOpxnUFwAvnXLALyajZUtfSnkqBW4Vnmfv6+/CSeUU/UOKMk+2SuxO00Hop6w3Yz+p8RCPzz02lpKiulGUkel7zQDLKqygmH5gOhJhXu79YCSxdrcpuNwdHlnqK1Rwd1gbeggY/ePa9okGtt0Bvo3otOXKJd6cDTz8DVcG383g5VhKRGzfLoJngM4QrCUKuAgx7sq84NAvH1EchQ7XH5VO3xp0jZ087DIkhi4Icn6plNRaSA9klyFIjORE6KQe2rpC3svdQX8iVIpj4qERva7IAse2MeaUpNAJTcYD1DdSq83tV+Fojksbx9bykcpP4jthMY3GWj3HA6huSQ/PN8fNuxl0JbngQokHqLLJODmGtbCg91KV+K6E0ImWlffV17wV9V0tHog1ofI3OaUx/XXPZYRRur+Jp9Kw9HSwCZw3iTqdGTde+cWSZbjUkIlHkf5OvjvQPQZpPSt9FZdvr6cAQN/ngT7idLyoPQEISavyHzmYEMDJPBsKtTxyEQbO5mz7M6VwvKOZD2oblL3T52y24pw4hZCihYSVqCN/mRzIeDotn5SZIQVIJEMYOT6+CiFzW81sNvEA5e2A/p3kJMbsK/zzaLsu9lPoHfxLLlhHsvbSeAzltRNPhznuTOQR+AdO5oMxZPvPwiSbULhSajzZ9mH7k0EH6CIwv2jFKvCvbLl+wIjgXjKoQptWue9nvHrQj0FoUkx3rmQixnpl7AjxqYXG0CgJQKiOqOZRmlMqQzCHHS1RjyBi319+Ws8+pi4lXpIFDB3EX6870PpGWTepG6Pe7CynBRXt8dB9If43PkSM3Ev5KYbW8vb10ToCMFeb+Vz1bHYhRSN0B4T6v30AWw5zw07Dv3QW+RSukJPprmSykE0ZmCPZO7IJweR/TEIRS5hpR/1Xy8iT2MERSuyy/7f4Nio7oR/NMnislpj9YZQTkfZ7ZTEwcKh2EJgm4ZIyA1WUVZyhdmb7hHrCknzODLunRABjsnvXtMjz6j+bid5SmMXoyLFJZH+dQgeBBwbAcaGzaHaXWpbBP/iS/yBeLTj3ZhUlS0XGsElXrXnbKZo2ijbrV3sMEey+MP50o9Slw1pDbPMBD3plWotFv9bEJ2blC3M4iVVfvqAKKxHLV9viU6DUfD/feHvjyaAxuhkB92nMZyU1mB15ad1ndBO8RypLJkOnro5n3pJhA5";
	decryptString(P,"783e007c783e007c","Password",oFile);}

Solution::Solution(string solvent,string solventConc,string solventConcType,string solute,string soluteConc,double T,string delimiter)
	{// Handle Input Solvent(s) and Solute(s)
	// Solvent Concentration = mole fraction
	// Solute Concentration = mole/L
	// Basic modeling principle: Calculate property of the pure (or mixed) solvent(s), then correct for presence of solutes

	// Pure Solvent(s) Parameters
	numSolvents=countDelimiter(solvent,delimiter);
	solvents=new string[numSolvents];
	string* val=fillStringArray(solvent,numSolvents,delimiter);
	for(int i=0;i<numSolvents;i++){solvents[i]=interpretMoleculeName(val[i]);}
	delete [] val;
	// Calculate Molecular Weight of Solvent(s)
	solventsMW=new double[numSolvents];
	double* solventsDensity=new double[numSolvents];
	for(int i=0;i<numSolvents;i++){solventsMW[i]=calcMoleculeMolecularWeight(solvents[i]);}
	// Convert Solvent Concentration Units to mole fraction, if not already
	solventsConc=fillDoubleArray(solventConc,numSolvents,delimiter);
	if(solventConcType.compare("massFraction")==0)
		{solventsConc=massFrac2MoleFrac(solventsConc,solventsMW,numSolvents);}
	else if(solventConcType.compare("moleFraction")==0){/*Do Nothing*/}
	else if(solventConcType.compare("volumeFraction")==0)
		{// Get Pure Solvent Densities
		// Compute Pure Solvent(s) Density [kg/L] in g/L
		for(int i=0;i<numSolvents;i++){solventsDensity[i]=1000*calcPureSolventDensity(solvents[i],T);}
		solventsConc=volFrac2MoleFrac(solventsConc,solventsMW,solventsDensity,numSolvents);}
	else
		{cerr<<"Error in Solution::Solution\nUnrecognized solvent concentration units ("<<solventConcType<<")\n";exit(EXIT_FAILURE);}

	// Solute Parameters
	numSolutes=countDelimiter(solute,delimiter);
	solutes=new string[numSolutes];
	val=fillStringArray(solute,numSolutes,delimiter);
	for(int i=0;i<numSolutes;i++){solutes[i]=interpretMoleculeName(val[i]);}
	delete [] val;
	solutesConc=fillDoubleArray(soluteConc,numSolutes,delimiter);
	// Calculate Molecular Weight of Solute(s)
	solutesMW=new double[numSolutes];
	for(int i=0;i<numSolutes;i++){solutesMW[i]=calcMoleculeMolecularWeight(solutes[i]);}
	
	// Solution Temperature [K]
	temperature=T;
	// Calculate Solution (Solvent(s)+Solute(s)) Density [kg/L]
	density=calcSolutionDensity(T);
	//cout<<density<<" kg/L"<<endl;
	// Calculate Solution (Solvent(s)+Solute(s)) Viscosity [Pa s]
	viscosity=calcSolutionViscosity(T);
	//cout<<viscosity<<" Pa s"<<endl;
	// Calculate Solution (Solvent(s)+Solute(s)) Relative Dielectric
	dielectric=calcSolutionDielectric(T);
	//cout<<dielectric<<endl;
	// Get Ion Data
	ionData=getIonData(soluteConc,solute,delimiter);
	//cout<<ionData<<endl;
	int N=countDelimiter(ionData,",");
	string* All=fill_string_array(ionData,N,",");
	N/=3;
	// Identify Unique Ion(s) valence/size
	string* valence=new string[N];
	string* ionConcentration=new string[N];
	string* ionRadius=new string[N];
	// Define Number of Ionic Species from Solute(s)
	numIon=0;
	string tmp="",tmp2="",tmp3="",rLst="",vLst="",cLst="";
	int indexLst;
	for(int i=0;i<N;i++)
		{valence[i]=All[3*i];
		ionConcentration[i]=All[1+3*i];
		ionRadius[i]=All[2+3*i];}
	bool FOUND;
	// Count Unique valences and radii	
	for(int i=0;i<N;i++)
		{for(int j=0;j<N;j++)
			{if(i!=j)
				{// Determine Unique Radii
				if(!IN_LIST(ionRadius[i],rLst,numIon,delimiter))
					{numIon++;
					rLst+=ionRadius[i]+delimiter;
					vLst+=valence[i]+delimiter;
					cLst+=ionConcentration[i]+delimiter;
					break;}
				else
					{if(!IN_LIST(valence[i],vLst,numIon,delimiter))
						{// Unique Ion Found with same size but different valence
						numIon++;
						rLst+=ionRadius[i]+delimiter;
						vLst+=valence[i]+delimiter;
						cLst+=ionConcentration[i]+delimiter;
						break;}
					}
				}
			}
		}
	
	// Organize Ion Data
	ionVal=fill_int_array(vLst,numIon,delimiter);
	ionConc=fill_double_array(cLst,numIon,delimiter);
	ionRad=fill_double_array(rLst,numIon,delimiter);

	for(int i=0;i<numIon;i++)
		{ionConc[i]=0;
		for(int j=0;j<N;j++)
			{tmp=valence[j];tmp2=ionRadius[j];tmp3=ionConcentration[j];
			if(ionVal[i]==atoi(tmp.c_str()) && ionRad[i]==strtod(tmp2.c_str(),NULL))
				{// Same Size and Valence
				ionConc[i]+=strtod(tmp3.c_str(),NULL);
				}
			}
		}

	double Max=0,value;
	for(int i=0;i<numIon;i++)
		{// Record Ion Radii [Angstrom]
		tmp=All[2+3*i];
		value=strtod(tmp.c_str(),NULL);
		if(value>Max){Max=value;}}
	largestIon=cnvrtNumToStrng(Max,2);
	// Calculate Solution Debye Length (A)
	debyeLength=calcDebyeLength(T);
	//cout<<ionData<<"|"<<debyeLength<<endl;
	delete [] ionRadius;delete [] ionConcentration;delete [] valence;}

double Solution::calcSolutionDensity(double T)
	{double Output;
	// Convert Mole Fractions of Solvent(s) into Mass Fractions
	double* w=moleFrac2MassFrac(solventsConc,solventsMW,numSolvents);
	// Initialize array for pure solvent density values [kg/L]
	double* p=new double[numSolvents];
	// Compute Pure Solvent(s) Density [kg/L]
	for(int i=0;i<numSolvents;i++){p[i]=calcPureSolventDensity(solvents[i],T);}
	// Define Pure Solvent(s) Mixture Density (Assuming ideal mixture) w/o solutes
	double Sum=0;
	for(int i=0;i<numSolvents;i++){Sum+=w[i]/p[i];}delete [] w;
	double solventDensity=1/Sum;
	// Convert from kg/L to kg/m^3
	solventDensity*=1000;
	double d0,d1,d2,d3,d4,vSolute,wTotal=0,wSolvent,MW,S;
	double a1,a2,a3,b1,b2,b3,c1,c2,c3;
	double *Coeff;
	string tmp=solutes[0];
	if(numSolutes==1 && tmp.compare("KH2PO4")==0)
		{// 2007. Temperature and Concentration Dependence of Density of Model Liquid Foods
		// Convert Absolute Temperature to celsius
		T-=273.15;
		// KH2PO4 Molecular Weight (g/mol)
		MW=136.086;
		// Solute Concentration
		S=solutesConc[0]*MW/10;	// g KH2PO4/100 mL Water
		// Empirical Coefficients
		a1=1.00263;b1=0.00004211;c1=0.00000273;
		a2=-0.00013;b2=5.395e-8;c2=-6.891e-9;
		a3=-3.147e-6;b3=-1.079e-9;c3=6.952e-11;
		// Solution Density [kg/L]
		Output=a1+b1*S+c1*S*S + T*(a2+b2*S+c2*S*S) + T*T*(a3+b3*S+c3*S*S);
		}
	else
		{// Convert Molar Concentration of Solute(s) into Mass Fractions
		w=molarity2MassFrac(solutesConc,solutesMW,numSolutes,solventDensity);	
		Sum=0;
		// Convert Absolute Temperature to celsius
		T-=273.15;
		// Reference: 2004. Model for calculating the density of aqueous electrolyte solutions		
		for(int i=0;i<numSolutes;i++)
			{Coeff=getDensityCoefficients(solutes[i]);
			d0=Coeff[0];d1=Coeff[1];d2=Coeff[2];d3=Coeff[3];d4=Coeff[4];		
			// Calculate Apparent Specific Volume of Each Salt Component
			if(d0==0&&d1==0&&d2==0&&d3==0&&d4==0){vSolute=0;}
			else{vSolute=(w[i]+d2+d3*T)/((d0*w[i]+d1)*exp(0.000001*(T+d4)*(T+d4)));}
			Sum+=w[i]*vSolute;
			wTotal+=w[i];}
		// Calculate Pure Solvent Mix Mass Fraction
		wSolvent=1-wTotal;	
		// Calculate Solution (Solute(s)+Solvent(s)) Density
		Output=1/((wSolvent/solventDensity)+Sum);
		// Convert from kg/m^3 to kg/L
		Output/=1000;}
	return Output;}

double Solution::calcSolutionViscosity(double T)
	{double Output;
	// Convert Mole Fractions of Solvent(s) into Mass Fractions
	double* w=moleFrac2MassFrac(solventsConc,solventsMW,numSolvents);
	// Initialize array for pure solvent viscosity values
	double* v=new double[numSolvents];
	// Compute Pure Solvent(s) Viscosity [mPas]
	for(int i=0;i<numSolvents;i++){v[i]=calcPureSolventViscosity(solvents[i],T);}
	// Define Pure Solvent(s) Mixture Viscosity (Assuming ideal mixture) w/o solutes
	double solventViscosity=1;
	for(int i=0;i<numSolvents;i++){solventViscosity*=pow(v[i],w[i]);}delete [] w;	
	// Convert Molar Concentration of Solute(s) into Mass Fractions
	w=molarity2MassFrac(solutesConc,solutesMW,numSolutes,density*1000);
	// Determine Mass Fraction of Solvent
	double wSolvent=1;
	for(int i=0;i<numSolutes;i++){wSolvent-=w[i];}
	double* vCoeff;
	double A,B,C,D,E,F,trm,trm1,trm2,trm3,A1;
	double viscSolute,A2=1,A3;
	double u,vo,n,val,val2,w1,w2;
	string tmp=solutes[0],tmp2;
	if(numSolutes==1 && tmp.compare("???")==0)
		{
		}
	else if(numSolutes==2 && (tmp.compare("H3Citrate")==0 || tmp.compare("Na2HPO4")==0) && (tmp2.compare("H3Citrate")==0 && tmp2.compare("Na2HPO4")==0))
		{tmp2=solutes[1];
		// Citrate Phosphate Buffer
		if(tmp.compare("H3Citrate")==0 && tmp2.compare("Na2HPO4")==0)
			{// Calculate Citric Acid Solution Viscosity (mPas)
			w1=w[0];	// Citric Acid Mass Fraction
			w2=w[1];	// Na2HPO4 Mass Fraction
			// Ref. 2014. Modelling of the thermophysical properties of citric acid aqueous solutions. Density and viscosity
			A=-0.85692331;B=-0.00043388783;C=0.14271232;D=0.0004995215;E=-0.18401808;
			trm=A+B*w1*100+C*log(T);
			trm1=1+D*w1*100+E*log(T);
			val=trm/trm1;		// Citric Acid Solution Viscosity (mPas)
			//cerr<<"H3Citrate Viscosity: "<<val<<" mPas\n";
			// Calculate Na2HPO4 Solution Viscosity
			vCoeff=getViscosityCoefficients(tmp2);
			A=vCoeff[0];B=vCoeff[1];C=vCoeff[2];D=vCoeff[3];E=vCoeff[4];F=vCoeff[5];

			trm=pow(1-wSolvent,B);
			trm1=A*trm+C;
			trm2=D*T+1;
			trm=pow(1-wSolvent,F);
			trm3=E*trm+1;

			viscSolute=exp(trm1/(trm2*trm3));
			A2=pow(viscSolute,w2);
			A1=pow(solventViscosity,wSolvent);
			val2=A1*A2;			// Na2HPO4 Solution Viscosity (mPas)
			//cerr<<"Na2HPO4 Viscosity: "<<val2<<" mPas\n";
			A3=pow(val,w1);
			A2=pow(val2,w2);
			Output=A1*A2*A3;
			Output/=1000;	// Convert from mPas to Pas
			}
		else if(tmp.compare("Na2HPO4")==0 && tmp2.compare("H3Citrate")==0)
			{
			w1=w[0];	// Na2HPO4 Mass Fraction
			w2=w[1];	// Citric Acid Mass Fraction
			// Calculate Na2HPO4 Solution Viscosity
			vCoeff=getViscosityCoefficients(tmp);
			A=vCoeff[0];B=vCoeff[1];C=vCoeff[2];D=vCoeff[3];E=vCoeff[4];F=vCoeff[5];

			trm=pow(1-wSolvent,B);
			trm1=A*trm+C;
			trm2=D*T+1;
			trm=pow(1-wSolvent,F);
			trm3=E*trm+1;

			viscSolute=exp(trm1/(trm2*trm3));
			A2=pow(viscSolute,w1);
			A1=pow(solventViscosity,wSolvent);
			val2=A1*A2;			// Na2HPO4 Solution Viscosity (mPas)
			//cerr<<"Na2HPO4 Viscosity: "<<val2<<" mPas\n";
			// Calculate Citric Acid Solution Viscosity
			// Ref. 2014. Modelling of the thermophysical properties of citric acid aqueous solutions. Density and viscosity
			A=-0.85692331;B=-0.00043388783;C=0.14271232;D=0.0004995215;E=-0.18401808;
			trm=A+B*w2*100+C*log(T);
			trm1=1+D*w2*100+E*log(T);
			val=trm/trm1;		// Citric Acid Solution Viscosity (mPas)
			//cerr<<"H3Citrate Viscosity: "<<val<<" mPas\n";
			A3=pow(val,w2);
			A2=pow(val2,w1);
			Output=A1*A2*A3;
			Output/=1000;	// Convert from mPas to Pas
			}
		}
	else
		{// Convert Absolute Temperature to Celsius
		T-=273.15;
		for(int i=0;i<numSolutes;i++)
			{// Empirical Constants
			vCoeff=getViscosityCoefficients(solutes[i]);
			A=vCoeff[0];B=vCoeff[1];C=vCoeff[2];D=vCoeff[3];E=vCoeff[4];F=vCoeff[5];

			trm=pow(1-wSolvent,B);
			trm1=A*trm+C;
			trm2=D*T+1;
			trm=pow(1-wSolvent,F);
			trm3=E*trm+1;

			viscSolute=exp(trm1/(trm2*trm3));
			A2*=pow(viscSolute,w[i]);}
		A1=pow(solventViscosity,wSolvent);
		Output=A1*A2;
		// Convert from mPas to Pas
		Output/=1000;}
	return Output;}

double Solution::calcSolutionDielectric(double T)
	{// Reference: 2001. Computaton of dielectric constants of solvent mixtures and electrolyte solutions
	double Output;
	// Calculate Molar Volume of Solvent(s)
	double* Vm=new double[numSolvents];
	// Initialize array for pure solvent density values [kg/L]
	double* d=new double[numSolvents];
	// Compute Pure Solvent(s) Density [kg/L]
	for(int i=0;i<numSolvents;i++){d[i]=calcPureSolventDensity(solvents[i],T);}
	for(int i=0;i<numSolvents;i++){Vm[i]=solventsMW[i]/(d[i]*1000);}
	// Array for Pure Solvent Relative Dielectric Values
	double* pure_er=new double[numSolvents];
	// Compute Pure Solvent(s) Dielectric
	for(int i=0;i<numSolvents;i++){pure_er[i]=calcPureSolventDielectric(solvents[i],T);}
	// Array for Polarization Values
	double* p=new double[numSolvents];
	// Compute Solvent(s) Polarization
	for(int i=0;i<numSolvents;i++){p[i]=(pure_er[i]-1)*(2*pure_er[i]+1)/(9*pure_er[i]);}
	// Compute Polarization of Solvent Mixture (Oster's Rule)
	double top=0,bottom=0;
	for(int i=0;i<numSolvents;i++){top+=solventsConc[i]*Vm[i]*p[i];bottom+=solventsConc[i]*Vm[i];}
	double solventPolarization=top/bottom;
	// Compute Relative Dielectric of Solvent(s) Mixture
	double solventDielectric=(9*solventPolarization+1+3*sqrt(9*solventPolarization*solventPolarization+2*solventPolarization+1))/4;		
	// Correct for Presence of Solutes (association=increase dielectric,dissociation=decreased dielectric)
	double B,maxB;
	int pos;
	for(int i=0;i<numSolutes;i++)
		{B=getDielectricLinearCoefficient(solutes[i]);
		if(i==0){maxB=B;pos=i;}
		else if(B>maxB){maxB=B;pos=i;}}
	// Currently Only Modeling Dielectric Decrement
	// Applies Greatest Linear Coefficient
	Output=solventDielectric+maxB*solutesConc[pos];
	return Output;}

double Solution::getDielectricLinearCoefficient(string soluteName)
	{// Reference: 2011. Dielectric decrement as a source of ion-specific effects
	double Output;
	if(soluteName.compare("HCl")==0){Output=-19.05;}
	else if(soluteName.compare("LiCl")==0){Output=-12.72;}
	else if(soluteName.compare("NaCl")==0){Output=-11.59;}
	else if(soluteName.compare("KCl")==0){Output=-10.02;}
	else if(soluteName.compare("CsCl")==0){Output=-10.20;}
	else if(soluteName.compare("RbCl")==0){Output=-8.98;}
	else if(soluteName.compare("NaF")==0){Output=-11.90;}
	else if(soluteName.compare("KF")==0){Output=-12.00;}
	else if(soluteName.compare("CsF")==0){Output=-12.60;}
	else if(soluteName.compare("LiI")==0){Output=-14.95;}
	else if(soluteName.compare("NaI")==0){Output=-14.59;}
	else if(soluteName.compare("KI")==0){Output=-14.69;}
	else if(soluteName.compare("CsI")==0){Output=-14.17;}
	else if(soluteName.compare("NaOH")==0){Output=-21;}
	else{//cerr<<"Error in Solution::getDielectricLinearCoefficient!\nUnrecognized solute ("<<soluteName<<").\nUsing pure solvent dielectric as an estimate...\n";
		Output=0;}
	return Output;}

// Reference: 2004. Model for calculating the density of aqueous solutions
double* Solution::getDensityCoefficients(string saltName)
	{double d0,d1,d2,d3,d4;
	double* Output=new double[5];
	if(saltName=="AlCl3"){d0=221.68;d1=160.90;d2=0.15125;d3=0.002500;d4=1500.0;}
	else if(saltName=="Al2(SO4)3"){d0=-0.0017202;d1=0.0018967;d2=-0.030904;d3=0.004087;d4=3804.2;}
	else if(saltName=="BaCl2"){d0=-0.0030518;d1=0.00526670;d2=4.1785;d3=0.068274;d4=3971.9;}
	else if(saltName=="CaCl2"){d0=-0.63254;d1=0.93995;d2=4.2785;d3=0.048319;d4=3180.9;}
	else if(saltName=="CdCl2"){d0=-0.090879;d1=0.29116;d2=7.3827;d3=-0.031855;d4=-3477.5;}
	else if(saltName=="CdSO4"){d0=-1.0440e-7;d1=6.1070e-8;d2=-0.003761;d3=0.004108;d4=5007.7;}
	else if(saltName=="CoCl2"){d0=-8.0924e-8;d1=8.0261e-8;d2=410.24;d3=9.1808;d4=5619.8;}
	else if(saltName=="CoSO4"){d0=-118.36;d1=1368.1;d2=0.01304;d3=-0.000145;d4=-294.02;}
	else if(saltName=="CrCl3"){d0=3.1469;d1=232.160;d2=0.20191;d3=0.002500;d4=1500.0;}
	else if(saltName=="Cr2(SO4)3"){d0=1.0045;d1=1.7697;d2=-0.085017;d3=0.002500;d4=1500.0;}
	else if(saltName=="CuCl2"){d0=1868.5;d1=1137.20;d2=0.07185;d3=0.002565;d4=575.7;}
	else if(saltName=="CuSO4"){d0=-1.9827e-7;d1=1.0883e-7;d2=-0.12506;d3=0.003831;d4=4936.8;}
	else if(saltName=="FeCl2"){d0=98.654;d1=199.51;d2=0.33639;d3=0.0038444;d4=1650.1;}
	else if(saltName=="FeSO4"){d0=-3.6737e-6;d1=1.2465e-4;d2=-0.062861;d3=0.0015696;d4=3943.0;}
	else if(saltName=="FeCl3"){d0=-1333.8;d1=4369.2;d2=1.5298;d3=0.007099;d4=829.21;}
	else if(saltName=="Fe2(SO4)3"){d0=0.47444;d1=-0.64624;d2=-713.10;d3=-25.569;d4=4023.2;}
	else if(saltName=="HCl"){d0=-80.061;d1=255.42;d2=118.42;d3=1.0164;d4=2619.5;}
	else if(saltName=="HCN"){d0=255.82;d1=283.11;d2=0.66888;d3=0.0062057;d4=891.0;}
	else if(saltName=="HNO3"){d0=12.993;d1=-23.579;d2=-3.6070;d3=0.0079416;d4=-2427.1;}
	else if(saltName=="H3PO4"){d0=1358.3;d1=-4327.7;d2=-4.5950;d3=0.0043831;d4=-912.45;}
	else if(saltName=="H2SO4"){d0=89.891;d1=224.48;d2=0.82285;d3=0.0068422;d4=1571.5;}
	else if(saltName=="KCl"){d0=-0.46782;d1=4.30800;d2=2.3780;d3=0.022044;d4=2714.0;}
	else if(saltName=="K2CO3"){d0=-1.4313;d1=2.49170;d2=1.1028;d3=0.013116;d4=2836.0;}
	else if(saltName=="KNO3"){d0=7.5436;d1=26.38800;d2=1.2396;d3=0.011656;d4=2214.0;}
	else if(saltName=="KOH"){d0=194.85;d1=407.31;d2=0.14542;d3=0.002040;d4=1180.9;}
	else if(saltName=="K2SO4"){d0=-2.6681e-5;d1=3.0412e-5;d2=0.97118;d3=0.019816;d4=4366.1;}
	else if(saltName=="LiCl"){d0=17.807;d1=32.011;d2=1.3951;d3=-0.006234;d4=-2131.6;}
	else if(saltName=="Li2SO4"){d0=0.0014730;d1=0.0026934;d2=0.17699;d3=0.0041319;d4=3640.7;}
	else if(saltName=="MgCl2"){d0=-0.00051500;d1=0.0013444;d2=0.58358;d3=0.0085832;d4=3843.6;}
	else if(saltName=="MgSO4"){d0=3.9412e-7;d1=1.4425e-6;d2=-0.05372;d3=0.002062;d4=4563.3;}
	else if(saltName=="MnCl2"){d0=0.000001869;d1=0.00004545;d2=1.5758;d3=-0.010776;d4=-4369.9;}
	else if(saltName=="MnSO4"){d0=0.0032447;d1=0.057246;d2=0.05136;d3=0.002146;d4=3287.8;}
	else if(saltName=="NaBr"){d0=109.770;d1=513.04;d2=1.54540;d3=0.011019;d4=1618.1;}
	else if(saltName=="NaCl"){d0=-0.00433;d1=0.06471;d2=1.01660;d3=0.014624;d4=3315.6;}
	else if(saltName=="NaClO3"){d0=0.014763;d1=0.024913;d2=1.2924;d3=-0.0076175;d4=-3454.3;}
	else if(saltName=="Na2CO3"){d0=0.012755;d1=0.014217;d2=-0.091456;d3=0.0021342;d4=3342.4;}
	else if(saltName=="NaF"){d0=2.8191e-6;d1=2.1777e-7;d2=-0.041483;d3=0.00021765;d4=4586.9;}
	else if(saltName=="NaHCO3"){d0=-9.4794e-8;d1=1.5657e-7;d2=0.9912;d3=0.022644;d4=4900.2;}
	else if(saltName=="NaH2PO4"){d0=208.77;d1=641.05;d2=0.78893;d3=0.0045520;d4=1198.4;}
	else if(saltName=="Na2HPO4"){d0=1096.7;d1=937.57;d2=0.01424;d3=-0.0005595;d4=-860.20;}
	else if(saltName=="NaHSO3"){d0=6.1384e-6;d1=1.3029e-6;d2=0.13635;d3=-0.0014624;d4=-4472.5;}
	else if(saltName=="NaI"){d0=626.15;d1=1858.2;d2=1.7387;d3=0.010500;d4=1203.3;}
	else if(saltName=="Na2MoO4"){d0=-2.0813;d1=4.8446;d2=4.4342;d3=-0.020815;d4=-2942.3;}
	else if(saltName=="NaNO2"){d0=78.365;d1=298.00;d2=0.96246;d3=0.0021999;d4=1500.0;}
	else if(saltName=="NaNO3"){d0=49.209;d1=94.737;d2=0.77927;d3=0.0075451;d4=1819.2;}
	else if(saltName=="NaOH"){d0=385.55;d1=753.47;d2=-0.10938;d3=0.0006953;d4=542.88;}
	else if(saltName=="Na3PO4"){d0=1015.6;d1=1533.7;d2=-0.15180;d3=0.00013660;d4=173.71;}
	else if(saltName=="Na2SO3"){d0=1.5197e-5;d1=4.3766e-7;d2=0.10296;d3=-0.0015271;d4=-4500.9;}
	else if(saltName=="Na2S2O3"){d0=0.84462;d1=-1.5142;d2=-42.949;d3=0.19335;d4=-3425.9;}
	else if(saltName=="Na2SO4"){d0=-1.2095e-7;d1=4.3474e-7;d2=0.15364;d3=0.0072514;d4=4731.5;}
	else if(saltName=="NH3"){d0=0.12693;d1=0.10470;d2=1.0302;d3=-0.0050803;d4=-2973.7;}
	else if(saltName=="NH4Cl"){d0=6.56150;d1=89.772;d2=4.9024;d3=-0.016574;d4=-2089.3;}
	else if(saltName=="NH4NO3"){d0=1379.3;d1=1124.4;d2=0.65598;d3=0.0014106;d4=176.41;}
	else if(saltName=="(NH4)2SO4"){d0=-123.22;d1=452.59;d2=3.2898;d3=0.016292;d4=1692.4;}
	else if(saltName=="NiCl2"){d0=-1.3900e-6;d1=4.1879e-6;d2=0.77734;d3=-0.0066936;d4=-4638.1;}
	else if(saltName=="NiSO4"){d0=-0.03894;d1=0.22109;d2=-0.14443;d3=0.0009867;d4=3073.8;}
	else if(saltName=="SrCl2"){d0=1.3534e-6;d1=-7.4877e-7;d2=-1.9356;d3=0.010704;d4=-4882.1;}
	else if(saltName=="ZnCl2"){d0=1943.6;d1=304.34;d2=-0.013753;d3=0.0011543;d4=573.79;}
	else if(saltName=="ZnSO4"){d0=18.378;d1=35.927;d2=-0.089193;d3=0.0010773;d4=2066.3;}
	else{//cerr<<"Warning from Solution::getDensityCoefficients!\nThe salt ("<<saltName<<") does not have any data associated with it.\nUsing pure solvent density as an estimate...\n";
		d0=0; d1=0; d2=0; d3=0; d4=0;}
	Output[0]=d0; Output[1]=d1; Output[2]=d2; Output[3]=d3; Output[4]=d4;
	return Output;}

double Solution::calcPureSolventDensity(string solventName,double temperature)
	{// temperature is in K
	double Output,T=temperature,trm,trm1,trm2;
	double c1,c2,c3,c4;
	// Molecular Formulae are in a structural format
	// Water Empirical Constants
	double Aw=-2.8054253e-10,Bw=1.0556302e-7,Cw=4.6170461e-5,Dw=0.0079870401,Ew=16.945176,Fw=999.83952,Gw=0.01687985;	
	// Reference: NIST Thermophysical Property Data
	if(solventName.compare("CH3C[::O]OH")==0)
		{// Acetic Acid = CH3C[::O]OH
		Output=1.27334-4.77633e-4*T-9.8132e-7*T*T;}
	else if(solventName.compare("CH3C[CH3]::O")==0)
		{// Acetone = CH3C[CH3]::O
		Output=1.06011-6.68357e-4*T-8.60506e-7*T*T;}
	else if(solventName.compare("CH3C:::N")==0)
		{// Acetonitrile = CH3C:::N
		T-=273.15;c1=-0.0012148333;c2=0.8075233333;Output=c1*T+c2;}
	else if(solventName.compare("CH3(CH2)3OH")==0)
		{// Butanol = "CH3(CH2)3OH"
		Output=1.15309-2.13475e-3*T+5.15573e-6*T*T-6.38112e-9*T*T*T;}
	else if(solventName.compare("CH3(CH2)3C[::O]CH3")==0)
		{// Butyl Methyl Ketone = CH3(CH2)3C[::O]CH3
		// Reference: Yaws' Handbook of Thermodynamic and Physical Properties of Chemical Compounds
		c1=0.2714;c2=0.2607;c3=587.05;c4=0.2963;
		trm=1-T/c3;trm1=pow(trm,c4);trm2=pow(c2,-trm1);
		//Output=c1*(c2^-((1-T/c3)^c4)); // [kg/L]
		Output=c1*trm2;}
	else if(solventName.compare("*1CHCHC[Cl]CHCH*1CH")==0)
		{// Chlorobenzene = *1CHCHC[Cl]CHCH*1CH
		T-=273.15;c1=-0.0010754545;c2=1.1275909091;
		Output=c1*T+c2;}
	else if(solventName.compare("CHCl3")==0)
		{// Chloroform = CHCl3 [kg/L]
		T-=273.15;c1=-0.0018595238;c2=1.5255833333;
		Output=c1*T+c2;}
	else if(solventName.compare("*1CH2(CH2)4*1CH2")==0)
		{// Cyclohexane = *1CH2(CH2)4*1CH2
		T-=273.15;c1=-0.0009791515;c2=0.7984133333;
		Output=c1*T+c2;}
	else if(solventName.compare("CH3(CH2)3O(CH2)3CH3")==0)
		{// Dibutyl Ether = CH3(CH2)3O(CH2)3CH3 [kg/L]
		// Reference: Yaws' Handbook of Thermodynamic and Physical Properties of Chemical Compounds
		c1=0.2552;c2=0.2599;c3=581;c4=0.2857;
		trm=1-T/c3;trm1=pow(trm,c4);trm2=pow(c2,-trm1);
		//Output=c1*(c2^-((1-T/c3)^c4)); // [kg/L]
		Output=c1*trm2;}	
	else if(solventName.compare("C[Cl]H2C[Cl]H2")==0)
		{// 1,2-Dichloroethane = C[Cl]H2C[Cl]H2
		// Reference: Yaws' Handbook of Thermodynamic and Physical Properties of Chemical Compounds
		c1=0.465;c2=0.2874;c3=561;c4=0.3104;
		trm=1-T/c3;trm1=pow(trm,c4);trm2=pow(c2,-trm1);Output=c1*trm2;}
	else if(solventName.compare("ClC[Cl]H2")==0)
		{// Dichloromethane = ClC[Cl]H2
		T-=273.15;c1=-0.0020708182;c2=1.3647318182;
		Output=c1*T+c2;}
	else if(solventName.compare("CH3OCH2CH2OCH3")==0)
		{// 1,2-Dimethoxyethane = CH3OCH2CH2OCH3
		// Reference: Yaws' Handbook of Thermodynamic and Physical Properties of Chemical Compounds
		c1=0.2989;c2=0.2618;c3=536.15;c4=0.2857;
		trm=1-T/c3;trm1=pow(trm,c4);trm2=pow(c2,-trm1);Output=c1*trm2;}
	else if(solventName.compare("CH3C[::O]N[CH3]CH3")==0)
		{// N,N-Dimethylacetamide = CH3C[::O]N[CH3]CH3 [kg/L]
		// Reference: Yaws' Handbook of Thermodynamic and Physical Properties of Chemical Compounds
		c1=0.2714;c2=0.2327;c3=658;c4=0.2702;
		trm=1-T/c3;trm1=pow(trm,c4);trm2=pow(c2,-trm1);Output=c1*trm2;}
	else if(solventName.compare("CH3N[CH3]C[::O]H")==0)
		{// N,N-dimethylformamide = CH3N[CH3]C[::O]H
		// Reference: Yaws' Handbook of Thermodynamic and Physical Properties of Chemical Compounds
		c1=0.2738;c2=0.2301;c3=647;c4=0.2763;
		trm=1-T/c3;trm1=pow(trm,c4);trm2=pow(c2,-trm1);Output=c1*trm2;}
	else if(solventName.compare("*1CH2OCH2CH2O*1CH2")==0)
		{// 1,4-Dioxane = *1CH2OCH2CH2O*1CH2
		c1=0.3702;c2=10.2813;c3=587;c4=0.3047;
		trm=1-T/c3;trm1=pow(trm,c4);trm2=pow(c2,-trm1);Output=c1*trm2;}
	else if(solventName.compare("CH3S[::O]CH3")==0)
		{// Dimethyl sulfoxide = CH3S[::O]CH3 [kg/L]
		c1=0.3442;c2=0.2534;c3=726;c4=0.322;
		trm=1-T/c3;trm1=pow(trm,c4);trm2=pow(c2,-trm1);Output=c1*trm2;}
	else if(solventName.compare("CH3CH2OH")==0)
		{// Ethanol = CH3CH2OH (kg/L)
		Output=1.16239-2.25788e-3*T+5.30621e-6*T*T-6.6307e-9*T*T*T;}
	else if(solventName.compare("CH3C[::O]OCH2CH3")==0)
		{// Ethyl acetate = CH3C[::O]OCH2CH3 (kg/L)
		T-=273.15;c1=-0.0012899091;c2=0.9263681818;Output=c1*T+c2;}
	else if(solventName.compare("CH3CH2OCH2CH3")==0)
		{// Ethyl ether = CH3CH2OCH2CH3 (kg/L)
		T-=273.15;c1=-0.001259;c2=0.7386954545;Output=c1*T+c2;}
	else if(solventName.compare("HOCH2CH2OH")==0)
		{// Ethylene glycol = HOCH2CH2OH (kg/L)
		c1=0.325;c2=0.255;c3=645;c4=0.172;
		trm=1-T/c3;trm1=pow(trm,c4);trm2=pow(c2,-trm1);Output=c1*trm2;}		
	else if(solventName.compare("CH3(CH2)3C[CH2CH3]HCH2OH")==0)
		{// 2-Ethylhexanol = CH3(CH2)3C[CH2CH3]HCH2OH (kg/L)
		c1=0.2685;c2=0.2613;c3=640.25;c4=0.2773;
		trm=1-T/c3;trm1=pow(trm,c4);trm2=pow(c2,-trm1);Output=c1*trm2;}
	else if(solventName.compare("NH2C[::O]H")==0)
		{// Formamide = NH2C[::O]H (kg/L)
		c1=0.2763;c2=0.2035;c3=771;c4=0.2518;
		trm=1-T/c3;trm1=pow(trm,c4);trm2=pow(c2,-trm1);Output=c1*trm2;}
	else if(solventName.compare("HOCH2C[OH]HCH2OH")==0)
		{// Glycerol = HOCH2C[OH]HCH2OH [kg/L]
		Output=1.43632-5.28889e-4*T-2.29556e-7*T*T;}
	else if(solventName.compare("CH3(CH2)4CH3")==0)
		{// Hexane = CH3(CH2)4CH3 (kg/L)
		T-=273.15;c1=-0.0009644545;c2=0.6785772727;Output=c1*T+c2;}
	else if(solventName.compare("CH3C[CH3]HCH2OH")==0)
		{// Isobutanol = CH3C[CH3]HCH2OH kg/L
		c1=0.2698;c2=0.2721;c3=547.73;c4=0.2344;
		trm=1-T/c3;trm1=pow(trm,c4);trm2=pow(c2,-trm1);Output=c1*trm2;}
	else if(solventName.compare("CH3OH")==0)
		{// Methanol = CH3OH (kg/L)
		Output=1.14445-1.79908e-3*T+3.1645e-6*T*T-3.87839e-9*T*T*T;}
	else if(solventName.compare("CH3O(CH2)2OH")==0)
		{// 2-Methoxyethanol = CH3O(CH2)2OH kg/L
		c1=0.3188;c2=0.255;c3=564;c4=0.2857;
		trm=1-T/c3;trm1=pow(trm,c4);trm2=pow(c2,-trm1);Output=c1*trm2;}
	else if(solventName.compare("CH3CH2C[::O]CH3")==0)
		{// Methyl ethyl ketone = CH3CH2C[::O]CH3 [kg/L]
		c1=0.2676;c2=0.2514;c3=535.5;c4=0.2857;
		trm=1-T/c3;trm1=pow(trm,c4);trm2=pow(c2,-trm1);Output=c1*trm2;}
	else if(solventName.compare("CH3C[CH3]HC[::O]CH3")==0)
		{// Methyl isopropyl ketone = CH3C[CH3]HC[::O]CH3 [kg/L]
		c1=0.2753;c2=0.262;c3=553;c4=0.2857;
		trm=1-T/c3;trm1=pow(trm,c4);trm2=pow(c2,-trm1);Output=c1*trm2;}
	else if(solventName.compare("CH3N::[O]O")==0)
		{// Nitromethane = CH3N[::O]O (kg/L)
		T-=273.15;c1=-0.0014116667;c2=1.1674777778;Output=c1*T+c2;}
	else if(solventName.compare("CH3C[OH]HCH2OH")==0)
		{// Propylene glycol = CH3C[OH]HCH2OH (kg/L)
		T-=273.15;c1=-0.0008510824;c2=1.2898675019;Output=c1*T+c2;}
	else if(solventName.compare("CH3(CH2)2OH")==0)
		{// Propanol = CH3(CH2)2OH (kg/L)
		Output=1.01077-3.99649e-8*T-6.64923e-6*T*T+2.16751e-8*T*T*T-2.46167e-11*T*T*T*T;}
	else if(solventName.compare("CH3C[OH]HCH3")==0)
		{// Isopropanol = CH3C[OH]HCH3 (kg/L)
		Output=0.993868-3.40464e-8*T-6.95191e-6*T*T+2.40158e-8*T*T*T-2.92637e-11*T*T*T*T;}
	else if(solventName.compare("*1CH2(CH2)3*1O")==0)
		{// Tetrahydrofuran = *1CH2(CH2)3*1O [kg/L]
		c1=0.3221;c2=0.2808;c3=540.15;c4=0.2912;
		trm=1-T/c3;trm1=pow(trm,c4);trm2=pow(c2,-trm1);Output=c1*trm2;}
	else if(solventName.compare("*1CH(CH)2C[CH2(CH2)2*2CH2]*2C*1CH")==0)
		{// Tetralin = *1CH(CH)2C[CH2(CH2)2*2CH2]*2C*1CH [kg/L]
		c1=0.2984;c2=0.2575;c3=720.15;c4=0.2677;
		trm=1-T/c3;trm1=pow(trm,c4);trm2=pow(c2,-trm1);Output=c1*trm2;}
	else if(solventName.compare("CH3C[CH3]HCH2C[::O]CH3")==0)
		{// Methyl isobutyl ketone = CH3C[CH3]HCH2C[::O]CH3 kg/L
		c1=0.2665;c2=0.2589;c3=571.4;c4=0.2857;
		trm=1-T/c3;trm1=pow(trm,c4);trm2=pow(c2,-trm1);Output=c1*trm2;}
	else if(solventName.compare("*1CH(CH)4*1C[CH3]")==0)
		{// Toluene = *1CH(CH)4*1C[CH3] (kg/L)
		T-=273.15;c1=-0.000953;c2=0.8859045455;Output=c1*T+c2;}
	else if(solventName.compare("ClC[Cl]::C[Cl]H")==0)
		{// Trichloroethene = ClC[Cl]::C[Cl]H (kg/L)
		c1=0.5042;c2=0.2695;c3=571;c4=0.2857;
		trm=1-T/c3;trm1=pow(trm,c4);trm2=pow(c2,-trm1);Output=c1*trm2;}
	else if(solventName.compare("H2O")==0)
		{// Pure Water Density (kg/m^3) (or g/L)
		T-=273.15;	// Convert to centigrade
		// Reference: 2004. Model for calculating the density of aqueous electrolyte solutions
		Output=(((((Aw*T+Bw)*T-Cw)*T-Dw)*T+Ew)*T+Fw)/(1+Gw*T);
		// Convert to kg/L
		Output/=1000;}
	else{cerr<<"Error in Solution::calcPureSolventDensity!!!\nSolvent ("<<solventName<<") is not registered\n";exit(EXIT_FAILURE);}
	return Output;}

double Solution::calcPureSolventViscosity(string solventName,double temperature)
	{// temperature is in K
	double Output,T=temperature,trm;
	double c1,c2,c3,c4;
	// Molecular Formulae are in a structural format
	if(solventName.compare("CH3C[::O]OH")==0)
		{// Acetic Acid = CH3C[::O]OH (mPas) (298.15K-373.15K)
		Output=66.46849*exp(-1.360185e-2*T);}
	else if(solventName.compare("CH3C[CH3]::O")==0)
		{// Acetone = CH3C[CH3]::O (mPas) (248.15K-323.15K)
		Output=4.62452*exp(-9.015176e-3*T);}
	else if(solventName.compare("CH3C:::N")==0)
		{// Acetonitrile = CH3C:::N (mPas) (273.15K-348.15k)
		c1=0.0332045441;c2=679.809658852;Output=c1*exp(c2/T);}
	else if(solventName.compare("CH3(CH2)3OH")==0)
		{// Butanol = CH3(CH2)3OH (mPas) (248.15K-373.15K)
		Output=2146.186*exp(-2.256471e-2*T);}
	else if(solventName.compare("CH3(CH2)3C[::O]CH3")==0)
		{// Butyl Methyl Ketone = CH3(CH2)3C[::O]CH3 (2-Hexanone) (mPas) (248.15-373.15)
		c1=0.0108971435;c2=1186.5587172499;Output=c1*exp(c2/T);}
	else if(solventName.compare("*1CHCHC[Cl]CHCH*1CH")==0)
		{// Chlorobenzene = *1CHCHC[Cl]CHCH*1CH (mPas) (248.15K-373.15K)
		c1=0.0177206558;c2=1132.9079132319;Output=c1*exp(c2/T);}
	else if(solventName.compare("CHCl3")==0)
		{// Chloroform = CHCl3 (mPas) (248.15-323.15)
		c1=0.0266062965;c2=896.9468102971;Output=c1*exp(c2/T);}
	else if(solventName.compare("*1CH2(CH2)4*1CH2")==0)
		{// Cyclohexane = *1CH2(CH2)4*1CH2 (mPas) (298.15K-348.15K)
		c1=0.0071658161;c2=1438.9863354079;Output=c1*exp(c2/T);}
	else if(solventName.compare("CH3(CH2)3O(CH2)3CH3")==0)
		{// Dibutyl Ether = CH3(CH2)3O(CH2)3CH3 (mPas) (248.15-373.15)
		c1=0.0113182343;c2=1198.5352582595;Output=c1*exp(c2/T);}
	else if(solventName.compare("C[Cl]H2C[Cl]H2")==0)
		{// 1,2-Dichloroethane = C[Cl]H2C[Cl]H2 (mPas) (273.15-348.15)
		c1=0.0155035101;c2=1170.3034886562;Output=c1*exp(c2/T);}
	else if(solventName.compare("ClC[Cl]H2")==0)
		{// Dichloromethane = ClC[Cl]H2 (mPas) (248.15K-298.15K)
		c1=0.0249525467;c2=836.7495385873;Output=c1*exp(c2/T);}
	else if(solventName.compare("CH3OCH2CH2OCH3")==0)
		{// 1,2-Dimethoxyethane = CH3OCH2CH2OCH3 (mPas) (215-536)
		c1=-5.7926;c2=8.13e2;c3=0.0136;c4=-1.50e-5;trm=c1+c2/T+c3*T+c4*T*T;Output=pow(10,trm);}
	else if(solventName.compare("CH3C[::O]N[CH3]CH3")==0)
		{// N,N-Dimethylacetamide = CH3C[::O]N[CH3]CH3 (cP=mPas) (253K-658K)
		c1=-4.653;c2=8.36e2;c3=0.0083;c4=-7.83e-6;trm=c1+c2/T+c3*T+c4*T*T;Output=pow(10,trm);}
	else if(solventName.compare("CH3N[CH3]C[::O]H")==0)
		{// N,N-dimethylformamide = CH3N[CH3]C[::O]H (mPas) (273.15-323.15)
		c1=0.0195723424;c2=1118.7559320768;Output=c1*exp(c2/T);}
	else if(solventName.compare("*1CH2OCH2CH2O*1CH2")==0)
		{// 1,4-Dioxane = *1CH2OCH2CH2O*1CH2 (mPas) (298.15-348.15)
		c1=0.0074611653;c2=1508.9408756918;Output=c1*exp(c2/T);}
	else if(solventName.compare("CH3S[::O]CH3")==0)
		{// Dimethyl sulfoxide = CH3S[::O]CH3 (mPas) (298.15-323.15)
		Output=126.2972*exp(-1.406096e-2*T);}
	else if(solventName.compare("CH3CH2OH")==0)
		{// Ethanol = CH3CH2OH (mPas) (248.15-348.15)
		trm=-6.4406+1120/T+0.0137*T-1.55e-5*T*T;
		Output=pow(10,trm);}
	else if(solventName.compare("CH3C[::O]OCH2CH3")==0)
		{// Ethyl acetate = CH3C[::O]OCH2CH3 (mPas) (273.15-348.15)
		c1=0.0139186245;c2=1017.8514197246;Output=c1*exp(c2/T);}
	else if(solventName.compare("CH3CH2OCH2CH3")==0)
		{// Ethyl ether = CH3CH2OCH2CH3 (mPas) (273.15K-298.15k)
		c1=0.0174116237;c2=761.6265724486;Output=c1*exp(c2/T);}
	else if(solventName.compare("HOCH2CH2OH")==0)
		{// Ethylene glycol = HOCH2CH2OH (mPas) (298.15-373.15)
		c1=0.0004756685;c2=3108.8461427998;Output=c1*exp(c2/T);}		
	else if(solventName.compare("CH3(CH2)3C[CH2CH3]HCH2OH")==0)
		{// 2-Ethylhexanol = CH3(CH2)3C[CH2CH3]HCH2OH (mPas) (273.15-373.15)
		c1=0.0001158614;c2=3303.2710820549;Output=c1*exp(c2/T);}
	else if(solventName.compare("NH2C[::O]H")==0)
		{// Formamide = NH2C[::O]H (mPas) (273.15-323.15)
		c1=0.0011144366;c2=2393.042157062;Output=c1*exp(c2/T);}
	else if(solventName.compare("HOCH2C[OH]HCH2OH")==0)
		{// Glycerol = HOCH2C[OH]HCH2OH (mPas) (298.15-373.15)
		trm=-18.215+4230/T+0.0287*T-1.86e-5*T*T;
		Output=pow(10,trm);}
	else if(solventName.compare("CH3(CH2)4CH3")==0)
		{// Hexane = CH3(CH2)4CH3 (mPas) (273.15-323.15)
		c1=0.0137650712;c2=923.725764523;Output=c1*exp(c2/T);}
	else if(solventName.compare("CH3C[CH3]HCH2OH")==0)
		{// Isobutanol = CH3C[CH3]HCH2OH (mPas) (211-548)
		c1=-1.20e1;c2=2.18e3;c3=0.0238;c4=-2.14e-5;trm=c1+c2/T+c3*T+c4*T*T;Output=pow(10,trm);}
	else if(solventName.compare("CH3OH")==0)
		{// Methanol = CH3OH (mPas) (28.15-298.15)
		trm=-9.0562+1250/T+0.0224*T-2.35e-5*T*T;
		Output=pow(10,trm);}
	else if(solventName.compare("CH3O(CH2)2OH")==0)
		{// 2-Methoxyethanol = CH3O(CH2)2OH (cP=mPas) (293.15-535.8)
		c1=-31.096;c2=4.47e3;c3=0.0721;c4=-5.92e-5;trm=c1+c2/T+c3*T+c4*T*T;Output=pow(10,trm);}
	else if(solventName.compare("CH3CH2C[::O]CH3")==0)
		{// Methyl ethyl ketone = CH3CH2C[::O]CH3 (mPas) (248.15-348.15)
		c1=0.0178606573;c2=917.323904847;Output=c1*exp(c2/T);}
	else if(solventName.compare("CH3C[CH3]HC[::O]CH3")==0)
		{// Methyl isopropyl ketone = CH3C[CH3]HC[::O]CH3 (mPas) (293.15-525.35)
		c1=-9.3257;c2=1.28e3;c3=0.022;c4=-2.13e-5;trm=c1+c2/T+c3*T+c4*T*T;Output=pow(10,trm);}
	else if(solventName.compare("CH3N[::O]O")==0)
		{// Nitromethane = CH3N[::O]O (mPas) (248.15-373.15)
		c1=0.0189276739;c2=1051.6399479432;Output=c1*exp(c2/T);}
	else if(solventName.compare("CH3C[OH]HCH2OH")==0)
		{// Propylene glycol = CH3C[OH]HCH2OH (mPas) (273.15-373.15)
		c1=1.2558135966842e-5;c2=4588.5295496621;Output=c1*exp(c2/T);}
	else if(solventName.compare("CH3(CH2)2OH")==0)
		{// Propanol = CH3(CH2)2OH (mPas) (248.15-348.15)
		trm=-3.7702+992/T+0.0041*T-5.46e-6*T*T;
		Output=pow(10,trm);}
	else if(solventName.compare("CH3C[OH]HCH3")==0)
		{// Isopropanol = CH3C[OH]HCH3 (mPas) (273.15-348.15)
		trm=-0.7009+842/T-0.0086*T+8.3e-6*T*T;
		Output=pow(10,trm);}
	else if(solventName.compare("*1CH2(CH2)3*1O")==0)
		{// Tetrahydrofuran = *1CH2(CH2)3*1O (mPas) (248.15-323.15)
		c1=0.02080995;c2=920.2960256817;Output=c1*exp(c2/T);}
	else if(solventName.compare("*1CH(CH)2C[CH2(CH2)2*2CH2]*2C*1CH")==0)
		{// Tetralin = *1CH(CH)2C[CH2(CH2)2*2CH2]*2C*1CH (mPas) (273-720)
		c1=-6.371;c2=1.27e3;c3=0.0105;c4=-8.12e-6;trm=c1+c2/T+c3*T+c4*T*T;Output=pow(10,trm);}
	else if(solventName.compare("CH3C[CH3]HCH2C[::O]CH3")==0)
		{// Methyl isobutyl ketone = CH3C[CH3]HCH2C[::O]CH3 (mPas) (298.15-323.15)
		c1=0.012121122;c2=1134.710075196;Output=c1*exp(c2/T);}
	else if(solventName.compare("*1CH(CH)4*1C[CH3]")==0)
		{// Toluene = *1CH(CH)4*1C[CH3] (mPas) (248.15-373.15)
		c1=0.0148196137;c2=1083.056833036;Output=c1*exp(c2/T);}
	else if(solventName.compare("ClC[Cl]::C[Cl]H")==0)
		{// Trichloroethene = ClC[Cl]::C[Cl]H (mPas) (273.15-348.15)
		c1=0.0384955636;c2=793.4499135534;Output=c1*exp(c2/T);}
	else if(solventName.compare("H2O")==0)
		{// Pure Water Viscosity (mPa s) Reference: 2007. Model for Calculating the Viscosity of Aqueous Solutions		
		T-=273.15;	// Convert Absolute Temperature to Celsius
		Output=(T+246)/(137.37 + 5.2842*T + 0.05594*T*T);}
	else{cerr<<"Error in Solution::calcPureSolventViscosity\nSolvent ("<<solventName<<") is not registered\n";exit(EXIT_FAILURE);}
	return Output;}

double Solution::calcPureSolventDielectric(string solventName,double temperature)
	{// temperature is in K
	double Output,T=temperature;
	double c1,c2,c3,c4;
	// Molecular Formulae are in a structural format
	if(solventName.compare("CH3C[::O]OH")==0)
		{// Acetic Acid = CH3C[::O]OH (293K-363K) Ref; CRC Handbook of Chemistry and Physics
		c1=-0.15731e2;c2=0.12662;c3=-0.17738e-3;Output=c1+c2*T+c3*T*T;}
	else if(solventName.compare("CH3C[CH3]::O")==0)
		{// Acetone = CH3C[CH3]::O (273K-323K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.88157e2;c2=-0.34300;c3=0.38925e-3;Output=c1+c2*T+c3*T*T;}
	else if(solventName.compare("CH3C:::N")==0)
		{// Acetonitrile = CH3C:::N (288K-333K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.29724e3;c2=-0.15508e1;c3=0.22591e-2;Output=c1+c2*T+c3*T*T;}
	else if(solventName.compare("CH3(CH2)3OH")==0)
		{// Butanol = CH3(CH2)3OH (193K-553K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.10578e3;c2=-0.50587;c3=0.84733e-3;c4=-0.48841e-6;Output=c1+c2*T+c3*T*T+c4*T*T*T;}
	else if(solventName.compare("CH3(CH2)3C[::O]CH3")==0)
		{// Butyl Methyl Ketone = CH3(CH2)3C[::O]CH3 (243K-293K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.70378e2;c2=-0.29385;c3=0.35289e-3;Output=c1+c2*T+c3*T*T;}
	else if(solventName.compare("*1CHCHC[Cl]CHCH*1CH")==0)
		{// Chlorobenzene = *1CHCHC[Cl]CHCH*1CH (293K-430K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.19471e2;c2=-0.70786e-1;c3=0.82466e-4;Output=c1+c2*T+c3*T*T;}
	else if(solventName.compare("CHCl3")==0)
		{// Chloroform = CHCl3 (218K-323K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.15115e2;c2=-0.51830e-1;c3=0.56803e-4;Output=c1+c2*T+c3*T*T;}
	else if(solventName.compare("*1CH2(CH2)4*1CH2")==0)
		{// Cyclohexane = *1CH2(CH2)4*1CH2 (283K-333K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.24293e1;c2=-0.12095e-2;c3=-0.58741e-6;Output=c1+c2*T+c3*T*T;}
	else if(solventName.compare("CH3(CH2)3O(CH2)3CH3")==0)
		{// Dibutyl Ether = CH3(CH2)3O(CH2)3CH3 (293K-314K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.65383e1;c2=-0.16172e-1;c3=0.14969e-4;Output=c1+c2*T+c3*T*T;}
	else if(solventName.compare("C[Cl]H2C[Cl]H2")==0)
		{// 1,2-Dichloroethane = C[Cl]H2C[Cl]H2 (293K-343K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.24404e2;c2=-0.47892e-1;Output=c1+c2*T;}
	else if(solventName.compare("ClC[Cl]H2")==0)
		{// Dichloromethane = ClC[Cl]H2 (184K-338K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.40452e2;c2=-0.17748;c3=0.23942e-3;Output=c1+c2*T+c3*T*T;}
	else if(solventName.compare("CH3OCH2CH2OCH3")==0)
		{// 1,2-Dimethoxyethane = CH3OCH2CH2OCH3 (256K-318K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.48832e2;c2=-0.24218;c3=0.34413e-3;Output=c1+c2*T+c3*T*T;}
	else if(solventName.compare("CH3C[::O]N[CH3]CH3")==0)
		{// N,N-Dimethylacetamide = CH3C[::O]N[CH3]CH3 (294K-433K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.15420e3;c2=-0.57506;c3=0.61911e-3;Output=c1+c2*T+c3*T*T;}
	else if(solventName.compare("CH3N[CH3]C[::O]H")==0)
		{// N,N-dimethylformamide = CH3N[CH3]C[::O]H (213K-353K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.15364e3;c2=-0.60367;c3=0.71505e-3;Output=c1+c2*T+c3*T*T;}
	else if(solventName.compare("*1CH2OCH2CH2O*1CH2")==0)
		{// 1,4-Dioxane = *1CH2OCH2CH2O*1CH2 (293K-313K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.27299e1;c2=-0.17440e-2;Output=c1+c2*T;}
	else if(solventName.compare("CH3S[::O]CH3")==0)
		{// Dimethyl sulfoxide = CH3S[::O]CH3 (288K-343K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.38478e2;c2=0.16939;c3=-0.47423e-3;Output=c1+c2*T+c3*T*T;}
	else if(solventName.compare("CH3CH2OH")==0)
		{// Ethanol = CH3CH2OH (163K-523K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.15145e3;c2=-0.87020;c3=0.19570e-2;c4=-0.15512e-5;Output=c1+c2*T+c3*T*T+c4*T*T*T;}
	else if(solventName.compare("CH3C[::O]OCH2CH3")==0)
		{// Ethyl acetate = CH3C[::O]OCH2CH3 (293K-433K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.15646e2;c2=-0.44066e-1;c3=0.39137e-4;Output=c1+c2*T+c3*T*T;}
	else if(solventName.compare("CH3CH2OCH2CH3")==0)
		{// Ethyl ether = CH3CH2OCH2CH3 (283K-301K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.79725e1;c2=-0.12519e-1;Output=c1+c2*T;}
	else if(solventName.compare("HOCH2CH2OH")==0)
		{// Ethylene glycol = HOCH2CH2OH (293K-423K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.14355e3;c2=-0.48573;c3=0.46703e-3;Output=c1+c2*T+c3*T*T;}
	else if(solventName.compare("CH3(CH2)3C[CH2CH3]HCH2OH")==0)
		{// 2-Ethylhexanol = CH3(CH2)3C[CH2CH3]HCH2OH (208K-318K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.86074e2;c2=-0.42636;c3=0.55078e-3;Output=c1+c2*T+c3*T*T;}
	else if(solventName.compare("NH2C[::O]H")==0)
		{// Formamide = NH2C[::O]H (278K-333K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.26076e3;c2=-0.61145;c3=0.34296e-3;Output=c1+c2*T+c3*T*T;}
	else if(solventName.compare("HOCH2C[OH]HCH2OH")==0)
		{// Glycerol = HOCH2C[OH]HCH2OH (288K-343K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.77503e2;c2=-0.37984e-1;c3=-0.23107e-3;Output=c1+c2*T+c3*T*T;}
	else if(solventName.compare("CH3(CH2)4CH3")==0)
		{// Hexane = CH3(CH2)4CH3 (293K-473K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.19768e1;c2=0.70933e-3;c3=-0.34470e-5;Output=c1+c2*T+c3*T*T;}
	else if(solventName.compare("CH3C[CH3]HCH2OH")==0)
		{// Isobutanol = CH3C[CH3]HCH2OH (173K-533K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.10762e3;c2=-0.51398;c3=0.83702e-3;c4=-0.45299e-6;Output=c1+c2*T+c3*T*T+c4*T*T*T;}
	else if(solventName.compare("CH3OH")==0)
		{// Methanol = CH3OH (177K-293K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.19341e3;c2=-0.92211;c3=0.12839e-2;Output=c1+c2*T+c3*T*T;}
	else if(solventName.compare("CH3O(CH2)2OH")==0)
		{// 2-Methoxyethanol = CH3O(CH2)2OH (254K-318K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.11803e3;c2=-0.58000;c3=0.81001e-3;Output=c1+c2*T+c3*T*T;}
	else if(solventName.compare("CH3CH2C[::O]CH3")==0)
		{// Methyl ethyl ketone = CH3CH2C[::O]CH3 (293K-333K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.15457e2;c2=0.90152e-1;c3=-0.27100e-3;Output=c1+c2*T+c3*T*T;}
	else if(solventName.compare("CH3C[CH3]HC[::O]CH3")==0)
		{// Methyl isopropyl ketone = CH3C[CH3]HC[::O]CH3 (293K-328K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.30695e2;c2=-0.10962;c3=0.13810e-3;Output=c1+c2*T+c3*T*T;}
	else if(solventName.compare("CH3N[::O]O")==0)
		{// Nitromethane = CH3N[::O]O (288K-343K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.11227e3;c2=-0.35591;c3=0.34206e-3;Output=c1+c2*T+c3*T*T;}
	else if(solventName.compare("CH3C[OH]HCH2OH")==0)
		{// Propylene glycol = CH3C[OH]HCH2OH (193K-403K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.24546e3;c2=-0.15738e1;c3=0.38068e-2;c4=-0.32544e-5;Output=c1+c2*T+c3*T*T+c4*T*T*T;}
	else if(solventName.compare("CH3(CH2)2OH")==0)
		{// Propanol = CH3(CH2)2OH (193K-493K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.98045e2;c2=-0.36860;c3=0.36422e-3;Output=c1+c2*T+c3*T*T;}
	else if(solventName.compare("CH3C[OH]HCH3")==0)
		{// Isopropanol = CH3C[OH]HCH3 (193K-493K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.10416e3;c2=-0.41011;c3=0.42049e-3;Output=c1+c2*T+c3*T*T;}
	else if(solventName.compare("*1CH2(CH2)3*1O")==0)
		{// Tetrahydrofuran = *1CH2(CH2)3*1O (224K-295K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.30739e2;c2=-0.12946;c3=0.17195e-3;Output=c1+c2*T+c3*T*T;}
	else if(solventName.compare("*1CH(CH)2C[CH2(CH2)2*2CH2]*2C*1CH")==0)
		{// Tetralin = *1CH(CH)2C[CH2(CH2)2*2CH2]*2C*1CH (298K-343K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.29172e1;c2=0.12832e-2;c3=-0.59453e-5;Output=c1+c2*T+c3*T*T;}
	else if(solventName.compare("CH3C[CH3]HCH2C[::O]CH3")==0)
		{// Methyl isobutyl ketone = CH3C[CH3]HCH2C[::O]CH3 (204K-373K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.36341e2;c2=-0.97119e-1;c3=0.61896e-4;Output=c1+c2*T+c3*T*T;}
	else if(solventName.compare("*1CH(CH)4*1C[CH3]")==0)
		{// Toluene = *1CH(CH)4*1C[CH3] (207k-316K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.32584e1;c2=-0.34410e-2;c3=0.15937e-5;Output=c1+c2*T+c3*T*T;}
	else if(solventName.compare("ClC[Cl]::C[Cl]H")==0)
		{// Trichloroethene = ClC[Cl]::C[Cl]H (302K-338K) Ref; CRC Handbook of Chemistry and Physics
		c1=0.58319e1;c2=-0.80828e-2;Output=c1+c2*T;}
	else if(solventName.compare("H2O")==0)
		{// Reference: 1956. Dielectric constant of water from 0 to 100C
		T=temperature-273.15;c1=87.740;c2=-0.4008;c3=0.0009398;c4=-0.00000141;Output=c1+c2*T+c3*T*T+c4*T*T*T;}
	else{cerr<<"Error in Dielectric::get_pure_solvent_dielectric\nSolvent ("<<solventName<<") is not registered\n";exit(EXIT_FAILURE);}
	return Output;}

int Solution::countDelimiter(string Data,string delimiter){int Counter=0;string tmp="";for(int i=0;i<Data.length();i++){tmp=Data[i];if(tmp.compare(delimiter)==0){Counter++;}}return Counter;}

double* Solution::fillDoubleArray(string Data,int numPnts,string delimiter){double* Output=new double[numPnts];string bld="",tmp="";int Counter=0;for(int i=0;i<Data.length();i++){tmp=Data[i];if(tmp.compare(delimiter)==0 && Counter<numPnts){Output[Counter]=strtod(bld.c_str(),NULL);Counter++;bld="";}else{bld+=Data[i];}}return Output;}

string* Solution::fillStringArray(string Data,int numPnts,string delimiter){string* Output=new string[numPnts];string bld="",tmp="";int Counter=0;for(int i=0;i<Data.length();i++){tmp=Data[i];if(tmp.compare(delimiter)==0 && Counter<numPnts){Output[Counter]=bld;Counter++;bld="";}else{bld+=Data[i];}}return Output;}

// convert mole fraction (x) [mol comp/mol total] to mass fraction (w) [g comp/g total]
// Molecular Weight (MW) [g/mol]
double* Solution::moleFrac2MassFrac(double* x,double* MW,int numComps)
	{double* w=new double[numComps];
	double Sum=0;
	for(int i=0;i<numComps;i++){Sum+=x[i]*MW[i];}
	for(int i=0;i<numComps;i++){w[i]=x[i]*MW[i]/Sum;}
	return w;}

// convert mass fraction (x) [g comp/g total] to mole fraction (w) [mol comp/mol total]
// Molecular Weight (MW) [g/mol]
double* Solution::massFrac2MoleFrac(double* w,double* MW,int numComps)
	{double* x=new double[numComps];
	double Sum=0;
	for(int i=0;i<numComps;i++){Sum+=w[i]/MW[i];}
	for(int i=0;i<numComps;i++){x[i]=(w[i]/MW[i])/Sum;}
	return x;}

double* Solution::massFrac2MoleFrac(string* sW,double* MW,int numComps)
	{double* x=new double[numComps];
	// Convert String to Double
	string tmp;
	double* w=new double[numComps];
	for(int i=0;i<numComps;i++)
		{tmp=sW[i];
		w[i]=strtod(tmp.c_str(),NULL);}
	double Sum=0;
	for(int i=0;i<numComps;i++){Sum+=w[i]/MW[i];}
	for(int i=0;i<numComps;i++){x[i]=(w[i]/MW[i])/Sum;}
	return x;}

// Density [g/L]
// Molecular Weight (MW) [g/mol]
double* Solution::volFrac2MoleFrac(double* v,double* MW,double* density,int numComps)
	{double* x=new double[numComps];
	double Sum=0;
	for(int i=0;i<numComps;i++){Sum+=v[i]*density[i]/MW[i];}
	for(int i=0;i<numComps;i++){x[i]=(v[i]*density[i]/MW[i])/Sum;}
	return x;}

double* Solution::volFrac2MoleFrac(string* sV,double* MW,double* density,int numComps)
	{double* x=new double[numComps];
	// Convert String to Double
	string tmp;
	double* v=new double[numComps];
	for(int i=0;i<numComps;i++)
		{tmp=sV[i];
		v[i]=strtod(tmp.c_str(),NULL);}
	double Sum=0;
	for(int i=0;i<numComps;i++){Sum+=v[i]*density[i]/MW[i];}
	for(int i=0;i<numComps;i++){x[i]=(v[i]*density[i]/MW[i])/Sum;}
	return x;}

// convert molarity (M) [mol solute/total solvent volume] to mass fraction (w) [g comp/g total]
// Molecular Weight (MW) [g/mol]
// solventDensity [g/L]
double* Solution::molarity2MassFrac(double* M,double* MW,int numComps,double solventDensity)
	{double* w=new double[numComps];
	double Sum=solventDensity;
	/* Estimate Solution Density by sum of mass concentrations of each component*/
	for(int i=0;i<numComps;i++){Sum+=MW[i]*M[i];}
	/* Calculate mass fraction of each component*/
	for(int i=0;i<numComps;i++){w[i]=MW[i]*M[i]/Sum;}
	return w;}

double Solution::calcMoleculeMolecularWeight(string structure)
	{double Output=0;
	// Assess Moleculalur Structural Formula
	string numAtomList="",atomList="",atomNm="",rpt="",branch="",delimiter=";",tmp;
	char letter,second_letter;
	bool PASS,SEARCHING;
	string *Atom;
	int *numAtom;
	int pos,aCount=0,multiplier,Counter,numRepeats;
	// Find Number of Each Atom and Atoms Present
	for(int i=0;i<structure.length();i++)
		{// Get Atom Name
		PASS=false;atomNm="";multiplier=1;
		letter=structure[i];
		if(isupper(letter))
			{atomNm=letter;
			// Check if second letter completes atom name or gives number of atoms
			if(i+1<=structure.length()-1)
				{second_letter=structure[i+1];
				if(islower(second_letter)){atomNm+=second_letter;}}
			// Check if number behind Atom Name
			if(i+atomNm.length()<=structure.length()-1)
				{SEARCHING=true;Counter=0;tmp="";
				while(SEARCHING)
					{letter=structure[i+atomNm.length()+Counter];
					if(isdigit(letter)){tmp+=letter;Counter++;}
					else{SEARCHING=false;break;}}
				if(tmp.compare("")==0){multiplier=1;}
				else{multiplier=atoi(tmp.c_str());}
				i+=Counter;}			
			// Check is atom is already in Atom List, if not add
			if(atomList.compare("")==0)
				{// Initialize Atoms Present Lists
				atomList=atomNm+delimiter;
				numAtomList=cnvrtNumToStrng(multiplier,0)+delimiter;
				aCount++;
				Atom=fill_string_array(atomList,aCount,delimiter);
				numAtom=fill_int_array(numAtomList,aCount,delimiter);}
			else{// Check is atom is already in Atom List, if not add
				PASS=false;
				for(pos=0;pos<aCount;pos++){tmp=Atom[pos];if(tmp.compare(atomNm)==0){PASS=true;break;}}
				if(!PASS)
					{// Atom not found in list, so add
					atomList+=atomNm+delimiter;
					numAtomList+=cnvrtNumToStrng(multiplier,0)+delimiter;
					delete [] Atom;delete [] numAtom;
					aCount++;
					Atom=fill_string_array(atomList,aCount,delimiter);
					numAtom=fill_int_array(numAtomList,aCount,delimiter);}
				else{// Atom Found, so update numAtomList
					numAtom[pos]=numAtom[pos]+multiplier;
					numAtomList=array2String(numAtom,aCount,delimiter);}}
			}
		else if(strcmp(&letter,"(")==0)
			{// Chain Repeat Identified					345678
			// i=position of (, find end of repeat )Num e.g. (CH2)2
			pos=structure.find(")",i);
			// Acquire Repeating Atoms Unit
			rpt=structure.substr(i+1,pos-i-1);
			// Acquire Number of Repeats of Unit
			SEARCHING=true;Counter=0;tmp="";
			while(SEARCHING)
				{letter=structure[i+rpt.length()+2+Counter];
				if(isdigit(letter)){tmp+=letter;Counter++;}
				else{SEARCHING=false;break;}}
			if(tmp.compare("")==0){numRepeats=1;}
			else{numRepeats=atoi(tmp.c_str());}
			// Advance Loop Forward
			//cout<<"i="<<i<<endl;
			i+=1+rpt.length()+tmp.length();
			//cout<<"i="<<i<<endl;
			//cout<<numRepeats<<endl;
			// Determine and Count Atoms in Repeat Unit
			for(int j=0;j<rpt.length();j++)
				{// Get Atom Name
				PASS=false;atomNm="";
				letter=rpt[j];
				if(isupper(letter))
					{atomNm=letter;
					// Check if second letter completes atom name or gives number of atoms
					if(j+1<=rpt.length()-1){second_letter=rpt[j+1];if(islower(second_letter)){atomNm+=second_letter;j++;}}
					//cout<<j<<" "<<atomNm<<endl;
					// Check if number behind Atom Name
					if(j+atomNm.length()<=rpt.length()-1)
						{SEARCHING=true;Counter=0;tmp="";
						while(SEARCHING)
							{letter=rpt[j+atomNm.length()+Counter];
							if(isdigit(letter)){tmp+=letter;Counter++;}
							else{SEARCHING=false;break;}}
						if(tmp.compare("")==0){multiplier=1;}
						else{multiplier=atoi(tmp.c_str());}
						j+=Counter;}
					// Check is atom is already in Atom List, if not add
					if(atomList.compare("")==0)
						{// Initialize Atoms Present Lists
						atomList=atomNm+delimiter;
						numAtomList=cnvrtNumToStrng(multiplier*numRepeats,0)+delimiter;
						aCount++;
						Atom=fill_string_array(atomList,aCount,delimiter);
						numAtom=fill_int_array(numAtomList,aCount,delimiter);}
					else{// Check is atom is already in Atom List, if not add
						PASS=false;
						for(pos=0;pos<aCount;pos++){tmp=Atom[pos];if(tmp.compare(atomNm)==0){PASS=true;break;}}
						if(!PASS)
							{// Atom not found in list, so add
							atomList+=atomNm+delimiter;
							numAtomList+=cnvrtNumToStrng(multiplier*numRepeats,0)+delimiter;
							delete [] Atom;delete [] numAtom;
							aCount++;
							Atom=fill_string_array(atomList,aCount,delimiter);
							numAtom=fill_int_array(numAtomList,aCount,delimiter);}
						else{// Atom Found, so update numAtomList
							numAtom[pos]=numAtom[pos]+multiplier*numRepeats;
							numAtomList=array2String(numAtom,aCount,delimiter);}}}
				}
			}
		else if(strcmp(&letter,"[")==0)
			{// ?4? Molecular Branch Identified
			// i=position of [, find end of branch] e.g. [CH3]
			pos=structure.find("]",i);
			// Acquire Branching Atoms
			branch=structure.substr(i+1,pos-i-1);
			// Advance Loop Forward
			i+=1+branch.length();
			// Determine and Count Atoms in Branch
			for(int j=0;j<branch.length();j++)
				{// Check for Internal Repeating Unit in Branch
				letter=branch[j];
				if(strcmp(&letter,"(")==0)
					{// Chain Repeat Identified
					// j=position of (, find end of repeat )Num e.g. (CH2)2
					pos=branch.find(")",j);
					// Acquire Repeating Atoms Unit
					rpt=branch.substr(j+1,pos-j-1);
					// Acquire Number of Repeats of Unit
					SEARCHING=true;Counter=0;tmp="";
					while(SEARCHING)
						{letter=branch[j+rpt.length()+2+Counter];
						if(isdigit(letter)){tmp+=letter;Counter++;}
						else{SEARCHING=false;break;}}
					if(tmp.compare("")==0){numRepeats=1;}
					else{numRepeats=atoi(tmp.c_str());}
					// Advance Loop Forward
					j+=1+rpt.length()+tmp.length();
					// Determine and Count Atoms in Repeat Unit
					for(int k=0;k<rpt.length();k++)
						{// Get Atom Name
						PASS=false;atomNm="";
						letter=rpt[k];
						if(isupper(letter))
							{atomNm=letter;
							// Check if second letter completes atom name or gives number of atoms
							if(k+1<=rpt.length()-1){second_letter=rpt[k+1];if(islower(second_letter)){atomNm+=second_letter;k++;}}
							//cout<<j<<" "<<atomNm<<endl;
							// Check if number behind Atom Name
							if(k+atomNm.length()<=rpt.length()-1)
								{SEARCHING=true;Counter=0;tmp="";
								while(SEARCHING)
									{letter=rpt[k+atomNm.length()+Counter];
									if(isdigit(letter)){tmp+=letter;Counter++;}
									else{SEARCHING=false;break;}}
								if(tmp.compare("")==0){multiplier=1;}
								else{multiplier=atoi(tmp.c_str());}
								k+=Counter;}
							// Check is atom is already in Atom List, if not add
							if(atomList.compare("")==0)
								{// Initialize Atoms Present Lists
								atomList=atomNm+delimiter;
								numAtomList=cnvrtNumToStrng(multiplier*numRepeats,0)+delimiter;
								aCount++;
								Atom=fill_string_array(atomList,aCount,delimiter);
								numAtom=fill_int_array(numAtomList,aCount,delimiter);}
							else{// Check is atom is already in Atom List, if not add
								PASS=false;
								for(pos=0;pos<aCount;pos++){tmp=Atom[pos];if(tmp.compare(atomNm)==0){PASS=true;break;}}
								if(!PASS)
									{// Atom not found in list, so add
									atomList+=atomNm+delimiter;
									numAtomList+=cnvrtNumToStrng(multiplier*numRepeats,0)+delimiter;
									delete [] Atom;delete [] numAtom;
									aCount++;
									Atom=fill_string_array(atomList,aCount,delimiter);
									numAtom=fill_int_array(numAtomList,aCount,delimiter);}
								else{// Atom Found, so update numAtomList
									numAtom[pos]=numAtom[pos]+multiplier*numRepeats;
									numAtomList=array2String(numAtom,aCount,delimiter);}}}}
					}
				else if(isupper(letter))
					{atomNm=letter;
					// Check if second letter completes atom name or gives number of atoms
					if(j+1<=branch.length()-1)
						{second_letter=branch[j+1];
						if(islower(second_letter)){atomNm+=second_letter;j++;}}
					// Check if number behind Atom Name
					if(j+atomNm.length()<=branch.length()-1)
						{SEARCHING=true;Counter=0;tmp="";
						while(SEARCHING)
							{letter=branch[j+atomNm.length()+Counter];
							if(isdigit(letter)){tmp+=letter;Counter++;}
							else{SEARCHING=false;break;}}
						if(tmp.compare("")==0){multiplier=1;}
						else{multiplier=atoi(tmp.c_str());}
						j+=Counter;}
					// Check is atom is already in Atom List, if not add
					if(atomList.compare("")==0)
						{// Initialize Atoms Present Lists
						atomList=atomNm+delimiter;
						numAtomList=cnvrtNumToStrng(multiplier,0)+delimiter;
						aCount++;
						Atom=fill_string_array(atomList,aCount,delimiter);
						numAtom=fill_int_array(numAtomList,aCount,delimiter);}
					else{// Check is atom is already in Atom List, if not add
						PASS=false;
						for(pos=0;pos<aCount;pos++){tmp=Atom[pos];if(tmp.compare(atomNm)==0){PASS=true;break;}}
						if(!PASS)
							{// Atom not found in list, so add
							atomList+=atomNm+delimiter;
							numAtomList+=cnvrtNumToStrng(multiplier,0)+delimiter;
							delete [] Atom;delete [] numAtom;
							aCount++;
							Atom=fill_string_array(atomList,aCount,delimiter);
							numAtom=fill_int_array(numAtomList,aCount,delimiter);}
						else{// Atom Found, so update numAtomList
							numAtom[pos]=numAtom[pos]+multiplier;
							numAtomList=array2String(numAtom,aCount,delimiter);}}
					}
				}			
			}
		}
	//for(int i=0;i<aCount;i++){cout<<Atom[i]<<numAtom[i];}cout<<"\n";
	for(int i=0;i<aCount;i++)
		{// Identify Atom
		tmp=Atom[i];
		for(pos=0;pos<numElements;pos++){if(tmp.compare(atomicSymbol[pos])==0){break;}}
		// Get Atomic Molecular Weight
		Output+=atomicMolecularWeight[pos]*numAtom[i];}
	return Output;}

// Reference: 2007. Model for calculating the viscosity of aqueous solutions
double* Solution::getViscosityCoefficients(string saltName)
	{double v1,v2,v3,v4,v5,v6;
	double* Output=new double[6];
	if(saltName=="NH4NH4SO4" || saltName=="(NH4)2SO4")
		{// Valid at 15-60C for max mass fraction of 0.46
		v1=11.567;v2=2.5709;v3=1.9046;v4=0.0073357;v5=134.87;v6=6.7567;}
	else if(saltName=="AlCl3")
		{// Valid at 25C for max mass fraction of 0.04
		v1=-8335.5; v2=4823.7; v3=18.29; v4=0.0083713; v5=19265; v6=0.37058;}
	else if(saltName=="BaCl2")
		{// Valid at 10-70C for max mass fraction of 0.33
		v1=2.9763; v2=1.104; v3=4.0186; v4=0.0029981; v5=19.538; v6=0.095807;}
	else if(saltName=="CaNO3NO3" || saltName=="Ca(NO3)2")
		{// Valid at -10-100C for max mass fraction of 0.51
		v1=218.21; v2=5.4442; v3=5.0356; v4=0.010467; v5=176320; v6=15.86;}
	else if(saltName=="CaCl2")
		{// Valid at 0-100C for max mass fraction of 0.51
		v1=32.028; v2=0.78792; v3=-1.1495; v4=0.0026995; v5=780860; v6=5.8442;}
	else if(saltName=="CdNO3NO3" || saltName=="Cd(NO3)2")
		{// Valid at 15-55C for max mass fraction of 0.36
		v1=9.2559; v2=1.2793; v3=3.1227; v4=0.0077153; v5=-17.82; v6=24.838;}
	else if(saltName=="CdCl2")
		{// Valid at 25C for max mass fraction of 0.1592
		v1=6.5301; v2=4.0727; v3=0.044872; v4=-0.038783; v5=-0.778; v6=4.064;}
	else if(saltName=="CdSO4")
		{// Valid at 18-75C for max mass fraction of 0.3574
		v1=34.268; v2=2.9192; v3=4.375; v4=0.012318; v5=-27.966; v6=35.285;}
	else if(saltName=="CoCl2")
		{// Valid at 20-50C for max mass fraction of 0.3445
		v1=16.08; v2=2.3042; v3=7.9624; v4=0.0041625; v5=48.864; v6=-0.14434;}
	else if(saltName=="CoSO4")
		{// Valid at 25-75C for max mass fraction of 0.3305
		v1=26.343; v2=2.6995; v3=5.1901; v4=0.012926; v5=-0.099594; v6=1;}
	else if(saltName=="Cr2SO4SO4SO4" || saltName=="Cr2(SO4)3")
		{// Valid at 25C for max mass fraction of 0.0015
		v1=12.673; v2=2.4726; v3=12.007; v4=0.0083713; v5=7.3974; v6=2.0697;}
	else if(saltName=="CrCl3")
		{// Valid at 20-50C for max mass fraction of 0.2535
		v1=-120.2; v2=4.8139; v3=5.655; v4=0.013; v5=-11.341; v6=1.92;}
	else if(saltName=="CuNO3NO3" || saltName=="Cu(NO3)2")
		{// Valid at 25C for max mass fraction of 0.3331
		v1=45.382; v2=1.9172; v3=3.897; v4=0.0083713; v5=9.4796; v6=2.0697;}
	else if(saltName=="CuCl2")
		{// Valid at 20-50C for max mass fraction of 0.3751
		v1=6.9303; v2=1.8668; v3=7.4786; v4=0.0060045; v5=65.035; v6=0.15662;}
	else if(saltName=="CuSO4")
		{// Valid at 15-60C for max mass fraction of 0.4129
		v1=-130.52; v2=4.0392; v3=10.017; v4=0.060995; v5=-2324.8; v6=9.2724;}
	else if(saltName=="Fe2SO4SO4SO4" || saltName=="Fe2(SO4)3")
		{// Valid at 20-50C for max mass fraction of 0.3009
		v1=42.849; v2=2.5502; v3=7.1619; v4=0.011598; v5=1.239; v6=-0.57468;}
	else if(saltName=="FeCl2")
		{// Valid at 18-40C for max mass fraction of 0.0366
		v1=-0.29592; v2=18.533; v3=8.8165; v4=0.0021966; v5=385.52; v6=0.23964;}
	else if(saltName=="FeSO4")
		{// Valid at 25-75C for max mass fraction of 0.2109
		v1=27.074; v2=0.88474; v3=0.86143; v4=0.0051165; v5=7322.9; v6=3.9248;}
	else if(saltName=="H2O2")
		{// Valid at 0-20C for max mass fraction of 1.00
		v1=227.72; v2=0.0009402; v3=-226.89; v4=0.04474; v5=0.26782; v6=3.3224;}
	else if(saltName=="H2SO4")
		{// Valid at -10-75C for max mass fraction of 0.782
		v1=7.777; v2=1.2344; v3=1.9164; v4=0.0056363; v5=46.007; v6=2.8307;}
	else if(saltName=="H3PO4")
		{// Valid at 20-25C for max mass fraction of 0.8188
		v1=5044.2; v2=-0.017169; v3=-5029.7; v4=0.0083713; v5=1497.1; v6=-74.319;}
	else if(saltName=="HCH3COO" || saltName=="HCH3CO2" || saltName=="CH3COOH" || saltName=="CH3CO2H")
		{// Valid at 15-55C for max mass fraction of 1.00
		v1=-0.5661; v2=-0.21327; v3=3.4874; v4=0.074792; v5=1.4946; v6=27.123;}
	else if(saltName=="HCHOO" || saltName=="HCHO2" || saltName=="CHOOH" || saltName=="CHO2H")
		{// Valid at 15-55C for max mass fraction of 1.00
		v1=10.991; v2=0.039543; v3=-6.9252; v4=0.0064144; v5=19.113; v6=0.37167;}
	else if(saltName=="HCl")
		{// Valid at 10-42.5C for max mass fraction of 0.36
		v1=7.124; v2=1.1919; v3=1.6648; v4=0.00096271; v5=22.185; v6=1.479;}
	else if(saltName=="HCN")
		{// Valid at 0C for max mass fraction of 1.00
		v1=1.1509; v2=3.8268; v3=-0.38751; v4=0.0083713; v5=7.385; v6=2.0697;}
	else if(saltName=="HNO3")
		{// Valid at 4-25C for max mass fraction of 0.309
		v1=0.000082264; v2=-1.3972; v3=0.11962; v4=-0.01992; v5=-1.4448; v6=0.90694;}
	else if(saltName=="K2CO3")
		{// Valid at 19-89C for max mass fraction of 0.36
		v1=15.804; v2=1.8414; v3=2.4469; v4=0.0060894; v5=36.771; v6=3.1555;}
	else if(saltName=="K2Cr2O7")
		{// Valid at 0.2 89.3C for max mass fraction of 0.4
		v1=3.2419; v2=1.1035; v3=14.602; v4=0.00024669; v5=5404950; v6=0.26452;}
	else if(saltName=="K2HPO4")
		{// Valid at 20.95-49.95C for max mass fraction of 0.181
		v1=5873.1; v2=5.555; v3=4.3106; v4=0.096537; v5=-0.81881; v6=0.051171;}
	else if(saltName=="K2SO4")
		{// Valid at 0-89.5C for max mass fraction of 0.155
		v1=-983.76; v2=0.00019331; v3=984.52; v4=0.0038473; v5=-9.5001; v6=2.1916;}
	else if(saltName=="K3PO4")
		{// Valid at 19.95-49.95C for max mass fraction of 0.209
		v1=2.3507; v2=0.46935; v3=2.8206; v4=0.0097273; v5=-6.3284; v6=1.9539;}
	else if(saltName=="KBr")
		{// Valid at 0-95C for max mass fraction of 0.452
		v1=187.46; v2=-0.00068486; v3=-188.58; v4=-0.0027457; v5=-1.0079; v6=0.47054;}
	else if(saltName=="KCH3COO" || saltName=="KCH3CO2")
		{// Valid at 15-55C for max mass fraction of 0.625
		v1=6.4061; v2=3.0168; v3=3.6581; v4=0.013116; v5=0.36839; v6=-0.45637;}
	else if(saltName=="KCHOO" || saltName=="KCHO2")
		{// Valid at 15-55C for max mass fraction of 0.813
		v1=4.8875; v2=4.7802; v3=1.2964; v4=0.044035; v5=-1.0602; v6=1.202;}
	else if(saltName=="KCl")
		{// Valid at 5-150C for max mass fraction of 0.306
		v1=6.4883; v2=1.3175; v3=-0.77785; v4=0.092722; v5=-1.3; v6=2.0811;}
	else if(saltName=="KH2PO4")
		{// Valid at 19.95-44.95C for max mass fraction of 0.198
		v1=1358.1; v2=3.8539; v3=1.6617; v4=0.012129; v5=-1.0516; v6=4.1301;}
	else if(saltName=="KI")
		{// Valid at 5-95C for max mass fraction of 0.627
		v1=4.9108; v2=1.1146; v3=-1.2651; v4=0.060535; v5=0.52054; v6=0.09659;}
	else if(saltName=="KNO3")
		{// Valid at 15-60C for max mass fraction of 0.495
		v1=3.9621; v2=0.39973; v3=4.259; v4=0.00076988; v5=925.92; v6=0.33733;}
	else if(saltName=="KOH")
		{// Valid at -14.1-40C for max mass fraction of 0.519
		v1=57.433; v2=3.8049; v3=2.6226; v4=0.010312; v5=5219; v6=10.946;}
	else if(saltName=="Li2SO4")
		{// Valid at 5-128.58C for max mass fraction of 0.26
		v1=42.491; v2=2.2133; v3=6.064; v4=0.0081429; v5=24.167; v6=2.96;}
	else if(saltName=="LiCl")
		{// Valid at 0-95C for max mass fraction of 0.454
		v1=19.265; v2=1.9701; v3=1.6661; v4=0.01149; v5=-0.79691; v6=-0.017456;}
	else if(saltName=="LiNO3")
		{// Valid at 0-110C for max mass fraction of 0.671
		v1=16.905; v2=1.5469; v3=0.63451; v4=0.0083965; v5=156.27; v6=4.3685;}
	else if(saltName=="LiOH")
		{// Valid at 20-40C for max mass fraction of 0.113
		v1=4017.7; v2=3.1299; v3=14.397; v4=0.008346; v5=669.91; v6=2.1575;}
	else if(saltName=="MgNO3NO3" || saltName=="Mg(NO3)2")
		{// Valid at 0-50C for max mass fraction of 0.37
		v1=31.394; v2=2.4805; v3=3.7822; v4=0.0072105; v5=1195.6; v6=31.967;}
	else if(saltName=="MgCl2")
		{// Valid at 15-70C for max mass fraction of 0.386
		v1=24.032; v2=2.2694; v3=3.7108; v4=0.021853; v5=-1.1236; v6=0.14474;}
	else if(saltName=="MgSO4")
		{// Valid at 15-150C for max mass fraction of 0.303
		v1=23.286; v2=0.99267; v3=5.4094; v4=0.0063869; v5=63.574; v6=1.6689;}
	else if(saltName=="MnCl2")
		{// Valid at 25C for max mass fraction of 0.42
		v1=28.172; v2=2.4694; v3=3.8408; v4=0.0083713; v5=7.385; v6=2.0697;}
	else if(saltName=="MnSO4")
		{// Valid at 20-80C for max mass fraction of 0.364
		v1=24.038; v2=2.1341; v3=6.4724; v4=0.0074808; v5=0.67399; v6=-0.53884;}
	else if(saltName=="Na2CO3")
		{// Valid at 20-90C for max mass fraction of 0.308
		v1=16.179; v2=0.48606; v3=1.6033; v4=0.01761; v5=-6.9093; v6=2.2356;}
	else if(saltName=="Na2HPO4")
		{// Valid at 20-50C for max mass fraction of 0.099
		v1=99.53; v2=2.7075; v3=0.23625; v4=-0.017106; v5=-0.99535; v6=0.0060289;}
	else if(saltName=="Na2S2O3")
		{// Valid at 20-50C for max mass fraction of 0.575
		v1=19.509; v2=1.5231; v3=2.7793; v4=0.015159; v5=2.01403e12; v6=49.214;}
	else if(saltName=="Na2SO3")
		{// Valid at 25-40C for max mass fraction of 0.06
		v1=0.000044078; v2=-2.2823; v3=5.5871; v4=0.01463; v5=-0.2519; v6=4.7169;}
	else if(saltName=="Na2SO4")
		{// Valid at 15-150C for max mass fraction of 0.331
		v1=26.519; v2=1.5746; v3=3.4966; v4=0.010388; v5=106.23; v6=2.9738;}
	else if(saltName=="Na3PO4")
		{// Valid at 19.95-49.95C for max mass fraction of 0.076
		v1=24.444; v2=0.63525; v3=12.95; v4=0.0025154; v5=1639040; v6=1.5312;}
	else if(saltName=="NaBr")
		{// Valid at 5-60C for max mass fraction of 0.54
		v1=13.029; v2=1.7478; v3=0.60413; v4=0.010804; v5=17.681; v6=2.3831;}
	else if(saltName=="NaCH3COO" || saltName=="NaCH3CO2")
		{// Valid at 25-55C for max mass fraction of 0.456
		v1=13.239; v2=1.6335; v3=5.6914; v4=0.020441; v5=23994; v6=14.214;}
	else if(saltName=="NaCl")
		{// Valid at 5-154C for max mass fraction of 0.264
		v1=16.222; v2=1.3229; v3=1.4849; v4=0.0074691; v5=30.78; v6=2.0583;}
	else if(saltName=="NaClO3")
		{// Valid at 25-55C for max mass fraction of 0.583
		v1=13.697; v2=0.37882; v3=-1.1782; v4=0.0015768; v5=4065.9; v6=2.1278;}
	else if(saltName=="NaF")
		{// Valid at 5-55C for max mass fraction of 0.032
		v1=158.35; v2=1.6418; v3=5.1181; v4=0.0014974; v5=0.42269; v6=6.1895;}
	else if(saltName=="NaH2PO4")
		{// Valid at 20-50C for max mass fraction of 0.3
		v1=3.9294; v2=0.36692; v3=3.4152; v4=0.0097606; v5=3.2217; v6=0.53556;}
	else if(saltName=="NaI")
		{// Valid at 5-97.83C for max mass fraction of 0.629
		v1=12.353; v2=1.7906; v3=-0.22864; v4=0.0084003; v5=43.458; v6=3.1429;}
	else if(saltName=="NaNO3")
		{// Valid at 10-60C for max mass fraction of 0.552
		v1=5.5367; v2=1.3221; v3=1.4038; v4=0.014242; v5=0.43102; v6=-0.12645;}
	else if(saltName=="NaOH")
		{// Valid at 12.5-70C for max mass fraction of 0.56
		v1=440.2; v2=0.0089764; v3=-423.67; v4=0.015949; v5=107.6; v6=4.6489;}
	else if(saltName=="NH3")
		{// Valid at 19.85-39.85C for max mass fraction of 0.62
		v1=2.2287; v2=1.17; v3=3.4326; v4=0.0085807; v5=54.787; v6=0.84697;}
	else if(saltName=="NH4Cl")
		{// Valid at 10-73.5C for max mass fraction of 0.324
		v1=12.396; v2=1.5039; v3=-1.7756; v4=0.23471; v5=-2.7591; v6=2.8408;}
	else if(saltName=="NH4NO3")
		{// Valid at 15-60C for max mass fraction of 0.785
		v1=3.5287; v2=2.5639; v3=0.78627; v4=0.0095033; v5=0.65; v6=-0.48778;}
	else if(saltName=="NiCl2")
		{// Valid at 20-50C for max mass fraction of 0.379
		v1=272.76; v2=5.5487; v3=7.4913; v4=0.0062831; v5=5.4278; v6=-0.70825;}
	else if(saltName=="NiSO4")
		{// Valid at 15-60C for max mass fraction of 0.353
		v1=26.187; v2=1.887; v3=5.3108; v4=0.010252; v5=-0.31459; v6=0.41465;}
	else if(saltName=="PbNO3NO3" || saltName=="Pb(NO3)2")
		{// Valid at 25-50C for max mass fraction of 0.375
		v1=3939.2; v2=0.00036493; v3=-3932.2; v4=0.0042192; v5=437.27; v6=2.1463;}
	else if(saltName=="SrNO3NO3" || saltName=="Sr(NO3)2")
		{// Valid at 25C for max mass fraction of 0.25
		v1=18.338; v2=1.3569; v3=2.0865; v4=0.0083713; v5=7.385; v6=2.0697;}
	else if(saltName=="SrCl2")
		{// Valid at 10-72.9C for max mass fraction of 0.454
		v1=6.3341; v2=1.6291; v3=1.9197; v4=0.008781; v5=-4.265; v6=2.5302;}
	else if(saltName=="sucrose")
		{// Valid at 15-55C for max mass fraction of 0.25
		v1=59.669; v2=1.7701; v3=10.201; v4=0.010025; v5=2716.5; v6=4.8553;}
	else if(saltName=="ZnCl2")
		{// Valid at 25 C for max mass fraction of 0.52
		v1=12.697; v2=2.8245; v3=2.8195; v4=0.0083713; v5=7.385; v6=2.0697;}
	else if(saltName=="ZnSO4")
		{// Valid at 15-55C for max mass fraction of 0.318
		v1=13.593; v2=1.354; v3=10.556; v4=0.0036034; v5=613.22; v6=0.19583;}
	else{//cerr<<"The salt ("<<saltName<<") does not have any viscosity data associated with it.\nUsing pure solvent viscosity as an estimate...\n";
		v1=0; v2=0; v3=0; v4=0; v5=0; v6=0;}
	Output[0]=v1; Output[1]=v2; Output[2]=v3; Output[3]=v4; Output[4]=v5; Output[5]=v6;
	return Output;}

Solution::Solution(){}

string Solution::interpretMoleculeName(string Molecule)
	{string Output="";
	// Does Molecule Name Input Contain Only Atoms, if so pass
	char letter,second_letter;
	string atomNm="";
	bool PASS,PASS2=true;
	// Determine if molecule name is atomic symbol sequence, structural sequence or some name
	for(int i=0;i<Molecule.length();i++)
		{PASS=false;atomNm="";
		letter=Molecule[i];
		if(isupper(letter))
			{atomNm=letter;
			// Check if second letter completes atom name
			if(i+1<=Molecule.length()-1)
				{second_letter=Molecule[i+1];
				if(islower(second_letter)){atomNm+=second_letter;i++;}}
			// Check if possible atom name is indeed an atom
			for(int j=0;j<numElements;j++){if(atomNm.compare(atomicSymbol[j])==0){PASS=true;break;}}
			if(!PASS){/*Unrecognized atom symbol in molecule name*/PASS2=false;break;}
			Output+=atomNm;}
		else if(isdigit(letter)||strcmp(&letter,":")==0||strcmp(&letter,"[")==0||strcmp(&letter,"]")==0||strcmp(&letter,"(")==0||strcmp(&letter,")")==0)
			{// Number in name can be skipped
			// * <- Indicator of Cyclic compound, can be skipped
			// : <- double (::) or triple (:::) bond indicator, can be skipped
			// [] <- branching chain indicator, can be skipped
			// () <- chain repeat indicator, can be skipped
			Output+=letter;}
		else{/*Unrecognized letter in molecule name*/PASS2=false;break;}}
	if(!PASS2)
		{//Contains Something other than atomic symbols (e.g. molecule name like acetonitrile or ethyl acetate)
		if(Molecule.compare("acetic acid")==0||Molecule.compare("acetic_acid")==0||Molecule.compare("ethanoic acid")==0||Molecule.compare("ethanoic_acid")==0)
			{// Acetic Acid = CH3C[::O]OH
			Output="CH3C[::O]OH";}
		else if(Molecule.compare("acetone")==0||Molecule.compare("propanone")==0)
			{// Acetone = CH3C[CH3]::O
			Output="CH3C[CH3]::O";}
		else if(Molecule.compare("acetonitrile")==0)
			{// Acetonitrile = CH3C:::N
			Output="CH3C:::N";}
		else if(Molecule.compare("butanol")==0||Molecule.compare("butyl alcohol")==0||Molecule.compare("butyl_alcohol")==0)
			{// Butanol = "CH3(CH2)3OH"
			Output="CH3(CH2)3OH";}
		else if(Molecule.compare("butyl methyl ketone")==0||Molecule.compare("butyl_methyl_ketone")==0||Molecule.compare("2-hexanone")==0||Molecule.compare("methyl butyl ketone")==0||Molecule.compare("methyl_butyl_ketone")==0||Molecule.compare("propylacetone")==0)
			{// Butyl Methyl Ketone = CH3(CH2)3C[::O]CH3
			Output="CH3(CH2)3C[::O]CH3";}
		else if(Molecule.compare("chlorobenzene")==0||Molecule.compare("benzene chloride")==0||Molecule.compare("benzene_chloride")==0||Molecule.compare("phenylchloride")==0||Molecule.compare("chlorobenzol")==0)
			{// Chlorobenzene = *1CHCHC[Cl]CHCH*1CH
			Output="*1CHCHC[Cl]CHCH*1CH";}
		else if(Molecule.compare("chloroform")==0||Molecule.compare("trichloromethane")==0)
			{// Chloroform = CHCl3
			Output="CHCl3";}
		else if(Molecule.compare("cyclohexane")==0)
			{// Cyclohexane = *1CH2(CH2)4*1CH2
			Output="*1CH2(CH2)4*1CH2";}
		else if(Molecule.compare("dibutyl ether")==0||Molecule.compare("dibutyl_ether")==0||Molecule.compare("1-butoxybutane")==0)
			{// Dibutyl Ether = CH3(CH2)3O(CH2)3CH3
			Output="CH3(CH2)3O(CH2)3CH3";}
		else if(Molecule.compare("1,2-dichloroethane")==0||Molecule.compare("ethane dichloride")==0||Molecule.compare("ethane_dichloride")==0)
			{// 1,2-Dichloroethane = "C[Cl]H2C[Cl]H2"
			Output="C[Cl]H2C[Cl]H2";}
		else if(Molecule.compare("dichloromethane")==0)
			{// Dichloromethane = ClC[Cl]H2
			Output="ClC[Cl]H2";}
		else if(Molecule.compare("1,2-dimethoxyethane")==0)
			{// 1,2-Dimethoxyethane = CH3OCH2CH2OCH3
			Output="CH3OCH2CH2OCH3";}
		else if(Molecule.compare("n,n-dimethylacetamide")==0)
			{// N,N-Dimethylacetamide = CH3C[::O]N[CH3]CH3
			Output="CH3C[::O]N[CH3]CH3";}
		else if(Molecule.compare("n,n-dimethylformamide")==0)
			{// N,N-dimethylformamide = CH3N[CH3]C[::O]H
			Output="CH3N[CH3]C[::O]H";}
		else if(Molecule.compare("1,4-dioxane")==0)
			{// 1,4-Dioxane = *1CH2OCH2CH2O*1CH2
			Output="*1CH2OCH2CH2O*1CH2";}
		else if(Molecule.compare("dimethyl sulfoxide")==0||Molecule.compare("dimethyl_sulfoxide")==0)
			{// Dimethyl sulfoxide = CH3S[::O]CH3
			Output="CH3S[::O]CH3";}
		else if(Molecule.compare("ethanol")==0||Molecule.compare("ethyl alcohol")==0||Molecule.compare("ethyl_alcohol")==0)
			{// Ethanol = CH3CH2OH
			Output="CH3CH2OH";}
		else if(Molecule.compare("ethyl acetate")==0||Molecule.compare("ethyl_acetate")==0||Molecule.compare("ethyl ethanoate")==0||Molecule.compare("ethyl_ethanoate")==0)
			{// Ethyl acetate = CH3C[::O]OCH2CH3
			Output="CH3C[::O]OCH2CH3";}
		else if(Molecule.compare("diethyl ether")==0||Molecule.compare("diethyl_ether")==0||Molecule.compare("ethyl ether")==0||Molecule.compare("ethyl_ether")==0||Molecule.compare("ethoxyethane")==0)
			{// Ethyl ether = CH3CH2OCH2CH3
			Output="CH3CH2OCH2CH3";}
		else if(Molecule.compare("ethylene glycol")==0||Molecule.compare("ethylene_glycol")==0||Molecule.compare("ethane-1,2-diol")==0)
			{// Ethylene glycol = HOCH2CH2OH
			Output="HOCH2CH2OH";}
		else if(Molecule.compare("2-ethylhexanol")==0)
			{// 2-Ethylhexanol = CH3(CH2)3C[CH2CH3]HCH2OH
			Output="CH3(CH2)3C[CH2CH3]HCH2OH";}
		else if(Molecule.compare("formamide")==0||Molecule.compare("methanamide")==0||Molecule.compare("carbamaldehyde")==0)
			{// Formamide = NH2C[::O]H
			Output="NH2C[::O]H";}
		else if(Molecule.compare("glycerol")==0||Molecule.compare("glycerine")==0||Molecule.compare("glycerin")==0||Molecule.compare("propane-1,2,3-triol")==0)
			{// Glycerol = HOCH2C[OH]HCH2OH
			Output="HOCH2C[OH]HCH2OH";}
		else if(Molecule.compare("hexane")==0)
			{// Hexane = CH3(CH2)4CH3
			Output="CH3(CH2)4CH3";}
		else if(Molecule.compare("isobutanol")==0||Molecule.compare("2-methylpropan-1-ol")==0||Molecule.compare("isobutyl alcohol")==0||Molecule.compare("isobutyl_alcohol")==0)
			{// Isobutanol = CH3C[CH3]HCH2OH
			Output="CH3C[CH3]HCH2OH";}
		else if(Molecule.compare("methanol")==0||Molecule.compare("methyl alcohol")==0||Molecule.compare("methyl_alcohol")==0)
			{// Methanol = CH3OH
			Output="CH3OH";}
		else if(Molecule.compare("2-methoxyethanol")==0)
			{// 2-Methoxyethanol = CH3O(CH2)2OH
			Output="CH3O(CH2)2OH";}
		else if(Molecule.compare("methyl ethyl ketone")==0||Molecule.compare("methyl_ethyl_ketone")==0||Molecule.compare("ethyl methyl ketone")==0||Molecule.compare("ethyl_methyl_ketone")==0||Molecule.compare("butanone")==0)
			{// Methyl ethyl ketone = CH3CH2C[::O]CH3
			Output="CH3CH2C[::O]CH3";}
		else if(Molecule.compare("methyl isopropyl ketone")==0||Molecule.compare("methyl_isopropyl_ketone")==0||Molecule.compare("3-methylbutan-2-one")==0)
			{// Methyl isopropyl ketone = CH3C[CH3]HC[::O]CH3
			Output="CH3C[CH3]HC[::O]CH3";}
		else if(Molecule.compare("nitromethane")==0||Molecule.compare("nitrocarbol")==0)
			{// Nitromethane = CH3N[::O]O
			Output="CH3N[::O]O";}
		else if(Molecule.compare("propylene glycol")==0||Molecule.compare("propylene_glycol")==0||Molecule.compare("propane-1,2-diol")==0)
			{// Propylene glycol = CH3C[OH]HCH2OH
			Output="CH3C[OH]HCH2OH";}
		else if(Molecule.compare("propanol")==0||Molecule.compare("1-propanol")==0||Molecule.compare("propyl alcohol")==0||Molecule.compare("propyl_alcohol")==0)
			{// Propanol = CH3(CH2)2OH
			Output="CH3(CH2)2OH";}
		else if(Molecule.compare("isopropanol")==0||Molecule.compare("2-propanol")==0||Molecule.compare("isopropyl alcohol")==0||Molecule.compare("isopropyl_alcohol")==0)
			{// Isopropanol = CH3C[OH]HCH3
			Output="CH3C[OH]HCH3";}
		else if(Molecule.compare("tetrahydrofuran")==0||Molecule.compare("oxolane")==0)
			{// Tetrahydrofuran = *1CH2(CH2)3*1O
			Output="*1CH2(CH2)3*1O";}
		else if(Molecule.compare("tetralin")==0||Molecule.compare("1,2,3,4-tetrahydronaphthalene")==0)
			{// Tetralin = *1CH(CH)2C[CH2(CH2)2*2CH2]*2C*1CH
			Output="*1CH(CH)2C[CH2(CH2)2*2CH2]*2C*1CH";}
		else if(Molecule.compare("methyl isobutyl ketone")==0||Molecule.compare("methyl_isobutyl_ketone")==0||Molecule.compare("4-methylpentan-2-one")==0)
			{// Methyl isobutyl ketone = CH3C[CH3]HCH2C[::O]CH3
			Output="CH3C[CH3]HCH2C[::O]CH3";}
		else if(Molecule.compare("toluene")==0||Molecule.compare("methyl benzene")==0||Molecule.compare("methyl_benzene")==0)
			{// Toluene = *1CH(CH)4*1C[CH3]
			Output="*1CH(CH)4*1C[CH3]";}
		else if(Molecule.compare("trichloroethene")==0||Molecule.compare("trichloroethylene")==0)
			{// Trichloroethene = ClC[Cl]::C[Cl]H
			Output="ClC[Cl]::C[Cl]H";}
		else if(Molecule.compare("water")==0)
			{// Water = H2O
			Output="H2O";}
		else{cout<<"Error in interpretMoleculeName!!!\nUnrecognized molecule ("<<Molecule<<")"<<endl;
			//exit(EXIT_FAILURE);
			Output=Molecule;}
		}
	return Output;}

// Reference: Lange's Handbook of Chemistry (Table >=4.9)
double Solution::getBondLength(string atomicBond)
	{// Output Bond Length in Angstroms (1A=0.1nm)
	double Output;
	if(atomicBond.compare("CC")==0){Output=1.54;}
	else if(atomicBond.compare("C::C")==0){Output=1.34;}
	else if(atomicBond.compare("C:::C")==0){Output=1.20;}
	else if(atomicBond.compare("CH")==0||atomicBond.compare("HC")==0){Output=1.09;}
	else if(atomicBond.compare("CF")==0||atomicBond.compare("FC")==0){Output=1.38;}
	else if(atomicBond.compare("CCl")==0||atomicBond.compare("ClC")==0){Output=1.76;}
	else if(atomicBond.compare("CBr")==0||atomicBond.compare("BrC")==0){Output=1.94;}
	else if(atomicBond.compare("CI")==0||atomicBond.compare("IC")==0){Output=2.14;}
	else if(atomicBond.compare("CN")==0||atomicBond.compare("NC")==0){Output=1.47;}
	else if(atomicBond.compare("C::N")==0||atomicBond.compare("N::C")==0){Output=1.32;}
	else if(atomicBond.compare("C:::N")==0||atomicBond.compare("N:::C")==0){Output=1.16;}
	else if(atomicBond.compare("CO")==0||atomicBond.compare("OC")==0){Output=1.43;}
	else if(atomicBond.compare("C::O")==0||atomicBond.compare("O::C")==0){Output=1.13;}
	else if(atomicBond.compare("CSe")==0||atomicBond.compare("SeC")==0){Output=1.98;}
	else if(atomicBond.compare("C::Se")==0||atomicBond.compare("Se::C")==0){Output=1.71;}
	else if(atomicBond.compare("CSi")==0||atomicBond.compare("SiC")==0){Output=1.87;}
	else if(atomicBond.compare("CS")==0||atomicBond.compare("SC")==0){Output=1.82;}
	else if(atomicBond.compare("C::S")==0||atomicBond.compare("S::C")==0){Output=1.71;}
	else if(atomicBond.compare("CAl")==0||atomicBond.compare("AlC")==0){Output=2.24;}
	else if(atomicBond.compare("CAs")==0||atomicBond.compare("AsC")==0){Output=1.98;}
	else if(atomicBond.compare("CB")==0||atomicBond.compare("BC")==0){Output=1.56;}
	else if(atomicBond.compare("CBe")==0||atomicBond.compare("BeC")==0){Output=1.93;}
	else if(atomicBond.compare("CBi")==0||atomicBond.compare("BiC")==0){Output=2.30;}
	else if(atomicBond.compare("CCo")==0||atomicBond.compare("CoC")==0){Output=1.83;}
	else if(atomicBond.compare("CCr")==0||atomicBond.compare("CrC")==0){Output=1.92;}
	else if(atomicBond.compare("CFe")==0||atomicBond.compare("FeC")==0){Output=1.84;}
	else if(atomicBond.compare("CGe")==0||atomicBond.compare("GeC")==0){Output=1.93;}
	else if(atomicBond.compare("CHg")==0||atomicBond.compare("HgC")==0){Output=2.07;}
	else if(atomicBond.compare("CIn")==0||atomicBond.compare("InC")==0){Output=2.16;}
	else if(atomicBond.compare("CMo")==0||atomicBond.compare("MoC")==0){Output=2.08;}
	else if(atomicBond.compare("CNi")==0||atomicBond.compare("NiC")==0){Output=2.11;}
	else if(atomicBond.compare("CPb")==0||atomicBond.compare("PbC")==0){Output=2.30;}
	else if(atomicBond.compare("CPd")==0||atomicBond.compare("PdC")==0){Output=2.27;}
	else if(atomicBond.compare("CSb")==0||atomicBond.compare("SbC")==0){Output=2.20;}
	else if(atomicBond.compare("CSn")==0||atomicBond.compare("SnC")==0){Output=2.14;}
	else if(atomicBond.compare("CTe")==0||atomicBond.compare("TeC")==0){Output=1.90;}
	else if(atomicBond.compare("CTl")==0||atomicBond.compare("TlC")==0){Output=2.70;}
	else if(atomicBond.compare("CW")==0||atomicBond.compare("WC")==0){Output=2.06;}
	else if(atomicBond.compare("BB")==0){Output=1.77;}
	else if(atomicBond.compare("BBr")==0||atomicBond.compare("BrB")==0){Output=1.87;}
	else if(atomicBond.compare("BCl")==0||atomicBond.compare("ClB")==0){Output=1.72;}
	else if(atomicBond.compare("BF")==0||atomicBond.compare("FB")==0){Output=1.29;}
	else if(atomicBond.compare("BH")==0||atomicBond.compare("HB")==0){Output=1.21;}
	else if(atomicBond.compare("BN")==0||atomicBond.compare("NB")==0){Output=1.42;}
	else if(atomicBond.compare("BO")==0||atomicBond.compare("OB")==0){Output=1.36;}
	else if(atomicBond.compare("HAl")==0||atomicBond.compare("AlH")==0){Output=1.65;}
	else if(atomicBond.compare("HAs")==0||atomicBond.compare("AsH")==0){Output=1.52;}
	else if(atomicBond.compare("HBe")==0||atomicBond.compare("BeH")==0){Output=1.34;}
	else if(atomicBond.compare("HBr")==0||atomicBond.compare("BrH")==0){Output=1.41;}
	else if(atomicBond.compare("HCa")==0||atomicBond.compare("CaH")==0){Output=2.00;}
	else if(atomicBond.compare("HCl")==0||atomicBond.compare("ClH")==0){Output=1.27;}
	else if(atomicBond.compare("HF")==0||atomicBond.compare("FH")==0){Output=0.92;}
	else if(atomicBond.compare("HGe")==0||atomicBond.compare("GeH")==0){Output=1.53;}
	else if(atomicBond.compare("HI")==0||atomicBond.compare("IH")==0){Output=1.61;}
	else if(atomicBond.compare("HK")==0||atomicBond.compare("KH")==0){Output=2.24;}
	else if(atomicBond.compare("HLi")==0||atomicBond.compare("LiH")==0){Output=1.60;}
	else if(atomicBond.compare("HMg")==0||atomicBond.compare("MgH")==0){Output=1.73;}
	else if(atomicBond.compare("HNa")==0||atomicBond.compare("NaH")==0){Output=1.89;}
	else if(atomicBond.compare("HSb")==0||atomicBond.compare("SbH")==0){Output=1.71;}
	else if(atomicBond.compare("HSe")==0||atomicBond.compare("SeH")==0){Output=1.46;}
	else if(atomicBond.compare("HSn")==0||atomicBond.compare("SnH")==0){Output=1.70;}
	else if(atomicBond.compare("NN")==0){Output=1.02;}
	else if(atomicBond.compare("NCl")==0||atomicBond.compare("ClN")==0){Output=1.79;}
	else if(atomicBond.compare("NF")==0||atomicBond.compare("FN")==0){Output=1.36;}
	else if(atomicBond.compare("NH")==0||atomicBond.compare("HN")==0){Output=1.02;}
	else if(atomicBond.compare("NO")==0||atomicBond.compare("ON")==0){Output=1.24;}
	else if(atomicBond.compare("N::O")==0||atomicBond.compare("O::N")==0){Output=1.19;}
	else if(atomicBond.compare("NSi")==0||atomicBond.compare("SiN")==0){Output=1.57;}
	else if(atomicBond.compare("OH")==0||atomicBond.compare("HO")==0){Output=0.96;}
	else if(atomicBond.compare("OO")==0){Output=1.48;}
	else if(atomicBond.compare("OAl")==0||atomicBond.compare("AlO")==0){Output=1.62;}
	else if(atomicBond.compare("OAs")==0||atomicBond.compare("AsO")==0){Output=1.79;}
	else if(atomicBond.compare("OBa")==0||atomicBond.compare("BaO")==0){Output=1.90;}
	else if(atomicBond.compare("OCl")==0||atomicBond.compare("ClO")==0){Output=1.48;}
	else if(atomicBond.compare("OMg")==0||atomicBond.compare("MgO")==0){Output=1.75;}
	else if(atomicBond.compare("OOs")==0||atomicBond.compare("OsO")==0){Output=1.66;}
	else if(atomicBond.compare("OPb")==0||atomicBond.compare("PbO")==0){Output=1.93;}
	else if(atomicBond.compare("PBr")==0||atomicBond.compare("BrP")==0){Output=2.23;}
	else if(atomicBond.compare("PCl")==0||atomicBond.compare("ClP")==0){Output=2.00;}
	else if(atomicBond.compare("PF")==0||atomicBond.compare("FP")==0){Output=1.55;}
	else if(atomicBond.compare("PH")==0||atomicBond.compare("HP")==0){Output=1.42;}
	else if(atomicBond.compare("PI")==0||atomicBond.compare("IP")==0){Output=2.52;}
	else if(atomicBond.compare("PN")==0||atomicBond.compare("NP")==0){Output=1.49;}
	else if(atomicBond.compare("PO")==0||atomicBond.compare("OP")==0){Output=1.45;}
	else if(atomicBond.compare("PS")==0||atomicBond.compare("SP")==0){Output=2.12;}
	else if(atomicBond.compare("PC")==0||atomicBond.compare("CP")==0){Output=1.56;}
	else if(atomicBond.compare("SiBr")==0||atomicBond.compare("BrSi")==0){Output=2.16;}
	else if(atomicBond.compare("SiCl")==0||atomicBond.compare("ClSi")==0){Output=2.02;}
	else if(atomicBond.compare("SiF")==0||atomicBond.compare("FSi")==0){Output=1.56;}
	else if(atomicBond.compare("SiH")==0||atomicBond.compare("HSi")==0){Output=1.48;}
	else if(atomicBond.compare("SiI")==0||atomicBond.compare("ISi")==0){Output=2.34;}
	else if(atomicBond.compare("SiO")==0||atomicBond.compare("OSi")==0){Output=1.53;}
	else if(atomicBond.compare("SiSi")==0){Output=2.30;}
	else if(atomicBond.compare("SBr")==0||atomicBond.compare("BrS")==0){Output=2.27;}
	else if(atomicBond.compare("SCl")==0||atomicBond.compare("ClS")==0){Output=1.59;}
	else if(atomicBond.compare("SF")==0||atomicBond.compare("FS")==0){Output=1.59;}
	else if(atomicBond.compare("SH")==0||atomicBond.compare("HS")==0){Output=1.33;}
	else if(atomicBond.compare("SO")==0||atomicBond.compare("OS")==0){Output=1.43;}
	else if(atomicBond.compare("SS")==0){Output=2.05;}
	else{cout<<"Error in Solution::getBondLength!!!\nUnrecognized Bond ("<<atomicBond<<")\n";exit(EXIT_FAILURE);}
	return Output;}

string Solution::interpretSolute(string solute)
	{string Output="",ionList="",chargeList="",radiusList="",delimiter=";";
	// Generate List of Possible Ion(s) contained in solute
	int Counter=0,pos,multiplier,pos2;	
	for(int i=0;i<numIons;i++)
		{pos=solute.find(modeledIons[i],0);
		if(pos!=string::npos)
			{// Add to list of culprits
			ionList+=modeledIons[i]+delimiter;Counter++;
			chargeList+=modeledIonsCharge[i]+delimiter;
			radiusList+=modeledIonsRadius[i]+delimiter;}}
	if(ionList.length()==0){cerr<<"Error in Solution::interpretSolute!\nNo ions identified in solute ("<<solute<<").\n";exit(EXIT_FAILURE);}
	string* iList=fill_string_array(ionList,Counter,delimiter);
	string* cList=fill_string_array(chargeList,Counter,delimiter);
	string* rList=fill_string_array(radiusList,Counter,delimiter);
	// Get Largest Culprit, which is guaranteed to be an ion w/o mistake
	int Max=iList[0].length(),maxPos=0;
	for(int i=1;i<Counter;i++){if(iList[i].length()>Max){maxPos=i;Max=iList[i].length();}}
	string largest=iList[maxPos];
	// If largest is transition metal, iList will hold a duplicate accounting for other possible oxidation states
	int Counter2=1;
	for(int i=0;i<Counter;i++){if(i!=maxPos && largest.compare(iList[i])==0){Counter2++;}}
	// Check if Largest Culprit is a Transition Metal
	if(Counter2>1)
		{// Largest Culprit is transition metal, reset maxPos to analyze next largest ion
		Max=0;
		for(int i=0;i<Counter;i++)
			{if(iList[i].length()>Max && largest.compare(iList[i])!=0){maxPos=i;Max=iList[i].length();}}
		}
	// Update Output charge valence of first ion
	Output=cList[maxPos]+",";
	// Check for any number(s) following largest ion
	pos=solute.find(largest.c_str(),0);
	bool SEARCHING=true;Counter=0;
	string tmp="";
	char letter;
	while(SEARCHING)
		{letter=solute[pos+largest.length()+Counter];
		if(isdigit(letter)){tmp+=letter;Counter++;}
		else{SEARCHING=false;break;}}
	if(tmp.compare("")==0){multiplier=1;}
	else{multiplier=atoi(tmp.c_str());}
	// Check for preceding and/or finishing parantheses
	int numRepeats=0;
	if(pos-1>=0)
		{letter=solute[pos-1];
		if(strcmp(&letter,"(")==0)
			{// Preceding Parantheses found, find end
			pos2=solute.find(")",pos-1);
			if(pos2==string::npos){cerr<<"Error in Solution::interpretSolute!\nUnbalanced parantheses in solute ("<<solute<<").\n";exit(EXIT_FAILURE);}
			// Acquire Number of Repeats of Unit
			SEARCHING=true;Counter=0;tmp="";
			while(SEARCHING)
				{letter=solute[pos2+1+Counter];
				if(isdigit(letter)){tmp+=letter;Counter++;}
				else{SEARCHING=false;break;}}
			if(tmp.compare("")==0){numRepeats=1;}
			else{numRepeats=atoi(tmp.c_str());}}
		}
	// Update Output Concentration Multiplier
	if(numRepeats==0){Output+=cnvrtNumToStrng(multiplier,0)+",";}
	else if(numRepeats>0){Output+=cnvrtNumToStrng(multiplier*numRepeats,0)+",";}
	else{cerr<<"Error in Solution::interpretSolute!\nBad parantheses in solute ("<<solute<<").\n";exit(EXIT_FAILURE);}
	// Update Output: Ionic Radius (A)
	Output+=rList[maxPos]+",";

	// Assess Parantheses to define remaining ion(s)
	string remainder="";
	int multiplierWidth;
	if(multiplier!=1){multiplierWidth=floor(log10(multiplier))+1;}
	else if(multiplier==1){multiplierWidth=0;}
	if(numRepeats==0)
		{// No Parantheses found, so simply remove largest ion
		if(pos==0)
			{// largestOtherIons
			remainder=solute.substr(largest.length()+multiplierWidth,solute.length()-largest.length());}
		else if(pos+largest.length()==solute.length())
			{// OtherIonslargest
			remainder=solute.substr(0,pos);}
		else{// OtherIonslargestOtherIons
			remainder=solute.substr(0,pos);
			remainder+=solute.substr(pos+largest.length()+multiplierWidth,solute.length()-pos-largest.length());}
		}
	else if(numRepeats==1)
		{// Parantheses found, but w/o a number
		if(pos==1)
			{// (largest)OtherIons
			remainder=solute.substr(largest.length()+2,solute.length()-largest.length()-2);}
		else if(pos+largest.length()==solute.length()-1)
			{// OtherIons(largest)
			remainder=solute.substr(0,pos-1);}
		else
			{// OtherIons(largest)OtherIons
			remainder=solute.substr(0,pos-1);
			remainder+=solute.substr(pos+largest.length()+1,solute.length()-pos-largest.length()-1);}
		}
	else if(numRepeats>1)
		{// Parantheses found, but w/ a number that is Counter long
		if(pos==0)
			{// (largest)?OtherIons, ?=numRepeats
			remainder=solute.substr(largest.length()+2+Counter,solute.length()-largest.length()-Counter-2);}
		else if(pos+largest.length()==solute.length()-1-Counter)
			{// OtherIons(largest)?
			remainder=solute.substr(0,pos-1);}
		else
			{// OtherIons(largest)?OtherIons
			remainder=solute.substr(0,pos-1);
			remainder+=solute.substr(pos+largest.length()+1+Counter,solute.length()-pos-largest.length()-Counter-1);}
		}
	else{cerr<<"Error in Solution::interpretSolute!\nBad solute ("<<solute<<").\n";exit(EXIT_FAILURE);}
	// Now Assess Remainder
	//cout<<remainder<<endl;
	bool ASSESSING=true;
	string remainder2="";
	while(ASSESSING)
		{ionList="";chargeList="";radiusList="";delete [] iList;delete [] cList;delete [] rList;
		// Generate List of Possible Ion(s) contained in solute
		Counter=0;
		for(int i=0;i<numIons;i++)
			{pos=remainder.find(modeledIons[i],0);
			if(pos!=string::npos)
				{// Add to list of culprits
				ionList+=modeledIons[i]+delimiter;Counter++;
				chargeList+=modeledIonsCharge[i]+delimiter;
				radiusList+=modeledIonsRadius[i]+delimiter;}}
		if(ionList.length()==0){cerr<<"Error in Solution::interpretSolute!\nNo ions identified in solute ("<<remainder<<").\n";exit(EXIT_FAILURE);}
		iList=fill_string_array(ionList,Counter,delimiter);
		cList=fill_string_array(chargeList,Counter,delimiter);
		rList=fill_string_array(radiusList,Counter,delimiter);
		// Get Largest Culprit, which is guaranteed to be an ion w/o mistake
		Max=iList[0].length(),maxPos=0;
		for(int i=1;i<Counter;i++){if(iList[i].length()>Max){maxPos=i;Max=iList[i].length();}}
		largest=iList[maxPos];
		// Update Output charge valence of first ion
		Output+=cList[maxPos]+",";
		// Check for any number(s) following largest ion
		pos=remainder.find(largest.c_str(),0);
		SEARCHING=true;Counter=0;tmp="";
		while(SEARCHING)
			{letter=remainder[pos+largest.length()+Counter];
			if(isdigit(letter)){tmp+=letter;Counter++;}
			else{SEARCHING=false;break;}}
		if(tmp.compare("")==0){multiplier=1;}
		else{multiplier=atoi(tmp.c_str());}
		// Check for preceding and/or finishing parantheses
		numRepeats=0;
		if(pos-1>=0)
			{letter=remainder[pos-1];
			if(strcmp(&letter,"(")==0)
				{// Preceding Parantheses found, find end
				pos2=remainder.find(")",pos-1);
				if(pos2==string::npos){cerr<<"Error in Solution::interpretSolute!\nUnbalanced parantheses in solute ("<<remainder<<").\n";exit(EXIT_FAILURE);}
				// Acquire Number of Repeats of Unit
				SEARCHING=true;Counter=0;tmp="";
				while(SEARCHING)
					{letter=remainder[pos2+1+Counter];
					if(isdigit(letter)){tmp+=letter;Counter++;}
					else{SEARCHING=false;break;}}
				if(tmp.compare("")==0){numRepeats=1;}
				else{numRepeats=atoi(tmp.c_str());}}
			}
		// Update Output Concentration Multiplier
		if(numRepeats==0){Output+=cnvrtNumToStrng(multiplier,0)+",";}
		else if(numRepeats>0){Output+=cnvrtNumToStrng(multiplier*numRepeats,0)+",";}
		else{cerr<<"Error in Solution::interpretSolute!\nBad parantheses in solute ("<<remainder<<").\n";exit(EXIT_FAILURE);}
		// Update Output: Ionic Radius (A)
		Output+=rList[maxPos]+",";
		//cout<<Output<<endl;
		// Assess Parantheses to define remaining ion(s)
		remainder2="";
		if(multiplier!=1){multiplierWidth=floor(log10(multiplier))+1;}
		else if(multiplier==1){multiplierWidth=0;}
		if(numRepeats==0)
			{// No Parantheses found, so simply remove largest ion
			if(pos==0)
				{// largestOtherIons
				remainder2=remainder.substr(largest.length()+multiplierWidth,remainder.length()-largest.length());}
			else if(pos+largest.length()==remainder.length())
				{// OtherIonslargest
				remainder2=remainder.substr(0,pos);}
			else{// OtherIonslargestOtherIons
				remainder2=remainder.substr(0,pos);
				remainder2+=remainder.substr(pos+largest.length()+multiplierWidth,remainder.length()-pos-largest.length());}
			}
		else if(numRepeats==1)
			{// Parantheses found, but w/o a number
			if(pos==1)
				{// (largest)OtherIons
				remainder2=remainder.substr(largest.length()+2,remainder.length()-largest.length()-2);}
			else if(pos+largest.length()==remainder.length()-1)
				{// OtherIons(largest)
				remainder2=remainder.substr(0,pos-1);}
			else
				{// OtherIons(largest)OtherIons
				remainder2=remainder.substr(0,pos-1);
				remainder2+=remainder.substr(pos+largest.length()+1,remainder.length()-pos-largest.length()-1);}
			}
		else if(numRepeats>1)
			{// Parantheses found, but w/ a number that is Counter long
			if(pos==0)
				{// (largest)?OtherIons, ?=numRepeats
				remainder2=remainder.substr(largest.length()+2+Counter,remainder.length()-largest.length()-Counter-2);}
			else if(pos+largest.length()==remainder.length()-1-Counter)
				{// OtherIons(largest)?
				remainder2=remainder.substr(0,pos-1);}
			else
				{// OtherIons(largest)?OtherIons
				remainder2=remainder.substr(0,pos-1);
				remainder2+=remainder.substr(pos+largest.length()+1+Counter,remainder.length()-pos-largest.length()-Counter-1);}
			}
		else{cerr<<"Error in Solution::interpretSolute!\nBad solute ("<<remainder<<").\n";exit(EXIT_FAILURE);}
		// Exit Loop when no more ions remain
		if(remainder2.compare("")==0){ASSESSING=false;break;}
		else{remainder=remainder2;}
		}
	return Output;}

string Solution::getIonData(string soluteConc,string soluteName,string delimiter)
	{int numSolutes=count_delimiter(soluteName,delimiter);
	int ErrChck=count_delimiter(soluteConc,delimiter);
	if(numSolutes!=ErrChck)
		{cerr<<"Error in Solution::getIonData\nNumber of solutes ("<<soluteName<<") does not match number of salt concentrations ("<<soluteConc<<")"<<endl;exit(EXIT_FAILURE);}
	// IonData Format: charge_valence,molar_concentration,radius_(A),
	int pos,multiplier,nIons;
	string Salt="",Conc="",ionString="",Output="",tmp="";
	double iC,ionSzCompare=0,test;
	for(int i=0;i<numSolutes;i++)
		{// Get Salt Component
		if(i==0)
			{// Acquire First Salt			
			Salt=soluteName.substr(0,soluteName.find(delimiter,0));
			// Acquire First Salt Concentration
			tmp=soluteConc.substr(0,soluteConc.find(delimiter,0));
			Conc=formatNumberString(tmp);}
		else{// Acquire Other Salts
			pos=0;
			for(int j=0;j<i;j++){pos=soluteName.find(delimiter,pos+1);}
			Salt=soluteName.substr(pos+1,soluteName.find(delimiter,pos+1)-pos-1);
			// Acquire Other Salt Concentration
			pos=0;
			for(int j=0;j<i;j++){pos=soluteConc.find(delimiter,pos+1);}
			tmp=soluteConc.substr(pos+1,soluteConc.find(delimiter,pos+1)-pos-1);
			Conc=formatNumberString(tmp);}

		// Generate Ion String for Salt
		ionString=interpretSolute(Salt);		
		nIons=countDelimiter(ionString,",");
		nIons/=3;pos=0;
		// Multiply Concentration Multiplier by Molar Concentration
		for(int j=0;j<nIons;j++)
			{if(j==0){pos=ionString.find(",",pos+1);}
			else{for(int k=0;k<3;k++){pos=ionString.find(",",pos+1);}}
			tmp=ionString.substr(pos+1,ionString.find(",",pos+1)-pos-1);
			multiplier=atoi(tmp.c_str());
			iC=strtod(Conc.c_str(),NULL);
			iC*=multiplier;
			ionString.replace(pos+1,tmp.length(),formatNumberString(cnvrtNumToStrng(iC,BUFFER_SIZE)));}
		Output+=ionString;}
	//largestIon=cnvrtNumToStrng(ionSzCompare,DISTANCE_SIG_FIGS);	// Keep Ion Radius with 2 significant digits
	return Output;}

double Solution::calcDebyeLength(double T)
	{// Count Number of Entries
	int nIon=count_delimiter(ionData,",");
	if(nIon%3!=0){cerr<<"ERROR in calcDebyeLength!!!\nIncorrect ion data input!"<<endl;exit(EXIT_FAILURE);}
	// Extract Data
	string *All=fill_string_array(ionData,nIon,",");
	// Number of Ions
	nIon/=3;
	int *ion_val=new int[nIon];
	double *ion_conc=new double[nIon];
	// Extract Information from Ion Data
	int Counter=0;
	for(int i=0;i<3*nIon;i++)
		{if(i%3==0 && i!=0){Counter++;}
		switch(i%3)
			{case 0:
				ion_val[Counter]=atoi(All[i].c_str());
				break;
			case 1:
				ion_conc[Counter]=strtod(All[i].c_str(),NULL);
				break;
			case 2:
				//ion_rad[Counter]=strtod(All[i].c_str(),NULL);
				break;
			default:
				cerr<<"How is this even possible!"<<endl;}}
	// Calculate Solution Properties
	for(int i=0;i<nIon;i++){ion_conc[i]*=1e3;} // Convert from [mol/L] to [mol/meter^3] (or equivalently millimolar)
	double ionic_strength=0;
	for(int i=0;i<nIon;i++){ionic_strength+=ion_conc[i]*ion_val[i]*ion_val[i];}
	ionic_strength/=2;
	double trm1=dielectric*eo*kb*T;
	double trm2=2*ec*ec*Na*ionic_strength;
	double debyeLength=sqrt(trm1/trm2);
	// Clear Dynamically Allocated Memory
	delete [] All; delete [] ion_val; delete [] ion_conc;
	// Convert to Angstroms
	debyeLength*=1e10;
	return debyeLength;}

void* runMSMS(msmsInput& In,string calcNum)
	{string sphereInFile=In.pdb_msmsFldr+In.PDB+"_"+calcNum+".xyzrn";
	string triSurfOutFile=In.pdb_msmsFldr+In.PDB+"_"+calcNum+"_surface";
	string areaFile=In.pdb_msmsFldr+In.PDB+"_"+calcNum+"_area";
	string outputFile=In.pdb_surfFldr+"fromMSMS/msmsOutput_SR"+In.probeRadius+"_"+calcNum+".txt";
	// Programs must be executed in MSMS Computation Folder
	//chdir(In.msmsFldr.c_str());
	long Res;
	// Run PDB_TO_XYZRN
	string cmd="./"+In.PDB_TO_XYZRN+" "+checkFilePathParantheses(In.pdbFile)+" > "+checkFilePathParantheses(sphereInFile);
	bool ATTEMPTING=true;
	int statusCode;	
	while(ATTEMPTING)
		{Res=syscall(SYS_chdir,In.pdb_msmsFldr.c_str());
		statusCode=system(cmd.c_str());
		if(Res==0 && statusCode==0){break;ATTEMPTING=false;}}
	// Run MSMS
	//cmd="./"+checkFilePathParantheses(In.MSMS)+" -if "+checkFilePathParantheses(sphereInFile)+" -of "+checkFilePathParantheses(triSurfOutFile)+" -af "+checkFilePathParantheses(areaFile)+" -probe_radius "+In.probeRadius+" -density "+In.surfPointDensity+" -hdensity "+In.surfPointHiDensity+" -no_header > "+checkFilePathParantheses(outputFile);
	//cmd="msms -if "+checkFilePathParantheses(sphereInFile)+" -of "+checkFilePathParantheses(triSurfOutFile)+" -af "+checkFilePathParantheses(areaFile)+" -probe_radius "+In.probeRadius+" -density "+In.surfPointDensity+" -hdensity "+In.surfPointHiDensity+" -no_header > "+checkFilePathParantheses(outputFile);
	cmd="msms -if "+sphereInFile+" -of "+triSurfOutFile+" -af "+areaFile+" -probe_radius "+In.probeRadius+" -density "+In.surfPointDensity+" -hdensity "+In.surfPointHiDensity+" -no_header > "+outputFile;
	ATTEMPTING=true;
	int Err;
	char errMsg[256];

	while(ATTEMPTING)
		{try
			{Res=syscall(SYS_chdir,In.pdb_msmsFldr.c_str());
			statusCode=system(cmd.c_str());
			throw statusCode;
			}
		//catch(exception& Exc)
		catch(int Exc)
			{//cerr<<Exc.what()<<endl;
			//cerr<<"Exception occurred.\n"<<Exc<<endl;
			if(Exc==35584)
				{//cerr<<"HERE"<<endl;
				In.SUCCESS=false;
				return 0;
				//exit(EXIT_FAILURE);
				}
			}
		//cerr<<statusCode<<endl;
		if(Res==0 && statusCode==0)
			{In.SUCCESS=true;
			break;
			ATTEMPTING=false;}
		else if(statusCode==32512)
			{cmd="msms -if "+checkFilePathParantheses(sphereInFile)+" -of "+checkFilePathParantheses(triSurfOutFile)+" -af "+checkFilePathParantheses(areaFile)+" -probe_radius "+In.probeRadius+" -density "+In.surfPointDensity+" -hdensity "+In.surfPointHiDensity+" -no_header > "+checkFilePathParantheses(outputFile);}
		else if(statusCode==35584)
			{// Terminate Thread
			//cerr<<"Terminating Calculation Number "<<calcNum<<"...\n";
			//terminate();
			//exit(EXIT_FAILURE);
			//~thread();
			//return 0;
			}
		else if(statusCode!=0 && statusCode!=32512 && statusCode!=256)
			{// An Error has occured, capture error number with erno
			// 35584 = segmentation fault
			// 256 = file in use
			Err=errno;//erase_display();
			cerr<<"ERROR in runMSMS!\nStatus Code: "<<statusCode<<"\nError Number: "<<Err<<"\n"<<strerror_r(Err,errMsg,256)<<"\n";
			exit(EXIT_FAILURE);}}

/*
	int PID=fork(),status;
	if(PID==0)
		{// Run in Child Process, next time fork is executed it gives child process PID
		Res=syscall(SYS_chdir,In.pdb_msmsFldr.c_str());
		statusCode=system(cmd.c_str());
		exit(EXIT_SUCCESS);}
	else if(PID>0)
		{// Return to parent processs, fork should hold child process PID
		waitpid(PID,&status,0);}
	else if(PID==-1)
		{// fork() failed
		cerr<<"Fork failed.\n";exit(EXIT_FAILURE);}
	else{// Unpredicted Output
		cerr<<"Output of fork() unpredicted:\n"<<PID<<endl;}
*/

	// Move Files to Appropriate Folders
	// Face File
	string oldF=In.pdb_msmsFldr+In.PDB+"_"+calcNum+"_surface.face";
	string newF=In.pdb_surfFldr+"fromMSMS/SR"+In.probeRadius+"_"+calcNum+".face";
	ATTEMPTING=true;
	while(ATTEMPTING)
		{Res=syscall(SYS_rename,oldF.c_str(),newF.c_str());
		if(Res==0){break;ATTEMPTING=false;}}
	// Vertices File
	//pdb_surfFldr+"fromMSMS/SR0.00"+"_"+calcNum+".vert";
	oldF=In.pdb_msmsFldr+In.PDB+"_"+calcNum+"_surface.vert";
	newF=In.pdb_surfFldr+"fromMSMS/SR"+In.probeRadius+"_"+calcNum+".vert";
	ATTEMPTING=true;
	while(ATTEMPTING)
		{Res=syscall(SYS_rename,oldF.c_str(),newF.c_str());
		if(Res==0){break;ATTEMPTING=false;}}
	// Surface Area File
	oldF=In.pdb_msmsFldr+In.PDB+"_"+calcNum+"_area.area";
	newF=In.pdb_surfFldr+"fromMSMS/SR"+In.probeRadius+"_"+calcNum+".area";
	ATTEMPTING=true;
	while(ATTEMPTING)
		{Res=syscall(SYS_rename,oldF.c_str(),newF.c_str());
		if(Res==0){break;ATTEMPTING=false;}}
	}

void readMSMSVertFile(string fileName,vertData& Data)
	{int Num=countNumLinesMSMSVertFile(fileName);

	Data.x=new double[Num];
	Data.y=new double[Num];
	Data.z=new double[Num];
	Data.nx=new double[Num];
	Data.ny=new double[Num];
	Data.nz=new double[Num];
	Data.analyticSurf=new int[Num];
	Data.sphereNum=new int[Num];
	Data.vertType=new int[Num];
	Data.closestAtom=new string[Num];
	Data.numVertices=Num;

	float x,y,z,nx,ny,nz;
	int analyticSurf,sphereNum,vertType,Counter=0;
	char closestAtom[15000];
	//string msms_vertices_file_format="%9.3f %9.3f %9.3f %9.3f %9.3f %9.3f %7d %7d %2d %s";	
	string msms_vertices_file_format="%f %f %f %f %f %f %d %d %d %s";

	FILE *fIn;
    fIn=fopen(fileName.c_str(),"r");
    if(fIn==NULL)
        {cerr<<"ERROR in readMSMSVertFile!\nInput Vertices File could not be found.\n\nFilepath:\t"<<fileName<<endl;exit(EXIT_FAILURE);}

	fseek(fIn,0,SEEK_END);
	long fileSize=ftell(fIn);
	rewind(fIn);	

	int lineSz;
	while(!feof(fIn))
        {fscanf(fIn,msms_vertices_file_format.c_str(),&x,&y,&z,&nx,&ny,&nz,&analyticSurf,&sphereNum,&vertType,&closestAtom);		
		lineSz=ftell(fIn);
		if(lineSz==fileSize){break;}
         else
            {Data.x[Counter]=x;
			Data.y[Counter]=y;
			Data.z[Counter]=z;
			Data.nx[Counter]=nx;
			Data.ny[Counter]=ny;
			Data.nz[Counter]=nz;
			Data.analyticSurf[Counter]=analyticSurf;
			Data.sphereNum[Counter]=sphereNum;
			Data.vertType[Counter]=vertType;
			Data.closestAtom[Counter]=closestAtom;
			Counter++;}}
	fclose(fIn);}

void writeHydroproInput(string calcType,string density,string molecularWeight,string proteinName,string oFile,string PDB,double specificVolume,double temperature,double viscosity)
	{string elementRadius,Output;
	ofstream fOut;
	fOut.open(oFile.c_str());
	if(fOut.fail()){cerr<<"ERROR in writeHydroproInput!!!\nFile could not be opened.\n"<<oFile<<endl;exit(EXIT_FAILURE);}
	Output=proteinName+"\t!Name of molecule\n";
	Output+=PDB+"\t\t\t\t!Name for output file\n";
	Output+=PDB+".pdb\t\t\t!Structural (PDB) file\n";
	if(calcType=="1"){elementRadius="2.9";}
	else if(calcType=="2"){elementRadius="4.8";}
	else if(calcType=="4"){elementRadius="6.1";}
	else{cerr<<"ERROR in writeHydroproInput!!!\nCalculation Type not recognized. Must be 1, 2 or 4."<<endl;exit(EXIT_FAILURE);}
	Output+=calcType+"\t\t\t\t\t!Type of calculation\n";
	Output+=elementRadius+",\t\t\t\t!AER, radius of primary elements\n";
	Output+="6,\t\t\t\t\t!NSIG\n";
	Output+="1.0,\t\t\t\t!Minimum radius of beads in the shell (SIGMIN)\n";
	Output+="2.0,\t\t\t\t!Maximum radius of beads in the shell (SIGMAX)\n";
	temperature-=273.15;	// Convert from Kelvin to Centigrade
	//Output+=cnvrtNumToStrng(temperature,2)+".,\t\t\t\t!T (temperature, centigrade)\n";
	Output+=formatNumberString(cnvrtNumToStrng(temperature,BUFFER_SIZE))+",\t\t\t\t!T (temperature, centigrade)\n";
	viscosity*=10;	// Convert from Pa s to poise	
	Output+=formatNumberString(cnvrtNumToStrng(viscosity,BUFFER_SIZE))+",\t\t!ETA (Viscosity of the solvent in poises)\n";
	Output+=molecularWeight+",\t\t\t!RM (Molecular weight)\n";
	specificVolume*=1000;	// Convert from L/g to mL/g
	Output+=formatNumberString(cnvrtNumToStrng(specificVolume,BUFFER_SIZE))+",\t\t\t!Partial specific volume, cm3/g\n";
	Output+=density+",\t\t!Solvent density, g/cm3\n";
	Output+="-1\t\t\t\t\t!Number of values of Q\n";
	Output+="-1\t\t\t\t\t!Number of intervals\n";
	Output+="0,\t\t\t\t\t!Number of trials for MC calculation of covolume\n";
	Output+="1\t\t\t\t\t!IDIF=1 (yes) for full diffusion tensors\n";
	Output+="*\t\t\t\t\t!End of file\n";
	fOut<<Output;
	fOut.close();}

void runHYDROPRO(string PDB,string pdb_hydroFldr,string inFile,string logFile,string calcNum)
	{// Define PDB File for Hydrodynamics Calculation
	string pdbFile=pdb_hydroFldr+PDB+"_"+calcNum+".pdb";
	// Generate Temporary Executable
	string tempXFile=pdb_hydroFldr+"hydropro10-lnx"+calcNum+".exe";
	char first[tempXFile.length()];
	for(int i=0;i<tempXFile.length();i++){first[i]=tempXFile[i];}
	char second[inFile.length()];
	for(int i=0;i<inFile.length();i++){second[i]=inFile[i];}
	char third[pdbFile.length()];
	for(int i=0;i<pdbFile.length();i++){third[i]=pdbFile[i];}
	char* argv[]={first,second,third,NULL};
	char* envp[]={NULL};
	bool ATTEMPTING=true;
	long Res,Res2;
	freopen(logFile.c_str(),"a",stdout);
	while(ATTEMPTING)
		{Res=syscall(SYS_chdir,pdb_hydroFldr.c_str());
		Res2=syscall(SYS_execve,tempXFile.c_str(),argv,envp);		
		if(Res==0 && Res2==0){break;ATTEMPTING=false;}}
	exit(3);}

double getDiffusivity(string hydroproFile)
	{ifstream fIn;
	fIn.open(hydroproFile.c_str());
	if(fIn.fail())
		{cerr<<"ERROR in getDiffusivity\nHYDROPRO output file could not be opened.\n"<<hydroproFile<<endl;
		 exit(EXIT_FAILURE);}
	// Copy Input File
	int Counter=0,Sz=15000;                      // overshoot actual line size, C++ automatically fixes c-string lengths
	char Val[Sz];
	string tmp,tmp1;
	// Skip HYDROPRO Header (7 lines)
	// Skip HYDROPRO data until translational diffusivity (cm^2/s)
	for(int i=0;i<25;i++){fIn.getline(Val,Sz);}
	tmp=Val;
	tmp1=tmp.substr(tmp.length()-16,9);
	double diffusivity=strtod(tmp1.c_str(),NULL);
	diffusivity/=10000;	// Convert from cm^2/s to m^2/s
	fIn.close();
	return diffusivity;}

double getDiffusivity_hullrad(string hullradFile)
	{ifstream fIn;
	fIn.open(hullradFile.c_str());
	if(fIn.fail())
		{cerr<<"ERROR in getDiffusivity_hullrad\nHullrad output file could not be opened.\n"<<hullradFile<<endl;
		 exit(EXIT_FAILURE);}
	// Copy Input File
	int Counter=0,Sz=15000;                      // overshoot actual line size, C++ automatically fixes c-string lengths
	char Val[Sz];
	string tmp,tmp1;
	// Skip 8 lines
	for(int i=0;i<9;i++){fIn.getline(Val,Sz);}
	// Acquire translational diffusivity (cm^2/s)
	tmp=Val;
	int pos=tmp.find(":",0);
	tmp1=tmp.substr(pos+1,tmp.find("cm^2/s",0)-pos-1);
	double diffusivity=strtod(tmp1.c_str(),NULL);
	diffusivity/=10000;	// Convert from cm^2/s to m^2/s
	fIn.close();
	return diffusivity;}

void runPROPKA_PDB2PQR(string pdbFile,string pqrFile,string calcNum,string forceField,string pdb_pqrFldr,string propkaOutFile,string pH,string PDB2PQR,string logFile)
	{string cmd="python "+checkFilePathParantheses(PDB2PQR)+" --ff="+forceField+" --with-ph="+pH+" --whitespace -v "+checkFilePathParantheses(pdbFile)+" "+checkFilePathParantheses(pqrFile);
	bool ATTEMPTING=true;
	int statusCode;
	freopen(logFile.c_str(),"a",stdout);
	while(ATTEMPTING)
		{statusCode=system(cmd.c_str());
		if(statusCode==0){break;ATTEMPTING=false;}}
	// Move PROPKA Output File to Appropriate Folder
	string oldF=pdb_pqrFldr+"pH"+pH+"_"+calcNum+".propka";
	long Res=syscall(SYS_rename,oldF.c_str(),propkaOutFile.c_str());}

void runAPBS(string exeFile,string inFile,string logFile)
	{// Define Input Arguments
	char first[exeFile.length()+1];
	for(int i=0;i<exeFile.length();i++){first[i]=exeFile[i];}
	char second[inFile.length()+1];
	for(int i=0;i<inFile.length();i++){second[i]=inFile[i];} 
	int df=0,charLen=strlen(second),strLen=inFile.length();
	if(charLen>strLen)
		{df=charLen-strLen;
		second[charLen-df]=0;}
	char* argv[]={first,second,NULL};
	char* envp[]={NULL};
	long Res;
	bool ATTEMPTING=true;
	freopen(logFile.c_str(),"a",stdout);
	while(ATTEMPTING)
		{Res=syscall(SYS_execve,exeFile.c_str(),argv,envp);
		if(Res==0){break;ATTEMPTING=false;}}
	exit(EXIT_SUCCESS);}

int countNumLines(string file)
    {ifstream fIn;
     fIn.open(file.c_str());
     int Sz=200;
     char Val[Sz];
     if(fIn.fail()){cerr<<"ERROR in countNumLines!\nPDB input file could not be opened.\n"<<file<<endl;exit(EXIT_FAILURE);}
     fIn.getline(Val,Sz);
     string chainLabel;
     string bld;
     int Count=0,bCount=0,cCount=0;
     int col1=6,col2=5+col1,col3=4+col2,col4=5+col3,col5=2+col4,col6=4+col5,col7=12+col6,col8=8+col7,col9=8+col8,col10=6+col9,col11=6+col10,col12=12+col11,col13=2+col12;
     while(!fIn.eof())
        {bld="";
         for(int i=0;i<col1;i++)
            {if(isalpha(Val[i]))
                {bld=bld+Val[i];}}
         if(bld=="ATOM")
            {Count++;}
         else if(bld=="HETATM")
            {Count++;}
         else if(bld=="TER")
            {Count++;}
         fIn.getline(Val,Sz);}
    // Account for counting of end
    //Count--;
    fIn.close();
    return Count;}

void definePDBData(pdbData& Data,int Sz)
    {string* recordType=new string[Sz];
     int* atomNum=new int[Sz];
     string* atomLabel=new string[Sz];
     string* residue=new string[Sz];
     string* chainLabel=new string[Sz];
     int* atmChnNum=new int[Sz];
     double* x=new double[Sz];
     double* y=new double[Sz];
     double* z=new double[Sz];
     double* atmOccupancy=new double[Sz];
     double* bFactor=new double[Sz];
     string* terminus=new string[Sz];

     Data.recordType=recordType;
     Data.atomNum=atomNum;
     Data.atomLabel=atomLabel;
     Data.residue=residue;
     Data.chainLabel=chainLabel;
     Data.atmChainNum=atmChnNum;
     Data.x=x;
     Data.y=y;
     Data.z=z;
     Data.atmOccupancy=atmOccupancy;
     Data.bFactor=bFactor;
     Data.terminus=terminus;}

void readPDBFile(string file,pdbData& Data)
    {ifstream fIn;
     fIn.open(file.c_str());
     if(fIn.fail())
        {cerr<<"ERROR in readPDBFile of ioProt!!!\n PDB file could not be opened.\n"<<file<<endl;
         exit(EXIT_FAILURE);}
     // Copy Input File
    int Counter=0,Sz=15000;                      // overshoot actual line size, C++ automatically fixes c-string lengths
    char Val[Sz];
    fIn.getline(Val,Sz);
    string recordType,atomNumber,atomLabel,residue,chainLabel,atmChainNumber,xPos,yPos,zPos,atomOccupancy,bFactor,terminus;
    int col1=6,col2=5+col1,col3=5+col2,col4=5+col3,col5=2+col4,col6=4+col5,col7=12+col6,col8=8+col7,col9=8+col8,col10=6+col9,col11=6+col10,col12=12+col11,col13=2+col12;
    while(!fIn.eof())
        {recordType="",atomNumber="",atomLabel="",residue="",chainLabel="",atmChainNumber="",xPos="",yPos="",zPos="",atomOccupancy="",bFactor="",terminus="";
         // Read First Column
         for(int i=0;i<col1;i++)
            {if(isalpha(Val[i]))
                {recordType=recordType+Val[i];}}
         if(recordType=="ATOM"||recordType=="HETATM"||recordType=="TER")
		 //if(recordType=="ATOM"||recordType=="HETATM")
            {// Read Second Column
             for(int i=col1;i<col2;i++)
                {if(Val[i]!=' ')
                    {atomNumber=atomNumber+Val[i];}}
             // Read Third Column
             for(int i=col2;i<col3;i++)
                {if(Val[i]!=' ')
                    {atomLabel=atomLabel+Val[i];}}
             // Read Fourth Column
             for(int i=col3;i<col4;i++)
                {if(Val[i]!=' ')
                    {residue=residue+Val[i];}}
             // Read Fifth Column
             for(int i=col4;i<col5;i++)
                {if(Val[i]!=' ')
                    {chainLabel=chainLabel+Val[i];}}
             // Read Sixth Column
             for(int i=col5;i<col6;i++)
                {if(Val[i]!=' ')
                    {atmChainNumber=atmChainNumber+Val[i];}}
             // Read Seventh Column
             for(int i=col6;i<col7;i++)
                {if(Val[i]!=' ')
                    {xPos=xPos+Val[i];}}
             // Read Eighth Column
             for(int i=col7;i<col8;i++)
                {if(Val[i]!=' ')
                    {yPos=yPos+Val[i];}}
             // Read Ninth Column
             for(int i=col8;i<col9;i++)
                {if(Val[i]!=' ')
                    {zPos=zPos+Val[i];}}
             // Read Tenth Column
             for(int i=col9;i<col10;i++)
                {if(Val[i]!=' ')
                    {atomOccupancy=atomOccupancy+Val[i];}}
             // Read Eleventh Column
             for(int i=col10;i<col11;i++)
                {if(Val[i]!=' ')
                    {bFactor=bFactor+Val[i];}}
             // Read Twelveth Column
             for(int i=col11;i<col12;i++)
                {if(Val[i]!=' ')
                    {terminus=terminus+Val[i];}}
             Data.recordType[Counter]=recordType;
             Data.atomNum[Counter]=atoi(atomNumber.c_str());
             Data.atomLabel[Counter]=atomLabel;
             Data.residue[Counter]=residue;
             Data.chainLabel[Counter]=chainLabel;
             Data.atmChainNum[Counter]=atoi(atmChainNumber.c_str());
             Data.x[Counter]=atof(xPos.c_str());
             Data.y[Counter]=atof(yPos.c_str());
             Data.z[Counter]=atof(zPos.c_str());
             Data.atmOccupancy[Counter]=atof(atomOccupancy.c_str());
             Data.bFactor[Counter]=atof(bFactor.c_str());
             Data.terminus[Counter]=terminus;
             Counter++;}
         fIn.getline(Val,Sz);}
         fIn.close();}

double getSpecificVolume(string msmsOutputFile,double molecularWeight)
	{ifstream fIn;
	fIn.open(msmsOutputFile.c_str());
     if(fIn.fail())
        {cerr<<"ERROR in read_hydropro_output_diffusivity!!!\nHYDROPRO output file could not be opened.\n"<<msmsOutputFile<<endl;
         exit(EXIT_FAILURE);}

	// Copy Input File
	int Counter=1,Sz=15000;                      // overshoot actual line size, C++ automatically fixes c-string lengths
	char Val[Sz];
	string tmp,tmp1;
	// Find Line Containing Volume
	string term="    Comp. probe_radius SES_volume SES_area)";
	bool RUNNING=true;
	while(RUNNING)
		{fIn.getline(Val,Sz);
		tmp=Val;
		if(tmp==term){RUNNING=false;}}
	// Capture line containing volume
	fIn.getline(Val,Sz);
	tmp=Val;
	// Find Space between volume and surfaec area
	RUNNING=true;
	while(RUNNING)
		{tmp1=tmp.substr(tmp.length()-Counter,1);
		if(tmp1==" "){RUNNING=false;}
		else{Counter++;}}
	// Find volume value
	RUNNING=true;
	while(RUNNING)
		{tmp1=tmp.substr(tmp.length()-Counter,1);
		if(tmp1!=" ")
			{RUNNING=false;}
		else
			{Counter++;}}
	// Record Volume
	string bld="";
	RUNNING=true;
	while(RUNNING)
		{tmp1=tmp.substr(tmp.length()-Counter,1);
		bld+=tmp1;
		if(tmp1==" ")
			{RUNNING=false;}
		else
			{Counter++;}}
	tmp="";
	for(int i=bld.length()-2;i>-1;i--)
		{tmp+=bld.substr(i,1);}	
	fIn.close();
	double Volume=strtod(tmp.c_str(),NULL);
	Volume/=1e27;	// Convert from A^3 to L
	double Mass=molecularWeight/Na;	// Determine mass in grams
	double specificVolume=Volume/Mass;	
	return specificVolume;}

Vec calc_center_of_mass(pdbData Data,int Sz)
    {Vec value;
	double xVal=0,yVal=0,zVal=0;
    for(int i=0;i<Sz;i++)
        {xVal+=Data.x[i];
         yVal+=Data.y[i];
         zVal+=Data.z[i];}
    xVal/=Sz;
    yVal/=Sz;
    zVal/=Sz;
    value.x=xVal;
    value.y=yVal;
    value.z=zVal;
	return value;}

double calc_distance(Vec Vec1,Vec Vec2)
    {return sqrt((Vec2.x-Vec1.x)*(Vec2.x-Vec1.x)+(Vec2.y-Vec1.y)*(Vec2.y-Vec1.y)+(Vec2.z-Vec1.z)*(Vec2.z-Vec1.z));}

double calc_protein_radius(vertData Data,int Sz,Vec centerCoord)
    {Vec pos;
	double Radius=0;
	for(int i=0;i<Sz;i++)
		{pos.x=Data.x[i];
		pos.y=Data.y[i];
		pos.z=Data.z[i];
		Radius+=calc_distance(pos,centerCoord);}
	Radius/=Sz;
	return Radius;}

double calc_protein_radius_std(vertData Data,int Sz,Vec centerCoord,double Radius)
     {double radStd=0,dst=0;
	Vec pos;
	for(int i=0;i<Sz;i++)
		{pos.x=Data.x[i];
		pos.y=Data.y[i];
		pos.z=Data.z[i];
		dst=calc_distance(pos,centerCoord);
		radStd+=(dst-Radius)*(dst-Radius);}
	return sqrt(radStd/(Sz-1));}

double calcProteinMolecularWeight(string pdbFile)
	{double Output=0;
	pdbData Data;
	int numLines=countNumLines(pdbFile);
	definePDBData(Data,numLines);
	readPDBFile(pdbFile,Data);
	string numAtomList="",atomList="",atomNm="",rpt="",branch="",delimiter=";",tmp,atm;
	char letter,second_letter;
	bool PASS,SEARCHING;
	string *Atom;
	int *numAtom;
	int pos,aCount=0,multiplier,Counter,numRepeats,i;

	for(int a=0;a<numLines;a++)
		{atm=Data.atomLabel[a];		
		// Get Atom Name
		PASS=false;atomNm="";multiplier=1;i=0;
		letter=atm[i];
		if(isupper(letter))
			{atomNm=letter;
			// Check if second letter completes atom name or gives number of atoms
			if(i+1<=atm.length()-1)
				{second_letter=atm[i+1];
				if(islower(second_letter)){atomNm+=second_letter;}}
			// Check if number behind Atom Name
			if(i+atomNm.length()<=atm.length()-1)
				{SEARCHING=true;Counter=0;tmp="";
				while(SEARCHING)
					{letter=atm[i+atomNm.length()+Counter];
					if(isdigit(letter)){tmp+=letter;Counter++;}
					else{SEARCHING=false;break;}}
				if(tmp.compare("")==0){multiplier=1;}
				else{multiplier=atoi(tmp.c_str());}
				i+=Counter;}			
			// Check is atom is already in Atom List, if not add
			if(atomList.compare("")==0)
				{// Initialize Atoms Present Lists
				atomList=atomNm+delimiter;
				numAtomList=cnvrtNumToStrng(multiplier,0)+delimiter;
				aCount++;
				Atom=fill_string_array(atomList,aCount,delimiter);
				numAtom=fill_int_array(numAtomList,aCount,delimiter);}
			else{// Check is atom is already in Atom List, if not add
				PASS=false;
				for(pos=0;pos<aCount;pos++){tmp=Atom[pos];if(tmp.compare(atomNm)==0){PASS=true;break;}}
				if(!PASS)
					{// Atom not found in list, so add
					atomList+=atomNm+delimiter;
					numAtomList+=cnvrtNumToStrng(multiplier,0)+delimiter;
					delete [] Atom;delete [] numAtom;
					aCount++;
					Atom=fill_string_array(atomList,aCount,delimiter);
					numAtom=fill_int_array(numAtomList,aCount,delimiter);}
				else{// Atom Found, so update numAtomList
					numAtom[pos]=numAtom[pos]+multiplier;
					numAtomList=array2String(numAtom,aCount,delimiter);}}
			}
		}
	Solution S;
	for(int i=0;i<aCount;i++)
		{// Identify Atom
		tmp=Atom[i];
		for(pos=0;pos<S.numElements;pos++){if(tmp.compare(S.atomicSymbol[pos])==0){break;}}
		// Get Atomic Molecular Weight
		Output+=S.atomicMolecularWeight[pos]*numAtom[i];}
	return Output;}

void inFileEditer(string* writeTypes,int N,string pdie,strVec dim,string pqrFile,string apbsInputgen,string ionData,string temperature,string largestIon,string er,string fldrExt)
	{// APBS IN File Parameters
	//int NumProcessors=12;
	//int NumMem=11700;
	string memMax="1024"; //11700/12
	string cfac="5";
	string fadd="80";	//80
	string Frmt="dx";
	string method="auto";
	// psize.py inputs
	string flags="--cfac="+cfac;
	flags+=" --fadd="+fadd;
	flags+=" --gmemceil="+memMax;
	flags+=" --method="+method;
	// APBS inputs
	flags+=" --pdie="+pdie;
	flags+=" --Frmt="+Frmt;
	flags+=" --istrng=1";
	flags+=" --dime-x="+dim.x;
	flags+=" --dime-y="+dim.y;
	flags+=" --dime-z="+dim.z;
	flags+=" --unfrmGrdSpcng";
	// APBS Flag write types
	string wt="";
	for(int i=0;i<N;i++)
		{wt=writeTypes[i];
		if(wt.compare("atompot")==0){flags+=" --atompot";}
		else if(wt.compare("charge")==0){flags+=" --charge";}
		else if(wt.compare("dielx")==0){flags+=" --dielx";}
		else if(wt.compare("diely")==0){flags+=" --diely";}
		else if(wt.compare("dielz")==0){flags+=" --dielz";}
		else if(wt.compare("edens")==0){flags+=" --edens";}		
		else if(wt.compare("ivdw")==0){flags+=" --ivdw";}
		else if(wt.compare("lap")==0){flags+=" --lap";}
		else if(wt.compare("ndens")==0){flags+=" --ndens";}
		else if(wt.compare("kappa")==0){flags+=" --kappa";}
		else if(wt.compare("pot")==0){flags+=" --pot";}
		else if(wt.compare("qdens")==0){flags+=" --qdens";}
		else if(wt.compare("smol")==0){flags+=" --smol";}
		else if(wt.compare("sspl")==0){flags+=" --sspl";}
		else if(wt.compare("vdw")==0){flags+=" --vdw";}
		else{cerr<<"ERROR in inFileEditer!\nUnrecognized APBS Write Type ("<<wt<<")"<<endl;}}
	// Non-Linear Poisson Boltzmann Calculation Flag
	flags+=" --npbe";
	// Ion Input Flag
	flags+=" --ion="+ionData;
	flags+=" --temp="+temperature;
	flags+=" --srad="+largestIon;
	flags+=" --sdie="+er;
	string cmd="python "+checkFilePathParantheses(apbsInputgen)+" "+flags+" "+checkFilePathParantheses(pqrFile)+" "+checkFilePathParantheses(fldrExt);
	int statusCode;
	bool ATTEMPTING=true;
	while(ATTEMPTING)
		{statusCode=system(cmd.c_str());
		if(statusCode==0){break;ATTEMPTING=false;}}}

void runMULTIVALUE(string exeFile,string csvFile,string potFile,string mvFile,string logFile)
	{bool ATTEMPTING=true;
	int statusCode;
	string cmd=checkFilePathParantheses(exeFile)+" "+checkFilePathParantheses(csvFile)+" "+checkFilePathParantheses(potFile)+" "+checkFilePathParantheses(mvFile);
	freopen(logFile.c_str(),"a",stdout);
	while(ATTEMPTING)
		{statusCode=system(cmd.c_str());
		if(statusCode==0){fclose(stdout);break;ATTEMPTING=false;}}
	exit(EXIT_SUCCESS);}

void inflateVert(double inflationDistance,string inVertFile,string outVertFile,bool VERBOSE)
	{// Read MSMS Vertices File
	if(VERBOSE){fprintf(stdout,"Reading MSMS vertices file (%s)...",inVertFile.c_str());}
	vertData V;
	readMSMSVertFile(inVertFile,V);
	if(VERBOSE){fprintf(stdout,"%i vertices\n",V.numVertices);}	

	if(VERBOSE){fprintf(stdout,"Inflating Vertices by %f Angstroms...",inflationDistance);}
	for(int i=0;i<V.numVertices;i++)
		{V.x[i]+=inflationDistance*V.nx[i];
		V.y[i]+=inflationDistance*V.ny[i];
		V.z[i]+=inflationDistance*V.nz[i];}
	if(VERBOSE){fprintf(stdout,"Done.\n");}

	if(VERBOSE){fprintf(stdout,"Writing MSMS vertices file (%s)...",outVertFile.c_str());}
	writeMSMSVertFile(outVertFile,V);
	if(VERBOSE){fprintf(stdout,"Done.\n");}}

void vert2csv(string inVertFile,string outCsvFile,bool VERBOSE)
	{// Read MSMS Vertices File
	if(VERBOSE){fprintf(stdout,"Reading MSMS vertices file (%s)...",inVertFile.c_str());}
	vertData V;
	readMSMSVertFile(inVertFile,V);
	if(VERBOSE){fprintf(stdout,"%i vertices\n",V.numVertices);}	

	if(VERBOSE){fprintf(stdout,"Writing Comma Separarted Vector (CSV) file (%s)...",outCsvFile.c_str());}
	char Frmt[]="%f%s%f%s%f\n",delimiter[]=",";
	string Output="";
	//FILE *Out;
	//Out=fopen(outCsvFile.c_str(),"w");
	//for(int i=0;i<V.numVertices;i++){fprintf(Out,Frmt,V.x[i],delimiter,V.y[i],delimiter,V.z[i]);}
	//fclose(Out);
	for(int i=0;i<V.numVertices;i++)
		{Output+=cnvrtNumToStrng(V.x[i],BUFFER_SIZE)+delimiter;
		Output+=cnvrtNumToStrng(V.y[i],BUFFER_SIZE)+delimiter;
		Output+=cnvrtNumToStrng(V.z[i],BUFFER_SIZE)+"\n";}
	ofstream fOut;
	fOut.open(outCsvFile.c_str());
	if(fOut.fail()){cerr<<"ERROR in vert2csv!!!\nCSV output file could not be opened.\n"<<outCsvFile<<endl;exit(EXIT_FAILURE);}
	fOut<<Output;
	fOut.close();
	if(VERBOSE){fprintf(stdout,"Done.\n");}}

void writeMSMSVertFile(string fileName,vertData Data)
	{string spc1,spc2,spc3,spc4,spc5,spc6,spc7,spc8,spc9,spc10;
	string x,y,z,nx,ny,nz,analyticSurf,sphereNum,vertType,closestAtom;
	int frontSz,spcSz,col1=5,col2=6,col3=6,col4=6,col5=6,col6=6,col7=8,col8=8,col9=3;
	string Output="";
	for(int i=0;i<Data.numVertices;i++)	
		{// X Coordinate
		x=formatNumberString(cnvrtNumToStrng(Data.x[i],BUFFER_SIZE)); frontSz=x.find("."); spcSz=col1-frontSz; spc1=makeWhiteSpace(spcSz);
		// Y Coordinate
		y=formatNumberString(cnvrtNumToStrng(Data.y[i],BUFFER_SIZE)); frontSz=y.find("."); spcSz=col2-frontSz; spc2=makeWhiteSpace(spcSz);
		// Z Coordinate
		z=formatNumberString(cnvrtNumToStrng(Data.z[i],BUFFER_SIZE)); frontSz=z.find("."); spcSz=col3-frontSz; spc3=makeWhiteSpace(spcSz);
		// X Component of Normal Unit Vector
		nx=formatNumberString(cnvrtNumToStrng(Data.nx[i],BUFFER_SIZE)); frontSz=nx.find("."); spcSz=col4-frontSz; spc4=makeWhiteSpace(spcSz);
		// Y Component of Normal Unit Vector
		ny=formatNumberString(cnvrtNumToStrng(Data.ny[i],BUFFER_SIZE)); frontSz=ny.find("."); spcSz=col5-frontSz; spc5=makeWhiteSpace(spcSz);
		// Z Component of Normal Unit Vector
		nz=formatNumberString(cnvrtNumToStrng(Data.nz[i],BUFFER_SIZE)); frontSz=nz.find("."); spcSz=col6-frontSz; spc6=makeWhiteSpace(spcSz);
		// Analytic Surface Number
		analyticSurf=cnvrtNumToStrng(Data.analyticSurf[i],0); spcSz=col7-analyticSurf.length(); spc7=makeWhiteSpace(spcSz);
		// Sphere Number
		sphereNum=cnvrtNumToStrng(Data.sphereNum[i],0); spcSz=col8-sphereNum.length(); spc8=makeWhiteSpace(spcSz);
		// Vertice Type		
		vertType=cnvrtNumToStrng(Data.vertType[i],0); spcSz=col9-vertType.length(); spc9=makeWhiteSpace(spcSz);
		// Closest Atom
		closestAtom=Data.closestAtom[i]; 
		Output+=spc1+x+spc2+y+spc3+z;
		Output+=spc4+nx+spc5+ny+spc6+nz;
		Output+=spc7+analyticSurf+spc8+sphereNum;
		Output+=spc9+vertType+" "+closestAtom+"\n";}
	ofstream fOut;
	fOut.open(fileName.c_str());
	if(fOut.fail()){cerr<<"ERROR in writeMSMSVertFile\nOutput MSMS .vert file could not be opened.\n"<<fileName<<endl;exit(EXIT_FAILURE);}
	fOut<<Output;
	fOut.close();}

float readPQRFile(string pqrFile)
    {ifstream fIn;
    fIn.open(pqrFile.c_str());
    if(fIn.fail())
        {cerr<<"ERROR:\n PQR file could not be opened.\n"<<pqrFile<<endl;
         exit(EXIT_FAILURE);}

     // Copy Input File
    int Sz=15000;                      // overshoot actual line size, C++ automatically fixes c-string lengths
    char Val[Sz];
    string valBld,recordType,recordNum,tmp;
    int col1=6,col2=4+col1;
    fIn.getline(Val,Sz);
    while(!fIn.eof())
        {recordType="";
         recordNum="";
         if(!fIn.eof())
            {for(int i=0;i<col1;i++)
               {if(isalpha(Val[i]))
                   {recordType+=Val[i];}}
            if(recordType=="REMARK")
               {// Read Second Column
                for(int i=col1;i<col2;i++)
                   {if(Val[i]!=' ')
                       {recordNum+=Val[i];}}
                if(recordNum=="6")
                   {for(int i=col2;i<strlen(Val);i++)
                       {if(isdigit(Val[i]) || Val[i]=='.' || Val[i]=='-')
                           {valBld+=Val[i];}}}}
                else
                    {break;}}

         fIn.getline(Val,Sz);}
     fIn.close();
     return atof(valBld.c_str());}

// 1994. A Simple Expression for Henry's Funtion for the Retardation Effect in Electrophoresis of Spherical Colloidal Particles
double calc_HF_for_Sphere(double ka)
    {double trm1=2.5/(1+2*exp(-ka));
	double trm2=1+trm1/ka;
    double f=1 + 1/(2*trm2*trm2*trm2);
	return 2*f/3;}

// 1996. Henry's Function for Electrophoresis of a Cylindrical Colloidal Particle
double calc_HF_for_Cylinder(double ka)
    {double trm1=1;
     double trm2=ka*(1+exp(-ka));
     double trm3=1+(2.55/trm2);
     double f=trm1+1/(trm3*trm3);
     return (1+2*f)/3;}

// 2001. Approximate Analytic Expression for the Electrophroteic Mobility of Spherical Colloidal Particle
double calc_OF_for_Sphere(ion_Data Ion,double er,double temperature,double zetaPot,double ka)
	{if(Ion.numIons>2){/*cerr<<"Can not use Ohshima approximation, because too many ions\n";*/return 0;}
	double mCo,mCtr,zCtr,zCo;
	// Dimensionless Ionic Drag Coefficient
	if(zetaPot>0)
		{if(Ion.valence[0]>0)
			{// First Ion is Co-Ion
			mCo=4*pi*er*eo*kb*temperature*Ion.radius[0]*1e-10;
			mCo/=Ion.valence[0]*Ion.valence[0]*ec*ec;
			zCo=Ion.valence[0];
			// Second Ion is Counter-Ion
			mCtr=4*pi*er*eo*kb*temperature*Ion.radius[1]*1e-10;
			mCtr/=Ion.valence[1]*Ion.valence[1]*ec*ec;
			zCtr=Ion.valence[1];}
		else if(Ion.valence[0]<0)
			{// First Ion is Counter-Ion
			mCtr=4*pi*er*eo*kb*temperature*Ion.radius[0]*1e-10;
			mCtr/=Ion.valence[0]*Ion.valence[0]*ec*ec;
			zCtr=Ion.valence[0];
			// Second Ion is Co-Ion
			mCo=4*pi*er*eo*kb*temperature*Ion.radius[1]*1e-10;
			mCo/=Ion.valence[1]*Ion.valence[1]*ec*ec;
			zCo=Ion.valence[1];}}
	else if(zetaPot<0)
		{if(Ion.valence[0]>0)
			{// First Ion is Counter-Ion
			mCtr=4*pi*er*eo*kb*temperature*Ion.radius[0]*1e-10;
			mCtr/=Ion.valence[0]*Ion.valence[0]*ec*ec;
			zCtr=Ion.valence[0];
			// Second Ion is Co-Ion
			mCo=4*pi*er*eo*kb*temperature*Ion.radius[1]*1e-10;
			mCo/=Ion.valence[1]*Ion.valence[1]*ec*ec;
			zCo=Ion.valence[1];}
		else if(Ion.valence[0]<0)
			{// First Ion is Co-Ion
			mCo=4*pi*er*eo*kb*temperature*Ion.radius[0]*1e-10;
			mCo/=Ion.valence[0]*Ion.valence[0]*ec*ec;
			zCo=Ion.valence[0];
			// Second Ion is Counter-Ion
			mCtr=4*pi*er*eo*kb*temperature*Ion.radius[1]*1e-10;
			mCtr/=Ion.valence[1]*Ion.valence[1]*ec*ec;
			zCtr=Ion.valence[1];}}
	
	//if(abs(Ion.valence[0])>abs(Ion.valence[1]))
	//	{zCtr=Ion.valence[0];}
	//else
	//	{zCtr=Ion.valence[1];}

	double fHenry=calc_HF_for_Sphere(ka);
	double f3=ka*(ka+1.3*exp(-0.18*ka)+2.5);
	f3/=2*(ka+1.2*exp(-7.4*ka)+4.8)*(ka+1.2*exp(-7.4*ka)+4.8)*(ka+1.2*exp(-7.4*ka)+4.8);
	double f4=9*ka*(ka+5.2*exp(-3.9*ka)+5.6);
	f4/=8*(ka-1.55*exp(-0.32*ka)+6.02)*(ka-1.55*exp(-0.32*ka)+6.02)*(ka-1.55*exp(-0.32*ka)+6.02);

	double output;
	double trm1,trm2;
	double dZ=ec*zetaPot/(kb*temperature);
	//cout<<dZ<<endl;
	if(abs(Ion.valence[0])!=abs(Ion.valence[1]))
		{if(zetaPot>=0)
			{//output=3*fHenry/2-dZ*(abs(zCtr)-zCo)*f4-dZ*dZ*((zCo*mCo+abs(zCtr)*mCtr)/(abs(zCtr)+zCo))*f4;
			trm1=dZ*(abs(zCtr)-zCo)*f4;
			//cout<<trm1<<endl;
			trm2=dZ*dZ*((zCo*mCo+abs(zCtr)*mCtr)/(abs(zCtr)+zCo))*f4;
			//cout<<trm2<<endl;
			output=3*fHenry/2-trm1-trm2;}
			//output=fHenry-trm1-trm2;}
		else if(zetaPot<0)
			{//output=3*fHenry/2-dZ*(zCtr-abs(zCo))*f4-dZ*dZ*((abs(zCo)*mCo+zCtr*mCtr)/(zCtr+abs(zCo)))*f4;
			trm1=dZ*(zCtr-abs(zCo))*f4;
			//cout<<trm1<<endl;
			trm2=dZ*dZ*((abs(zCo)*mCo+zCtr*mCtr)/(zCtr+abs(zCo)))*f4;
			//cout<<trm2<<endl;
			output=3*fHenry/2-trm1-trm2;}}
			//output=fHenry-trm1-trm2;}}
	else		
		{output=3*fHenry/2-(zCtr*ec*zetaPot/(kb*temperature))*(zCtr*ec*zetaPot/(kb*temperature))*(f3+(mCo+mCtr)*f4/2);}
		//output=fHenry-(zCtr*ec*zetaPot/(kb*temperature))*(zCtr*ec*zetaPot/(kb*temperature))*(f3+(mCo+mCtr)*f4/2);}
	return 2*output/3;}

// 1983. Approximate Analytical Expressions for the Electrophoretic Mobility of Spherical Colloidal Particles and the Conductivity of their Dilute Suspensions
double calc_OHWF_for_Sphere(ion_Data Ion,double er,double temperature,double zetaPot,double ka)
	{if(Ion.numIons>2){/*cerr<<"Can not use Ohshima-Healy-White approximation, because too many ions"<<endl;*/return 0;}
	// Define Dimensionless Zeta Potential
	double zCtr,zCo,rCo,rCtr;
	if(abs(Ion.valence[0])>abs(Ion.valence[1]))
		{zCtr=Ion.valence[0];}
	else
		{zCtr=Ion.valence[1];}	
	double dZ=zCtr*ec*abs(zetaPot)/(kb*temperature);

	if(zetaPot>0)
		{if(Ion.valence[0]>0)
			{// First Ion is Co-Ion
			zCo=Ion.valence[0];
			rCo=Ion.radius[0]*1e-10;
			// Second Ion is Counter-Ion
			zCtr=Ion.valence[1];
			rCtr=Ion.radius[1]*1e-10;}
		else if(Ion.valence[0]<0)
			{// First Ion is Counter-Ion
			zCtr=Ion.valence[0];
			rCtr=Ion.radius[0]*1e-10;
			// Second Ion is Co-Ion
			zCo=Ion.valence[1];
			rCo=Ion.radius[1]*1e-10;}}
	else if(zetaPot<0)
		{if(Ion.valence[0]>0)
			{// First Ion is Counter-Ion
			zCtr=Ion.valence[0];
			rCtr=Ion.radius[0]*1e-10;
			// Second Ion is Co-Ion
			zCo=Ion.valence[1];
			rCo=Ion.radius[1]*1e-10;}
		else if(Ion.valence[0]<0)
			{// First Ion is Co-Ion
			zCo=Ion.valence[0];
			rCo=Ion.radius[0]*1e-10;
			// Second Ion is Counter-Ion
			zCtr=Ion.valence[1];
			rCtr=Ion.radius[1]*1e-10;}}

	double A=2.0*(1.0+(12.0*pi*er*eo*kb*temperature*rCtr/(ec*ec*zCtr*zCtr*abs(zCtr))))*(exp(dZ/2.0)-1.0)/ka;
	double B=log(1.0+exp(dZ/2.0))-log(2.0);
	double C=1.0-25.0*exp(-ka*dZ/(6.0*(ka+6.0)))/(3.0*(ka+10.0));
	double D=log(1.0+exp(-dZ/2.0))-log(2.0);
	double t=tanh(dZ/4);
	double W=10.0*A*(t+7.0*t*t/20.0+t*t*t/9.0)/(1.0+A)-12.0*C*(t+t*t*t/9.0);
	double X=4.0*D*(1.0+12.0*pi*er*eo*kb*temperature*rCo/(ec*ec*zCo*zCo*abs(zCo)))*(1.0-exp(-dZ/2.0));
	double Y=8.0*A*B/((1.0+A)*(1.0+A))+6.0*dZ*(4.0*pi*er*eo*kb*temperature*rCo*D/(ec*ec*zCo*zCo*abs(zCo))+4.0*pi*er*eo*kb*temperature*rCtr*B/(ec*ec*zCtr*zCtr*abs(zCtr)))/(1.0+A);
	double Z=24.0*A*(4.0*pi*er*eo*kb*temperature*rCo*D*D/(ec*ec*zCo*zCo*abs(zCo))+4.0*pi*er*eo*kb*temperature*rCtr*B*B/(ec*ec*zCtr*zCtr*abs(zCtr)*(1.0+A)))/(1.0+A);

	double output=1-2*A*B/(dZ*(1+A))+(W-X+Y-Z)/(dZ*ka);
	return 2*output/3;}

// INPUT: Zeta Potential (ZP) [Volts]
// INPUT: Solvated Radius (a) [meters]
// INPUT: Solution Structure Array
double two_ion_problem(double ZP,double a,Solution S,Error E,bool VERBOSE)
	{// Convert Debye Length from Angstroms to Meters
	double Debye=S.debyeLength*1e-10;
	// Final Position: Solvated Radius [meters]
	double rf=a;
	double r0;
	double dr=-1e-15;	// integrate from Inf to Protein Radius
	if(Debye>a){r0=5*Debye;}
	else{r0=5*a;}
		
	if(VERBOSE){cout<<"2 ION PROBLEM\nInitial Position:\t"<<r0<<" m"<<"\nFinal Position:\t\t"<<rf<<" m"<<"\nStep Size:\t\t"<<dr<<" m"<<endl;}

	// Calculate Poisson Boltzmann Coefficient and Determine Initial Position away from Protein
	double C=calc_PBE_coefficient(ZP,r0,rf,dr,S,E,VERBOSE);
	if(VERBOSE){cout<<"PBE Coeff: "<<C<<endl;}
	if(isnan(C)){return nan("");}
	int N=22;
	state_type y(N);
	// F Function
	// y[0] = f
	// y[1] = df/dr
	// y[2] = d2f/dr2
	// y[3] = d3f/dr3
	// y[4] = d4f/dr4
	// Equilibrium Electric Pontential
	// y[5] = potential
	// y[6] = d(potential)/dr
	// Induced Electrochemical Potential Function (2nd ion)
	// y[7] = IEP1
	// y[8] = d(IEP1)/dr
	// y[9] = IEP2
	// y[10] = d(IEP2)/dr	
	// Constants
	// y[11] = Temp					// [Kelvin]
	// y[12] = numIon
	// Ion Properties
	// y[13] = Anion.val;		
	// y[14] = Anion.conc;		// mM [mol/m^3]
	// y[15] = Anion.radius;		// meters
	// y[16] = Cation.val;
	// y[17] = Cation.conc;
	// y[18] = Cation.radius;
	// Solution Properties
	// y[19] = relative dielectric	[dimensionless]
	// y[20] = Debye Length [meters]
	// y[21] = viscosity  [Pa s]

	// Collect Error Data
	double abs_err=E.absolute;//1e-12;
	double rel_err=E.relative;//1e-7;
	double a_x=E.a_x;//1;
	double a_dxdt=E.a_dxdt;//1;
	controlled_stepper_type controlled_stepper(default_error_checker<double,range_algebra,default_operations>(abs_err,rel_err,a_x,a_dxdt));	

	// Calculate Mobility
	vector<state_type> y1,y2,y3,y4,y5,y6;
	vector<double> r1,r2,r3,r4,r5,r6;
	// Specify Boundary Conditions / Initial Values Infinitely Far from the Particle
	if(VERBOSE){cout<<"Solving Homogeneous Problem for 1st Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=1/(r0*r0);y[8]=-2/(r0*r0*r0);
	// Second Ion
	y[9]=0;y[10]=0;
	// Constants
	y[11]=S.temperature;y[12]=S.numIon;
	// Fist Ion Properties
	y[13]=S.ionVal[0];y[14]=S.ionConc[0]*1000;y[15]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[16]=S.ionVal[1];y[17]=S.ionConc[1]*1000;y[18]=S.ionRad[1]*1e-10;
	// Solution Properties
	y[19]=S.dielectric;y[20]=Debye;y[21]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps1=integrate_adaptive(controlled_stepper,homogeneous_form_2ion,y,r0,rf,dr,push_back_state_and_time(y1,r1));
	int Sz1=steps1+1;
	if(VERBOSE){cout<<"Done! ("<<Sz1<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 2nd Ion...";}	
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=1/(r0*r0);y[10]=-2/(r0*r0*r0);
	// Constants
	y[11]=S.temperature;y[12]=S.numIon;
	// Fist Ion Properties
	y[13]=S.ionVal[0];y[14]=S.ionConc[0]*1000;y[15]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[16]=S.ionVal[1];y[17]=S.ionConc[1]*1000;y[18]=S.ionRad[1]*1e-10;
	// Solution Properties
	y[19]=S.dielectric;y[20]=Debye;y[21]=S.viscosity;
	// Solve Homogeneous Form for Second Ion
	size_t steps2=integrate_adaptive(controlled_stepper,homogeneous_form_2ion,y,r0,rf,dr,push_back_state_and_time(y2,r2));
	int Sz2=steps2+1;
	if(VERBOSE){cout<<"Done! ("<<Sz2<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 1st f term...";}
	// F Function
	y[0]=r0;y[1]=1;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Constants
	y[11]=S.temperature;y[12]=S.numIon;
	// Fist Ion Properties
	y[13]=S.ionVal[0];y[14]=S.ionConc[0]*1000;y[15]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[16]=S.ionVal[1];y[17]=S.ionConc[1]*1000;y[18]=S.ionRad[1]*1e-10;
	// Solution Properties
	y[19]=S.dielectric;y[20]=Debye;y[21]=S.viscosity;
	// Solve Homogeneous Form for 1st term of F function
	size_t steps3=integrate_adaptive(controlled_stepper,homogeneous_form_2ion,y,r0,rf,dr,push_back_state_and_time(y3,r3));
	int Sz3=steps3+1;
	if(VERBOSE){cout<<"Done! ("<<Sz3<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 2nd f term...";}
	// F Function
	y[0]=1.0/r0;y[1]=-1.0/(r0*r0);y[2]=2.0/(r0*r0*r0);y[3]=-6.0/(r0*r0*r0*r0);y[4]=24.0/(r0*r0*r0*r0*r0);
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Constants
	y[11]=S.temperature;y[12]=S.numIon;
	// Fist Ion Properties
	y[13]=S.ionVal[0];y[14]=S.ionConc[0]*1000;y[15]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[16]=S.ionVal[1];y[17]=S.ionConc[1]*1000;y[18]=S.ionRad[1]*1e-10;
	// Solution Properties
	y[19]=S.dielectric;y[20]=Debye;y[21]=S.viscosity;
	// Solve Homogeneous Form for 2nd term of F function
	size_t steps4=integrate_adaptive(controlled_stepper,homogeneous_form_2ion,y,r0,rf,dr,push_back_state_and_time(y4,r4));
	int Sz4=steps4+1;
	if(VERBOSE){cout<<"Done! ("<<Sz4<<" points)"<<endl;}	

	if(VERBOSE){cout<<"Solving Flow Field Problem...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Constants
	y[11]=S.temperature;y[12]=S.numIon;
	// Fist Ion Properties
	y[13]=S.ionVal[0];y[14]=S.ionConc[0]*1000;y[15]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[16]=S.ionVal[1];y[17]=S.ionConc[1]*1000;y[18]=S.ionRad[1]*1e-10;
	// Solution Properties
	y[19]=S.dielectric;y[20]=Debye;y[21]=S.viscosity;
	// Solve Flow Field Perturbation 
	size_t steps5=integrate_adaptive(controlled_stepper,inhomogeneous_Prob1_2ion,y,r0,rf,dr,push_back_state_and_time(y5,r5));
	int Sz5=steps5+1;
	if(VERBOSE){cout<<"Done! ("<<Sz5<<" points)"<<endl;}

	if(VERBOSE){cout<<"Calculating Asymptotic Constants...";}
	alglib::real_2d_array A;
	alglib::real_1d_array C1,B1;
	// Define System Matrix containing coefficients of linear system
	A.setlength(4,4);
	for(int i=0;i<4;i++)
		{for(int j=0;j<4;j++)
			{A[i][j]=0;}}
	// d(IEP1)/dr
	A[0][0]=y1[Sz1-1][8];A[0][1]=y2[Sz2-1][8];A[0][2]=y3[Sz3-1][8];A[0][3]=y4[Sz4-1][8];
	// d(IEP2)/dr
	A[1][0]=y1[Sz1-1][10];A[1][1]=y2[Sz2-1][10];A[1][2]=y3[Sz3-1][10];A[1][3]=y4[Sz4-1][10];
	// f 1st (df/dr)
	A[2][0]=y1[Sz1-1][1];A[2][1]=y2[Sz2-1][1];A[2][2]=y3[Sz3-1][1];A[2][3]=y4[Sz4-1][1];
	// f 2nd (d2f/dr2)
	A[3][0]=y1[Sz1-1][2];A[3][1]=y2[Sz2-1][2];A[3][2]=y3[Sz3-1][2];A[3][3]=y4[Sz4-1][2];
	// Define Solution Matrix for Problem #1
	B1.setlength(4);
	// d(IEP1)/dr = 0
	B1[0]=0-y5[Sz5-1][8];
	// d(IEP2)/dr = 0
	B1[1]=0-y5[Sz5-1][10];
	// df/dr = -Radius/2
	B1[2]=-a/2 - y5[Sz5-1][1];
	// d2f/dr2 = -0.5
	B1[3]=-0.5 - y5[Sz5-1][2];
	// Create Output Parameters
	alglib::ae_int_t info;
	alglib::densesolverreport rep;
	alglib::rmatrixsolve(A,4,B1,info,rep,C1);
	if(VERBOSE)
		{cout<<"\n";
		cout<<C1[0]*A[0][0] + C1[1]*A[0][1] + C1[2]*A[0][2] + C1[3]*A[0][3] + y5[Sz5-1][8]<<endl;
		cout<<C1[0]*A[1][0] + C1[1]*A[1][1] + C1[2]*A[1][2] + C1[3]*A[1][3] + y5[Sz5-1][10]<<endl;
		cout<<C1[0]*A[2][0] + C1[1]*A[2][1] + C1[2]*A[2][2] + C1[3]*A[2][3] + y5[Sz5-1][1]<<endl;
		cout<<C1[0]*A[3][0] + C1[1]*A[3][1] + C1[2]*A[3][2] + C1[3]*A[3][3] + y5[Sz5-1][2]<<endl;
		cout<<"Done!"<<endl;
		cout<<"C1_1 = "<<C1[0]<<endl;
		cout<<"C2_1 = "<<C1[1]<<endl;
		cout<<"C3_1 = "<<C1[2]<<endl;
		cout<<"C4_1 = "<<C1[3]<<endl;}

	if(VERBOSE){cout<<"Solving Electric Field Problem...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Constants
	y[11]=S.temperature;y[12]=S.numIon;
	// Fist Ion Properties
	y[13]=S.ionVal[0];y[14]=S.ionConc[0]*1000;y[15]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[16]=S.ionVal[1];y[17]=S.ionConc[1]*1000;y[18]=S.ionRad[1]*1e-10;
	// Solution Properties
	y[19]=S.dielectric;y[20]=Debye;y[21]=S.viscosity;
	// Solve Electric Field Perturbation
	size_t steps6=integrate_adaptive(controlled_stepper,inhomogeneous_Prob2_2ion,y,r0,rf,dr,push_back_state_and_time(y6,r6));
	int Sz6=steps6+1;
	if(VERBOSE){cout<<"Done! ("<<Sz6<<" points)"<<endl;}
	
	if(VERBOSE){cout<<"Calculating Asymptotic Constants...";}
	alglib::real_1d_array C2,B2;
	// d(IEP1)/dr
	A[0][0]=y1[Sz1-1][8];A[0][1]=y2[Sz2-1][8];A[0][2]=y3[Sz3-1][8];A[0][3]=y4[Sz4-1][8];
	// d(IEP2)/dr
	A[1][0]=y1[Sz1-1][10];A[1][1]=y2[Sz2-1][10];A[1][2]=y3[Sz3-1][10];A[1][3]=y4[Sz4-1][10];
	// f 1st (df/dr)
	A[2][0]=y1[Sz1-1][1];A[2][1]=y2[Sz2-1][1];A[2][2]=y3[Sz3-1][1];A[2][3]=y4[Sz4-1][1];
	// f 2nd (d2f/dr2)
	A[3][0]=y1[Sz1-1][2];A[3][1]=y2[Sz2-1][2];A[3][2]=y3[Sz3-1][2];A[3][3]=y4[Sz4-1][2];
	// Define Solution Matrix for Problem #2
	B2.setlength(4);
	// d(IEP1)/dr = -1
	B2[0]=-1-y6[Sz6-1][8];
	// d(IEP2)/dr = -1
	B2[1]=-1-y6[Sz6-1][10];
	// df/dr = 0
	B2[2]=0-y6[Sz6-1][1];
	// d2f/dr2 = 0
	B2[3]=0-y6[Sz6-1][2];
	// Create Output Parameters
	alglib::rmatrixsolve(A,4,B2,info,rep,C2);

	if(VERBOSE)
		{cout<<"\n";
		cout<<C2[0]*A[0][0] + C2[1]*A[0][1] + C2[2]*A[0][2] + C2[3]*A[0][3] + y6[Sz6-1][8]<<endl;
		cout<<C2[0]*A[1][0] + C2[1]*A[1][1] + C2[2]*A[1][2] + C2[3]*A[1][3] + y6[Sz6-1][10]<<endl;
		cout<<C2[0]*A[2][0] + C2[1]*A[2][1] + C2[2]*A[2][2] + C2[3]*A[2][3] + y6[Sz6-1][1]<<endl;
		cout<<C2[0]*A[3][0] + C2[1]*A[3][1] + C2[2]*A[3][2] + C2[3]*A[3][3] + y6[Sz6-1][2]<<endl;
		cout<<"Done!"<<endl;
		cout<<"C1_2 = "<<C2[0]<<endl;
		cout<<"C2_2 = "<<C2[1]<<endl;
		cout<<"C3_2 = "<<C2[2]<<endl;
		cout<<"C4_2 = "<<C2[3]<<endl;}

	double mobility=-C2[2]/C1[2];
	
	if(VERBOSE)
		{cout<<"\n\nElectrophoretic Mobility:\t"<<mobility<<" m^2/Vs\n";
		cout<<"ka:\t\t"<<a/Debye<<endl;
		cout<<"Zeta Potential:\t"<<ZP<<" V\n";
		cout<<"E:\t\t"<<3*S.viscosity*ec*mobility/(2*eo*S.dielectric*kb*S.temperature)<<endl;
		cout<<"y:\t\t"<<ec*ZP/(kb*S.temperature)<<endl;}

	return mobility;}

// INPUT: Zeta Potential (ZP) [Volts]
// INPUT: Solvated Radius (a) [meters]
// INPUT: Solution Structure Array
double three_ion_problem(double ZP,double a,Solution S,Error E,bool VERBOSE)
	{// Convert Debye Length from Angstroms to Meters
	double Debye=S.debyeLength*1e-10;
	// Final Position: Solvated Radius [meters]
	double rf=a;
	double r0;
	double dr=-1e-15;	// integrate from Inf to Protein Radius
	if(Debye>a){r0=5*Debye;}
	else{r0=5*a;}
		
	if(VERBOSE){cout<<"3 ION PROBLEM\nInitial Position:\t"<<r0<<" m"<<"\nFinal Position:\t\t"<<rf<<" m"<<"\nStep Size:\t\t"<<dr<<" m"<<endl;}

	// Calculate Poisson Boltzmann Coefficient and Determine Initial Position away from Protein
	double C=calc_PBE_coefficient(ZP,r0,rf,dr,S,E,VERBOSE);
	if(VERBOSE){cout<<"PBE Coeff: "<<C<<endl;}
	if(isnan(C)){return nan("");}
	int N=27;
	state_type y(N);
	// F Function
	// y[0] = f
	// y[1] = df/dr
	// y[2] = d2f/dr2
	// y[3] = d3f/dr3
	// y[4] = d4f/dr4
	// Equilibrium Electric Pontential
	// y[5] = potential
	// y[6] = d(potential)/dr
	// Induced Electrochemical Potential Function (3 ion)
	// y[7] = IEP1
	// y[8] = d(IEP1)/dr
	// y[9] = IEP2
	// y[10] = d(IEP2)/dr
	// y[11] = IEP3
	// y[12] = d(IEP3)/dr
	// Constants
	// y[13] = Temp					// [Kelvin]
	// y[14] = numIon
	// Ion Properties
	// y[15] = Ion1.val;		
	// y[16] = Ion1.conc;		// mM [mol/m^3]
	// y[17] = Ion1.radius;		// meters
	// y[18] = Ion2.val;
	// y[19] = Ion2.conc;
	// y[20] = Ion2.radius;
	// y[21] = Ion3.val;
	// y[22] = Ion3.conc;
	// y[23] = Ion3.radius;
	// Solution Properties
	// y[24] = relative dielectric	[dimensionless]
	// y[25] = Debye Length [meters]
	// y[26] = viscosity  [Pa s]

	// Collect Error Data
	double abs_err=E.absolute;
	double rel_err=E.relative;
	double a_x=E.a_x;
	double a_dxdt=E.a_dxdt;
	controlled_stepper_type controlled_stepper(default_error_checker<double,range_algebra,default_operations>(abs_err,rel_err,a_x,a_dxdt));	

	// Calculate Mobility
	vector<state_type> y1,y2,y3,y4,y5,y6,y7;
	vector<double> r1,r2,r3,r4,r5,r6,r7;
	// Specify Boundary Conditions / Initial Values Infinitely Far from the Particle
	if(VERBOSE){cout<<"Solving Homogeneous Problem for 1st Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=1/(r0*r0);y[8]=-2/(r0*r0*r0);
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Constants
	y[13]=S.temperature;y[14]=S.numIon;
	// Fist Ion Properties
	y[15]=S.ionVal[0];y[16]=S.ionConc[0]*1000;y[17]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[18]=S.ionVal[1];y[19]=S.ionConc[1]*1000;y[20]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[21]=S.ionVal[2];y[22]=S.ionConc[2]*1000;y[23]=S.ionRad[2]*1e-10;
	// Solution Properties
	y[24]=S.dielectric;y[25]=Debye;y[26]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps1=integrate_adaptive(controlled_stepper,homogeneous_form_3ion,y,r0,rf,dr,push_back_state_and_time(y1,r1));
	int Sz1=steps1+1;
	if(VERBOSE){cout<<"Done! ("<<Sz1<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 2nd Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=1/(r0*r0);y[10]=-2/(r0*r0*r0);
	// Third Ion
	y[11]=0;y[12]=0;
	// Constants
	y[13]=S.temperature;y[14]=S.numIon;
	// Fist Ion Properties
	y[15]=S.ionVal[0];y[16]=S.ionConc[0]*1000;y[17]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[18]=S.ionVal[1];y[19]=S.ionConc[1]*1000;y[20]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[21]=S.ionVal[2];y[22]=S.ionConc[2]*1000;y[23]=S.ionRad[2]*1e-10;
	// Solution Properties
	y[24]=S.dielectric;y[25]=Debye;y[26]=S.viscosity;
	// Solve Homogeneous Form for Second Ion
	size_t steps2=integrate_adaptive(controlled_stepper,homogeneous_form_3ion,y,r0,rf,dr,push_back_state_and_time(y2,r2));
	int Sz2=steps2+1;
	if(VERBOSE){cout<<"Done! ("<<Sz2<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 3rd Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=1/(r0*r0);y[12]=-2/(r0*r0*r0);
	// Constants
	y[13]=S.temperature;y[14]=S.numIon;
	// Fist Ion Properties
	y[15]=S.ionVal[0];y[16]=S.ionConc[0]*1000;y[17]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[18]=S.ionVal[1];y[19]=S.ionConc[1]*1000;y[20]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[21]=S.ionVal[2];y[22]=S.ionConc[2]*1000;y[23]=S.ionRad[2]*1e-10;
	// Solution Properties
	y[24]=S.dielectric;y[25]=Debye;y[26]=S.viscosity;
	// Solve Homogeneous Form for 3rd Ion
	size_t steps3=integrate_adaptive(controlled_stepper,homogeneous_form_3ion,y,r0,rf,dr,push_back_state_and_time(y3,r3));
	int Sz3=steps3+1;
	if(VERBOSE){cout<<"Done! ("<<Sz3<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 1st f term...";}
	// F Function
	y[0]=r0;y[1]=1;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Constants
	y[13]=S.temperature;y[14]=S.numIon;
	// Fist Ion Properties
	y[15]=S.ionVal[0];y[16]=S.ionConc[0]*1000;y[17]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[18]=S.ionVal[1];y[19]=S.ionConc[1]*1000;y[20]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[21]=S.ionVal[2];y[22]=S.ionConc[2]*1000;y[23]=S.ionRad[2]*1e-10;
	// Solution Properties
	y[24]=S.dielectric;y[25]=Debye;y[26]=S.viscosity;
	// Solve Homogeneous Form
	size_t steps4=integrate_adaptive(controlled_stepper,homogeneous_form_3ion,y,r0,rf,dr,push_back_state_and_time(y4,r4));
	int Sz4=steps4+1;
	if(VERBOSE){cout<<"Done! ("<<Sz4<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 2nd f term...";}
	// F Function
	y[0]=1/r0;y[1]=-1/(r0*r0);y[2]=2/(r0*r0*r0);y[3]=-6/(r0*r0*r0*r0);y[4]=24/(r0*r0*r0*r0*r0);
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Constants
	y[13]=S.temperature;y[14]=S.numIon;
	// Fist Ion Properties
	y[15]=S.ionVal[0];y[16]=S.ionConc[0]*1000;y[17]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[18]=S.ionVal[1];y[19]=S.ionConc[1]*1000;y[20]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[21]=S.ionVal[2];y[22]=S.ionConc[2]*1000;y[23]=S.ionRad[2]*1e-10;
	// Solution Properties
	y[24]=S.dielectric;y[25]=Debye;y[26]=S.viscosity;
	// Solve Homogeneous Form
	size_t steps5=integrate_adaptive(controlled_stepper,homogeneous_form_3ion,y,r0,rf,dr,push_back_state_and_time(y5,r5));
	int Sz5=steps5+1;
	if(VERBOSE){cout<<"Done! ("<<Sz5<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Flow Field Problem...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Constants
	y[13]=S.temperature;y[14]=S.numIon;
	// Fist Ion Properties
	y[15]=S.ionVal[0];y[16]=S.ionConc[0]*1000;y[17]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[18]=S.ionVal[1];y[19]=S.ionConc[1]*1000;y[20]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[21]=S.ionVal[2];y[22]=S.ionConc[2]*1000;y[23]=S.ionRad[2]*1e-10;
	// Solution Properties
	y[24]=S.dielectric;y[25]=Debye;y[26]=S.viscosity;
	// Solve Flow Field Perturbation 
	size_t steps6=integrate_adaptive(controlled_stepper,inhomogeneous_Prob1_3ion,y,r0,rf,dr,push_back_state_and_time(y6,r6));
	int Sz6=steps6+1;
	if(VERBOSE){cout<<"Done! ("<<Sz6<<" points)"<<endl;}

	if(VERBOSE){cout<<"Calculating Asymptotic Constants...";}
	alglib::real_2d_array A;
	alglib::real_1d_array C1,B1;
	// Define System Matrix containing coefficients of linear system
	A.setlength(5,5);
	for(int i=0;i<5;i++)
		{for(int j=0;j<5;j++)
			{A[i][j]=0;}}
	// d(IEP1)/dr
	A[0][0]=y1[Sz1-1][8];A[0][1]=y2[Sz2-1][8];A[0][2]=y3[Sz3-1][8];A[0][3]=y4[Sz4-1][8];A[0][4]=y5[Sz5-1][8];
	// d(IEP2)/dr
	A[1][0]=y1[Sz1-1][10];A[1][1]=y2[Sz2-1][10];A[1][2]=y3[Sz3-1][10];A[1][3]=y4[Sz4-1][10];A[1][4]=y5[Sz5-1][10];
	// d(IEP3)/dr
	A[2][0]=y1[Sz1-1][12];A[2][1]=y2[Sz2-1][12];A[2][2]=y3[Sz3-1][12];A[2][3]=y4[Sz4-1][12];A[2][4]=y5[Sz5-1][12];
	// f 1st (df/dr)
	A[3][0]=y1[Sz1-1][1];A[3][1]=y2[Sz2-1][1];A[3][2]=y3[Sz3-1][1];A[3][3]=y4[Sz4-1][1];A[3][4]=y5[Sz5-1][1];
	// f 2nd (d2f/dr2)
	A[4][0]=y1[Sz1-1][2];A[4][1]=y2[Sz2-1][2];A[4][2]=y3[Sz3-1][2];A[4][3]=y4[Sz4-1][2];A[4][4]=y5[Sz5-1][2];
	// Define Solution Matrix for Problem #1
	B1.setlength(5);
	// d(IEP1)/dr = 0
	B1[0]=0-y6[Sz6-1][8];
	// d(IEP2)/dr = 0
	B1[1]=0-y6[Sz6-1][10];
	// d(IEP3)/dr = 0
	B1[2]=0-y6[Sz6-1][12];
	// df/dr = -Radius/2
	B1[3]=-a/2 - y6[Sz6-1][1];
	// d2f/dr2 = -0.5
	B1[4]=-0.5 - y6[Sz6-1][2];
	// Create Output Parameters
	alglib::ae_int_t info;
	alglib::densesolverreport rep;
	alglib::rmatrixsolve(A,5,B1,info,rep,C1);
	if(VERBOSE)
		{cout<<"\n";
		cout<<C1[0]*A[0][0] + C1[1]*A[0][1] + C1[2]*A[0][2] + C1[3]*A[0][3] + C1[4]*A[0][4] + y6[Sz6-1][8]<<endl;
		cout<<C1[0]*A[1][0] + C1[1]*A[1][1] + C1[2]*A[1][2] + C1[3]*A[1][3] + C1[4]*A[1][4] + y6[Sz6-1][10]<<endl;
		cout<<C1[0]*A[2][0] + C1[1]*A[2][1] + C1[2]*A[2][2] + C1[3]*A[2][3] + C1[4]*A[2][4] + y6[Sz6-1][12]<<endl;
		cout<<C1[0]*A[3][0] + C1[1]*A[3][1] + C1[2]*A[3][2] + C1[3]*A[3][3] + C1[4]*A[3][4] + y6[Sz6-1][1]<<endl;
		cout<<C1[0]*A[4][0] + C1[1]*A[4][1] + C1[2]*A[4][2] + C1[3]*A[4][3] + C1[4]*A[4][4] + y6[Sz6-1][2]<<endl;
		cout<<"Done!"<<endl;
		cout<<"C1_1 = "<<C1[0]<<endl;
		cout<<"C2_1 = "<<C1[1]<<endl;
		cout<<"C3_1 = "<<C1[2]<<endl;
		cout<<"C4_1 = "<<C1[3]<<endl;
		cout<<"C5_1 = "<<C1[4]<<endl;}
	
	if(VERBOSE){cout<<"Solving Electric Field Problem...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Constants
	y[13]=S.temperature;y[14]=S.numIon;
	// Fist Ion Properties
	y[15]=S.ionVal[0];y[16]=S.ionConc[0]*1000;y[17]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[18]=S.ionVal[1];y[19]=S.ionConc[1]*1000;y[20]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[21]=S.ionVal[2];y[22]=S.ionConc[2]*1000;y[23]=S.ionRad[2]*1e-10;
	// Solution Properties
	y[24]=S.dielectric;y[25]=Debye;y[26]=S.viscosity;
	// Solve Electric Field Perturbation
	size_t steps7=integrate_adaptive(controlled_stepper,inhomogeneous_Prob2_3ion,y,r0,rf,dr,push_back_state_and_time(y7,r7));
	int Sz7=steps7+1;
	if(VERBOSE){cout<<"Done! ("<<Sz7<<" points)"<<endl;}
	
	if(VERBOSE){cout<<"Calculating Asymptotic Constants...";}
	alglib::real_1d_array C2,B2;
	// d(IEP1)/dr
	A[0][0]=y1[Sz1-1][8];A[0][1]=y2[Sz2-1][8];A[0][2]=y3[Sz3-1][8];A[0][3]=y4[Sz4-1][8];A[0][4]=y5[Sz5-1][8];
	// d(IEP2)/dr
	A[1][0]=y1[Sz1-1][10];A[1][1]=y2[Sz2-1][10];A[1][2]=y3[Sz3-1][10];A[1][3]=y4[Sz4-1][10];A[1][4]=y5[Sz5-1][10];
	// d(IEP3)/dr
	A[2][0]=y1[Sz1-1][12];A[2][1]=y2[Sz2-1][12];A[2][2]=y3[Sz3-1][12];A[2][3]=y4[Sz4-1][12];A[2][4]=y5[Sz5-1][12];
	// f 1st (df/dr)
	A[3][0]=y1[Sz1-1][1];A[3][1]=y2[Sz2-1][1];A[3][2]=y3[Sz3-1][1];A[3][3]=y4[Sz4-1][1];A[3][4]=y5[Sz5-1][1];
	// f 2nd (d2f/dr2)
	A[4][0]=y1[Sz1-1][2];A[4][1]=y2[Sz2-1][2];A[4][2]=y3[Sz3-1][2];A[4][3]=y4[Sz4-1][2];A[4][4]=y5[Sz5-1][2];
	// Define Solution Matrix for Problem #1
	B2.setlength(5);
	// d(IEP1)/dr = -1
	B2[0]=-1-y7[Sz7-1][8];
	// d(IEP2)/dr = -1
	B2[1]=-1-y7[Sz7-1][10];
	// d(IEP3)/dr = -1
	B2[2]=-1-y7[Sz7-1][12];
	// df/dr = 0
	B2[3]=0-y7[Sz7-1][1];
	// d2f/dr2 = 0
	B2[4]=0-y7[Sz7-1][2];
	// Create Output Parameters
	alglib::rmatrixsolve(A,5,B2,info,rep,C2);
	if(VERBOSE)
		{cout<<"\n";
		cout<<C2[0]*A[0][0] + C2[1]*A[0][1] + C2[2]*A[0][2] + C2[3]*A[0][3] + C2[4]*A[0][4] + y7[Sz7-1][8]<<endl;
		cout<<C2[0]*A[1][0] + C2[1]*A[1][1] + C2[2]*A[1][2] + C2[3]*A[1][3] + C2[4]*A[1][4] + y7[Sz7-1][10]<<endl;
		cout<<C2[0]*A[2][0] + C2[1]*A[2][1] + C2[2]*A[2][2] + C2[3]*A[2][3] + C2[4]*A[2][4] + y7[Sz7-1][12]<<endl;
		cout<<C2[0]*A[3][0] + C2[1]*A[3][1] + C2[2]*A[3][2] + C2[3]*A[3][3] + C2[4]*A[3][4] + y7[Sz7-1][1]<<endl;
		cout<<C2[0]*A[4][0] + C2[1]*A[4][1] + C2[2]*A[4][2] + C2[3]*A[4][3] + C2[4]*A[4][4] + y7[Sz7-1][2]<<endl;
		cout<<"Done!"<<endl;
		cout<<"C1_2 = "<<C2[0]<<endl;
		cout<<"C2_2 = "<<C2[1]<<endl;
		cout<<"C3_2 = "<<C2[2]<<endl;
		cout<<"C4_2 = "<<C2[3]<<endl;
		cout<<"C5_2 = "<<C2[4]<<endl;}

	double mobility=-C2[3]/C1[3];
	
	if(VERBOSE)
		{cout<<"\n\nElectrophoretic Mobility:\t"<<mobility<<" m^2/Vs\n";
		cout<<"ka:\t\t"<<a/Debye<<endl;
		cout<<"Zeta Potential:\t"<<ZP<<" V\n";
		cout<<"E:\t\t"<<3*S.viscosity*ec*mobility/(2*eo*S.dielectric*kb*S.temperature)<<endl;
		cout<<"y:\t\t"<<ec*ZP/(kb*S.temperature)<<endl;}

	return mobility;}

double four_ion_problem(double ZP,double a,Solution S,Error E,bool VERBOSE)
	{// Convert Debye Length from Angstroms to Meters
	double Debye=S.debyeLength*1e-10;
	// Final Position: Solvated Radius [meters]
	double rf=a;
	double r0;
	double dr=-1e-15;	// integrate from Inf to Protein Radius
	if(Debye>a){r0=5*Debye;}
	else{r0=5*a;}
		
	if(VERBOSE){cout<<"4 ION PROBLEM\nInitial Position:\t"<<r0<<" m"<<"\nFinal Position:\t\t"<<rf<<" m"<<"\nStep Size:\t\t"<<dr<<" m"<<endl;}

	// Calculate Poisson Boltzmann Coefficient and Determine Initial Position away from Protein
	double C=calc_PBE_coefficient(ZP,r0,rf,dr,S,E,VERBOSE);
	if(VERBOSE){cout<<"PBE Coeff: "<<C<<endl;}
	if(isnan(C)){return nan("");}
	int N=7+2*S.numIon+2+3*S.numIon+3;//32;
	state_type y(N);
	// F Function
	// y[0] = f
	// y[1] = df/dr
	// y[2] = d2f/dr2
	// y[3] = d3f/dr3
	// y[4] = d4f/dr4
	// Equilibrium Electric Pontential
	// y[5] = potential
	// y[6] = d(potential)/dr
	// Induced Electrochemical Potential Function (4 ion)
	// y[7] = IEP1
	// y[8] = d(IEP1)/dr
	// y[9] = IEP2
	// y[10] = d(IEP2)/dr
	// y[11] = IEP3
	// y[12] = d(IEP3)/dr
	// y[13] = IEP4
	// y[14] = d(IEP4)/dr
	// Constants
	// y[15] = Temp					// [Kelvin]
	// y[16] = numIon
	// Ion Properties
	// y[17] = Ion1.val;		
	// y[18] = Ion1.conc;		// mM [mol/m^3]
	// y[19] = Ion1.radius;		// meters
	// y[20] = Ion2.val;
	// y[21] = Ion2.conc;
	// y[22] = Ion2.radius;
	// y[23] = Ion3.val;
	// y[24] = Ion3.conc;
	// y[25] = Ion3.radius;
	// y[26] = Ion4.val;
	// y[27] = Ion4.conc;
	// y[28] = Ion4.radius;
	// Solution Properties
	// y[29] = relative dielectric	[dimensionless]
	// y[30] = Debye Length [meters]
	// y[31] = viscosity  [Pa s]

	// Collect Error Data
	double abs_err=E.absolute;
	double rel_err=E.relative;
	double a_x=E.a_x;
	double a_dxdt=E.a_dxdt;
	controlled_stepper_type controlled_stepper(default_error_checker<double,range_algebra,default_operations>(abs_err,rel_err,a_x,a_dxdt));	

	// Calculate Mobility
	vector<state_type> y1,y2,y3,y4,y5,y6,y7,y8;
	vector<double> r1,r2,r3,r4,r5,r6,r7,r8;
	// Specify Boundary Conditions / Initial Values Infinitely Far from the Particle
	if(VERBOSE){cout<<"Solving Homogeneous Problem for 1st Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=1/(r0*r0);y[8]=-2/(r0*r0*r0);
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Constants
	y[15]=S.temperature;y[16]=S.numIon;
	// Fist Ion Properties
	y[17]=S.ionVal[0];y[18]=S.ionConc[0]*1000;y[19]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[20]=S.ionVal[1];y[21]=S.ionConc[1]*1000;y[22]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[23]=S.ionVal[2];y[24]=S.ionConc[2]*1000;y[25]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[26]=S.ionVal[3];y[27]=S.ionConc[3]*1000;y[28]=S.ionRad[3]*1e-10;
	// Solution Properties
	y[29]=S.dielectric;y[30]=Debye;y[31]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps1=integrate_adaptive(controlled_stepper,homogeneous_form_4ion,y,r0,rf,dr,push_back_state_and_time(y1,r1));
	int Sz1=steps1+1;
	if(VERBOSE){cout<<"Done! ("<<Sz1<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 2nd Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=1/(r0*r0);y[10]=-2/(r0*r0*r0);
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Constants
	y[15]=S.temperature;y[16]=S.numIon;
	// Fist Ion Properties
	y[17]=S.ionVal[0];y[18]=S.ionConc[0]*1000;y[19]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[20]=S.ionVal[1];y[21]=S.ionConc[1]*1000;y[22]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[23]=S.ionVal[2];y[24]=S.ionConc[2]*1000;y[25]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[26]=S.ionVal[3];y[27]=S.ionConc[3]*1000;y[28]=S.ionRad[3]*1e-10;
	// Solution Properties
	y[29]=S.dielectric;y[30]=Debye;y[31]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps2=integrate_adaptive(controlled_stepper,homogeneous_form_4ion,y,r0,rf,dr,push_back_state_and_time(y2,r2));
	int Sz2=steps2+1;
	if(VERBOSE){cout<<"Done! ("<<Sz2<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 3rd Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=1/(r0*r0);y[12]=-2/(r0*r0*r0);
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Constants
	y[15]=S.temperature;y[16]=S.numIon;
	// Fist Ion Properties
	y[17]=S.ionVal[0];y[18]=S.ionConc[0]*1000;y[19]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[20]=S.ionVal[1];y[21]=S.ionConc[1]*1000;y[22]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[23]=S.ionVal[2];y[24]=S.ionConc[2]*1000;y[25]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[26]=S.ionVal[3];y[27]=S.ionConc[3]*1000;y[28]=S.ionRad[3]*1e-10;
	// Solution Properties
	y[29]=S.dielectric;y[30]=Debye;y[31]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps3=integrate_adaptive(controlled_stepper,homogeneous_form_4ion,y,r0,rf,dr,push_back_state_and_time(y3,r3));
	int Sz3=steps3+1;
	if(VERBOSE){cout<<"Done! ("<<Sz3<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 4th Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=1/(r0*r0);y[14]=-2/(r0*r0*r0);
	// Constants
	y[15]=S.temperature;y[16]=S.numIon;
	// Fist Ion Properties
	y[17]=S.ionVal[0];y[18]=S.ionConc[0]*1000;y[19]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[20]=S.ionVal[1];y[21]=S.ionConc[1]*1000;y[22]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[23]=S.ionVal[2];y[24]=S.ionConc[2]*1000;y[25]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[26]=S.ionVal[3];y[27]=S.ionConc[3]*1000;y[28]=S.ionRad[3]*1e-10;
	// Solution Properties
	y[29]=S.dielectric;y[30]=Debye;y[31]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps4=integrate_adaptive(controlled_stepper,homogeneous_form_4ion,y,r0,rf,dr,push_back_state_and_time(y4,r4));
	int Sz4=steps4+1;
	if(VERBOSE){cout<<"Done! ("<<Sz4<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 1st f term...";}
	// F Function
	y[0]=r0;y[1]=1;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Constants
	y[15]=S.temperature;y[16]=S.numIon;
	// Fist Ion Properties
	y[17]=S.ionVal[0];y[18]=S.ionConc[0]*1000;y[19]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[20]=S.ionVal[1];y[21]=S.ionConc[1]*1000;y[22]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[23]=S.ionVal[2];y[24]=S.ionConc[2]*1000;y[25]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[26]=S.ionVal[3];y[27]=S.ionConc[3]*1000;y[28]=S.ionRad[3]*1e-10;
	// Solution Properties
	y[29]=S.dielectric;y[30]=Debye;y[31]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps5=integrate_adaptive(controlled_stepper,homogeneous_form_4ion,y,r0,rf,dr,push_back_state_and_time(y5,r5));
	int Sz5=steps5+1;
	if(VERBOSE){cout<<"Done! ("<<Sz5<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 2nd f term...";}
	// F Function
	y[0]=1/r0;y[1]=-1/(r0*r0);y[2]=2/(r0*r0*r0);y[3]=-6/(r0*r0*r0*r0);y[4]=24/(r0*r0*r0*r0*r0);
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Constants
	y[15]=S.temperature;y[16]=S.numIon;
	// Fist Ion Properties
	y[17]=S.ionVal[0];y[18]=S.ionConc[0]*1000;y[19]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[20]=S.ionVal[1];y[21]=S.ionConc[1]*1000;y[22]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[23]=S.ionVal[2];y[24]=S.ionConc[2]*1000;y[25]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[26]=S.ionVal[3];y[27]=S.ionConc[3]*1000;y[28]=S.ionRad[3]*1e-10;
	// Solution Properties
	y[29]=S.dielectric;y[30]=Debye;y[31]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps6=integrate_adaptive(controlled_stepper,homogeneous_form_4ion,y,r0,rf,dr,push_back_state_and_time(y6,r6));
	int Sz6=steps6+1;
	if(VERBOSE){cout<<"Done! ("<<Sz6<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Flow Field Problem...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Constants
	y[15]=S.temperature;y[16]=S.numIon;
	// Fist Ion Properties
	y[17]=S.ionVal[0];y[18]=S.ionConc[0]*1000;y[19]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[20]=S.ionVal[1];y[21]=S.ionConc[1]*1000;y[22]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[23]=S.ionVal[2];y[24]=S.ionConc[2]*1000;y[25]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[26]=S.ionVal[3];y[27]=S.ionConc[3]*1000;y[28]=S.ionRad[3]*1e-10;
	// Solution Properties
	y[29]=S.dielectric;y[30]=Debye;y[31]=S.viscosity;
	// Solve Flow Field Perturbation 
	size_t steps7=integrate_adaptive(controlled_stepper,inhomogeneous_Prob1_4ion,y,r0,rf,dr,push_back_state_and_time(y7,r7));
	int Sz7=steps7+1;
	if(VERBOSE){cout<<"Done! ("<<Sz7<<" points)"<<endl;}

	if(VERBOSE){cout<<"Calculating Asymptotic Constants...";}
	alglib::real_2d_array A;
	alglib::real_1d_array C1,B1;
	// Define System Matrix containing coefficients of linear system
	A.setlength(6,6);
	for(int i=0;i<6;i++)
		{for(int j=0;j<6;j++)
			{A[i][j]=0;}}
	// d(IEP1)/dr
	A[0][0]=y1[Sz1-1][8];A[0][1]=y2[Sz2-1][8];A[0][2]=y3[Sz3-1][8];A[0][3]=y4[Sz4-1][8];A[0][4]=y5[Sz5-1][8];A[0][5]=y6[Sz6-1][8];
	// d(IEP2)/dr
	A[1][0]=y1[Sz1-1][10];A[1][1]=y2[Sz2-1][10];A[1][2]=y3[Sz3-1][10];A[1][3]=y4[Sz4-1][10];A[1][4]=y5[Sz5-1][10];A[1][5]=y6[Sz6-1][10];
	// d(IEP3)/dr
	A[2][0]=y1[Sz1-1][12];A[2][1]=y2[Sz2-1][12];A[2][2]=y3[Sz3-1][12];A[2][3]=y4[Sz4-1][12];A[2][4]=y5[Sz5-1][12];A[2][5]=y6[Sz6-1][12];
	// d(IEP4)/dr
	A[3][0]=y1[Sz1-1][14];A[3][1]=y2[Sz2-1][14];A[3][2]=y3[Sz3-1][14];A[3][3]=y4[Sz4-1][14];A[3][4]=y5[Sz5-1][14];A[3][5]=y6[Sz6-1][14];
	// f 1st (df/dr)
	A[4][0]=y1[Sz1-1][1];A[4][1]=y2[Sz2-1][1];A[4][2]=y3[Sz3-1][1];A[4][3]=y4[Sz4-1][1];A[4][4]=y5[Sz5-1][1];A[4][5]=y6[Sz6-1][1];
	// f 2nd (d2f/dr2)
	A[5][0]=y1[Sz1-1][2];A[5][1]=y2[Sz2-1][2];A[5][2]=y3[Sz3-1][2];A[5][3]=y4[Sz4-1][2];A[5][4]=y5[Sz5-1][2];A[5][5]=y6[Sz6-1][2];
	// Define Solution Matrix for Problem #1
	B1.setlength(6);
	// d(IEP1)/dr = 0
	B1[0]=0-y7[Sz7-1][8];
	// d(IEP2)/dr = 0
	B1[1]=0-y7[Sz7-1][10];
	// d(IEP3)/dr = 0
	B1[2]=0-y7[Sz7-1][12];
	// d(IEP4)/dr = 0
	B1[3]=0-y7[Sz7-1][14];
	// df/dr = -Radius/2
	B1[4]=-a/2 - y7[Sz7-1][1];
	// d2f/dr2 = -0.5
	B1[5]=-0.5 - y7[Sz7-1][2];
	// Create Output Parameters
	alglib::ae_int_t info;
	alglib::densesolverreport rep;
	alglib::rmatrixsolve(A,6,B1,info,rep,C1);
	if(VERBOSE)
		{cout<<"\n";
		cout<<C1[0]*A[0][0] + C1[1]*A[0][1] + C1[2]*A[0][2] + C1[3]*A[0][3] + C1[4]*A[0][4] + C1[5]*A[0][5] + y7[Sz7-1][8]<<endl;
		cout<<C1[0]*A[1][0] + C1[1]*A[1][1] + C1[2]*A[1][2] + C1[3]*A[1][3] + C1[4]*A[1][4] + C1[5]*A[1][5] + y7[Sz7-1][10]<<endl;
		cout<<C1[0]*A[2][0] + C1[1]*A[2][1] + C1[2]*A[2][2] + C1[3]*A[2][3] + C1[4]*A[2][4] + C1[5]*A[2][5] + y7[Sz7-1][12]<<endl;
		cout<<C1[0]*A[3][0] + C1[1]*A[3][1] + C1[2]*A[3][2] + C1[3]*A[3][3] + C1[4]*A[3][4] + C1[5]*A[3][5] + y7[Sz7-1][14]<<endl;
		cout<<C1[0]*A[4][0] + C1[1]*A[4][1] + C1[2]*A[4][2] + C1[3]*A[4][3] + C1[4]*A[4][4] + C1[5]*A[4][5] + y7[Sz7-1][1]<<endl;
		cout<<C1[0]*A[5][0] + C1[1]*A[5][1] + C1[2]*A[5][2] + C1[3]*A[5][3] + C1[4]*A[5][4] + C1[5]*A[5][5] + y7[Sz7-1][2]<<endl;
		cout<<"Done!"<<endl;
		cout<<"C1_1 = "<<C1[0]<<endl;
		cout<<"C2_1 = "<<C1[1]<<endl;
		cout<<"C3_1 = "<<C1[2]<<endl;
		cout<<"C4_1 = "<<C1[3]<<endl;
		cout<<"C5_1 = "<<C1[4]<<endl;
		cout<<"C6_1 = "<<C1[5]<<endl;}

	if(VERBOSE){cout<<"Solving Electric Field Problem...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Constants
	y[15]=S.temperature;y[16]=S.numIon;
	// Fist Ion Properties
	y[17]=S.ionVal[0];y[18]=S.ionConc[0]*1000;y[19]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[20]=S.ionVal[1];y[21]=S.ionConc[1]*1000;y[22]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[23]=S.ionVal[2];y[24]=S.ionConc[2]*1000;y[25]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[26]=S.ionVal[3];y[27]=S.ionConc[3]*1000;y[28]=S.ionRad[3]*1e-10;
	// Solution Properties
	y[29]=S.dielectric;y[30]=Debye;y[31]=S.viscosity;
	// Solve Electric Field Perturbation
	size_t steps8=integrate_adaptive(controlled_stepper,inhomogeneous_Prob2_4ion,y,r0,rf,dr,push_back_state_and_time(y8,r8));
	int Sz8=steps8+1;
	if(VERBOSE){cout<<"Done! ("<<Sz8<<" points)"<<endl;}

	if(VERBOSE){cout<<"Calculating Asymptotic Constants...";}
	alglib::real_1d_array C2,B2;
	// d(IEP1)/dr
	A[0][0]=y1[Sz1-1][8];A[0][1]=y2[Sz2-1][8];A[0][2]=y3[Sz3-1][8];A[0][3]=y4[Sz4-1][8];A[0][4]=y5[Sz5-1][8];A[0][5]=y6[Sz6-1][8];
	// d(IEP2)/dr
	A[1][0]=y1[Sz1-1][10];A[1][1]=y2[Sz2-1][10];A[1][2]=y3[Sz3-1][10];A[1][3]=y4[Sz4-1][10];A[1][4]=y5[Sz5-1][10];A[1][5]=y6[Sz6-1][10];
	// d(IEP3)/dr
	A[2][0]=y1[Sz1-1][12];A[2][1]=y2[Sz2-1][12];A[2][2]=y3[Sz3-1][12];A[2][3]=y4[Sz4-1][12];A[2][4]=y5[Sz5-1][12];A[2][5]=y6[Sz6-1][12];
	// d(IEP4)/dr
	A[3][0]=y1[Sz1-1][14];A[3][1]=y2[Sz2-1][14];A[3][2]=y3[Sz3-1][14];A[3][3]=y4[Sz4-1][14];A[3][4]=y5[Sz5-1][14];A[3][5]=y6[Sz6-1][14];
	// f 1st (df/dr)
	A[4][0]=y1[Sz1-1][1];A[4][1]=y2[Sz2-1][1];A[4][2]=y3[Sz3-1][1];A[4][3]=y4[Sz4-1][1];A[4][4]=y5[Sz5-1][1];A[4][5]=y6[Sz6-1][1];
	// f 2nd (d2f/dr2)
	A[5][0]=y1[Sz1-1][2];A[5][1]=y2[Sz2-1][2];A[5][2]=y3[Sz3-1][2];A[5][3]=y4[Sz4-1][2];A[5][4]=y5[Sz5-1][2];A[5][5]=y6[Sz6-1][2];
	// Define Solution Matrix for Problem #2
	B2.setlength(6);
	// d(IEP1)/dr = -1
	B2[0]=-1-y8[Sz8-1][8];
	// d(IEP2)/dr = -1
	B2[1]=-1-y8[Sz8-1][10];
	// d(IEP3)/dr = -1
	B2[2]=-1-y8[Sz8-1][12];
	// d(IEP4)/dr = -1
	B2[3]=-1-y8[Sz8-1][14];
	// df/dr = 0
	B2[4]=0-y8[Sz8-1][1];
	// d2f/dr2 = 0
	B2[5]=0-y8[Sz8-1][2];
	// Create Output Parameters
	alglib::rmatrixsolve(A,6,B2,info,rep,C2);
	if(VERBOSE)
		{cout<<"\n";
		cout<<C2[0]*A[0][0] + C2[1]*A[0][1] + C2[2]*A[0][2] + C2[3]*A[0][3] + C2[4]*A[0][4] + C2[5]*A[0][5] + y8[Sz8-1][8]<<endl;
		cout<<C2[0]*A[1][0] + C2[1]*A[1][1] + C2[2]*A[1][2] + C2[3]*A[1][3] + C2[4]*A[1][4] + C2[5]*A[1][5] + y8[Sz8-1][10]<<endl;
		cout<<C2[0]*A[2][0] + C2[1]*A[2][1] + C2[2]*A[2][2] + C2[3]*A[2][3] + C2[4]*A[2][4] + C2[5]*A[2][5] + y8[Sz8-1][12]<<endl;
		cout<<C2[0]*A[3][0] + C2[1]*A[3][1] + C2[2]*A[3][2] + C2[3]*A[3][3] + C2[4]*A[3][4] + C2[5]*A[3][5] + y8[Sz8-1][14]<<endl;
		cout<<C2[0]*A[4][0] + C2[1]*A[4][1] + C2[2]*A[4][2] + C2[3]*A[4][3] + C2[4]*A[4][4] + C2[5]*A[4][5] + y8[Sz8-1][1]<<endl;
		cout<<C2[0]*A[5][0] + C2[1]*A[5][1] + C2[2]*A[5][2] + C2[3]*A[5][3] + C2[4]*A[5][4] + C2[5]*A[5][5] + y8[Sz8-1][2]<<endl;
		cout<<"Done!"<<endl;
		cout<<"C1_2 = "<<C2[0]<<endl;
		cout<<"C2_2 = "<<C2[1]<<endl;
		cout<<"C3_2 = "<<C2[2]<<endl;
		cout<<"C4_2 = "<<C2[3]<<endl;
		cout<<"C5_2 = "<<C2[4]<<endl;
		cout<<"C6_2 = "<<C2[5]<<endl;}

	double mobility=-C2[4]/C1[4];
	
	if(VERBOSE)
		{cout<<"\n\nElectrophoretic Mobility:\t"<<mobility<<" m^2/Vs\n";
		cout<<"ka:\t\t"<<a/Debye<<endl;
		cout<<"Zeta Potential:\t"<<ZP<<" V\n";
		cout<<"E:\t\t"<<3*S.viscosity*ec*mobility/(2*eo*S.dielectric*kb*S.temperature)<<endl;
		cout<<"y:\t\t"<<ec*ZP/(kb*S.temperature)<<endl;}

	return mobility;}

double five_ion_problem(double ZP,double a,Solution S,Error E,bool VERBOSE)
	{// Convert Debye Length from Angstroms to Meters
	double Debye=S.debyeLength*1e-10;
	// Final Position: Solvated Radius [meters]
	double rf=a;
	double r0;
	double dr=-1e-15;	// integrate from Inf to Protein Radius
	if(Debye>a){r0=5*Debye;}
	else{r0=5*a;}
		
	if(VERBOSE){cout<<"5 ION PROBLEM\nInitial Position:\t"<<r0<<" m"<<"\nFinal Position:\t\t"<<rf<<" m"<<"\nStep Size:\t\t"<<dr<<" m"<<endl;}

	// Calculate Poisson Boltzmann Coefficient and Determine Initial Position away from Protein
	double C=calc_PBE_coefficient(ZP,r0,rf,dr,S,E,VERBOSE);
	if(VERBOSE){cout<<"PBE Coeff: "<<C<<endl;}
	if(isnan(C)){return nan("");}
	int N=7+2*S.numIon+2+3*S.numIon+3;//37;
	state_type y(N);
	// F Function
	// y[0] = f
	// y[1] = df/dr
	// y[2] = d2f/dr2
	// y[3] = d3f/dr3
	// y[4] = d4f/dr4
	// Equilibrium Electric Pontential
	// y[5] = potential
	// y[6] = d(potential)/dr
	// Induced Electrochemical Potential Function (5 ion)
	// y[7] = IEP1
	// y[8] = d(IEP1)/dr
	// y[9] = IEP2
	// y[10] = d(IEP2)/dr
	// y[11] = IEP3
	// y[12] = d(IEP3)/dr
	// y[13] = IEP4
	// y[14] = d(IEP4)/dr
	// y[15] = IEP5
	// y[16] = d(IEP5)/dr
	// Constants
	// y[17] = Temp					// [Kelvin]
	// y[18] = numIon
	// Ion Properties
	// y[19] = Ion1.val;		
	// y[20] = Ion1.conc;		// mM [mol/m^3]
	// y[21] = Ion1.radius;		// meters
	// y[22] = Ion2.val;
	// y[23] = Ion2.conc;
	// y[24] = Ion2.radius;
	// y[25] = Ion3.val;
	// y[26] = Ion3.conc;
	// y[27] = Ion3.radius;
	// y[28] = Ion4.val;
	// y[29] = Ion4.conc;
	// y[30] = Ion4.radius;
	// y[31] = Ion5.val;
	// y[32] = Ion5.conc;
	// y[33] = Ion5.radius;
	// Solution Properties
	// y[34] = relative dielectric	[dimensionless]
	// y[35] = Debye Length [meters]
	// y[36] = viscosity  [Pa s]
	// Collect Error Data
	double abs_err=E.absolute;
	double rel_err=E.relative;
	double a_x=E.a_x;
	double a_dxdt=E.a_dxdt;
	controlled_stepper_type controlled_stepper(default_error_checker<double,range_algebra,default_operations>(abs_err,rel_err,a_x,a_dxdt));	

	// Calculate Mobility
	vector<state_type> y1,y2,y3,y4,y5,y6,y7,y8,y9;
	vector<double> r1,r2,r3,r4,r5,r6,r7,r8,r9;
	// Specify Boundary Conditions / Initial Values Infinitely Far from the Particle
	if(VERBOSE){cout<<"Solving Homogeneous Problem for 1st Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=1/(r0*r0);y[8]=-2/(r0*r0*r0);
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fiveth Ion
	y[15]=0;y[16]=0;
	// Constants
	y[17]=S.temperature;y[18]=S.numIon;
	// Fist Ion Properties
	y[19]=S.ionVal[0];y[20]=S.ionConc[0]*1000;y[21]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[22]=S.ionVal[1];y[23]=S.ionConc[1]*1000;y[24]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[25]=S.ionVal[2];y[26]=S.ionConc[2]*1000;y[27]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[28]=S.ionVal[3];y[29]=S.ionConc[3]*1000;y[30]=S.ionRad[3]*1e-10;
	// Fiveth Ion Properties
	y[31]=S.ionVal[4];y[32]=S.ionConc[4]*1000;y[33]=S.ionRad[4]*1e-10;
	// Solution Properties
	y[34]=S.dielectric;y[35]=Debye;y[36]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps1=integrate_adaptive(controlled_stepper,homogeneous_form_5ion,y,r0,rf,dr,push_back_state_and_time(y1,r1));
	int Sz1=steps1+1;
	if(VERBOSE){cout<<"Done! ("<<Sz1<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 2nd Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=1/(r0*r0);y[10]=-2/(r0*r0*r0);
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fiveth Ion
	y[15]=0;y[16]=0;
	// Constants
	y[17]=S.temperature;y[18]=S.numIon;
	// Fist Ion Properties
	y[19]=S.ionVal[0];y[20]=S.ionConc[0]*1000;y[21]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[22]=S.ionVal[1];y[23]=S.ionConc[1]*1000;y[24]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[25]=S.ionVal[2];y[26]=S.ionConc[2]*1000;y[27]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[28]=S.ionVal[3];y[29]=S.ionConc[3]*1000;y[30]=S.ionRad[3]*1e-10;
	// Fiveth Ion Properties
	y[31]=S.ionVal[4];y[32]=S.ionConc[4]*1000;y[33]=S.ionRad[4]*1e-10;
	// Solution Properties
	y[34]=S.dielectric;y[35]=Debye;y[36]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps2=integrate_adaptive(controlled_stepper,homogeneous_form_5ion,y,r0,rf,dr,push_back_state_and_time(y2,r2));
	int Sz2=steps2+1;
	if(VERBOSE){cout<<"Done! ("<<Sz2<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 3rd Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=1/(r0*r0);y[12]=-2/(r0*r0*r0);
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fiveth Ion
	y[15]=0;y[16]=0;
	// Constants
	y[17]=S.temperature;y[18]=S.numIon;
	// Fist Ion Properties
	y[19]=S.ionVal[0];y[20]=S.ionConc[0]*1000;y[21]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[22]=S.ionVal[1];y[23]=S.ionConc[1]*1000;y[24]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[25]=S.ionVal[2];y[26]=S.ionConc[2]*1000;y[27]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[28]=S.ionVal[3];y[29]=S.ionConc[3]*1000;y[30]=S.ionRad[3]*1e-10;
	// Fiveth Ion Properties
	y[31]=S.ionVal[4];y[32]=S.ionConc[4]*1000;y[33]=S.ionRad[4]*1e-10;
	// Solution Properties
	y[34]=S.dielectric;y[35]=Debye;y[36]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps3=integrate_adaptive(controlled_stepper,homogeneous_form_5ion,y,r0,rf,dr,push_back_state_and_time(y3,r3));
	int Sz3=steps3+1;
	if(VERBOSE){cout<<"Done! ("<<Sz3<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 4th Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=1/(r0*r0);y[14]=-2/(r0*r0*r0);
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Constants
	y[17]=S.temperature;y[18]=S.numIon;
	// Fist Ion Properties
	y[19]=S.ionVal[0];y[20]=S.ionConc[0]*1000;y[21]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[22]=S.ionVal[1];y[23]=S.ionConc[1]*1000;y[24]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[25]=S.ionVal[2];y[26]=S.ionConc[2]*1000;y[27]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[28]=S.ionVal[3];y[29]=S.ionConc[3]*1000;y[30]=S.ionRad[3]*1e-10;
	// Fiveth Ion Properties
	y[31]=S.ionVal[4];y[32]=S.ionConc[4]*1000;y[33]=S.ionRad[4]*1e-10;
	// Solution Properties
	y[34]=S.dielectric;y[35]=Debye;y[36]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps4=integrate_adaptive(controlled_stepper,homogeneous_form_5ion,y,r0,rf,dr,push_back_state_and_time(y4,r4));
	int Sz4=steps4+1;
	if(VERBOSE){cout<<"Done! ("<<Sz4<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 5th Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=1/(r0*r0);y[16]=-2/(r0*r0*r0);
	// Constants
	y[17]=S.temperature;y[18]=S.numIon;
	// Fist Ion Properties
	y[19]=S.ionVal[0];y[20]=S.ionConc[0]*1000;y[21]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[22]=S.ionVal[1];y[23]=S.ionConc[1]*1000;y[24]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[25]=S.ionVal[2];y[26]=S.ionConc[2]*1000;y[27]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[28]=S.ionVal[3];y[29]=S.ionConc[3]*1000;y[30]=S.ionRad[3]*1e-10;
	// Fiveth Ion Properties
	y[31]=S.ionVal[4];y[32]=S.ionConc[4]*1000;y[33]=S.ionRad[4]*1e-10;
	// Solution Properties
	y[34]=S.dielectric;y[35]=Debye;y[36]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps5=integrate_adaptive(controlled_stepper,homogeneous_form_5ion,y,r0,rf,dr,push_back_state_and_time(y5,r5));
	int Sz5=steps5+1;
	if(VERBOSE){cout<<"Done! ("<<Sz5<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 1st f term...";}
	// F Function
	y[0]=r0;y[1]=1;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Constants
	y[17]=S.temperature;y[18]=S.numIon;
	// Fist Ion Properties
	y[19]=S.ionVal[0];y[20]=S.ionConc[0]*1000;y[21]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[22]=S.ionVal[1];y[23]=S.ionConc[1]*1000;y[24]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[25]=S.ionVal[2];y[26]=S.ionConc[2]*1000;y[27]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[28]=S.ionVal[3];y[29]=S.ionConc[3]*1000;y[30]=S.ionRad[3]*1e-10;
	// Fiveth Ion Properties
	y[31]=S.ionVal[4];y[32]=S.ionConc[4]*1000;y[33]=S.ionRad[4]*1e-10;
	// Solution Properties
	y[34]=S.dielectric;y[35]=Debye;y[36]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps6=integrate_adaptive(controlled_stepper,homogeneous_form_5ion,y,r0,rf,dr,push_back_state_and_time(y6,r6));
	int Sz6=steps6+1;
	if(VERBOSE){cout<<"Done! ("<<Sz6<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 2nd f term...";}
	// F Function
	y[0]=1/r0;y[1]=-1/(r0*r0);y[2]=2/(r0*r0*r0);y[3]=-6/(r0*r0*r0*r0);y[4]=24/(r0*r0*r0*r0*r0);
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Constants
	y[17]=S.temperature;y[18]=S.numIon;
	// Fist Ion Properties
	y[19]=S.ionVal[0];y[20]=S.ionConc[0]*1000;y[21]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[22]=S.ionVal[1];y[23]=S.ionConc[1]*1000;y[24]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[25]=S.ionVal[2];y[26]=S.ionConc[2]*1000;y[27]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[28]=S.ionVal[3];y[29]=S.ionConc[3]*1000;y[30]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[31]=S.ionVal[4];y[32]=S.ionConc[4]*1000;y[33]=S.ionRad[4]*1e-10;
	// Solution Properties
	y[34]=S.dielectric;y[35]=Debye;y[36]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps7=integrate_adaptive(controlled_stepper,homogeneous_form_5ion,y,r0,rf,dr,push_back_state_and_time(y7,r7));
	int Sz7=steps7+1;
	if(VERBOSE){cout<<"Done! ("<<Sz7<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Flow Field Problem...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Constants
	y[17]=S.temperature;y[18]=S.numIon;
	// Fist Ion Properties
	y[19]=S.ionVal[0];y[20]=S.ionConc[0]*1000;y[21]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[22]=S.ionVal[1];y[23]=S.ionConc[1]*1000;y[24]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[25]=S.ionVal[2];y[26]=S.ionConc[2]*1000;y[27]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[28]=S.ionVal[3];y[29]=S.ionConc[3]*1000;y[30]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[31]=S.ionVal[4];y[32]=S.ionConc[4]*1000;y[33]=S.ionRad[4]*1e-10;
	// Solution Properties
	y[34]=S.dielectric;y[35]=Debye;y[36]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps8=integrate_adaptive(controlled_stepper,inhomogeneous_Prob1_5ion,y,r0,rf,dr,push_back_state_and_time(y8,r8));
	int Sz8=steps8+1;
	if(VERBOSE){cout<<"Done! ("<<Sz8<<" points)"<<endl;}

	if(VERBOSE){cout<<"Calculating Asymptotic Constants...";}
	alglib::real_2d_array A;
	alglib::real_1d_array C1,B1;
	// Define System Matrix containing coefficients of linear system
	A.setlength(7,7);
	for(int i=0;i<7;i++)
		{for(int j=0;j<7;j++)
			{A[i][j]=0;}}
	// d(IEP1)/dr
	A[0][0]=y1[Sz1-1][8];A[0][1]=y2[Sz2-1][8];A[0][2]=y3[Sz3-1][8];A[0][3]=y4[Sz4-1][8];A[0][4]=y5[Sz5-1][8];A[0][5]=y6[Sz6-1][8];A[0][6]=y7[Sz7-1][8];
	// d(IEP2)/dr
	A[1][0]=y1[Sz1-1][10];A[1][1]=y2[Sz2-1][10];A[1][2]=y3[Sz3-1][10];A[1][3]=y4[Sz4-1][10];A[1][4]=y5[Sz5-1][10];A[1][5]=y6[Sz6-1][10];A[1][6]=y7[Sz7-1][10];
	// d(IEP3)/dr
	A[2][0]=y1[Sz1-1][12];A[2][1]=y2[Sz2-1][12];A[2][2]=y3[Sz3-1][12];A[2][3]=y4[Sz4-1][12];A[2][4]=y5[Sz5-1][12];A[2][5]=y6[Sz6-1][12];A[2][6]=y7[Sz7-1][12];
	// d(IEP4)/dr
	A[3][0]=y1[Sz1-1][14];A[3][1]=y2[Sz2-1][14];A[3][2]=y3[Sz3-1][14];A[3][3]=y4[Sz4-1][14];A[3][4]=y5[Sz5-1][14];A[3][5]=y6[Sz6-1][14];A[3][6]=y7[Sz7-1][14];
	// d(IEP5)/dr
	A[4][0]=y1[Sz1-1][16];A[4][1]=y2[Sz2-1][16];A[4][2]=y3[Sz3-1][16];A[4][3]=y4[Sz4-1][16];A[4][4]=y5[Sz5-1][16];A[4][5]=y6[Sz6-1][16];A[4][6]=y7[Sz7-1][16];
	// f 1st (df/dr)
	A[5][0]=y1[Sz1-1][1];A[5][1]=y2[Sz2-1][1];A[5][2]=y3[Sz3-1][1];A[5][3]=y4[Sz4-1][1];A[5][4]=y5[Sz5-1][1];A[5][5]=y6[Sz6-1][1];A[5][6]=y7[Sz7-1][1];
	// f 2nd (d2f/dr2)
	A[6][0]=y1[Sz1-1][2];A[6][1]=y2[Sz2-1][2];A[6][2]=y3[Sz3-1][2];A[6][3]=y4[Sz4-1][2];A[6][4]=y5[Sz5-1][2];A[6][5]=y6[Sz6-1][2];A[6][6]=y7[Sz7-1][2];
	// Define Solution Matrix for Problem #1
	B1.setlength(7);
	// d(IEP1)/dr = 0
	B1[0]=0-y8[Sz8-1][8];
	// d(IEP2)/dr = 0
	B1[1]=0-y8[Sz8-1][10];
	// d(IEP3)/dr = 0
	B1[2]=0-y8[Sz8-1][12];
	// d(IEP4)/dr = 0
	B1[3]=0-y8[Sz8-1][14];
	// d(IEP5)/dr = 0
	B1[4]=0-y8[Sz8-1][16];
	// df/dr = -Radius/2
	B1[5]=-a/2 - y8[Sz8-1][1];
	// d2f/dr2 = -0.5
	B1[6]=-0.5 - y8[Sz8-1][2];
	// Create Output Parameters
	alglib::ae_int_t info;
	alglib::densesolverreport rep;
	alglib::rmatrixsolve(A,7,B1,info,rep,C1);
	if(VERBOSE)
		{cout<<"\n";
		cout<<C1[0]*A[0][0] + C1[1]*A[0][1] + C1[2]*A[0][2] + C1[3]*A[0][3] + C1[4]*A[0][4] + C1[5]*A[0][5] + C1[6]*A[0][6] + y8[Sz8-1][8]<<endl;
		cout<<C1[0]*A[1][0] + C1[1]*A[1][1] + C1[2]*A[1][2] + C1[3]*A[1][3] + C1[4]*A[1][4] + C1[5]*A[1][5] + C1[6]*A[1][6] + y8[Sz8-1][10]<<endl;
		cout<<C1[0]*A[2][0] + C1[1]*A[2][1] + C1[2]*A[2][2] + C1[3]*A[2][3] + C1[4]*A[2][4] + C1[5]*A[2][5] + C1[6]*A[2][6] + y8[Sz8-1][12]<<endl;
		cout<<C1[0]*A[3][0] + C1[1]*A[3][1] + C1[2]*A[3][2] + C1[3]*A[3][3] + C1[4]*A[3][4] + C1[5]*A[3][5] + C1[6]*A[3][6] + y8[Sz8-1][14]<<endl;
		cout<<C1[0]*A[4][0] + C1[1]*A[4][1] + C1[2]*A[4][2] + C1[3]*A[4][3] + C1[4]*A[4][4] + C1[5]*A[4][5] + C1[6]*A[4][6] + y8[Sz8-1][16]<<endl;
		cout<<C1[0]*A[5][0] + C1[1]*A[5][1] + C1[2]*A[5][2] + C1[3]*A[5][3] + C1[4]*A[5][4] + C1[5]*A[5][5] + C1[6]*A[5][6] + y8[Sz8-1][1]<<endl;
		cout<<C1[0]*A[6][0] + C1[1]*A[6][1] + C1[2]*A[6][2] + C1[3]*A[6][3] + C1[4]*A[6][4] + C1[5]*A[6][5] + C1[6]*A[6][6] + y8[Sz8-1][2]<<endl;
		cout<<"Done!"<<endl;
		cout<<"C1_1 = "<<C1[0]<<endl;
		cout<<"C2_1 = "<<C1[1]<<endl;
		cout<<"C3_1 = "<<C1[2]<<endl;
		cout<<"C4_1 = "<<C1[3]<<endl;
		cout<<"C5_1 = "<<C1[4]<<endl;
		cout<<"C6_1 = "<<C1[5]<<endl;
		cout<<"C7_1 = "<<C1[6]<<endl;}

	if(VERBOSE){cout<<"Solving Electric Field Problem...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Constants
	y[17]=S.temperature;y[18]=S.numIon;
	// Fist Ion Properties
	y[19]=S.ionVal[0];y[20]=S.ionConc[0]*1000;y[21]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[22]=S.ionVal[1];y[23]=S.ionConc[1]*1000;y[24]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[25]=S.ionVal[2];y[26]=S.ionConc[2]*1000;y[27]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[28]=S.ionVal[3];y[29]=S.ionConc[3]*1000;y[30]=S.ionRad[3]*1e-10;
	// Fiveth Ion Properties
	y[31]=S.ionVal[4];y[32]=S.ionConc[4]*1000;y[33]=S.ionRad[4]*1e-10;
	// Solution Properties
	y[34]=S.dielectric;y[35]=Debye;y[36]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps9=integrate_adaptive(controlled_stepper,inhomogeneous_Prob2_5ion,y,r0,rf,dr,push_back_state_and_time(y9,r9));
	int Sz9=steps9+1;
	if(VERBOSE){cout<<"Done! ("<<Sz9<<" points)"<<endl;}

	if(VERBOSE){cout<<"Calculating Asymptotic Constants...";}
	alglib::real_1d_array C2,B2;
	// d(IEP1)/dr
	A[0][0]=y1[Sz1-1][8];A[0][1]=y2[Sz2-1][8];A[0][2]=y3[Sz3-1][8];A[0][3]=y4[Sz4-1][8];A[0][4]=y5[Sz5-1][8];A[0][5]=y6[Sz6-1][8];A[0][6]=y7[Sz7-1][8];
	// d(IEP2)/dr
	A[1][0]=y1[Sz1-1][10];A[1][1]=y2[Sz2-1][10];A[1][2]=y3[Sz3-1][10];A[1][3]=y4[Sz4-1][10];A[1][4]=y5[Sz5-1][10];A[1][5]=y6[Sz6-1][10];A[1][6]=y7[Sz7-1][10];
	// d(IEP3)/dr
	A[2][0]=y1[Sz1-1][12];A[2][1]=y2[Sz2-1][12];A[2][2]=y3[Sz3-1][12];A[2][3]=y4[Sz4-1][12];A[2][4]=y5[Sz5-1][12];A[2][5]=y6[Sz6-1][12];A[2][6]=y7[Sz7-1][12];
	// d(IEP4)/dr
	A[3][0]=y1[Sz1-1][14];A[3][1]=y2[Sz2-1][14];A[3][2]=y3[Sz3-1][14];A[3][3]=y4[Sz4-1][14];A[3][4]=y5[Sz5-1][14];A[3][5]=y6[Sz6-1][14];A[3][6]=y7[Sz7-1][14];
	// d(IEP5)/dr
	A[4][0]=y1[Sz1-1][16];A[4][1]=y2[Sz2-1][16];A[4][2]=y3[Sz3-1][16];A[4][3]=y4[Sz4-1][16];A[4][4]=y5[Sz5-1][16];A[4][5]=y6[Sz6-1][16];A[4][6]=y7[Sz7-1][16];
	// f 1st (df/dr)
	A[5][0]=y1[Sz1-1][1];A[5][1]=y2[Sz2-1][1];A[5][2]=y3[Sz3-1][1];A[5][3]=y4[Sz4-1][1];A[5][4]=y5[Sz5-1][1];A[5][5]=y6[Sz6-1][1];A[5][6]=y7[Sz7-1][1];
	// f 2nd (d2f/dr2)
	A[6][0]=y1[Sz1-1][2];A[6][1]=y2[Sz2-1][2];A[6][2]=y3[Sz3-1][2];A[6][3]=y4[Sz4-1][2];A[6][4]=y5[Sz5-1][2];A[6][5]=y6[Sz6-1][2];A[6][6]=y7[Sz7-1][2];
	// Define Solution Matrix for Problem #2
	B2.setlength(7);
	// d(IEP1)/dr = -1
	B2[0]=-1-y9[Sz9-1][8];
	// d(IEP2)/dr = -1
	B2[1]=-1-y9[Sz9-1][10];
	// d(IEP3)/dr = -1
	B2[2]=-1-y9[Sz9-1][12];
	// d(IEP4)/dr = -1
	B2[3]=-1-y9[Sz9-1][14];
	// d(IEP5)/dr = -1
	B2[4]=-1-y9[Sz9-1][16];
	// df/dr = 0
	B2[5]=0-y9[Sz9-1][1];
	// d2f/dr2 = 0
	B2[6]=0-y9[Sz9-1][2];
	// Create Output Parameters
	alglib::rmatrixsolve(A,7,B2,info,rep,C2);
	if(VERBOSE)
		{cout<<"\n";
		cout<<C2[0]*A[0][0] + C2[1]*A[0][1] + C2[2]*A[0][2] + C2[3]*A[0][3] + C2[4]*A[0][4] + C2[5]*A[0][5] + C2[6]*A[0][6] + y9[Sz9-1][8]<<endl;
		cout<<C2[0]*A[1][0] + C2[1]*A[1][1] + C2[2]*A[1][2] + C2[3]*A[1][3] + C2[4]*A[1][4] + C2[5]*A[1][5] + C2[6]*A[1][6] + y9[Sz9-1][10]<<endl;
		cout<<C2[0]*A[2][0] + C2[1]*A[2][1] + C2[2]*A[2][2] + C2[3]*A[2][3] + C2[4]*A[2][4] + C2[5]*A[2][5] + C2[6]*A[2][6] + y9[Sz9-1][12]<<endl;
		cout<<C2[0]*A[3][0] + C2[1]*A[3][1] + C2[2]*A[3][2] + C2[3]*A[3][3] + C2[4]*A[3][4] + C2[5]*A[3][5] + C2[6]*A[3][6] + y9[Sz9-1][14]<<endl;
		cout<<C2[0]*A[4][0] + C2[1]*A[4][1] + C2[2]*A[4][2] + C2[3]*A[4][3] + C2[4]*A[4][4] + C2[5]*A[4][5] + C2[6]*A[4][6] + y9[Sz9-1][16]<<endl;
		cout<<C2[0]*A[5][0] + C2[1]*A[5][1] + C2[2]*A[5][2] + C2[3]*A[5][3] + C2[4]*A[5][4] + C2[5]*A[5][5] + C2[6]*A[5][6] + y9[Sz9-1][1]<<endl;
		cout<<C2[0]*A[6][0] + C2[1]*A[6][1] + C2[2]*A[6][2] + C2[3]*A[6][3] + C2[4]*A[6][4] + C2[5]*A[6][5] + C2[6]*A[6][6] + y9[Sz9-1][2]<<endl;
		cout<<"Done!"<<endl;
		cout<<"C1_2 = "<<C2[0]<<endl;
		cout<<"C2_2 = "<<C2[1]<<endl;
		cout<<"C3_2 = "<<C2[2]<<endl;
		cout<<"C4_2 = "<<C2[3]<<endl;
		cout<<"C5_2 = "<<C2[4]<<endl;
		cout<<"C6_2 = "<<C2[5]<<endl;
		cout<<"C7_2 = "<<C2[6]<<endl;}

	double mobility=-C2[5]/C1[5];
	
	if(VERBOSE)
		{cout<<"\n\nElectrophoretic Mobility:\t"<<mobility<<" m^2/Vs\n";
		cout<<"ka:\t\t"<<a/Debye<<endl;
		cout<<"Zeta Potential:\t"<<ZP<<" V\n";
		cout<<"E:\t\t"<<3*S.viscosity*ec*mobility/(2*eo*S.dielectric*kb*S.temperature)<<endl;
		cout<<"y:\t\t"<<ec*ZP/(kb*S.temperature)<<endl;}

	return mobility;}

double six_ion_problem(double ZP,double a,Solution S,Error E,bool VERBOSE)
	{// Convert Debye Length from Angstroms to Meters
	double Debye=S.debyeLength*1e-10;
	// Final Position: Solvated Radius [meters]
	double rf=a;
	double r0;
	double dr=-1e-15;	// integrate from Inf to Protein Radius
	if(Debye>a){r0=5*Debye;}
	else{r0=5*a;}
		
	if(VERBOSE){cout<<"6 ION PROBLEM\nInitial Position:\t"<<r0<<" m"<<"\nFinal Position:\t\t"<<rf<<" m"<<"\nStep Size:\t\t"<<dr<<" m"<<endl;}

	// Calculate Poisson Boltzmann Coefficient and Determine Initial Position away from Protein
	double C=calc_PBE_coefficient(ZP,r0,rf,dr,S,E,VERBOSE);
	if(VERBOSE){cout<<"PBE Coeff: "<<C<<endl;}
	if(isnan(C)){return nan("");}
	int N=7+2*S.numIon+2+3*S.numIon+3;//42;
	state_type y(N);
	// F Function
	// y[0] = f
	// y[1] = df/dr
	// y[2] = d2f/dr2
	// y[3] = d3f/dr3
	// y[4] = d4f/dr4
	// Equilibrium Electric Pontential
	// y[5] = potential
	// y[6] = d(potential)/dr
	// Induced Electrochemical Potential Function (6 ion)
	// y[7] = IEP1
	// y[8] = d(IEP1)/dr
	// y[9] = IEP2
	// y[10] = d(IEP2)/dr
	// y[11] = IEP3
	// y[12] = d(IEP3)/dr
	// y[13] = IEP4
	// y[14] = d(IEP4)/dr
	// y[15] = IEP5
	// y[16] = d(IEP5)/dr
	// y[17] = IEP6
	// y[18] = d(IEP6)/dr
	// Constants
	// y[19] = Temp					// [Kelvin]
	// y[20] = numIon
	// Ion Properties
	// y[21] = Ion1.val;		
	// y[22] = Ion1.conc;		// mM [mol/m^3]
	// y[23] = Ion1.radius;		// meters
	// y[24] = Ion2.val;
	// y[25] = Ion2.conc;
	// y[26] = Ion2.radius;
	// y[27] = Ion3.val;
	// y[28] = Ion3.conc;
	// y[29] = Ion3.radius;
	// y[30] = Ion4.val;
	// y[31] = Ion4.conc;
	// y[32] = Ion4.radius;
	// y[33] = Ion5.val;
	// y[34] = Ion5.conc;
	// y[35] = Ion5.radius;
	// y[36] = Ion6.val;
	// y[37] = Ion6.conc;
	// y[38] = Ion6.radius;
	// Solution Properties
	// y[39] = relative dielectric	[dimensionless]
	// y[40] = Debye Length [meters]
	// y[41] = viscosity  [Pa s]
	// Collect Error Data
	double abs_err=E.absolute;
	double rel_err=E.relative;
	double a_x=E.a_x;
	double a_dxdt=E.a_dxdt;
	controlled_stepper_type controlled_stepper(default_error_checker<double,range_algebra,default_operations>(abs_err,rel_err,a_x,a_dxdt));	

	// Calculate Mobility
	vector<state_type> y1,y2,y3,y4,y5,y6,y7,y8,y9,y10;
	vector<double> r1,r2,r3,r4,r5,r6,r7,r8,r9,r10;
	// Specify Boundary Conditions / Initial Values Infinitely Far from the Particle
	if(VERBOSE){cout<<"Solving Homogeneous Problem for 1st Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=1/(r0*r0);y[8]=-2/(r0*r0*r0);
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Constants
	y[19]=S.temperature;y[20]=S.numIon;
	// Fist Ion Properties
	y[21]=S.ionVal[0];y[22]=S.ionConc[0]*1000;y[23]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[24]=S.ionVal[1];y[25]=S.ionConc[1]*1000;y[26]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[27]=S.ionVal[2];y[28]=S.ionConc[2]*1000;y[29]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[30]=S.ionVal[3];y[31]=S.ionConc[3]*1000;y[32]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[33]=S.ionVal[4];y[34]=S.ionConc[4]*1000;y[35]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[36]=S.ionVal[5];y[37]=S.ionConc[5]*1000;y[38]=S.ionRad[5]*1e-10;
	// Solution Properties
	y[39]=S.dielectric;y[40]=Debye;y[41]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps1=integrate_adaptive(controlled_stepper,homogeneous_form_6ion,y,r0,rf,dr,push_back_state_and_time(y1,r1));
	int Sz1=steps1+1;
	if(VERBOSE){cout<<"Done! ("<<Sz1<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 2nd Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=1/(r0*r0);y[10]=-2/(r0*r0*r0);
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Constants
	y[19]=S.temperature;y[20]=S.numIon;
	// Fist Ion Properties
	y[21]=S.ionVal[0];y[22]=S.ionConc[0]*1000;y[23]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[24]=S.ionVal[1];y[25]=S.ionConc[1]*1000;y[26]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[27]=S.ionVal[2];y[28]=S.ionConc[2]*1000;y[29]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[30]=S.ionVal[3];y[31]=S.ionConc[3]*1000;y[32]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[33]=S.ionVal[4];y[34]=S.ionConc[4]*1000;y[35]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[36]=S.ionVal[5];y[37]=S.ionConc[5]*1000;y[38]=S.ionRad[5]*1e-10;
	// Solution Properties
	y[39]=S.dielectric;y[40]=Debye;y[41]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps2=integrate_adaptive(controlled_stepper,homogeneous_form_6ion,y,r0,rf,dr,push_back_state_and_time(y2,r2));
	int Sz2=steps2+1;
	if(VERBOSE){cout<<"Done! ("<<Sz2<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 3rd Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=1/(r0*r0);y[12]=-2/(r0*r0*r0);
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Constants
	y[19]=S.temperature;y[20]=S.numIon;
	// Fist Ion Properties
	y[21]=S.ionVal[0];y[22]=S.ionConc[0]*1000;y[23]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[24]=S.ionVal[1];y[25]=S.ionConc[1]*1000;y[26]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[27]=S.ionVal[2];y[28]=S.ionConc[2]*1000;y[29]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[30]=S.ionVal[3];y[31]=S.ionConc[3]*1000;y[32]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[33]=S.ionVal[4];y[34]=S.ionConc[4]*1000;y[35]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[36]=S.ionVal[5];y[37]=S.ionConc[5]*1000;y[38]=S.ionRad[5]*1e-10;
	// Solution Properties
	y[39]=S.dielectric;y[40]=Debye;y[41]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps3=integrate_adaptive(controlled_stepper,homogeneous_form_6ion,y,r0,rf,dr,push_back_state_and_time(y3,r3));
	int Sz3=steps3+1;
	if(VERBOSE){cout<<"Done! ("<<Sz3<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 4th Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=1/(r0*r0);y[14]=-2/(r0*r0*r0);
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Constants
	y[19]=S.temperature;y[20]=S.numIon;
	// Fist Ion Properties
	y[21]=S.ionVal[0];y[22]=S.ionConc[0]*1000;y[23]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[24]=S.ionVal[1];y[25]=S.ionConc[1]*1000;y[26]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[27]=S.ionVal[2];y[28]=S.ionConc[2]*1000;y[29]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[30]=S.ionVal[3];y[31]=S.ionConc[3]*1000;y[32]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[33]=S.ionVal[4];y[34]=S.ionConc[4]*1000;y[35]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[36]=S.ionVal[5];y[37]=S.ionConc[5]*1000;y[38]=S.ionRad[5]*1e-10;
	// Solution Properties
	y[39]=S.dielectric;y[40]=Debye;y[41]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps4=integrate_adaptive(controlled_stepper,homogeneous_form_6ion,y,r0,rf,dr,push_back_state_and_time(y4,r4));
	int Sz4=steps4+1;
	if(VERBOSE){cout<<"Done! ("<<Sz4<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 5th Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=1/(r0*r0);y[16]=-2/(r0*r0*r0);
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Constants
	y[19]=S.temperature;y[20]=S.numIon;
	// Fist Ion Properties
	y[21]=S.ionVal[0];y[22]=S.ionConc[0]*1000;y[23]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[24]=S.ionVal[1];y[25]=S.ionConc[1]*1000;y[26]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[27]=S.ionVal[2];y[28]=S.ionConc[2]*1000;y[29]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[30]=S.ionVal[3];y[31]=S.ionConc[3]*1000;y[32]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[33]=S.ionVal[4];y[34]=S.ionConc[4]*1000;y[35]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[36]=S.ionVal[5];y[37]=S.ionConc[5]*1000;y[38]=S.ionRad[5]*1e-10;
	// Solution Properties
	y[39]=S.dielectric;y[40]=Debye;y[41]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps5=integrate_adaptive(controlled_stepper,homogeneous_form_6ion,y,r0,rf,dr,push_back_state_and_time(y5,r5));
	int Sz5=steps5+1;
	if(VERBOSE){cout<<"Done! ("<<Sz5<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 6th Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=1/(r0*r0);y[18]=-2/(r0*r0*r0);
	// Constants
	y[19]=S.temperature;y[20]=S.numIon;
	// Fist Ion Properties
	y[21]=S.ionVal[0];y[22]=S.ionConc[0]*1000;y[23]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[24]=S.ionVal[1];y[25]=S.ionConc[1]*1000;y[26]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[27]=S.ionVal[2];y[28]=S.ionConc[2]*1000;y[29]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[30]=S.ionVal[3];y[31]=S.ionConc[3]*1000;y[32]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[33]=S.ionVal[4];y[34]=S.ionConc[4]*1000;y[35]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[36]=S.ionVal[5];y[37]=S.ionConc[5]*1000;y[38]=S.ionRad[5]*1e-10;
	// Solution Properties
	y[39]=S.dielectric;y[40]=Debye;y[41]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps6=integrate_adaptive(controlled_stepper,homogeneous_form_6ion,y,r0,rf,dr,push_back_state_and_time(y6,r6));
	int Sz6=steps6+1;
	if(VERBOSE){cout<<"Done! ("<<Sz6<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 1st f term...";}
	// F Function
	y[0]=r0;y[1]=1;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Constants
	y[19]=S.temperature;y[20]=S.numIon;
	// Fist Ion Properties
	y[21]=S.ionVal[0];y[22]=S.ionConc[0]*1000;y[23]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[24]=S.ionVal[1];y[25]=S.ionConc[1]*1000;y[26]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[27]=S.ionVal[2];y[28]=S.ionConc[2]*1000;y[29]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[30]=S.ionVal[3];y[31]=S.ionConc[3]*1000;y[32]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[33]=S.ionVal[4];y[34]=S.ionConc[4]*1000;y[35]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[36]=S.ionVal[5];y[37]=S.ionConc[5]*1000;y[38]=S.ionRad[5]*1e-10;
	// Solution Properties
	y[39]=S.dielectric;y[40]=Debye;y[41]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps7=integrate_adaptive(controlled_stepper,homogeneous_form_6ion,y,r0,rf,dr,push_back_state_and_time(y7,r7));
	int Sz7=steps7+1;
	if(VERBOSE){cout<<"Done! ("<<Sz7<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 2nd f term...";}
	// F Function
	y[0]=1/r0;y[1]=-1/(r0*r0);y[2]=2/(r0*r0*r0);y[3]=-6/(r0*r0*r0*r0);y[4]=24/(r0*r0*r0*r0*r0);
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Constants
	y[19]=S.temperature;y[20]=S.numIon;
	// Fist Ion Properties
	y[21]=S.ionVal[0];y[22]=S.ionConc[0]*1000;y[23]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[24]=S.ionVal[1];y[25]=S.ionConc[1]*1000;y[26]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[27]=S.ionVal[2];y[28]=S.ionConc[2]*1000;y[29]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[30]=S.ionVal[3];y[31]=S.ionConc[3]*1000;y[32]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[33]=S.ionVal[4];y[34]=S.ionConc[4]*1000;y[35]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[36]=S.ionVal[5];y[37]=S.ionConc[5]*1000;y[38]=S.ionRad[5]*1e-10;
	// Solution Properties
	y[39]=S.dielectric;y[40]=Debye;y[41]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps8=integrate_adaptive(controlled_stepper,homogeneous_form_6ion,y,r0,rf,dr,push_back_state_and_time(y8,r8));
	int Sz8=steps8+1;
	if(VERBOSE){cout<<"Done! ("<<Sz8<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Flow Field Problem...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Constants
	y[19]=S.temperature;y[20]=S.numIon;
	// Fist Ion Properties
	y[21]=S.ionVal[0];y[22]=S.ionConc[0]*1000;y[23]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[24]=S.ionVal[1];y[25]=S.ionConc[1]*1000;y[26]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[27]=S.ionVal[2];y[28]=S.ionConc[2]*1000;y[29]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[30]=S.ionVal[3];y[31]=S.ionConc[3]*1000;y[32]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[33]=S.ionVal[4];y[34]=S.ionConc[4]*1000;y[35]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[36]=S.ionVal[5];y[37]=S.ionConc[5]*1000;y[38]=S.ionRad[5]*1e-10;
	// Solution Properties
	y[39]=S.dielectric;y[40]=Debye;y[41]=S.viscosity;
	// Solve
	size_t steps9=integrate_adaptive(controlled_stepper,inhomogeneous_Prob1_6ion,y,r0,rf,dr,push_back_state_and_time(y9,r9));
	int Sz9=steps9+1;
	if(VERBOSE){cout<<"Done! ("<<Sz9<<" points)"<<endl;}

	if(VERBOSE){cout<<"Calculating Asymptotic Constants...";}
	alglib::real_2d_array A;
	alglib::real_1d_array C1,B1;
	// Define System Matrix containing coefficients of linear system
	A.setlength(8,8);
	for(int i=0;i<8;i++)
		{for(int j=0;j<8;j++)
			{A[i][j]=0;}}
	// d(IEP1)/dr
	A[0][0]=y1[Sz1-1][8];A[0][1]=y2[Sz2-1][8];A[0][2]=y3[Sz3-1][8];A[0][3]=y4[Sz4-1][8];A[0][4]=y5[Sz5-1][8];A[0][5]=y6[Sz6-1][8];A[0][6]=y7[Sz7-1][8];A[0][7]=y8[Sz8-1][8];
	// d(IEP2)/dr
	A[1][0]=y1[Sz1-1][10];A[1][1]=y2[Sz2-1][10];A[1][2]=y3[Sz3-1][10];A[1][3]=y4[Sz4-1][10];A[1][4]=y5[Sz5-1][10];A[1][5]=y6[Sz6-1][10];A[1][6]=y7[Sz7-1][10];A[1][7]=y8[Sz8-1][10];
	// d(IEP3)/dr
	A[2][0]=y1[Sz1-1][12];A[2][1]=y2[Sz2-1][12];A[2][2]=y3[Sz3-1][12];A[2][3]=y4[Sz4-1][12];A[2][4]=y5[Sz5-1][12];A[2][5]=y6[Sz6-1][12];A[2][6]=y7[Sz7-1][12];A[2][7]=y8[Sz8-1][12];
	// d(IEP4)/dr
	A[3][0]=y1[Sz1-1][14];A[3][1]=y2[Sz2-1][14];A[3][2]=y3[Sz3-1][14];A[3][3]=y4[Sz4-1][14];A[3][4]=y5[Sz5-1][14];A[3][5]=y6[Sz6-1][14];A[3][6]=y7[Sz7-1][14];A[3][7]=y8[Sz8-1][14];
	// d(IEP5)/dr
	A[4][0]=y1[Sz1-1][16];A[4][1]=y2[Sz2-1][16];A[4][2]=y3[Sz3-1][16];A[4][3]=y4[Sz4-1][16];A[4][4]=y5[Sz5-1][16];A[4][5]=y6[Sz6-1][16];A[4][6]=y7[Sz7-1][16];A[4][7]=y8[Sz8-1][16];
	// d(IEP6)/dr
	A[5][0]=y1[Sz1-1][18];A[5][1]=y2[Sz2-1][18];A[5][2]=y3[Sz3-1][18];A[5][3]=y4[Sz4-1][18];A[5][4]=y5[Sz5-1][18];A[5][5]=y6[Sz6-1][18];A[5][6]=y7[Sz7-1][18];A[5][7]=y8[Sz8-1][18];
	// f 1st (df/dr)
	A[6][0]=y1[Sz1-1][1];A[6][1]=y2[Sz2-1][1];A[6][2]=y3[Sz3-1][1];A[6][3]=y4[Sz4-1][1];A[6][4]=y5[Sz5-1][1];A[6][5]=y6[Sz6-1][1];A[6][6]=y7[Sz7-1][1];A[6][7]=y8[Sz8-1][1];
	// f 2nd (d2f/dr2)
	A[7][0]=y1[Sz1-1][2];A[7][1]=y2[Sz2-1][2];A[7][2]=y3[Sz3-1][2];A[7][3]=y4[Sz4-1][2];A[7][4]=y5[Sz5-1][2];A[7][5]=y6[Sz6-1][2];A[7][6]=y7[Sz7-1][2];A[7][7]=y8[Sz8-1][2];
	// Define Solution Matrix for Problem #1
	B1.setlength(8);
	// d(IEP1)/dr = 0
	B1[0]=0-y9[Sz9-1][8];
	// d(IEP2)/dr = 0
	B1[1]=0-y9[Sz9-1][10];
	// d(IEP3)/dr = 0
	B1[2]=0-y9[Sz9-1][12];
	// d(IEP4)/dr = 0
	B1[3]=0-y9[Sz9-1][14];
	// d(IEP5)/dr = 0
	B1[4]=0-y9[Sz9-1][16];
	// d(IEP6)/dr = 0
	B1[5]=0-y9[Sz9-1][18];
	// df/dr = -Radius/2
	B1[6]=-a/2 - y9[Sz9-1][1];
	// d2f/dr2 = -0.5
	B1[7]=-0.5 - y9[Sz9-1][2];
	// Create Output Parameters
	alglib::ae_int_t info;
	alglib::densesolverreport rep;
	alglib::rmatrixsolve(A,8,B1,info,rep,C1);
	if(VERBOSE)
		{cout<<"\n";
		cout<<C1[0]*A[0][0] + C1[1]*A[0][1] + C1[2]*A[0][2] + C1[3]*A[0][3] + C1[4]*A[0][4] + C1[5]*A[0][5] + C1[6]*A[0][6] + C1[7]*A[0][7] + y9[Sz9-1][8]<<endl;
		cout<<C1[0]*A[1][0] + C1[1]*A[1][1] + C1[2]*A[1][2] + C1[3]*A[1][3] + C1[4]*A[1][4] + C1[5]*A[1][5] + C1[6]*A[1][6] + C1[7]*A[1][7] + y9[Sz9-1][10]<<endl;
		cout<<C1[0]*A[2][0] + C1[1]*A[2][1] + C1[2]*A[2][2] + C1[3]*A[2][3] + C1[4]*A[2][4] + C1[5]*A[2][5] + C1[6]*A[2][6] + C1[7]*A[2][7] + y9[Sz9-1][12]<<endl;
		cout<<C1[0]*A[3][0] + C1[1]*A[3][1] + C1[2]*A[3][2] + C1[3]*A[3][3] + C1[4]*A[3][4] + C1[5]*A[3][5] + C1[6]*A[3][6] + C1[7]*A[3][7] + y9[Sz9-1][14]<<endl;
		cout<<C1[0]*A[4][0] + C1[1]*A[4][1] + C1[2]*A[4][2] + C1[3]*A[4][3] + C1[4]*A[4][4] + C1[5]*A[4][5] + C1[6]*A[4][6] + C1[7]*A[4][7] + y9[Sz9-1][16]<<endl;
		cout<<C1[0]*A[5][0] + C1[1]*A[5][1] + C1[2]*A[5][2] + C1[3]*A[5][3] + C1[4]*A[5][4] + C1[5]*A[5][5] + C1[6]*A[5][6] + C1[7]*A[5][7] + y9[Sz9-1][18]<<endl;
		cout<<C1[0]*A[6][0] + C1[1]*A[6][1] + C1[2]*A[6][2] + C1[3]*A[6][3] + C1[4]*A[6][4] + C1[5]*A[6][5] + C1[6]*A[6][6] + C1[7]*A[6][7] + y9[Sz9-1][1]<<endl;
		cout<<C1[0]*A[7][0] + C1[1]*A[7][1] + C1[2]*A[7][2] + C1[3]*A[7][3] + C1[4]*A[7][4] + C1[5]*A[7][5] + C1[6]*A[7][6] + C1[7]*A[7][7] + y9[Sz9-1][2]<<endl;
		cout<<"Done!"<<endl;
		cout<<"C1_1 = "<<C1[0]<<endl;
		cout<<"C2_1 = "<<C1[1]<<endl;
		cout<<"C3_1 = "<<C1[2]<<endl;
		cout<<"C4_1 = "<<C1[3]<<endl;
		cout<<"C5_1 = "<<C1[4]<<endl;
		cout<<"C6_1 = "<<C1[5]<<endl;
		cout<<"C7_1 = "<<C1[6]<<endl;
		cout<<"C8_1 = "<<C1[7]<<endl;}

	if(VERBOSE){cout<<"Solving Electric Field Problem...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Constants
	y[19]=S.temperature;y[20]=S.numIon;
	// Fist Ion Properties
	y[21]=S.ionVal[0];y[22]=S.ionConc[0]*1000;y[23]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[24]=S.ionVal[1];y[25]=S.ionConc[1]*1000;y[26]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[27]=S.ionVal[2];y[28]=S.ionConc[2]*1000;y[29]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[30]=S.ionVal[3];y[31]=S.ionConc[3]*1000;y[32]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[33]=S.ionVal[4];y[34]=S.ionConc[4]*1000;y[35]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[36]=S.ionVal[5];y[37]=S.ionConc[5]*1000;y[38]=S.ionRad[5]*1e-10;
	// Solution Properties
	y[39]=S.dielectric;y[40]=Debye;y[41]=S.viscosity;
	// Solve
	size_t steps10=integrate_adaptive(controlled_stepper,inhomogeneous_Prob2_6ion,y,r0,rf,dr,push_back_state_and_time(y10,r10));
	int Sz10=steps10+1;
	if(VERBOSE){cout<<"Done! ("<<Sz10<<" points)"<<endl;}

	if(VERBOSE){cout<<"Calculating Asymptotic Constants...";}
	alglib::real_1d_array C2,B2;
	// d(IEP1)/dr
	A[0][0]=y1[Sz1-1][8];A[0][1]=y2[Sz2-1][8];A[0][2]=y3[Sz3-1][8];A[0][3]=y4[Sz4-1][8];A[0][4]=y5[Sz5-1][8];A[0][5]=y6[Sz6-1][8];A[0][6]=y7[Sz7-1][8];A[0][7]=y8[Sz8-1][8];
	// d(IEP2)/dr
	A[1][0]=y1[Sz1-1][10];A[1][1]=y2[Sz2-1][10];A[1][2]=y3[Sz3-1][10];A[1][3]=y4[Sz4-1][10];A[1][4]=y5[Sz5-1][10];A[1][5]=y6[Sz6-1][10];A[1][6]=y7[Sz7-1][10];A[1][7]=y8[Sz8-1][10];
	// d(IEP3)/dr
	A[2][0]=y1[Sz1-1][12];A[2][1]=y2[Sz2-1][12];A[2][2]=y3[Sz3-1][12];A[2][3]=y4[Sz4-1][12];A[2][4]=y5[Sz5-1][12];A[2][5]=y6[Sz6-1][12];A[2][6]=y7[Sz7-1][12];A[2][7]=y8[Sz8-1][12];
	// d(IEP4)/dr
	A[3][0]=y1[Sz1-1][14];A[3][1]=y2[Sz2-1][14];A[3][2]=y3[Sz3-1][14];A[3][3]=y4[Sz4-1][14];A[3][4]=y5[Sz5-1][14];A[3][5]=y6[Sz6-1][14];A[3][6]=y7[Sz7-1][14];A[3][7]=y8[Sz8-1][14];
	// d(IEP5)/dr
	A[4][0]=y1[Sz1-1][16];A[4][1]=y2[Sz2-1][16];A[4][2]=y3[Sz3-1][16];A[4][3]=y4[Sz4-1][16];A[4][4]=y5[Sz5-1][16];A[4][5]=y6[Sz6-1][16];A[4][6]=y7[Sz7-1][16];A[4][7]=y8[Sz8-1][16];
	// d(IEP6)/dr
	A[5][0]=y1[Sz1-1][18];A[5][1]=y2[Sz2-1][18];A[5][2]=y3[Sz3-1][18];A[5][3]=y4[Sz4-1][18];A[5][4]=y5[Sz5-1][18];A[5][5]=y6[Sz6-1][18];A[5][6]=y7[Sz7-1][18];A[5][7]=y8[Sz8-1][18];
	// f 1st (df/dr)
	A[6][0]=y1[Sz1-1][1];A[6][1]=y2[Sz2-1][1];A[6][2]=y3[Sz3-1][1];A[6][3]=y4[Sz4-1][1];A[6][4]=y5[Sz5-1][1];A[6][5]=y6[Sz6-1][1];A[6][6]=y7[Sz7-1][1];A[6][7]=y8[Sz8-1][1];
	// f 2nd (d2f/dr2)
	A[7][0]=y1[Sz1-1][2];A[7][1]=y2[Sz2-1][2];A[7][2]=y3[Sz3-1][2];A[7][3]=y4[Sz4-1][2];A[7][4]=y5[Sz5-1][2];A[7][5]=y6[Sz6-1][2];A[7][6]=y7[Sz7-1][2];A[7][7]=y8[Sz8-1][2];
	// Define Solution Matrix for Problem #2
	B2.setlength(8);
	// d(IEP1)/dr = -1
	B2[0]=-1-y10[Sz10-1][8];
	// d(IEP2)/dr = -1
	B2[1]=-1-y10[Sz10-1][10];
	// d(IEP3)/dr = -1
	B2[2]=-1-y10[Sz10-1][12];
	// d(IEP4)/dr = -1
	B2[3]=-1-y10[Sz10-1][14];
	// d(IEP5)/dr = -1
	B2[4]=-1-y10[Sz10-1][16];
	// d(IEP6)/dr = -1
	B2[5]=-1-y10[Sz10-1][18];
	// df/dr = 0
	B2[6]=0-y10[Sz10-1][1];
	// d2f/dr2 = 0
	B2[7]=0-y10[Sz10-1][2];
	// Create Output Parameters
	alglib::rmatrixsolve(A,8,B2,info,rep,C2);
	if(VERBOSE)
		{cout<<"\n";
		cout<<C2[0]*A[0][0] + C2[1]*A[0][1] + C2[2]*A[0][2] + C2[3]*A[0][3] + C2[4]*A[0][4] + C2[5]*A[0][5] + C2[6]*A[0][6] + C2[7]*A[0][7] + y10[Sz10-1][8]<<endl;
		cout<<C2[0]*A[1][0] + C2[1]*A[1][1] + C2[2]*A[1][2] + C2[3]*A[1][3] + C2[4]*A[1][4] + C2[5]*A[1][5] + C2[6]*A[1][6] + C2[7]*A[1][7] + y10[Sz10-1][10]<<endl;
		cout<<C2[0]*A[2][0] + C2[1]*A[2][1] + C2[2]*A[2][2] + C2[3]*A[2][3] + C2[4]*A[2][4] + C2[5]*A[2][5] + C2[6]*A[2][6] + C2[7]*A[2][7] + y10[Sz10-1][12]<<endl;
		cout<<C2[0]*A[3][0] + C2[1]*A[3][1] + C2[2]*A[3][2] + C2[3]*A[3][3] + C2[4]*A[3][4] + C2[5]*A[3][5] + C2[6]*A[3][6] + C2[7]*A[3][7] + y10[Sz10-1][14]<<endl;
		cout<<C2[0]*A[4][0] + C2[1]*A[4][1] + C2[2]*A[4][2] + C2[3]*A[4][3] + C2[4]*A[4][4] + C2[5]*A[4][5] + C2[6]*A[4][6] + C2[7]*A[4][7] + y10[Sz10-1][16]<<endl;
		cout<<C2[0]*A[5][0] + C2[1]*A[5][1] + C2[2]*A[5][2] + C2[3]*A[5][3] + C2[4]*A[5][4] + C2[5]*A[5][5] + C2[6]*A[5][6] + C2[7]*A[5][7] + y10[Sz10-1][18]<<endl;
		cout<<C2[0]*A[6][0] + C2[1]*A[6][1] + C2[2]*A[6][2] + C2[3]*A[6][3] + C2[4]*A[6][4] + C2[5]*A[6][5] + C2[6]*A[6][6] + C2[7]*A[6][7] + y10[Sz10-1][1]<<endl;
		cout<<C2[0]*A[7][0] + C2[1]*A[7][1] + C2[2]*A[7][2] + C2[3]*A[7][3] + C2[4]*A[7][4] + C2[5]*A[7][5] + C2[6]*A[7][6] + C2[7]*A[7][7] + y10[Sz10-1][2]<<endl;
		cout<<"Done!"<<endl;
		cout<<"C1_2 = "<<C2[0]<<endl;
		cout<<"C2_2 = "<<C2[1]<<endl;
		cout<<"C3_2 = "<<C2[2]<<endl;
		cout<<"C4_2 = "<<C2[3]<<endl;
		cout<<"C5_2 = "<<C2[4]<<endl;
		cout<<"C6_2 = "<<C2[5]<<endl;
		cout<<"C7_2 = "<<C2[6]<<endl;
		cout<<"C8_2 = "<<C2[7]<<endl;}

	double mobility=-C2[6]/C1[6];
	
	if(VERBOSE)
		{cout<<"\n\nElectrophoretic Mobility:\t"<<mobility<<" m^2/Vs\n";
		cout<<"ka:\t\t"<<a/Debye<<endl;
		cout<<"Zeta Potential:\t"<<ZP<<" V\n";
		cout<<"E:\t\t"<<3*S.viscosity*ec*mobility/(2*eo*S.dielectric*kb*S.temperature)<<endl;
		cout<<"y:\t\t"<<ec*ZP/(kb*S.temperature)<<endl;}

	return mobility;}

double seven_ion_problem(double ZP,double a,Solution S,Error E,bool VERBOSE)
	{// Convert Debye Length from Angstroms to Meters
	double Debye=S.debyeLength*1e-10;
	// Final Position: Solvated Radius [meters]
	double rf=a;
	double r0;
	double dr=-1e-15;	// integrate from Inf to Protein Radius
	if(Debye>a){r0=5*Debye;}
	else{r0=5*a;}
		
	if(VERBOSE){cout<<"7 ION PROBLEM\nInitial Position:\t"<<r0<<" m"<<"\nFinal Position:\t\t"<<rf<<" m"<<"\nStep Size:\t\t"<<dr<<" m"<<endl;}

	// Calculate Poisson Boltzmann Coefficient and Determine Initial Position away from Protein
	double C=calc_PBE_coefficient(ZP,r0,rf,dr,S,E,VERBOSE);
	if(VERBOSE){cout<<"PBE Coeff: "<<C<<endl;}
	if(isnan(C)){return nan("");}
	int N=7+2*S.numIon+2+3*S.numIon+3;//47;
	state_type y(N);
	// F Function
	// y[0] = f
	// y[1] = df/dr
	// y[2] = d2f/dr2
	// y[3] = d3f/dr3
	// y[4] = d4f/dr4
	// Equilibrium Electric Pontential
	// y[5] = potential
	// y[6] = d(potential)/dr
	// Induced Electrochemical Potential Function (7 ion)
	// y[7] = IEP1
	// y[8] = d(IEP1)/dr
	// y[9] = IEP2
	// y[10] = d(IEP2)/dr
	// y[11] = IEP3
	// y[12] = d(IEP3)/dr
	// y[13] = IEP4
	// y[14] = d(IEP4)/dr
	// y[15] = IEP5
	// y[16] = d(IEP5)/dr
	// y[17] = IEP6
	// y[18] = d(IEP6)/dr
	// y[19] = IEP7
	// y[20] = d(IEP7)/dr
	// Constants
	// y[21] = Temp					// [Kelvin]
	// y[22] = numIon
	// Ion Properties
	// y[23] = Ion1.val;		
	// y[24] = Ion1.conc;		// mM [mol/m^3]
	// y[25] = Ion1.radius;		// meters
	// y[26] = Ion2.val;
	// y[27] = Ion2.conc;
	// y[28] = Ion2.radius;
	// y[29] = Ion3.val;
	// y[30] = Ion3.conc;
	// y[31] = Ion3.radius;
	// y[32] = Ion4.val;
	// y[33] = Ion4.conc;
	// y[34] = Ion4.radius;
	// y[35] = Ion5.val;
	// y[36] = Ion5.conc;
	// y[37] = Ion5.radius;
	// y[38] = Ion6.val;
	// y[39] = Ion6.conc;
	// y[40] = Ion6.radius;
	// y[41] = Ion7.val;
	// y[42] = Ion7.conc;
	// y[43] = Ion7.radius;
	// Solution Properties
	// y[44] = relative dielectric	[dimensionless]
	// y[45] = Debye Length [meters]
	// y[46] = viscosity  [Pa s]
	// Collect Error Data
	double abs_err=E.absolute,rel_err=E.relative,a_x=E.a_x,a_dxdt=E.a_dxdt;
	controlled_stepper_type controlled_stepper(default_error_checker<double,range_algebra,default_operations>(abs_err,rel_err,a_x,a_dxdt));	

	// Calculate Mobility
	vector<state_type> y1,y2,y3,y4,y5,y6,y7,y8,y9,y10,y11;
	vector<double> r1,r2,r3,r4,r5,r6,r7,r8,r9,r10,r11;
	// Specify Boundary Conditions / Initial Values Infinitely Far from the Particle
	if(VERBOSE){cout<<"Solving Homogeneous Problem for 1st Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=1/(r0*r0);y[8]=-2/(r0*r0*r0);
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Seventh Ion
	y[19]=0;y[20]=0;
	// Constants
	y[21]=S.temperature;y[22]=S.numIon;
	// Fist Ion Properties
	y[23]=S.ionVal[0];y[24]=S.ionConc[0]*1000;y[25]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[26]=S.ionVal[1];y[27]=S.ionConc[1]*1000;y[28]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[29]=S.ionVal[2];y[30]=S.ionConc[2]*1000;y[31]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[32]=S.ionVal[3];y[33]=S.ionConc[3]*1000;y[34]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[35]=S.ionVal[4];y[36]=S.ionConc[4]*1000;y[37]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[38]=S.ionVal[5];y[39]=S.ionConc[5]*1000;y[40]=S.ionRad[5]*1e-10;
	// Seventh Ion Properties
	y[41]=S.ionVal[6];y[42]=S.ionConc[6]*1000;y[43]=S.ionRad[6]*1e-10;
	// Solution Properties
	y[44]=S.dielectric;y[45]=Debye;y[46]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps1=integrate_adaptive(controlled_stepper,homogeneous_form_7ion,y,r0,rf,dr,push_back_state_and_time(y1,r1));
	int Sz1=steps1+1;
	if(VERBOSE){cout<<"Done! ("<<Sz1<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 2nd Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=1/(r0*r0);y[10]=-2/(r0*r0*r0);
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Seventh Ion
	y[19]=0;y[20]=0;
	// Constants
	y[21]=S.temperature;y[22]=S.numIon;
	// Fist Ion Properties
	y[23]=S.ionVal[0];y[24]=S.ionConc[0]*1000;y[25]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[26]=S.ionVal[1];y[27]=S.ionConc[1]*1000;y[28]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[29]=S.ionVal[2];y[30]=S.ionConc[2]*1000;y[31]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[32]=S.ionVal[3];y[33]=S.ionConc[3]*1000;y[34]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[35]=S.ionVal[4];y[36]=S.ionConc[4]*1000;y[37]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[38]=S.ionVal[5];y[39]=S.ionConc[5]*1000;y[40]=S.ionRad[5]*1e-10;
	// Seventh Ion Properties
	y[41]=S.ionVal[6];y[42]=S.ionConc[6]*1000;y[43]=S.ionRad[6]*1e-10;
	// Solution Properties
	y[44]=S.dielectric;y[45]=Debye;y[46]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps2=integrate_adaptive(controlled_stepper,homogeneous_form_7ion,y,r0,rf,dr,push_back_state_and_time(y2,r2));
	int Sz2=steps2+1;
	if(VERBOSE){cout<<"Done! ("<<Sz2<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 3rd Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=1/(r0*r0);y[12]=-2/(r0*r0*r0);
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Seventh Ion
	y[19]=0;y[20]=0;
	// Constants
	y[21]=S.temperature;y[22]=S.numIon;
	// Fist Ion Properties
	y[23]=S.ionVal[0];y[24]=S.ionConc[0]*1000;y[25]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[26]=S.ionVal[1];y[27]=S.ionConc[1]*1000;y[28]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[29]=S.ionVal[2];y[30]=S.ionConc[2]*1000;y[31]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[32]=S.ionVal[3];y[33]=S.ionConc[3]*1000;y[34]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[35]=S.ionVal[4];y[36]=S.ionConc[4]*1000;y[37]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[38]=S.ionVal[5];y[39]=S.ionConc[5]*1000;y[40]=S.ionRad[5]*1e-10;
	// Seventh Ion Properties
	y[41]=S.ionVal[6];y[42]=S.ionConc[6]*1000;y[43]=S.ionRad[6]*1e-10;
	// Solution Properties
	y[44]=S.dielectric;y[45]=Debye;y[46]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps3=integrate_adaptive(controlled_stepper,homogeneous_form_7ion,y,r0,rf,dr,push_back_state_and_time(y3,r3));
	int Sz3=steps3+1;
	if(VERBOSE){cout<<"Done! ("<<Sz3<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 4th Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=1/(r0*r0);y[14]=-2/(r0*r0*r0);
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Seventh Ion
	y[19]=0;y[20]=0;
	// Constants
	y[21]=S.temperature;y[22]=S.numIon;
	// Fist Ion Properties
	y[23]=S.ionVal[0];y[24]=S.ionConc[0]*1000;y[25]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[26]=S.ionVal[1];y[27]=S.ionConc[1]*1000;y[28]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[29]=S.ionVal[2];y[30]=S.ionConc[2]*1000;y[31]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[32]=S.ionVal[3];y[33]=S.ionConc[3]*1000;y[34]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[35]=S.ionVal[4];y[36]=S.ionConc[4]*1000;y[37]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[38]=S.ionVal[5];y[39]=S.ionConc[5]*1000;y[40]=S.ionRad[5]*1e-10;
	// Seventh Ion Properties
	y[41]=S.ionVal[6];y[42]=S.ionConc[6]*1000;y[43]=S.ionRad[6]*1e-10;
	// Solution Properties
	y[44]=S.dielectric;y[45]=Debye;y[46]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps4=integrate_adaptive(controlled_stepper,homogeneous_form_7ion,y,r0,rf,dr,push_back_state_and_time(y4,r4));
	int Sz4=steps4+1;
	if(VERBOSE){cout<<"Done! ("<<Sz4<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 5th Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=1/(r0*r0);y[16]=-2/(r0*r0*r0);
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Seventh Ion
	y[19]=0;y[20]=0;
	// Constants
	y[21]=S.temperature;y[22]=S.numIon;
	// Fist Ion Properties
	y[23]=S.ionVal[0];y[24]=S.ionConc[0]*1000;y[25]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[26]=S.ionVal[1];y[27]=S.ionConc[1]*1000;y[28]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[29]=S.ionVal[2];y[30]=S.ionConc[2]*1000;y[31]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[32]=S.ionVal[3];y[33]=S.ionConc[3]*1000;y[34]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[35]=S.ionVal[4];y[36]=S.ionConc[4]*1000;y[37]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[38]=S.ionVal[5];y[39]=S.ionConc[5]*1000;y[40]=S.ionRad[5]*1e-10;
	// Seventh Ion Properties
	y[41]=S.ionVal[6];y[42]=S.ionConc[6]*1000;y[43]=S.ionRad[6]*1e-10;
	// Solution Properties
	y[44]=S.dielectric;y[45]=Debye;y[46]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps5=integrate_adaptive(controlled_stepper,homogeneous_form_7ion,y,r0,rf,dr,push_back_state_and_time(y5,r5));
	int Sz5=steps5+1;
	if(VERBOSE){cout<<"Done! ("<<Sz5<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 6th Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=1/(r0*r0);y[18]=-2/(r0*r0*r0);
	// Seventh Ion
	y[19]=0;y[20]=0;
	// Constants
	y[21]=S.temperature;y[22]=S.numIon;
	// Fist Ion Properties
	y[23]=S.ionVal[0];y[24]=S.ionConc[0]*1000;y[25]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[26]=S.ionVal[1];y[27]=S.ionConc[1]*1000;y[28]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[29]=S.ionVal[2];y[30]=S.ionConc[2]*1000;y[31]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[32]=S.ionVal[3];y[33]=S.ionConc[3]*1000;y[34]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[35]=S.ionVal[4];y[36]=S.ionConc[4]*1000;y[37]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[38]=S.ionVal[5];y[39]=S.ionConc[5]*1000;y[40]=S.ionRad[5]*1e-10;
	// Seventh Ion Properties
	y[41]=S.ionVal[6];y[42]=S.ionConc[6]*1000;y[43]=S.ionRad[6]*1e-10;
	// Solution Properties
	y[44]=S.dielectric;y[45]=Debye;y[46]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps6=integrate_adaptive(controlled_stepper,homogeneous_form_7ion,y,r0,rf,dr,push_back_state_and_time(y6,r6));
	int Sz6=steps6+1;
	if(VERBOSE){cout<<"Done! ("<<Sz6<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 7th Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Seventh Ion
	y[19]=1/(r0*r0);y[20]=-2/(r0*r0*r0);
	// Constants
	y[21]=S.temperature;y[22]=S.numIon;
	// Fist Ion Properties
	y[23]=S.ionVal[0];y[24]=S.ionConc[0]*1000;y[25]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[26]=S.ionVal[1];y[27]=S.ionConc[1]*1000;y[28]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[29]=S.ionVal[2];y[30]=S.ionConc[2]*1000;y[31]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[32]=S.ionVal[3];y[33]=S.ionConc[3]*1000;y[34]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[35]=S.ionVal[4];y[36]=S.ionConc[4]*1000;y[37]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[38]=S.ionVal[5];y[39]=S.ionConc[5]*1000;y[40]=S.ionRad[5]*1e-10;
	// Seventh Ion Properties
	y[41]=S.ionVal[6];y[42]=S.ionConc[6]*1000;y[43]=S.ionRad[6]*1e-10;
	// Solution Properties
	y[44]=S.dielectric;y[45]=Debye;y[46]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps7=integrate_adaptive(controlled_stepper,homogeneous_form_7ion,y,r0,rf,dr,push_back_state_and_time(y7,r7));
	int Sz7=steps7+1;
	if(VERBOSE){cout<<"Done! ("<<Sz7<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 1st f term...";}
	// F Function
	y[0]=r0;y[1]=1;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Seventh Ion
	y[19]=0;y[20]=0;
	// Constants
	y[21]=S.temperature;y[22]=S.numIon;
	// Fist Ion Properties
	y[23]=S.ionVal[0];y[24]=S.ionConc[0]*1000;y[25]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[26]=S.ionVal[1];y[27]=S.ionConc[1]*1000;y[28]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[29]=S.ionVal[2];y[30]=S.ionConc[2]*1000;y[31]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[32]=S.ionVal[3];y[33]=S.ionConc[3]*1000;y[34]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[35]=S.ionVal[4];y[36]=S.ionConc[4]*1000;y[37]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[38]=S.ionVal[5];y[39]=S.ionConc[5]*1000;y[40]=S.ionRad[5]*1e-10;
	// Seventh Ion Properties
	y[41]=S.ionVal[6];y[42]=S.ionConc[6]*1000;y[43]=S.ionRad[6]*1e-10;
	// Solution Properties
	y[44]=S.dielectric;y[45]=Debye;y[46]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps8=integrate_adaptive(controlled_stepper,homogeneous_form_7ion,y,r0,rf,dr,push_back_state_and_time(y8,r8));
	int Sz8=steps8+1;
	if(VERBOSE){cout<<"Done! ("<<Sz8<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 2nd f term...";}
	// F Function
	y[0]=1/r0;y[1]=-1/(r0*r0);y[2]=2/(r0*r0*r0);y[3]=-6/(r0*r0*r0*r0);y[4]=24/(r0*r0*r0*r0*r0);
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Seventh Ion
	y[19]=0;y[20]=0;
	// Constants
	y[21]=S.temperature;y[22]=S.numIon;
	// Fist Ion Properties
	y[23]=S.ionVal[0];y[24]=S.ionConc[0]*1000;y[25]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[26]=S.ionVal[1];y[27]=S.ionConc[1]*1000;y[28]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[29]=S.ionVal[2];y[30]=S.ionConc[2]*1000;y[31]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[32]=S.ionVal[3];y[33]=S.ionConc[3]*1000;y[34]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[35]=S.ionVal[4];y[36]=S.ionConc[4]*1000;y[37]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[38]=S.ionVal[5];y[39]=S.ionConc[5]*1000;y[40]=S.ionRad[5]*1e-10;
	// Seventh Ion Properties
	y[41]=S.ionVal[6];y[42]=S.ionConc[6]*1000;y[43]=S.ionRad[6]*1e-10;
	// Solution Properties
	y[44]=S.dielectric;y[45]=Debye;y[46]=S.viscosity;
	// Solve Homogeneous Form
	size_t steps9=integrate_adaptive(controlled_stepper,homogeneous_form_7ion,y,r0,rf,dr,push_back_state_and_time(y9,r9));
	int Sz9=steps9+1;
	if(VERBOSE){cout<<"Done! ("<<Sz9<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Flow Field Problem...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Seventh Ion
	y[19]=0;y[20]=0;
	// Constants
	y[21]=S.temperature;y[22]=S.numIon;
	// Fist Ion Properties
	y[23]=S.ionVal[0];y[24]=S.ionConc[0]*1000;y[25]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[26]=S.ionVal[1];y[27]=S.ionConc[1]*1000;y[28]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[29]=S.ionVal[2];y[30]=S.ionConc[2]*1000;y[31]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[32]=S.ionVal[3];y[33]=S.ionConc[3]*1000;y[34]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[35]=S.ionVal[4];y[36]=S.ionConc[4]*1000;y[37]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[38]=S.ionVal[5];y[39]=S.ionConc[5]*1000;y[40]=S.ionRad[5]*1e-10;
	// Seventh Ion Properties
	y[41]=S.ionVal[6];y[42]=S.ionConc[6]*1000;y[43]=S.ionRad[6]*1e-10;
	// Solution Properties
	y[44]=S.dielectric;y[45]=Debye;y[46]=S.viscosity;
	// Solve 
	size_t steps10=integrate_adaptive(controlled_stepper,inhomogeneous_Prob1_7ion,y,r0,rf,dr,push_back_state_and_time(y10,r10));
	int Sz10=steps10+1;
	if(VERBOSE){cout<<"Done! ("<<Sz10<<" points)"<<endl;}
	
	if(VERBOSE){cout<<"Calculating Asymptotic Constants...";}
	alglib::real_2d_array A;
	alglib::real_1d_array C1,B1;
	// Define System Matrix containing coefficients of linear system
	A.setlength(9,9);
	for(int i=0;i<9;i++)
		{for(int j=0;j<9;j++)
			{A[i][j]=0;}}
	// d(IEP1)/dr
	A[0][0]=y1[Sz1-1][8];A[0][1]=y2[Sz2-1][8];A[0][2]=y3[Sz3-1][8];A[0][3]=y4[Sz4-1][8];A[0][4]=y5[Sz5-1][8];A[0][5]=y6[Sz6-1][8];A[0][6]=y7[Sz7-1][8];A[0][7]=y8[Sz8-1][8];A[0][8]=y9[Sz9-1][8];
	// d(IEP2)/dr
	A[1][0]=y1[Sz1-1][10];A[1][1]=y2[Sz2-1][10];A[1][2]=y3[Sz3-1][10];A[1][3]=y4[Sz4-1][10];A[1][4]=y5[Sz5-1][10];A[1][5]=y6[Sz6-1][10];A[1][6]=y7[Sz7-1][10];A[1][7]=y8[Sz8-1][10];A[1][8]=y9[Sz9-1][10];
	// d(IEP3)/dr
	A[2][0]=y1[Sz1-1][12];A[2][1]=y2[Sz2-1][12];A[2][2]=y3[Sz3-1][12];A[2][3]=y4[Sz4-1][12];A[2][4]=y5[Sz5-1][12];A[2][5]=y6[Sz6-1][12];A[2][6]=y7[Sz7-1][12];A[2][7]=y8[Sz8-1][12];A[2][8]=y9[Sz9-1][12];
	// d(IEP4)/dr
	A[3][0]=y1[Sz1-1][14];A[3][1]=y2[Sz2-1][14];A[3][2]=y3[Sz3-1][14];A[3][3]=y4[Sz4-1][14];A[3][4]=y5[Sz5-1][14];A[3][5]=y6[Sz6-1][14];A[3][6]=y7[Sz7-1][14];A[3][7]=y8[Sz8-1][14];A[3][8]=y9[Sz9-1][14];
	// d(IEP5)/dr
	A[4][0]=y1[Sz1-1][16];A[4][1]=y2[Sz2-1][16];A[4][2]=y3[Sz3-1][16];A[4][3]=y4[Sz4-1][16];A[4][4]=y5[Sz5-1][16];A[4][5]=y6[Sz6-1][16];A[4][6]=y7[Sz7-1][16];A[4][7]=y8[Sz8-1][16];A[4][8]=y9[Sz9-1][16];
	// d(IEP6)/dr
	A[5][0]=y1[Sz1-1][18];
	A[5][1]=y2[Sz2-1][18];
	A[5][2]=y3[Sz3-1][18];
	A[5][3]=y4[Sz4-1][18];
	A[5][4]=y5[Sz5-1][18];
	A[5][5]=y6[Sz6-1][18];
	A[5][6]=y7[Sz7-1][18];
	A[5][7]=y8[Sz8-1][18];
	A[5][8]=y9[Sz9-1][18];
	// d(IEP7)/dr
	A[6][0]=y1[Sz1-1][20];
	A[6][1]=y2[Sz2-1][20];
	A[6][2]=y3[Sz3-1][20];
	A[6][3]=y4[Sz4-1][20];
	A[6][4]=y5[Sz5-1][20];
	A[6][5]=y6[Sz6-1][20];
	A[6][6]=y7[Sz7-1][20];
	A[6][7]=y8[Sz8-1][20];
	A[6][8]=y9[Sz9-1][20];
	// f 1st (df/dr)
	A[7][0]=y1[Sz1-1][1];
	A[7][1]=y2[Sz2-1][1];
	A[7][2]=y3[Sz3-1][1];
	A[7][3]=y4[Sz4-1][1];
	A[7][4]=y5[Sz5-1][1];
	A[7][5]=y6[Sz6-1][1];
	A[7][6]=y7[Sz7-1][1];
	A[7][7]=y8[Sz8-1][1];
	A[7][8]=y9[Sz9-1][1];
	// f 2nd (d2f/dr2)
	A[8][0]=y1[Sz1-1][2];
	A[8][1]=y2[Sz2-1][2];
	A[8][2]=y3[Sz3-1][2];
	A[8][3]=y4[Sz4-1][2];
	A[8][4]=y5[Sz5-1][2];
	A[8][5]=y6[Sz6-1][2];
	A[8][6]=y7[Sz7-1][2];
	A[8][7]=y8[Sz8-1][2];
	A[8][8]=y9[Sz9-1][2];
	// Define Solution Matrix for Problem #1
	B1.setlength(9);
	// d(IEP1)/dr = 0
	B1[0]=0-y10[Sz10-1][8];
	// d(IEP2)/dr = 0
	B1[1]=0-y10[Sz10-1][10];
	// d(IEP3)/dr = 0
	B1[2]=0-y10[Sz10-1][12];
	// d(IEP4)/dr = 0
	B1[3]=0-y10[Sz10-1][14];
	// d(IEP5)/dr = 0
	B1[4]=0-y10[Sz10-1][16];
	// d(IEP6)/dr = 0
	B1[5]=0-y10[Sz10-1][18];
	// d(IEP7)/dr = 0
	B1[6]=0-y10[Sz10-1][20];
	// df/dr = -Radius/2
	B1[7]=-a/2 - y10[Sz10-1][1];
	// d2f/dr2 = -0.5
	B1[8]=-0.5 - y10[Sz10-1][2];
	// Create Output Parameters
	alglib::ae_int_t info;
	alglib::densesolverreport rep;
	alglib::rmatrixsolve(A,9,B1,info,rep,C1);
	if(VERBOSE)
		{cout<<"\n";
		cout<<C1[0]*A[0][0] + C1[1]*A[0][1] + C1[2]*A[0][2] + C1[3]*A[0][3] + C1[4]*A[0][4] + C1[5]*A[0][5] + C1[6]*A[0][6] + C1[7]*A[0][7] + C1[8]*A[0][8] + y10[Sz10-1][8]<<endl;
		cout<<C1[0]*A[1][0] + C1[1]*A[1][1] + C1[2]*A[1][2] + C1[3]*A[1][3] + C1[4]*A[1][4] + C1[5]*A[1][5] + C1[6]*A[1][6] + C1[7]*A[1][7] + C1[8]*A[1][8] + y10[Sz10-1][10]<<endl;
		cout<<C1[0]*A[2][0] + C1[1]*A[2][1] + C1[2]*A[2][2] + C1[3]*A[2][3] + C1[4]*A[2][4] + C1[5]*A[2][5] + C1[6]*A[2][6] + C1[7]*A[2][7] + C1[8]*A[2][8] + y10[Sz10-1][12]<<endl;
		cout<<C1[0]*A[3][0] + C1[1]*A[3][1] + C1[2]*A[3][2] + C1[3]*A[3][3] + C1[4]*A[3][4] + C1[5]*A[3][5] + C1[6]*A[3][6] + C1[7]*A[3][7] + C1[8]*A[3][8] + y10[Sz10-1][14]<<endl;
		cout<<C1[0]*A[4][0] + C1[1]*A[4][1] + C1[2]*A[4][2] + C1[3]*A[4][3] + C1[4]*A[4][4] + C1[5]*A[4][5] + C1[6]*A[4][6] + C1[7]*A[4][7] + C1[8]*A[4][8] + y10[Sz10-1][16]<<endl;
		cout<<C1[0]*A[5][0] + C1[1]*A[5][1] + C1[2]*A[5][2] + C1[3]*A[5][3] + C1[4]*A[5][4] + C1[5]*A[5][5] + C1[6]*A[5][6] + C1[7]*A[5][7] + C1[8]*A[5][8] + y10[Sz10-1][18]<<endl;
		cout<<C1[0]*A[6][0] + C1[1]*A[6][1] + C1[2]*A[6][2] + C1[3]*A[6][3] + C1[4]*A[6][4] + C1[5]*A[6][5] + C1[6]*A[6][6] + C1[7]*A[6][7] + C1[8]*A[6][8] + y10[Sz10-1][20]<<endl;
		cout<<C1[0]*A[7][0] + C1[1]*A[7][1] + C1[2]*A[7][2] + C1[3]*A[7][3] + C1[4]*A[7][4] + C1[5]*A[7][5] + C1[6]*A[7][6] + C1[7]*A[7][7] + C1[8]*A[7][8] + y10[Sz10-1][1]<<endl;
		cout<<C1[0]*A[8][0] + C1[1]*A[8][1] + C1[2]*A[8][2] + C1[3]*A[8][3] + C1[4]*A[8][4] + C1[5]*A[8][5] + C1[6]*A[8][6] + C1[7]*A[8][7] + C1[8]*A[8][8] + y10[Sz10-1][2]<<endl;
		cout<<"Done!"<<endl;
		cout<<"C1_1 = "<<C1[0]<<endl;
		cout<<"C2_1 = "<<C1[1]<<endl;
		cout<<"C3_1 = "<<C1[2]<<endl;
		cout<<"C4_1 = "<<C1[3]<<endl;
		cout<<"C5_1 = "<<C1[4]<<endl;
		cout<<"C6_1 = "<<C1[5]<<endl;
		cout<<"C7_1 = "<<C1[6]<<endl;
		cout<<"C8_1 = "<<C1[7]<<endl;
		cout<<"C9_1 = "<<C1[8]<<endl;}

	if(VERBOSE){cout<<"Solving Electric Field Problem...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Seventh Ion
	y[19]=0;y[20]=0;
	// Constants
	y[21]=S.temperature;y[22]=S.numIon;
	// Fist Ion Properties
	y[23]=S.ionVal[0];y[24]=S.ionConc[0]*1000;y[25]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[26]=S.ionVal[1];y[27]=S.ionConc[1]*1000;y[28]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[29]=S.ionVal[2];y[30]=S.ionConc[2]*1000;y[31]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[32]=S.ionVal[3];y[33]=S.ionConc[3]*1000;y[34]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[35]=S.ionVal[4];y[36]=S.ionConc[4]*1000;y[37]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[38]=S.ionVal[5];y[39]=S.ionConc[5]*1000;y[40]=S.ionRad[5]*1e-10;
	// Seventh Ion Properties
	y[41]=S.ionVal[6];y[42]=S.ionConc[6]*1000;y[43]=S.ionRad[6]*1e-10;
	// Solution Properties
	y[44]=S.dielectric;y[45]=Debye;y[46]=S.viscosity;
	// Solve 
	size_t steps11=integrate_adaptive(controlled_stepper,inhomogeneous_Prob2_7ion,y,r0,rf,dr,push_back_state_and_time(y11,r11));
	int Sz11=steps11+1;
	if(VERBOSE){cout<<"Done! ("<<Sz11<<" points)"<<endl;}

	if(VERBOSE){cout<<"Calculating Asymptotic Constants...";}
	alglib::real_1d_array C2,B2;
	// d(IEP1)/dr
	A[0][0]=y1[Sz1-1][8];A[0][1]=y2[Sz2-1][8];A[0][2]=y3[Sz3-1][8];A[0][3]=y4[Sz4-1][8];A[0][4]=y5[Sz5-1][8];A[0][5]=y6[Sz6-1][8];A[0][6]=y7[Sz7-1][8];A[0][7]=y8[Sz8-1][8];A[0][8]=y9[Sz9-1][8];
	// d(IEP2)/dr
	A[1][0]=y1[Sz1-1][10];A[1][1]=y2[Sz2-1][10];A[1][2]=y3[Sz3-1][10];A[1][3]=y4[Sz4-1][10];A[1][4]=y5[Sz5-1][10];A[1][5]=y6[Sz6-1][10];A[1][6]=y7[Sz7-1][10];A[1][7]=y8[Sz8-1][10];A[1][8]=y9[Sz9-1][10];
	// d(IEP3)/dr
	A[2][0]=y1[Sz1-1][12];A[2][1]=y2[Sz2-1][12];A[2][2]=y3[Sz3-1][12];A[2][3]=y4[Sz4-1][12];A[2][4]=y5[Sz5-1][12];A[2][5]=y6[Sz6-1][12];A[2][6]=y7[Sz7-1][12];A[2][7]=y8[Sz8-1][12];A[2][8]=y9[Sz9-1][12];
	// d(IEP4)/dr
	A[3][0]=y1[Sz1-1][14];A[3][1]=y2[Sz2-1][14];A[3][2]=y3[Sz3-1][14];A[3][3]=y4[Sz4-1][14];A[3][4]=y5[Sz5-1][14];A[3][5]=y6[Sz6-1][14];A[3][6]=y7[Sz7-1][14];A[3][7]=y8[Sz8-1][14];A[3][8]=y9[Sz9-1][14];
	// d(IEP5)/dr
	A[4][0]=y1[Sz1-1][16];A[4][1]=y2[Sz2-1][16];A[4][2]=y3[Sz3-1][16];A[4][3]=y4[Sz4-1][16];A[4][4]=y5[Sz5-1][16];A[4][5]=y6[Sz6-1][16];A[4][6]=y7[Sz7-1][16];A[4][7]=y8[Sz8-1][16];A[4][8]=y9[Sz9-1][16];
	// d(IEP6)/dr
	A[5][0]=y1[Sz1-1][18];A[5][1]=y2[Sz2-1][18];A[5][2]=y3[Sz3-1][18];A[5][3]=y4[Sz4-1][18];A[5][4]=y5[Sz5-1][18];A[5][5]=y6[Sz6-1][18];A[5][6]=y7[Sz7-1][18];A[5][7]=y8[Sz8-1][18];A[5][8]=y9[Sz9-1][18];
	// d(IEP7)/dr
	A[6][0]=y1[Sz1-1][20];
	A[6][1]=y2[Sz2-1][20];
	A[6][2]=y3[Sz3-1][20];
	A[6][3]=y4[Sz4-1][20];
	A[6][4]=y5[Sz5-1][20];
	A[6][5]=y6[Sz6-1][20];
	A[6][6]=y7[Sz7-1][20];
	A[6][7]=y8[Sz8-1][20];
	A[6][8]=y9[Sz9-1][20];
	// f 1st (df/dr)
	A[7][0]=y1[Sz1-1][1];
	A[7][1]=y2[Sz2-1][1];
	A[7][2]=y3[Sz3-1][1];
	A[7][3]=y4[Sz4-1][1];
	A[7][4]=y5[Sz5-1][1];
	A[7][5]=y6[Sz6-1][1];
	A[7][6]=y7[Sz7-1][1];
	A[7][7]=y8[Sz8-1][1];
	A[7][8]=y9[Sz9-1][1];
	// f 2nd (d2f/dr2)
	A[8][0]=y1[Sz1-1][2];
	A[8][1]=y2[Sz2-1][2];
	A[8][2]=y3[Sz3-1][2];
	A[8][3]=y4[Sz4-1][2];
	A[8][4]=y5[Sz5-1][2];
	A[8][5]=y6[Sz6-1][2];
	A[8][6]=y7[Sz7-1][2];
	A[8][7]=y8[Sz8-1][2];
	A[8][8]=y9[Sz9-1][2];
	// Define Solution Matrix for Problem #2
	B2.setlength(9);
	// d(IEP1)/dr = -1
	B2[0]=-1-y11[Sz11-1][8];
	// d(IEP2)/dr = -1
	B2[1]=-1-y11[Sz11-1][10];
	// d(IEP3)/dr = -1
	B2[2]=-1-y11[Sz11-1][12];
	// d(IEP4)/dr = -1
	B2[3]=-1-y11[Sz11-1][14];
	// d(IEP5)/dr = -1
	B2[4]=-1-y11[Sz11-1][16];
	// d(IEP6)/dr = -1
	B2[5]=-1-y11[Sz11-1][18];
	// d(IEP7)/dr = -1
	B2[6]=-1-y11[Sz11-1][20];
	// df/dr = 0
	B2[7]=0-y11[Sz11-1][1];
	// d2f/dr2 = 0
	B2[8]=0-y11[Sz11-1][2];
	// Create Output Parameters
	alglib::rmatrixsolve(A,9,B2,info,rep,C2);
	if(VERBOSE)
		{cout<<"\n";
		cout<<C2[0]*A[0][0] + C2[1]*A[0][1] + C2[2]*A[0][2] + C2[3]*A[0][3] + C2[4]*A[0][4] + C2[5]*A[0][5] + C2[6]*A[0][6] + C2[7]*A[0][7] + C2[8]*A[0][8] + y11[Sz11-1][8]<<endl;
		cout<<C2[0]*A[1][0] + C2[1]*A[1][1] + C2[2]*A[1][2] + C2[3]*A[1][3] + C2[4]*A[1][4] + C2[5]*A[1][5] + C2[6]*A[1][6] + C2[7]*A[1][7] + C2[8]*A[1][8] + y11[Sz11-1][10]<<endl;
		cout<<C2[0]*A[2][0] + C2[1]*A[2][1] + C2[2]*A[2][2] + C2[3]*A[2][3] + C2[4]*A[2][4] + C2[5]*A[2][5] + C2[6]*A[2][6] + C2[7]*A[2][7] + C2[8]*A[2][8] + y11[Sz11-1][12]<<endl;
		cout<<C2[0]*A[3][0] + C2[1]*A[3][1] + C2[2]*A[3][2] + C2[3]*A[3][3] + C2[4]*A[3][4] + C2[5]*A[3][5] + C2[6]*A[3][6] + C2[7]*A[3][7] + C2[8]*A[3][8] + y11[Sz11-1][14]<<endl;
		cout<<C2[0]*A[4][0] + C2[1]*A[4][1] + C2[2]*A[4][2] + C2[3]*A[4][3] + C2[4]*A[4][4] + C2[5]*A[4][5] + C2[6]*A[4][6] + C2[7]*A[4][7] + C2[8]*A[4][8] + y11[Sz11-1][16]<<endl;
		cout<<C2[0]*A[5][0] + C2[1]*A[5][1] + C2[2]*A[5][2] + C2[3]*A[5][3] + C2[4]*A[5][4] + C2[5]*A[5][5] + C2[6]*A[5][6] + C2[7]*A[5][7] + C2[8]*A[5][8] + y11[Sz11-1][18]<<endl;
		cout<<C2[0]*A[6][0] + C2[1]*A[6][1] + C2[2]*A[6][2] + C2[3]*A[6][3] + C2[4]*A[6][4] + C2[5]*A[6][5] + C2[6]*A[6][6] + C2[7]*A[6][7] + C2[8]*A[6][8] + y11[Sz11-1][20]<<endl;
		cout<<C2[0]*A[7][0] + C2[1]*A[7][1] + C2[2]*A[7][2] + C2[3]*A[7][3] + C2[4]*A[7][4] + C2[5]*A[7][5] + C2[6]*A[7][6] + C2[7]*A[7][7] + C2[8]*A[7][8] + y11[Sz11-1][1]<<endl;
		cout<<C2[0]*A[8][0] + C2[1]*A[8][1] + C2[2]*A[8][2] + C2[3]*A[8][3] + C2[4]*A[8][4] + C2[5]*A[8][5] + C2[6]*A[8][6] + C2[7]*A[8][7] + C2[8]*A[8][8] + y11[Sz11-1][2]<<endl;
		cout<<"Done!"<<endl;
		cout<<"C1_2 = "<<C2[0]<<endl;
		cout<<"C2_2 = "<<C2[1]<<endl;
		cout<<"C3_2 = "<<C2[2]<<endl;
		cout<<"C4_2 = "<<C2[3]<<endl;
		cout<<"C5_2 = "<<C2[4]<<endl;
		cout<<"C6_2 = "<<C2[5]<<endl;
		cout<<"C7_2 = "<<C2[6]<<endl;
		cout<<"C8_2 = "<<C2[7]<<endl;
		cout<<"C9_2 = "<<C2[8]<<endl;}

	double mobility=-C2[7]/C1[7];
	
	if(VERBOSE)
		{cout<<"\n\nElectrophoretic Mobility:\t"<<mobility<<" m^2/Vs\n";
		cout<<"ka:\t\t"<<a/Debye<<endl;
		cout<<"Zeta Potential:\t"<<ZP<<" V\n";
		cout<<"E:\t\t"<<3*S.viscosity*ec*mobility/(2*eo*S.dielectric*kb*S.temperature)<<endl;
		cout<<"y:\t\t"<<ec*ZP/(kb*S.temperature)<<endl;}

	return mobility;}

double eight_ion_problem(double ZP,double a,Solution S,Error E,bool VERBOSE)
	{// Convert Debye Length from Angstroms to Meters
	double Debye=S.debyeLength*1e-10;
	// Final Position: Solvated Radius [meters]
	double rf=a;
	double r0;
	double dr=-1e-15;	// integrate from Inf to Protein Radius
	if(Debye>a){r0=5*Debye;}
	else{r0=5*a;}
		
	if(VERBOSE){cout<<"8 ION PROBLEM\nInitial Position:\t"<<r0<<" m"<<"\nFinal Position:\t\t"<<rf<<" m"<<"\nStep Size:\t\t"<<dr<<" m"<<endl;}

	// Calculate Poisson Boltzmann Coefficient and Determine Initial Position away from Protein
	double C=calc_PBE_coefficient(ZP,r0,rf,dr,S,E,VERBOSE);
	if(VERBOSE){cout<<"PBE Coeff: "<<C<<endl;}
	if(isnan(C)){return nan("");}
	int N=7+2*S.numIon+2+3*S.numIon+3;//52;
	state_type y(N);
	// F Function
	// y[0] = f
	// y[1] = df/dr
	// y[2] = d2f/dr2
	// y[3] = d3f/dr3
	// y[4] = d4f/dr4
	// Equilibrium Electric Pontential
	// y[5] = potential
	// y[6] = d(potential)/dr
	// Induced Electrochemical Potential Function (8 ion)
	// y[7] = IEP1
	// y[8] = d(IEP1)/dr
	// y[9] = IEP2
	// y[10] = d(IEP2)/dr
	// y[11] = IEP3
	// y[12] = d(IEP3)/dr
	// y[13] = IEP4
	// y[14] = d(IEP4)/dr
	// y[15] = IEP5
	// y[16] = d(IEP5)/dr
	// y[17] = IEP6
	// y[18] = d(IEP6)/dr
	// y[19] = IEP7
	// y[20] = d(IEP7)/dr
	// y[21] = IEP8
	// y[22] = d(IEP8)/dr
	// Constants
	// y[23] = Temp					// [Kelvin]
	// y[24] = numIon
	// Ion Properties
	// y[25] = Ion1.val;		
	// y[26] = Ion1.conc;		// mM [mol/m^3]
	// y[27] = Ion1.radius;		// meters
	// y[28] = Ion2.val;
	// y[29] = Ion2.conc;
	// y[30] = Ion2.radius;
	// y[31] = Ion3.val;
	// y[32] = Ion3.conc;
	// y[33] = Ion3.radius;
	// y[34] = Ion4.val;
	// y[35] = Ion4.conc;
	// y[36] = Ion4.radius;
	// y[37] = Ion5.val;
	// y[38] = Ion5.conc;
	// y[39] = Ion5.radius;
	// y[40] = Ion6.val;
	// y[41] = Ion6.conc;
	// y[42] = Ion6.radius;
	// y[43] = Ion7.val;
	// y[44] = Ion7.conc;
	// y[45] = Ion7.radius;
	// y[46] = Ion8.val;
	// y[47] = Ion8.conc;
	// y[48] = Ion8.radius;
	// Solution Properties
	// y[49] = relative dielectric	[dimensionless]
	// y[50] = Debye Length [meters]
	// y[51] = viscosity  [Pa s]
	// Collect Error Data
	double abs_err=E.absolute,rel_err=E.relative,a_x=E.a_x,a_dxdt=E.a_dxdt;
	controlled_stepper_type controlled_stepper(default_error_checker<double,range_algebra,default_operations>(abs_err,rel_err,a_x,a_dxdt));	

	// Calculate Mobility
	vector<state_type> y1,y2,y3,y4,y5,y6,y7,y8,y9,y10,y11,y12;
	vector<double> r1,r2,r3,r4,r5,r6,r7,r8,r9,r10,r11,r12;
	// Specify Boundary Conditions / Initial Values Infinitely Far from the Particle
	if(VERBOSE){cout<<"Solving Homogeneous Problem for 1st Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=1/(r0*r0);y[8]=-2/(r0*r0*r0);
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Seventh Ion
	y[19]=0;y[20]=0;
	// Eigth Ion
	y[21]=0;y[22]=0;
	// Constants
	y[23]=S.temperature;y[24]=S.numIon;
	// Fist Ion Properties
	y[25]=S.ionVal[0];y[26]=S.ionConc[0]*1000;y[27]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[28]=S.ionVal[1];y[29]=S.ionConc[1]*1000;y[30]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[31]=S.ionVal[2];y[32]=S.ionConc[2]*1000;y[33]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[34]=S.ionVal[3];y[35]=S.ionConc[3]*1000;y[36]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[37]=S.ionVal[4];y[38]=S.ionConc[4]*1000;y[39]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[40]=S.ionVal[5];y[41]=S.ionConc[5]*1000;y[42]=S.ionRad[5]*1e-10;
	// Seventh Ion Properties
	y[43]=S.ionVal[6];y[44]=S.ionConc[6]*1000;y[45]=S.ionRad[6]*1e-10;
	// Eigth Ion Properties
	y[46]=S.ionVal[7];y[47]=S.ionConc[7]*1000;y[48]=S.ionRad[7]*1e-10;
	// Solution Properties
	y[49]=S.dielectric;y[50]=Debye;y[51]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps1=integrate_adaptive(controlled_stepper,homogeneous_form_8ion,y,r0,rf,dr,push_back_state_and_time(y1,r1));
	int Sz1=steps1+1;
	if(VERBOSE){cout<<"Done! ("<<Sz1<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 2nd Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=1/(r0*r0);y[10]=-2/(r0*r0*r0);
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Seventh Ion
	y[19]=0;y[20]=0;
	// Eigth Ion
	y[21]=0;y[22]=0;
	// Constants
	y[23]=S.temperature;y[24]=S.numIon;
	// Fist Ion Properties
	y[25]=S.ionVal[0];y[26]=S.ionConc[0]*1000;y[27]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[28]=S.ionVal[1];y[29]=S.ionConc[1]*1000;y[30]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[31]=S.ionVal[2];y[32]=S.ionConc[2]*1000;y[33]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[34]=S.ionVal[3];y[35]=S.ionConc[3]*1000;y[36]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[37]=S.ionVal[4];y[38]=S.ionConc[4]*1000;y[39]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[40]=S.ionVal[5];y[41]=S.ionConc[5]*1000;y[42]=S.ionRad[5]*1e-10;
	// Seventh Ion Properties
	y[43]=S.ionVal[6];y[44]=S.ionConc[6]*1000;y[45]=S.ionRad[6]*1e-10;
	// Eigth Ion Properties
	y[46]=S.ionVal[7];y[47]=S.ionConc[7]*1000;y[48]=S.ionRad[7]*1e-10;
	// Solution Properties
	y[49]=S.dielectric;y[50]=Debye;y[51]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps2=integrate_adaptive(controlled_stepper,homogeneous_form_8ion,y,r0,rf,dr,push_back_state_and_time(y2,r2));
	int Sz2=steps2+1;
	if(VERBOSE){cout<<"Done! ("<<Sz2<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 3rd Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=1/(r0*r0);y[12]=-2/(r0*r0*r0);
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Seventh Ion
	y[19]=0;y[20]=0;
	// Eigth Ion
	y[21]=0;y[22]=0;
	// Constants
	y[23]=S.temperature;y[24]=S.numIon;
	// Fist Ion Properties
	y[25]=S.ionVal[0];y[26]=S.ionConc[0]*1000;y[27]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[28]=S.ionVal[1];y[29]=S.ionConc[1]*1000;y[30]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[31]=S.ionVal[2];y[32]=S.ionConc[2]*1000;y[33]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[34]=S.ionVal[3];y[35]=S.ionConc[3]*1000;y[36]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[37]=S.ionVal[4];y[38]=S.ionConc[4]*1000;y[39]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[40]=S.ionVal[5];y[41]=S.ionConc[5]*1000;y[42]=S.ionRad[5]*1e-10;
	// Seventh Ion Properties
	y[43]=S.ionVal[6];y[44]=S.ionConc[6]*1000;y[45]=S.ionRad[6]*1e-10;
	// Eigth Ion Properties
	y[46]=S.ionVal[7];y[47]=S.ionConc[7]*1000;y[48]=S.ionRad[7]*1e-10;
	// Solution Properties
	y[49]=S.dielectric;y[50]=Debye;y[51]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps3=integrate_adaptive(controlled_stepper,homogeneous_form_8ion,y,r0,rf,dr,push_back_state_and_time(y3,r3));
	int Sz3=steps3+1;
	if(VERBOSE){cout<<"Done! ("<<Sz3<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 4th Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=1/(r0*r0);y[14]=-2/(r0*r0*r0);
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Seventh Ion
	y[19]=0;y[20]=0;
	// Eigth Ion
	y[21]=0;y[22]=0;
	// Constants
	y[23]=S.temperature;y[24]=S.numIon;
	// Fist Ion Properties
	y[25]=S.ionVal[0];y[26]=S.ionConc[0]*1000;y[27]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[28]=S.ionVal[1];y[29]=S.ionConc[1]*1000;y[30]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[31]=S.ionVal[2];y[32]=S.ionConc[2]*1000;y[33]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[34]=S.ionVal[3];y[35]=S.ionConc[3]*1000;y[36]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[37]=S.ionVal[4];y[38]=S.ionConc[4]*1000;y[39]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[40]=S.ionVal[5];y[41]=S.ionConc[5]*1000;y[42]=S.ionRad[5]*1e-10;
	// Seventh Ion Properties
	y[43]=S.ionVal[6];y[44]=S.ionConc[6]*1000;y[45]=S.ionRad[6]*1e-10;
	// Eigth Ion Properties
	y[46]=S.ionVal[7];y[47]=S.ionConc[7]*1000;y[48]=S.ionRad[7]*1e-10;
	// Solution Properties
	y[49]=S.dielectric;y[50]=Debye;y[51]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps4=integrate_adaptive(controlled_stepper,homogeneous_form_8ion,y,r0,rf,dr,push_back_state_and_time(y4,r4));
	int Sz4=steps4+1;
	if(VERBOSE){cout<<"Done! ("<<Sz4<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 5th Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=1/(r0*r0);y[16]=-2/(r0*r0*r0);
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Seventh Ion
	y[19]=0;y[20]=0;
	// Eigth Ion
	y[21]=0;y[22]=0;
	// Constants
	y[23]=S.temperature;y[24]=S.numIon;
	// Fist Ion Properties
	y[25]=S.ionVal[0];y[26]=S.ionConc[0]*1000;y[27]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[28]=S.ionVal[1];y[29]=S.ionConc[1]*1000;y[30]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[31]=S.ionVal[2];y[32]=S.ionConc[2]*1000;y[33]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[34]=S.ionVal[3];y[35]=S.ionConc[3]*1000;y[36]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[37]=S.ionVal[4];y[38]=S.ionConc[4]*1000;y[39]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[40]=S.ionVal[5];y[41]=S.ionConc[5]*1000;y[42]=S.ionRad[5]*1e-10;
	// Seventh Ion Properties
	y[43]=S.ionVal[6];y[44]=S.ionConc[6]*1000;y[45]=S.ionRad[6]*1e-10;
	// Eigth Ion Properties
	y[46]=S.ionVal[7];y[47]=S.ionConc[7]*1000;y[48]=S.ionRad[7]*1e-10;
	// Solution Properties
	y[49]=S.dielectric;y[50]=Debye;y[51]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps5=integrate_adaptive(controlled_stepper,homogeneous_form_8ion,y,r0,rf,dr,push_back_state_and_time(y5,r5));
	int Sz5=steps5+1;
	if(VERBOSE){cout<<"Done! ("<<Sz5<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 6th Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=1/(r0*r0);y[18]=-2/(r0*r0*r0);
	// Seventh Ion
	y[19]=0;y[20]=0;
	// Eigth Ion
	y[21]=0;y[22]=0;
	// Constants
	y[23]=S.temperature;y[24]=S.numIon;
	// Fist Ion Properties
	y[25]=S.ionVal[0];y[26]=S.ionConc[0]*1000;y[27]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[28]=S.ionVal[1];y[29]=S.ionConc[1]*1000;y[30]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[31]=S.ionVal[2];y[32]=S.ionConc[2]*1000;y[33]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[34]=S.ionVal[3];y[35]=S.ionConc[3]*1000;y[36]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[37]=S.ionVal[4];y[38]=S.ionConc[4]*1000;y[39]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[40]=S.ionVal[5];y[41]=S.ionConc[5]*1000;y[42]=S.ionRad[5]*1e-10;
	// Seventh Ion Properties
	y[43]=S.ionVal[6];y[44]=S.ionConc[6]*1000;y[45]=S.ionRad[6]*1e-10;
	// Eigth Ion Properties
	y[46]=S.ionVal[7];y[47]=S.ionConc[7]*1000;y[48]=S.ionRad[7]*1e-10;
	// Solution Properties
	y[49]=S.dielectric;y[50]=Debye;y[51]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps6=integrate_adaptive(controlled_stepper,homogeneous_form_8ion,y,r0,rf,dr,push_back_state_and_time(y6,r6));
	int Sz6=steps6+1;
	if(VERBOSE){cout<<"Done! ("<<Sz6<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 7th Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Seventh Ion
	y[19]=1/(r0*r0);y[20]=-2/(r0*r0*r0);
	// Eigth Ion
	y[21]=0;y[22]=0;
	// Constants
	y[23]=S.temperature;y[24]=S.numIon;
	// Fist Ion Properties
	y[25]=S.ionVal[0];y[26]=S.ionConc[0]*1000;y[27]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[28]=S.ionVal[1];y[29]=S.ionConc[1]*1000;y[30]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[31]=S.ionVal[2];y[32]=S.ionConc[2]*1000;y[33]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[34]=S.ionVal[3];y[35]=S.ionConc[3]*1000;y[36]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[37]=S.ionVal[4];y[38]=S.ionConc[4]*1000;y[39]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[40]=S.ionVal[5];y[41]=S.ionConc[5]*1000;y[42]=S.ionRad[5]*1e-10;
	// Seventh Ion Properties
	y[43]=S.ionVal[6];y[44]=S.ionConc[6]*1000;y[45]=S.ionRad[6]*1e-10;
	// Eigth Ion Properties
	y[46]=S.ionVal[7];y[47]=S.ionConc[7]*1000;y[48]=S.ionRad[7]*1e-10;
	// Solution Properties
	y[49]=S.dielectric;y[50]=Debye;y[51]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps7=integrate_adaptive(controlled_stepper,homogeneous_form_8ion,y,r0,rf,dr,push_back_state_and_time(y7,r7));
	int Sz7=steps7+1;
	if(VERBOSE){cout<<"Done! ("<<Sz7<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 8th Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Seventh Ion
	y[19]=0;y[20]=0;
	// Eigth Ion
	y[21]=1/(r0*r0);y[22]=-2/(r0*r0*r0);
	// Constants
	y[23]=S.temperature;y[24]=S.numIon;
	// Fist Ion Properties
	y[25]=S.ionVal[0];y[26]=S.ionConc[0]*1000;y[27]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[28]=S.ionVal[1];y[29]=S.ionConc[1]*1000;y[30]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[31]=S.ionVal[2];y[32]=S.ionConc[2]*1000;y[33]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[34]=S.ionVal[3];y[35]=S.ionConc[3]*1000;y[36]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[37]=S.ionVal[4];y[38]=S.ionConc[4]*1000;y[39]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[40]=S.ionVal[5];y[41]=S.ionConc[5]*1000;y[42]=S.ionRad[5]*1e-10;
	// Seventh Ion Properties
	y[43]=S.ionVal[6];y[44]=S.ionConc[6]*1000;y[45]=S.ionRad[6]*1e-10;
	// Eigth Ion Properties
	y[46]=S.ionVal[7];y[47]=S.ionConc[7]*1000;y[48]=S.ionRad[7]*1e-10;
	// Solution Properties
	y[49]=S.dielectric;y[50]=Debye;y[51]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps8=integrate_adaptive(controlled_stepper,homogeneous_form_8ion,y,r0,rf,dr,push_back_state_and_time(y8,r8));
	int Sz8=steps8+1;
	if(VERBOSE){cout<<"Done! ("<<Sz8<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 1st f term...";}
	// F Function
	y[0]=r0;y[1]=1;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Seventh Ion
	y[19]=0;y[20]=0;
	// Eigth Ion
	y[21]=0;y[22]=0;
	// Constants
	y[23]=S.temperature;y[24]=S.numIon;
	// Fist Ion Properties
	y[25]=S.ionVal[0];y[26]=S.ionConc[0]*1000;y[27]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[28]=S.ionVal[1];y[29]=S.ionConc[1]*1000;y[30]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[31]=S.ionVal[2];y[32]=S.ionConc[2]*1000;y[33]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[34]=S.ionVal[3];y[35]=S.ionConc[3]*1000;y[36]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[37]=S.ionVal[4];y[38]=S.ionConc[4]*1000;y[39]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[40]=S.ionVal[5];y[41]=S.ionConc[5]*1000;y[42]=S.ionRad[5]*1e-10;
	// Seventh Ion Properties
	y[43]=S.ionVal[6];y[44]=S.ionConc[6]*1000;y[45]=S.ionRad[6]*1e-10;
	// Eigth Ion Properties
	y[46]=S.ionVal[7];y[47]=S.ionConc[7]*1000;y[48]=S.ionRad[7]*1e-10;
	// Solution Properties
	y[49]=S.dielectric;y[50]=Debye;y[51]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps9=integrate_adaptive(controlled_stepper,homogeneous_form_8ion,y,r0,rf,dr,push_back_state_and_time(y9,r9));
	int Sz9=steps9+1;
	if(VERBOSE){cout<<"Done! ("<<Sz9<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 2nd f term...";}
	// F Function
	y[0]=1/r0;y[1]=-1/(r0*r0);y[2]=2/(r0*r0*r0);y[3]=-6/(r0*r0*r0*r0);y[4]=24/(r0*r0*r0*r0*r0);
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Seventh Ion
	y[19]=0;y[20]=0;
	// Eigth Ion
	y[21]=0;y[22]=0;
	// Constants
	y[23]=S.temperature;y[24]=S.numIon;
	// Fist Ion Properties
	y[25]=S.ionVal[0];y[26]=S.ionConc[0]*1000;y[27]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[28]=S.ionVal[1];y[29]=S.ionConc[1]*1000;y[30]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[31]=S.ionVal[2];y[32]=S.ionConc[2]*1000;y[33]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[34]=S.ionVal[3];y[35]=S.ionConc[3]*1000;y[36]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[37]=S.ionVal[4];y[38]=S.ionConc[4]*1000;y[39]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[40]=S.ionVal[5];y[41]=S.ionConc[5]*1000;y[42]=S.ionRad[5]*1e-10;
	// Seventh Ion Properties
	y[43]=S.ionVal[6];y[44]=S.ionConc[6]*1000;y[45]=S.ionRad[6]*1e-10;
	// Eigth Ion Properties
	y[46]=S.ionVal[7];y[47]=S.ionConc[7]*1000;y[48]=S.ionRad[7]*1e-10;
	// Solution Properties
	y[49]=S.dielectric;y[50]=Debye;y[51]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps10=integrate_adaptive(controlled_stepper,homogeneous_form_8ion,y,r0,rf,dr,push_back_state_and_time(y10,r10));
	int Sz10=steps10+1;
	if(VERBOSE){cout<<"Done! ("<<Sz10<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Flow Field Problem...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Seventh Ion
	y[19]=0;y[20]=0;
	// Eigth Ion
	y[21]=0;y[22]=0;
	// Constants
	y[23]=S.temperature;y[24]=S.numIon;
	// Fist Ion Properties
	y[25]=S.ionVal[0];y[26]=S.ionConc[0]*1000;y[27]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[28]=S.ionVal[1];y[29]=S.ionConc[1]*1000;y[30]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[31]=S.ionVal[2];y[32]=S.ionConc[2]*1000;y[33]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[34]=S.ionVal[3];y[35]=S.ionConc[3]*1000;y[36]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[37]=S.ionVal[4];y[38]=S.ionConc[4]*1000;y[39]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[40]=S.ionVal[5];y[41]=S.ionConc[5]*1000;y[42]=S.ionRad[5]*1e-10;
	// Seventh Ion Properties
	y[43]=S.ionVal[6];y[44]=S.ionConc[6]*1000;y[45]=S.ionRad[6]*1e-10;
	// Eigth Ion Properties
	y[46]=S.ionVal[7];y[47]=S.ionConc[7]*1000;y[48]=S.ionRad[7]*1e-10;
	// Solution Properties
	y[49]=S.dielectric;y[50]=Debye;y[51]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps11=integrate_adaptive(controlled_stepper,inhomogeneous_Prob1_8ion,y,r0,rf,dr,push_back_state_and_time(y11,r11));
	int Sz11=steps11+1;
	if(VERBOSE){cout<<"Done! ("<<Sz11<<" points)"<<endl;}
	
	if(VERBOSE){cout<<"Calculating Asymptotic Constants...";}
	alglib::real_2d_array A;
	alglib::real_1d_array C1,B1;
	// Define System Matrix containing coefficients of linear system
	A.setlength(10,10);
	for(int i=0;i<10;i++)
		{for(int j=0;j<10;j++)
			{A[i][j]=0;}}
	// d(IEP1)/dr
	A[0][0]=y1[Sz1-1][8];A[0][1]=y2[Sz2-1][8];A[0][2]=y3[Sz3-1][8];A[0][3]=y4[Sz4-1][8];A[0][4]=y5[Sz5-1][8];A[0][5]=y6[Sz6-1][8];A[0][6]=y7[Sz7-1][8];A[0][7]=y8[Sz8-1][8];
	A[0][8]=y9[Sz9-1][8];A[0][9]=y10[Sz10-1][8];
	// d(IEP2)/dr
	A[1][0]=y1[Sz1-1][10];A[1][1]=y2[Sz2-1][10];A[1][2]=y3[Sz3-1][10];A[1][3]=y4[Sz4-1][10];A[1][4]=y5[Sz5-1][10];A[1][5]=y6[Sz6-1][10];A[1][6]=y7[Sz7-1][10];A[1][7]=y8[Sz8-1][10];
	A[1][8]=y9[Sz9-1][10];A[1][9]=y10[Sz10-1][10];
	// d(IEP3)/dr
	A[2][0]=y1[Sz1-1][12];A[2][1]=y2[Sz2-1][12];A[2][2]=y3[Sz3-1][12];A[2][3]=y4[Sz4-1][12];A[2][4]=y5[Sz5-1][12];A[2][5]=y6[Sz6-1][12];A[2][6]=y7[Sz7-1][12];A[2][7]=y8[Sz8-1][12];
	A[2][8]=y9[Sz9-1][12];A[2][9]=y10[Sz10-1][12];
	// d(IEP4)/dr
	A[3][0]=y1[Sz1-1][14];A[3][1]=y2[Sz2-1][14];A[3][2]=y3[Sz3-1][14];A[3][3]=y4[Sz4-1][14];A[3][4]=y5[Sz5-1][14];A[3][5]=y6[Sz6-1][14];A[3][6]=y7[Sz7-1][14];A[3][7]=y8[Sz8-1][14];
	A[3][8]=y9[Sz9-1][14];A[3][9]=y10[Sz10-1][14];
	// d(IEP5)/dr
	A[4][0]=y1[Sz1-1][16];A[4][1]=y2[Sz2-1][16];A[4][2]=y3[Sz3-1][16];A[4][3]=y4[Sz4-1][16];A[4][4]=y5[Sz5-1][16];A[4][5]=y6[Sz6-1][16];A[4][6]=y7[Sz7-1][16];A[4][7]=y8[Sz8-1][16];
	A[4][8]=y9[Sz9-1][16];A[4][9]=y10[Sz10-1][16];
	// d(IEP6)/dr
	A[5][0]=y1[Sz1-1][18];A[5][1]=y2[Sz2-1][18];A[5][2]=y3[Sz3-1][18];A[5][3]=y4[Sz4-1][18];A[5][4]=y5[Sz5-1][18];A[5][5]=y6[Sz6-1][18];A[5][6]=y7[Sz7-1][18];A[5][7]=y8[Sz8-1][18];
	A[5][8]=y9[Sz9-1][18];A[5][9]=y10[Sz10-1][18];
	// d(IEP7)/dr
	A[6][0]=y1[Sz1-1][20];A[6][1]=y2[Sz2-1][20];A[6][2]=y3[Sz3-1][20];A[6][3]=y4[Sz4-1][20];A[6][4]=y5[Sz5-1][20];A[6][5]=y6[Sz6-1][20];A[6][6]=y7[Sz7-1][20];A[6][7]=y8[Sz8-1][20];
	A[6][8]=y9[Sz9-1][20];A[6][9]=y10[Sz10-1][20];
	// d(IEP8)/dr
	A[7][0]=y1[Sz1-1][22];
	A[7][1]=y2[Sz2-1][22];
	A[7][2]=y3[Sz3-1][22];
	A[7][3]=y4[Sz4-1][22];
	A[7][4]=y5[Sz5-1][22];
	A[7][5]=y6[Sz6-1][22];
	A[7][6]=y7[Sz7-1][22];
	A[7][7]=y8[Sz8-1][22];
	A[7][8]=y9[Sz9-1][22];
	A[7][9]=y10[Sz10-1][22];
	// f 1st (df/dr)
	A[8][0]=y1[Sz1-1][1];
	A[8][1]=y2[Sz2-1][1];
	A[8][2]=y3[Sz3-1][1];
	A[8][3]=y4[Sz4-1][1];
	A[8][4]=y5[Sz5-1][1];
	A[8][5]=y6[Sz6-1][1];
	A[8][6]=y7[Sz7-1][1];
	A[8][7]=y8[Sz8-1][1];
	A[8][8]=y9[Sz9-1][1];
	A[8][9]=y10[Sz10-1][1];
	// f 2nd (d2f/dr2)
	A[9][0]=y1[Sz1-1][2];
	A[9][1]=y2[Sz2-1][2];
	A[9][2]=y3[Sz3-1][2];
	A[9][3]=y4[Sz4-1][2];
	A[9][4]=y5[Sz5-1][2];
	A[9][5]=y6[Sz6-1][2];
	A[9][6]=y7[Sz7-1][2];
	A[9][7]=y8[Sz8-1][2];
	A[9][8]=y9[Sz9-1][2];
	A[9][9]=y10[Sz10-1][2];
	// Define Solution Matrix for Problem #1
	B1.setlength(10);
	// d(IEP1)/dr = 0
	B1[0]=0-y11[Sz11-1][8];
	// d(IEP2)/dr = 0
	B1[1]=0-y11[Sz11-1][10];
	// d(IEP3)/dr = 0
	B1[2]=0-y11[Sz11-1][12];
	// d(IEP4)/dr = 0
	B1[3]=0-y11[Sz11-1][14];
	// d(IEP5)/dr = 0
	B1[4]=0-y11[Sz11-1][16];
	// d(IEP6)/dr = 0
	B1[5]=0-y11[Sz11-1][18];
	// d(IEP7)/dr = 0
	B1[6]=0-y11[Sz11-1][20];
	// d(IEP8)/dr = 0
	B1[7]=0-y11[Sz11-1][22];
	// df/dr = -Radius/2
	B1[8]=-a/2 - y11[Sz11-1][1];
	// d2f/dr2 = -0.5
	B1[9]=-0.5 - y11[Sz11-1][2];
	// Create Output Parameters
	alglib::ae_int_t info;
	alglib::densesolverreport rep;
	alglib::rmatrixsolve(A,10,B1,info,rep,C1);
	if(VERBOSE)
	{cout<<"\n";
	cout<<C1[0]*A[0][0] + C1[1]*A[0][1] + C1[2]*A[0][2] + C1[3]*A[0][3] + C1[4]*A[0][4] + C1[5]*A[0][5] + C1[6]*A[0][6] + C1[7]*A[0][7] + C1[8]*A[0][8] + C1[9]*A[0][9] + y11[Sz11-1][8]<<endl;
	cout<<C1[0]*A[1][0] + C1[1]*A[1][1] + C1[2]*A[1][2] + C1[3]*A[1][3] + C1[4]*A[1][4] + C1[5]*A[1][5] + C1[6]*A[1][6] + C1[7]*A[1][7] + C1[8]*A[1][8] + C1[9]*A[1][9] + y11[Sz11-1][10]<<endl;
	cout<<C1[0]*A[2][0] + C1[1]*A[2][1] + C1[2]*A[2][2] + C1[3]*A[2][3] + C1[4]*A[2][4] + C1[5]*A[2][5] + C1[6]*A[2][6] + C1[7]*A[2][7] + C1[8]*A[2][8] + C1[9]*A[2][9] + y11[Sz11-1][12]<<endl;
	cout<<C1[0]*A[3][0] + C1[1]*A[3][1] + C1[2]*A[3][2] + C1[3]*A[3][3] + C1[4]*A[3][4] + C1[5]*A[3][5] + C1[6]*A[3][6] + C1[7]*A[3][7] + C1[8]*A[3][8] + C1[9]*A[3][9] + y11[Sz11-1][14]<<endl;
	cout<<C1[0]*A[4][0] + C1[1]*A[4][1] + C1[2]*A[4][2] + C1[3]*A[4][3] + C1[4]*A[4][4] + C1[5]*A[4][5] + C1[6]*A[4][6] + C1[7]*A[4][7] + C1[8]*A[4][8] + C1[9]*A[4][9] + y11[Sz11-1][16]<<endl;
	cout<<C1[0]*A[5][0] + C1[1]*A[5][1] + C1[2]*A[5][2] + C1[3]*A[5][3] + C1[4]*A[5][4] + C1[5]*A[5][5] + C1[6]*A[5][6] + C1[7]*A[5][7] + C1[8]*A[5][8] + C1[9]*A[5][9] + y11[Sz11-1][18]<<endl;
	cout<<C1[0]*A[6][0] + C1[1]*A[6][1] + C1[2]*A[6][2] + C1[3]*A[6][3] + C1[4]*A[6][4] + C1[5]*A[6][5] + C1[6]*A[6][6] + C1[7]*A[6][7] + C1[8]*A[6][8] + C1[9]*A[6][9] + y11[Sz11-1][20]<<endl;
	cout<<C1[0]*A[7][0] + C1[1]*A[7][1] + C1[2]*A[7][2] + C1[3]*A[7][3] + C1[4]*A[7][4] + C1[5]*A[7][5] + C1[6]*A[7][6] + C1[7]*A[7][7] + C1[8]*A[7][8] + C1[9]*A[7][9] + y11[Sz11-1][22]<<endl;
	cout<<C1[0]*A[8][0] + C1[1]*A[8][1] + C1[2]*A[8][2] + C1[3]*A[8][3] + C1[4]*A[8][4] + C1[5]*A[8][5] + C1[6]*A[8][6] + C1[7]*A[8][7] + C1[8]*A[8][8] + C1[9]*A[8][9] + y11[Sz11-1][1]<<endl;
	cout<<C1[0]*A[9][0] + C1[1]*A[9][1] + C1[2]*A[9][2] + C1[3]*A[9][3] + C1[4]*A[9][4] + C1[5]*A[9][5] + C1[6]*A[9][6] + C1[7]*A[9][7] + C1[8]*A[9][8] + C1[9]*A[9][9] + y11[Sz11-1][2]<<endl;
	cout<<"Done!"<<endl;
	cout<<"C1_1 = "<<C1[0]<<endl;
	cout<<"C2_1 = "<<C1[1]<<endl;
	cout<<"C3_1 = "<<C1[2]<<endl;
	cout<<"C4_1 = "<<C1[3]<<endl;
	cout<<"C5_1 = "<<C1[4]<<endl;
	cout<<"C6_1 = "<<C1[5]<<endl;
	cout<<"C7_1 = "<<C1[6]<<endl;
	cout<<"C8_1 = "<<C1[7]<<endl;
	cout<<"C9_1 = "<<C1[8]<<endl;
	cout<<"C10_1 = "<<C1[9]<<endl;}

	if(VERBOSE){cout<<"Solving Electric Field Problem...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Seventh Ion
	y[19]=0;y[20]=0;
	// Eigth Ion
	y[21]=0;y[22]=0;
	// Constants
	y[23]=S.temperature;y[24]=S.numIon;
	// Fist Ion Properties
	y[25]=S.ionVal[0];y[26]=S.ionConc[0]*1000;y[27]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[28]=S.ionVal[1];y[29]=S.ionConc[1]*1000;y[30]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[31]=S.ionVal[2];y[32]=S.ionConc[2]*1000;y[33]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[34]=S.ionVal[3];y[35]=S.ionConc[3]*1000;y[36]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[37]=S.ionVal[4];y[38]=S.ionConc[4]*1000;y[39]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[40]=S.ionVal[5];y[41]=S.ionConc[5]*1000;y[42]=S.ionRad[5]*1e-10;
	// Seventh Ion Properties
	y[43]=S.ionVal[6];y[44]=S.ionConc[6]*1000;y[45]=S.ionRad[6]*1e-10;
	// Eigth Ion Properties
	y[46]=S.ionVal[7];y[47]=S.ionConc[7]*1000;y[48]=S.ionRad[7]*1e-10;
	// Solution Properties
	y[49]=S.dielectric;y[50]=Debye;y[51]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps12=integrate_adaptive(controlled_stepper,inhomogeneous_Prob2_8ion,y,r0,rf,dr,push_back_state_and_time(y12,r12));
	int Sz12=steps12+1;
	if(VERBOSE){cout<<"Done! ("<<Sz12<<" points)"<<endl;}

	if(VERBOSE){cout<<"Calculating Asymptotic Constants...";}
	alglib::real_1d_array C2,B2;
	// d(IEP1)/dr
	A[0][0]=y1[Sz1-1][8];A[0][1]=y2[Sz2-1][8];A[0][2]=y3[Sz3-1][8];A[0][3]=y4[Sz4-1][8];A[0][4]=y5[Sz5-1][8];A[0][5]=y6[Sz6-1][8];A[0][6]=y7[Sz7-1][8];A[0][7]=y8[Sz8-1][8];
	A[0][8]=y9[Sz9-1][8];A[0][9]=y10[Sz10-1][8];
	// d(IEP2)/dr
	A[1][0]=y1[Sz1-1][10];A[1][1]=y2[Sz2-1][10];A[1][2]=y3[Sz3-1][10];A[1][3]=y4[Sz4-1][10];A[1][4]=y5[Sz5-1][10];A[1][5]=y6[Sz6-1][10];A[1][6]=y7[Sz7-1][10];A[1][7]=y8[Sz8-1][10];
	A[1][8]=y9[Sz9-1][10];A[1][9]=y10[Sz10-1][10];
	// d(IEP3)/dr
	A[2][0]=y1[Sz1-1][12];A[2][1]=y2[Sz2-1][12];A[2][2]=y3[Sz3-1][12];A[2][3]=y4[Sz4-1][12];A[2][4]=y5[Sz5-1][12];A[2][5]=y6[Sz6-1][12];A[2][6]=y7[Sz7-1][12];A[2][7]=y8[Sz8-1][12];
	A[2][8]=y9[Sz9-1][12];A[2][9]=y10[Sz10-1][12];
	// d(IEP4)/dr
	A[3][0]=y1[Sz1-1][14];A[3][1]=y2[Sz2-1][14];A[3][2]=y3[Sz3-1][14];A[3][3]=y4[Sz4-1][14];A[3][4]=y5[Sz5-1][14];A[3][5]=y6[Sz6-1][14];A[3][6]=y7[Sz7-1][14];A[3][7]=y8[Sz8-1][14];
	A[3][8]=y9[Sz9-1][14];A[3][9]=y10[Sz10-1][14];
	// d(IEP5)/dr
	A[4][0]=y1[Sz1-1][16];A[4][1]=y2[Sz2-1][16];A[4][2]=y3[Sz3-1][16];A[4][3]=y4[Sz4-1][16];A[4][4]=y5[Sz5-1][16];A[4][5]=y6[Sz6-1][16];A[4][6]=y7[Sz7-1][16];A[4][7]=y8[Sz8-1][16];
	A[4][8]=y9[Sz9-1][16];A[4][9]=y10[Sz10-1][16];
	// d(IEP6)/dr
	A[5][0]=y1[Sz1-1][18];A[5][1]=y2[Sz2-1][18];A[5][2]=y3[Sz3-1][18];A[5][3]=y4[Sz4-1][18];A[5][4]=y5[Sz5-1][18];A[5][5]=y6[Sz6-1][18];A[5][6]=y7[Sz7-1][18];A[5][7]=y8[Sz8-1][18];
	A[5][8]=y9[Sz9-1][18];A[5][9]=y10[Sz10-1][18];
	// d(IEP7)/dr
	A[6][0]=y1[Sz1-1][20];
	A[6][1]=y2[Sz2-1][20];
	A[6][2]=y3[Sz3-1][20];
	A[6][3]=y4[Sz4-1][20];
	A[6][4]=y5[Sz5-1][20];
	A[6][5]=y6[Sz6-1][20];
	A[6][6]=y7[Sz7-1][20];
	A[6][7]=y8[Sz8-1][20];
	A[6][8]=y9[Sz9-1][20];
	A[6][9]=y10[Sz10-1][20];
	// d(IEP8)/dr
	A[7][0]=y1[Sz1-1][22];
	A[7][1]=y2[Sz2-1][22];
	A[7][2]=y3[Sz3-1][22];
	A[7][3]=y4[Sz4-1][22];
	A[7][4]=y5[Sz5-1][22];
	A[7][5]=y6[Sz6-1][22];
	A[7][6]=y7[Sz7-1][22];
	A[7][7]=y8[Sz8-1][22];
	A[7][8]=y9[Sz9-1][22];
	A[7][9]=y10[Sz10-1][22];
	// f 1st (df/dr)
	A[8][0]=y1[Sz1-1][1];
	A[8][1]=y2[Sz2-1][1];
	A[8][2]=y3[Sz3-1][1];
	A[8][3]=y4[Sz4-1][1];
	A[8][4]=y5[Sz5-1][1];
	A[8][5]=y6[Sz6-1][1];
	A[8][6]=y7[Sz7-1][1];
	A[8][7]=y8[Sz8-1][1];
	A[8][8]=y9[Sz9-1][1];
	A[8][9]=y10[Sz10-1][1];
	// f 2nd (d2f/dr2)
	A[9][0]=y1[Sz1-1][2];
	A[9][1]=y2[Sz2-1][2];
	A[9][2]=y3[Sz3-1][2];
	A[9][3]=y4[Sz4-1][2];
	A[9][4]=y5[Sz5-1][2];
	A[9][5]=y6[Sz6-1][2];
	A[9][6]=y7[Sz7-1][2];
	A[9][7]=y8[Sz8-1][2];
	A[9][8]=y9[Sz9-1][2];
	A[9][9]=y10[Sz10-1][2];
	// Define Solution Matrix for Problem #2
	B2.setlength(10);
	// d(IEP1)/dr = -1
	B2[0]=-1-y12[Sz12-1][8];
	// d(IEP2)/dr = -1
	B2[1]=-1-y12[Sz12-1][10];
	// d(IEP3)/dr = -1
	B2[2]=-1-y12[Sz12-1][12];
	// d(IEP4)/dr = -1
	B2[3]=-1-y12[Sz12-1][14];
	// d(IEP5)/dr = -1
	B2[4]=-1-y12[Sz12-1][16];
	// d(IEP6)/dr = -1
	B2[5]=-1-y12[Sz12-1][18];
	// d(IEP7)/dr = -1
	B2[6]=-1-y12[Sz12-1][20];
	// d(IEP8)/dr = -1
	B2[7]=-1-y12[Sz12-1][22];
	// df/dr = 0
	B2[8]=0-y12[Sz12-1][1];
	// d2f/dr2 = 0
	B2[9]=0-y12[Sz12-1][2];
	// Create Output Parameters
	alglib::rmatrixsolve(A,10,B2,info,rep,C2);
	if(VERBOSE)
	{cout<<"\n";
	cout<<C2[0]*A[0][0] + C2[1]*A[0][1] + C2[2]*A[0][2] + C2[3]*A[0][3] + C2[4]*A[0][4] + C2[5]*A[0][5] + C2[6]*A[0][6] + C2[7]*A[0][7] + C2[8]*A[0][8] + C2[9]*A[0][9] + y12[Sz12-1][8]<<endl;
	cout<<C2[0]*A[1][0] + C2[1]*A[1][1] + C2[2]*A[1][2] + C2[3]*A[1][3] + C2[4]*A[1][4] + C2[5]*A[1][5] + C2[6]*A[1][6] + C2[7]*A[1][7] + C2[8]*A[1][8] + C2[9]*A[1][9] + y12[Sz12-1][10]<<endl;
	cout<<C2[0]*A[2][0] + C2[1]*A[2][1] + C2[2]*A[2][2] + C2[3]*A[2][3] + C2[4]*A[2][4] + C2[5]*A[2][5] + C2[6]*A[2][6] + C2[7]*A[2][7] + C2[8]*A[2][8] + C2[9]*A[2][9] + y12[Sz12-1][12]<<endl;
	cout<<C2[0]*A[3][0] + C2[1]*A[3][1] + C2[2]*A[3][2] + C2[3]*A[3][3] + C2[4]*A[3][4] + C2[5]*A[3][5] + C2[6]*A[3][6] + C2[7]*A[3][7] + C2[8]*A[3][8] + C2[9]*A[3][9] + y12[Sz12-1][14]<<endl;
	cout<<C2[0]*A[4][0] + C2[1]*A[4][1] + C2[2]*A[4][2] + C2[3]*A[4][3] + C2[4]*A[4][4] + C2[5]*A[4][5] + C2[6]*A[4][6] + C2[7]*A[4][7] + C2[8]*A[4][8] + C2[9]*A[4][9] + y12[Sz12-1][16]<<endl;
	cout<<C2[0]*A[5][0] + C2[1]*A[5][1] + C2[2]*A[5][2] + C2[3]*A[5][3] + C2[4]*A[5][4] + C2[5]*A[5][5] + C2[6]*A[5][6] + C2[7]*A[5][7] + C2[8]*A[5][8] + C2[9]*A[5][9] + y12[Sz12-1][18]<<endl;
	cout<<C2[0]*A[6][0] + C2[1]*A[6][1] + C2[2]*A[6][2] + C2[3]*A[6][3] + C2[4]*A[6][4] + C2[5]*A[6][5] + C2[6]*A[6][6] + C2[7]*A[6][7] + C2[8]*A[6][8] + C2[9]*A[6][9] + y12[Sz12-1][20]<<endl;
	cout<<C2[0]*A[7][0] + C2[1]*A[7][1] + C2[2]*A[7][2] + C2[3]*A[7][3] + C2[4]*A[7][4] + C2[5]*A[7][5] + C2[6]*A[7][6] + C2[7]*A[7][7] + C2[8]*A[7][8] + C2[9]*A[7][9] + y12[Sz12-1][22]<<endl;
	cout<<C2[0]*A[8][0] + C2[1]*A[8][1] + C2[2]*A[8][2] + C2[3]*A[8][3] + C2[4]*A[8][4] + C2[5]*A[8][5] + C2[6]*A[8][6] + C2[7]*A[8][7] + C2[8]*A[8][8] + C2[9]*A[8][9] + y12[Sz12-1][1]<<endl;
	cout<<C2[0]*A[9][0] + C2[1]*A[9][1] + C2[2]*A[9][2] + C2[3]*A[9][3] + C2[4]*A[9][4] + C2[5]*A[9][5] + C2[6]*A[9][6] + C2[7]*A[9][7] + C2[8]*A[9][8] + C2[9]*A[9][9] + y12[Sz12-1][2]<<endl;
	cout<<"Done!"<<endl;
	cout<<"C1_2 = "<<C2[0]<<endl;
	cout<<"C2_2 = "<<C2[1]<<endl;
	cout<<"C3_2 = "<<C2[2]<<endl;
	cout<<"C4_2 = "<<C2[3]<<endl;
	cout<<"C5_2 = "<<C2[4]<<endl;
	cout<<"C6_2 = "<<C2[5]<<endl;
	cout<<"C7_2 = "<<C2[6]<<endl;
	cout<<"C8_2 = "<<C2[7]<<endl;
	cout<<"C9_2 = "<<C2[8]<<endl;
	cout<<"C10_2 = "<<C2[9]<<endl;}

	double mobility=-C2[8]/C1[8];
	
	if(VERBOSE)
		{cout<<"\n\nElectrophoretic Mobility:\t"<<mobility<<" m^2/Vs\n";
		cout<<"ka:\t\t"<<a/Debye<<endl;
		cout<<"Zeta Potential:\t"<<ZP<<" V\n";
		cout<<"E:\t\t"<<3*S.viscosity*ec*mobility/(2*eo*S.dielectric*kb*S.temperature)<<endl;
		cout<<"y:\t\t"<<ec*ZP/(kb*S.temperature)<<endl;}

	return mobility;}

double nine_ion_problem(double ZP,double a,Solution S,Error E,bool VERBOSE)
	{// Convert Debye Length from Angstroms to Meters
	double Debye=S.debyeLength*1e-10;
	// Final Position: Solvated Radius [meters]
	double rf=a;
	double r0;
	double dr=-1e-15;	// integrate from Inf to Protein Radius
	if(Debye>a){r0=5*Debye;}
	else{r0=5*a;}
		
	if(VERBOSE){cout<<"9 ION PROBLEM\nInitial Position:\t"<<r0<<" m"<<"\nFinal Position:\t\t"<<rf<<" m"<<"\nStep Size:\t\t"<<dr<<" m"<<endl;}

	// Calculate Poisson Boltzmann Coefficient and Determine Initial Position away from Protein
	double C=calc_PBE_coefficient(ZP,r0,rf,dr,S,E,VERBOSE);
	if(VERBOSE){cout<<"PBE Coeff: "<<C<<endl;}
	if(isnan(C)){return nan("");}
	int N=7+2*S.numIon+2+3*S.numIon+3;//57;
	state_type y(N);
	// F Function
	// y[0] = f
	// y[1] = df/dr
	// y[2] = d2f/dr2
	// y[3] = d3f/dr3
	// y[4] = d4f/dr4
	// Equilibrium Electric Pontential
	// y[5] = potential
	// y[6] = d(potential)/dr
	// Induced Electrochemical Potential Function (9 ion)
	// y[7] = IEP1
	// y[8] = d(IEP1)/dr
	// y[9] = IEP2
	// y[10] = d(IEP2)/dr
	// y[11] = IEP3
	// y[12] = d(IEP3)/dr
	// y[13] = IEP4
	// y[14] = d(IEP4)/dr
	// y[15] = IEP5
	// y[16] = d(IEP5)/dr
	// y[17] = IEP6
	// y[18] = d(IEP6)/dr
	// y[19] = IEP7
	// y[20] = d(IEP7)/dr
	// y[21] = IEP8
	// y[22] = d(IEP8)/dr
	// y[23] = IEP9
	// y[24] = d(IEP9)/dr
	// Constants
	// y[25] = Temp					// [Kelvin]
	// y[26] = numIon
	// Ion Properties
	// y[27] = Ion1.val;		
	// y[28] = Ion1.conc;		// mM [mol/m^3]
	// y[29] = Ion1.radius;		// meters
	// y[30] = Ion2.val;
	// y[31] = Ion2.conc;
	// y[32] = Ion2.radius;
	// y[33] = Ion3.val;
	// y[34] = Ion3.conc;
	// y[35] = Ion3.radius;
	// y[36] = Ion4.val;
	// y[37] = Ion4.conc;
	// y[38] = Ion4.radius;
	// y[39] = Ion5.val;
	// y[40] = Ion5.conc;
	// y[41] = Ion5.radius;
	// y[42] = Ion6.val;
	// y[43] = Ion6.conc;
	// y[44] = Ion6.radius;
	// y[45] = Ion7.val;
	// y[46] = Ion7.conc;
	// y[47] = Ion7.radius;
	// y[48] = Ion8.val;
	// y[49] = Ion8.conc;
	// y[50] = Ion8.radius;
	// y[51] = Ion9.val;
	// y[52] = Ion9.conc;
	// y[53] = Ion9.radius;
	// Solution Properties
	// y[54] = relative dielectric	[dimensionless]
	// y[55] = Debye Length [meters]
	// y[56] = viscosity  [Pa s]
	// Collect Error Data
	double abs_err=E.absolute,rel_err=E.relative,a_x=E.a_x,a_dxdt=E.a_dxdt;
	controlled_stepper_type controlled_stepper(default_error_checker<double,range_algebra,default_operations>(abs_err,rel_err,a_x,a_dxdt));	

	// Calculate Mobility
	vector<state_type> y1,y2,y3,y4,y5,y6,y7,y8,y9,y10,y11,y12,y13;
	vector<double> r1,r2,r3,r4,r5,r6,r7,r8,r9,r10,r11,r12,r13;
	// Specify Boundary Conditions / Initial Values Infinitely Far from the Particle
	if(VERBOSE){cout<<"Solving Homogeneous Problem for 1st Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=1/(r0*r0);y[8]=-2/(r0*r0*r0);
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Seventh Ion
	y[19]=0;y[20]=0;
	// Eigth Ion
	y[21]=0;y[22]=0;
	// Ninth Ion
	y[23]=0;y[24]=0;
	// Constants
	y[25]=S.temperature;y[26]=S.numIon;
	// Fist Ion Properties
	y[27]=S.ionVal[0];y[28]=S.ionConc[0]*1000;y[29]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[30]=S.ionVal[1];y[31]=S.ionConc[1]*1000;y[32]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[33]=S.ionVal[2];y[34]=S.ionConc[2]*1000;y[35]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[36]=S.ionVal[3];y[37]=S.ionConc[3]*1000;y[38]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[39]=S.ionVal[4];y[40]=S.ionConc[4]*1000;y[41]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[42]=S.ionVal[5];y[43]=S.ionConc[5]*1000;y[44]=S.ionRad[5]*1e-10;
	// Seventh Ion Properties
	y[45]=S.ionVal[6];y[46]=S.ionConc[6]*1000;y[47]=S.ionRad[6]*1e-10;
	// Eigth Ion Properties
	y[48]=S.ionVal[7];y[49]=S.ionConc[7]*1000;y[50]=S.ionRad[7]*1e-10;
	// Ninth Ion Properties
	y[51]=S.ionVal[8];y[52]=S.ionConc[8]*1000;y[53]=S.ionRad[8]*1e-10;
	// Solution Properties
	y[54]=S.dielectric;y[55]=Debye;y[56]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps1=integrate_adaptive(controlled_stepper,homogeneous_form_9ion,y,r0,rf,dr,push_back_state_and_time(y1,r1));
	int Sz1=steps1+1;
	if(VERBOSE){cout<<"Done! ("<<Sz1<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 2nd Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=1/(r0*r0);y[10]=-2/(r0*r0*r0);
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Seventh Ion
	y[19]=0;y[20]=0;
	// Eigth Ion
	y[21]=0;y[22]=0;
	// Ninth Ion
	y[23]=0;y[24]=0;
	// Constants
	y[25]=S.temperature;y[26]=S.numIon;
	// Fist Ion Properties
	y[27]=S.ionVal[0];y[28]=S.ionConc[0]*1000;y[29]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[30]=S.ionVal[1];y[31]=S.ionConc[1]*1000;y[32]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[33]=S.ionVal[2];y[34]=S.ionConc[2]*1000;y[35]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[36]=S.ionVal[3];y[37]=S.ionConc[3]*1000;y[38]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[39]=S.ionVal[4];y[40]=S.ionConc[4]*1000;y[41]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[42]=S.ionVal[5];y[43]=S.ionConc[5]*1000;y[44]=S.ionRad[5]*1e-10;
	// Seventh Ion Properties
	y[45]=S.ionVal[6];y[46]=S.ionConc[6]*1000;y[47]=S.ionRad[6]*1e-10;
	// Eigth Ion Properties
	y[48]=S.ionVal[7];y[49]=S.ionConc[7]*1000;y[50]=S.ionRad[7]*1e-10;
	// Ninth Ion Properties
	y[51]=S.ionVal[8];y[52]=S.ionConc[8]*1000;y[53]=S.ionRad[8]*1e-10;
	// Solution Properties
	y[54]=S.dielectric;y[55]=Debye;y[56]=S.viscosity;
	// Solve Homogeneous Form for First Ion
	size_t steps2=integrate_adaptive(controlled_stepper,homogeneous_form_9ion,y,r0,rf,dr,push_back_state_and_time(y2,r2));
	int Sz2=steps2+1;
	if(VERBOSE){cout<<"Done! ("<<Sz2<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 3rd Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=1/(r0*r0);y[12]=-2/(r0*r0*r0);
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Seventh Ion
	y[19]=0;y[20]=0;
	// Eigth Ion
	y[21]=0;y[22]=0;
	// Ninth Ion
	y[23]=0;y[24]=0;
	// Constants
	y[25]=S.temperature;y[26]=S.numIon;
	// Fist Ion Properties
	y[27]=S.ionVal[0];y[28]=S.ionConc[0]*1000;y[29]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[30]=S.ionVal[1];y[31]=S.ionConc[1]*1000;y[32]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[33]=S.ionVal[2];y[34]=S.ionConc[2]*1000;y[35]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[36]=S.ionVal[3];y[37]=S.ionConc[3]*1000;y[38]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[39]=S.ionVal[4];y[40]=S.ionConc[4]*1000;y[41]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[42]=S.ionVal[5];y[43]=S.ionConc[5]*1000;y[44]=S.ionRad[5]*1e-10;
	// Seventh Ion Properties
	y[45]=S.ionVal[6];y[46]=S.ionConc[6]*1000;y[47]=S.ionRad[6]*1e-10;
	// Eigth Ion Properties
	y[48]=S.ionVal[7];y[49]=S.ionConc[7]*1000;y[50]=S.ionRad[7]*1e-10;
	// Ninth Ion Properties
	y[51]=S.ionVal[8];y[52]=S.ionConc[8]*1000;y[53]=S.ionRad[8]*1e-10;
	// Solution Properties
	y[54]=S.dielectric;y[55]=Debye;y[56]=S.viscosity;
	// Solve Homogeneous Form
	size_t steps3=integrate_adaptive(controlled_stepper,homogeneous_form_9ion,y,r0,rf,dr,push_back_state_and_time(y3,r3));
	int Sz3=steps3+1;
	if(VERBOSE){cout<<"Done! ("<<Sz3<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 4th Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=1/(r0*r0);y[14]=-2/(r0*r0*r0);
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Seventh Ion
	y[19]=0;y[20]=0;
	// Eigth Ion
	y[21]=0;y[22]=0;
	// Ninth Ion
	y[23]=0;y[24]=0;
	// Constants
	y[25]=S.temperature;y[26]=S.numIon;
	// Fist Ion Properties
	y[27]=S.ionVal[0];y[28]=S.ionConc[0]*1000;y[29]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[30]=S.ionVal[1];y[31]=S.ionConc[1]*1000;y[32]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[33]=S.ionVal[2];y[34]=S.ionConc[2]*1000;y[35]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[36]=S.ionVal[3];y[37]=S.ionConc[3]*1000;y[38]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[39]=S.ionVal[4];y[40]=S.ionConc[4]*1000;y[41]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[42]=S.ionVal[5];y[43]=S.ionConc[5]*1000;y[44]=S.ionRad[5]*1e-10;
	// Seventh Ion Properties
	y[45]=S.ionVal[6];y[46]=S.ionConc[6]*1000;y[47]=S.ionRad[6]*1e-10;
	// Eigth Ion Properties
	y[48]=S.ionVal[7];y[49]=S.ionConc[7]*1000;y[50]=S.ionRad[7]*1e-10;
	// Ninth Ion Properties
	y[51]=S.ionVal[8];y[52]=S.ionConc[8]*1000;y[53]=S.ionRad[8]*1e-10;
	// Solution Properties
	y[54]=S.dielectric;y[55]=Debye;y[56]=S.viscosity;
	// Solve Homogeneous Form
	size_t steps4=integrate_adaptive(controlled_stepper,homogeneous_form_9ion,y,r0,rf,dr,push_back_state_and_time(y4,r4));
	int Sz4=steps4+1;
	if(VERBOSE){cout<<"Done! ("<<Sz4<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 5th Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=1/(r0*r0);y[16]=-2/(r0*r0*r0);
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Seventh Ion
	y[19]=0;y[20]=0;
	// Eigth Ion
	y[21]=0;y[22]=0;
	// Ninth Ion
	y[23]=0;y[24]=0;
	// Constants
	y[25]=S.temperature;y[26]=S.numIon;
	// Fist Ion Properties
	y[27]=S.ionVal[0];y[28]=S.ionConc[0]*1000;y[29]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[30]=S.ionVal[1];y[31]=S.ionConc[1]*1000;y[32]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[33]=S.ionVal[2];y[34]=S.ionConc[2]*1000;y[35]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[36]=S.ionVal[3];y[37]=S.ionConc[3]*1000;y[38]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[39]=S.ionVal[4];y[40]=S.ionConc[4]*1000;y[41]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[42]=S.ionVal[5];y[43]=S.ionConc[5]*1000;y[44]=S.ionRad[5]*1e-10;
	// Seventh Ion Properties
	y[45]=S.ionVal[6];y[46]=S.ionConc[6]*1000;y[47]=S.ionRad[6]*1e-10;
	// Eigth Ion Properties
	y[48]=S.ionVal[7];y[49]=S.ionConc[7]*1000;y[50]=S.ionRad[7]*1e-10;
	// Ninth Ion Properties
	y[51]=S.ionVal[8];y[52]=S.ionConc[8]*1000;y[53]=S.ionRad[8]*1e-10;
	// Solution Properties
	y[54]=S.dielectric;y[55]=Debye;y[56]=S.viscosity;
	// Solve Homogeneous Form
	size_t steps5=integrate_adaptive(controlled_stepper,homogeneous_form_9ion,y,r0,rf,dr,push_back_state_and_time(y5,r5));
	int Sz5=steps5+1;
	if(VERBOSE){cout<<"Done! ("<<Sz5<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 6th Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=1/(r0*r0);y[18]=-2/(r0*r0*r0);
	// Seventh Ion
	y[19]=0;y[20]=0;
	// Eigth Ion
	y[21]=0;y[22]=0;
	// Ninth Ion
	y[23]=0;y[24]=0;
	// Constants
	y[25]=S.temperature;y[26]=S.numIon;
	// Fist Ion Properties
	y[27]=S.ionVal[0];y[28]=S.ionConc[0]*1000;y[29]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[30]=S.ionVal[1];y[31]=S.ionConc[1]*1000;y[32]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[33]=S.ionVal[2];y[34]=S.ionConc[2]*1000;y[35]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[36]=S.ionVal[3];y[37]=S.ionConc[3]*1000;y[38]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[39]=S.ionVal[4];y[40]=S.ionConc[4]*1000;y[41]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[42]=S.ionVal[5];y[43]=S.ionConc[5]*1000;y[44]=S.ionRad[5]*1e-10;
	// Seventh Ion Properties
	y[45]=S.ionVal[6];y[46]=S.ionConc[6]*1000;y[47]=S.ionRad[6]*1e-10;
	// Eigth Ion Properties
	y[48]=S.ionVal[7];y[49]=S.ionConc[7]*1000;y[50]=S.ionRad[7]*1e-10;
	// Ninth Ion Properties
	y[51]=S.ionVal[8];y[52]=S.ionConc[8]*1000;y[53]=S.ionRad[8]*1e-10;
	// Solution Properties
	y[54]=S.dielectric;y[55]=Debye;y[56]=S.viscosity;
	// Solve Homogeneous Form
	size_t steps6=integrate_adaptive(controlled_stepper,homogeneous_form_9ion,y,r0,rf,dr,push_back_state_and_time(y6,r6));
	int Sz6=steps6+1;
	if(VERBOSE){cout<<"Done! ("<<Sz6<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 7th Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Seventh Ion
	y[19]=1/(r0*r0);y[20]=-2/(r0*r0*r0);
	// Eigth Ion
	y[21]=0;y[22]=0;
	// Ninth Ion
	y[23]=0;y[24]=0;
	// Constants
	y[25]=S.temperature;y[26]=S.numIon;
	// Fist Ion Properties
	y[27]=S.ionVal[0];y[28]=S.ionConc[0]*1000;y[29]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[30]=S.ionVal[1];y[31]=S.ionConc[1]*1000;y[32]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[33]=S.ionVal[2];y[34]=S.ionConc[2]*1000;y[35]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[36]=S.ionVal[3];y[37]=S.ionConc[3]*1000;y[38]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[39]=S.ionVal[4];y[40]=S.ionConc[4]*1000;y[41]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[42]=S.ionVal[5];y[43]=S.ionConc[5]*1000;y[44]=S.ionRad[5]*1e-10;
	// Seventh Ion Properties
	y[45]=S.ionVal[6];y[46]=S.ionConc[6]*1000;y[47]=S.ionRad[6]*1e-10;
	// Eigth Ion Properties
	y[48]=S.ionVal[7];y[49]=S.ionConc[7]*1000;y[50]=S.ionRad[7]*1e-10;
	// Ninth Ion Properties
	y[51]=S.ionVal[8];y[52]=S.ionConc[8]*1000;y[53]=S.ionRad[8]*1e-10;
	// Solution Properties
	y[54]=S.dielectric;y[55]=Debye;y[56]=S.viscosity;
	// Solve Homogeneous Form
	size_t steps7=integrate_adaptive(controlled_stepper,homogeneous_form_9ion,y,r0,rf,dr,push_back_state_and_time(y7,r7));
	int Sz7=steps7+1;
	if(VERBOSE){cout<<"Done! ("<<Sz7<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 8th Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Seventh Ion
	y[19]=0;y[20]=0;
	// Eigth Ion
	y[21]=1/(r0*r0);y[22]=-2/(r0*r0*r0);
	// Ninth Ion
	y[23]=0;y[24]=0;
	// Constants
	y[25]=S.temperature;y[26]=S.numIon;
	// Fist Ion Properties
	y[27]=S.ionVal[0];y[28]=S.ionConc[0]*1000;y[29]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[30]=S.ionVal[1];y[31]=S.ionConc[1]*1000;y[32]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[33]=S.ionVal[2];y[34]=S.ionConc[2]*1000;y[35]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[36]=S.ionVal[3];y[37]=S.ionConc[3]*1000;y[38]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[39]=S.ionVal[4];y[40]=S.ionConc[4]*1000;y[41]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[42]=S.ionVal[5];y[43]=S.ionConc[5]*1000;y[44]=S.ionRad[5]*1e-10;
	// Seventh Ion Properties
	y[45]=S.ionVal[6];y[46]=S.ionConc[6]*1000;y[47]=S.ionRad[6]*1e-10;
	// Eigth Ion Properties
	y[48]=S.ionVal[7];y[49]=S.ionConc[7]*1000;y[50]=S.ionRad[7]*1e-10;
	// Ninth Ion Properties
	y[51]=S.ionVal[8];y[52]=S.ionConc[8]*1000;y[53]=S.ionRad[8]*1e-10;
	// Solution Properties
	y[54]=S.dielectric;y[55]=Debye;y[56]=S.viscosity;
	// Solve Homogeneous Form
	size_t steps8=integrate_adaptive(controlled_stepper,homogeneous_form_9ion,y,r0,rf,dr,push_back_state_and_time(y8,r8));
	int Sz8=steps8+1;
	if(VERBOSE){cout<<"Done! ("<<Sz8<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 9th Ion...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Seventh Ion
	y[19]=0;y[20]=0;
	// Eigth Ion
	y[21]=0;y[22]=0;
	// Ninth Ion
	y[23]=1/(r0*r0);y[24]=-2/(r0*r0*r0);
	// Constants
	y[25]=S.temperature;y[26]=S.numIon;
	// Fist Ion Properties
	y[27]=S.ionVal[0];y[28]=S.ionConc[0]*1000;y[29]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[30]=S.ionVal[1];y[31]=S.ionConc[1]*1000;y[32]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[33]=S.ionVal[2];y[34]=S.ionConc[2]*1000;y[35]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[36]=S.ionVal[3];y[37]=S.ionConc[3]*1000;y[38]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[39]=S.ionVal[4];y[40]=S.ionConc[4]*1000;y[41]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[42]=S.ionVal[5];y[43]=S.ionConc[5]*1000;y[44]=S.ionRad[5]*1e-10;
	// Seventh Ion Properties
	y[45]=S.ionVal[6];y[46]=S.ionConc[6]*1000;y[47]=S.ionRad[6]*1e-10;
	// Eigth Ion Properties
	y[48]=S.ionVal[7];y[49]=S.ionConc[7]*1000;y[50]=S.ionRad[7]*1e-10;
	// Ninth Ion Properties
	y[51]=S.ionVal[8];y[52]=S.ionConc[8]*1000;y[53]=S.ionRad[8]*1e-10;
	// Solution Properties
	y[54]=S.dielectric;y[55]=Debye;y[56]=S.viscosity;
	// Solve Homogeneous Form
	size_t steps9=integrate_adaptive(controlled_stepper,homogeneous_form_9ion,y,r0,rf,dr,push_back_state_and_time(y9,r9));
	int Sz9=steps9+1;
	if(VERBOSE){cout<<"Done! ("<<Sz9<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 1st f term...";}
	// F Function
	y[0]=r0;y[1]=1;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Seventh Ion
	y[19]=0;y[20]=0;
	// Eigth Ion
	y[21]=0;y[22]=0;
	// Ninth Ion
	y[23]=0;y[24]=0;
	// Constants
	y[25]=S.temperature;y[26]=S.numIon;
	// Fist Ion Properties
	y[27]=S.ionVal[0];y[28]=S.ionConc[0]*1000;y[29]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[30]=S.ionVal[1];y[31]=S.ionConc[1]*1000;y[32]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[33]=S.ionVal[2];y[34]=S.ionConc[2]*1000;y[35]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[36]=S.ionVal[3];y[37]=S.ionConc[3]*1000;y[38]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[39]=S.ionVal[4];y[40]=S.ionConc[4]*1000;y[41]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[42]=S.ionVal[5];y[43]=S.ionConc[5]*1000;y[44]=S.ionRad[5]*1e-10;
	// Seventh Ion Properties
	y[45]=S.ionVal[6];y[46]=S.ionConc[6]*1000;y[47]=S.ionRad[6]*1e-10;
	// Eigth Ion Properties
	y[48]=S.ionVal[7];y[49]=S.ionConc[7]*1000;y[50]=S.ionRad[7]*1e-10;
	// Ninth Ion Properties
	y[51]=S.ionVal[8];y[52]=S.ionConc[8]*1000;y[53]=S.ionRad[8]*1e-10;
	// Solution Properties
	y[54]=S.dielectric;y[55]=Debye;y[56]=S.viscosity;
	// Solve Homogeneous Form
	size_t steps10=integrate_adaptive(controlled_stepper,homogeneous_form_9ion,y,r0,rf,dr,push_back_state_and_time(y10,r10));
	int Sz10=steps10+1;
	if(VERBOSE){cout<<"Done! ("<<Sz10<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Homogeneous Problem for 2nd f term...";}
	// F Function
	y[0]=1/r0;y[1]=-1/(r0*r0);y[2]=2/(r0*r0*r0);y[3]=-6/(r0*r0*r0*r0);y[4]=24/(r0*r0*r0*r0*r0);
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Seventh Ion
	y[19]=0;y[20]=0;
	// Eigth Ion
	y[21]=0;y[22]=0;
	// Ninth Ion
	y[23]=0;y[24]=0;
	// Constants
	y[25]=S.temperature;y[26]=S.numIon;
	// Fist Ion Properties
	y[27]=S.ionVal[0];y[28]=S.ionConc[0]*1000;y[29]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[30]=S.ionVal[1];y[31]=S.ionConc[1]*1000;y[32]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[33]=S.ionVal[2];y[34]=S.ionConc[2]*1000;y[35]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[36]=S.ionVal[3];y[37]=S.ionConc[3]*1000;y[38]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[39]=S.ionVal[4];y[40]=S.ionConc[4]*1000;y[41]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[42]=S.ionVal[5];y[43]=S.ionConc[5]*1000;y[44]=S.ionRad[5]*1e-10;
	// Seventh Ion Properties
	y[45]=S.ionVal[6];y[46]=S.ionConc[6]*1000;y[47]=S.ionRad[6]*1e-10;
	// Eigth Ion Properties
	y[48]=S.ionVal[7];y[49]=S.ionConc[7]*1000;y[50]=S.ionRad[7]*1e-10;
	// Ninth Ion Properties
	y[51]=S.ionVal[8];y[52]=S.ionConc[8]*1000;y[53]=S.ionRad[8]*1e-10;
	// Solution Properties
	y[54]=S.dielectric;y[55]=Debye;y[56]=S.viscosity;
	// Solve Homogeneous Form
	size_t steps11=integrate_adaptive(controlled_stepper,homogeneous_form_9ion,y,r0,rf,dr,push_back_state_and_time(y11,r11));
	int Sz11=steps11+1;
	if(VERBOSE){cout<<"Done! ("<<Sz11<<" points)"<<endl;}

	if(VERBOSE){cout<<"Solving Flow Field Problem...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Seventh Ion
	y[19]=0;y[20]=0;
	// Eigth Ion
	y[21]=0;y[22]=0;
	// Ninth Ion
	y[23]=0;y[24]=0;
	// Constants
	y[25]=S.temperature;y[26]=S.numIon;
	// Fist Ion Properties
	y[27]=S.ionVal[0];y[28]=S.ionConc[0]*1000;y[29]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[30]=S.ionVal[1];y[31]=S.ionConc[1]*1000;y[32]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[33]=S.ionVal[2];y[34]=S.ionConc[2]*1000;y[35]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[36]=S.ionVal[3];y[37]=S.ionConc[3]*1000;y[38]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[39]=S.ionVal[4];y[40]=S.ionConc[4]*1000;y[41]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[42]=S.ionVal[5];y[43]=S.ionConc[5]*1000;y[44]=S.ionRad[5]*1e-10;
	// Seventh Ion Properties
	y[45]=S.ionVal[6];y[46]=S.ionConc[6]*1000;y[47]=S.ionRad[6]*1e-10;
	// Eigth Ion Properties
	y[48]=S.ionVal[7];y[49]=S.ionConc[7]*1000;y[50]=S.ionRad[7]*1e-10;
	// Ninth Ion Properties
	y[51]=S.ionVal[8];y[52]=S.ionConc[8]*1000;y[53]=S.ionRad[8]*1e-10;
	// Solution Properties
	y[54]=S.dielectric;y[55]=Debye;y[56]=S.viscosity;
	// Solve InHomogeneous Form
	size_t steps12=integrate_adaptive(controlled_stepper,inhomogeneous_Prob1_9ion,y,r0,rf,dr,push_back_state_and_time(y12,r12));
	int Sz12=steps12+1;
	if(VERBOSE){cout<<"Done! ("<<Sz12<<" points)"<<endl;}
	
	if(VERBOSE){cout<<"Calculating Asymptotic Constants...";}
	alglib::real_2d_array A;
	alglib::real_1d_array C1,B1;
	// Define System Matrix containing coefficients of linear system
	A.setlength(11,11);
	for(int i=0;i<11;i++)
		{for(int j=0;j<11;j++)
			{A[i][j]=0;}}
	// d(IEP1)/dr
	A[0][0]=y1[Sz1-1][8];A[0][1]=y2[Sz2-1][8];A[0][2]=y3[Sz3-1][8];A[0][3]=y4[Sz4-1][8];A[0][4]=y5[Sz5-1][8];A[0][5]=y6[Sz6-1][8];A[0][6]=y7[Sz7-1][8];A[0][7]=y8[Sz8-1][8];
	A[0][8]=y9[Sz9-1][8];A[0][9]=y10[Sz10-1][8];A[0][10]=y11[Sz11-1][8];
	// d(IEP2)/dr
	A[1][0]=y1[Sz1-1][10];A[1][1]=y2[Sz2-1][10];A[1][2]=y3[Sz3-1][10];A[1][3]=y4[Sz4-1][10];A[1][4]=y5[Sz5-1][10];A[1][5]=y6[Sz6-1][10];A[1][6]=y7[Sz7-1][10];A[1][7]=y8[Sz8-1][10];
	A[1][8]=y9[Sz9-1][10];A[1][9]=y10[Sz10-1][10];A[1][10]=y11[Sz11-1][10];
	// d(IEP3)/dr
	A[2][0]=y1[Sz1-1][12];A[2][1]=y2[Sz2-1][12];A[2][2]=y3[Sz3-1][12];A[2][3]=y4[Sz4-1][12];A[2][4]=y5[Sz5-1][12];A[2][5]=y6[Sz6-1][12];A[2][6]=y7[Sz7-1][12];A[2][7]=y8[Sz8-1][12];
	A[2][8]=y9[Sz9-1][12];A[2][9]=y10[Sz10-1][12];A[2][10]=y11[Sz11-1][12];
	// d(IEP4)/dr
	A[3][0]=y1[Sz1-1][14];A[3][1]=y2[Sz2-1][14];A[3][2]=y3[Sz3-1][14];A[3][3]=y4[Sz4-1][14];A[3][4]=y5[Sz5-1][14];A[3][5]=y6[Sz6-1][14];A[3][6]=y7[Sz7-1][14];A[3][7]=y8[Sz8-1][14];
	A[3][8]=y9[Sz9-1][14];A[3][9]=y10[Sz10-1][14];A[3][10]=y11[Sz11-1][14];
	// d(IEP5)/dr
	A[4][0]=y1[Sz1-1][16];A[4][1]=y2[Sz2-1][16];A[4][2]=y3[Sz3-1][16];A[4][3]=y4[Sz4-1][16];A[4][4]=y5[Sz5-1][16];A[4][5]=y6[Sz6-1][16];A[4][6]=y7[Sz7-1][16];A[4][7]=y8[Sz8-1][16];
	A[4][8]=y9[Sz9-1][16];A[4][9]=y10[Sz10-1][16];A[4][10]=y11[Sz11-1][16];
	// d(IEP6)/dr
	A[5][0]=y1[Sz1-1][18];A[5][1]=y2[Sz2-1][18];A[5][2]=y3[Sz3-1][18];A[5][3]=y4[Sz4-1][18];A[5][4]=y5[Sz5-1][18];A[5][5]=y6[Sz6-1][18];A[5][6]=y7[Sz7-1][18];A[5][7]=y8[Sz8-1][18];
	A[5][8]=y9[Sz9-1][18];A[5][9]=y10[Sz10-1][18];A[5][10]=y11[Sz11-1][18];
	// d(IEP7)/dr
	A[6][0]=y1[Sz1-1][20];A[6][1]=y2[Sz2-1][20];A[6][2]=y3[Sz3-1][20];A[6][3]=y4[Sz4-1][20];A[6][4]=y5[Sz5-1][20];A[6][5]=y6[Sz6-1][20];A[6][6]=y7[Sz7-1][20];A[6][7]=y8[Sz8-1][20];
	A[6][8]=y9[Sz9-1][20];A[6][9]=y10[Sz10-1][20];A[6][10]=y11[Sz11-1][20];
	// d(IEP8)/dr
	A[7][0]=y1[Sz1-1][22];
	A[7][1]=y2[Sz2-1][22];
	A[7][2]=y3[Sz3-1][22];
	A[7][3]=y4[Sz4-1][22];
	A[7][4]=y5[Sz5-1][22];
	A[7][5]=y6[Sz6-1][22];
	A[7][6]=y7[Sz7-1][22];
	A[7][7]=y8[Sz8-1][22];
	A[7][8]=y9[Sz9-1][22];
	A[7][9]=y10[Sz10-1][22];
	A[7][10]=y11[Sz11-1][22];
	// d(IEP9)/dr
	A[8][0]=y1[Sz1-1][24];
	A[8][1]=y2[Sz2-1][24];
	A[8][2]=y3[Sz3-1][24];
	A[8][3]=y4[Sz4-1][24];
	A[8][4]=y5[Sz5-1][24];
	A[8][5]=y6[Sz6-1][24];
	A[8][6]=y7[Sz7-1][24];
	A[8][7]=y8[Sz8-1][24];
	A[8][8]=y9[Sz9-1][24];
	A[8][9]=y10[Sz10-1][24];
	A[8][10]=y11[Sz11-1][24];
	// f 1st (df/dr)
	A[9][0]=y1[Sz1-1][1];
	A[9][1]=y2[Sz2-1][1];
	A[9][2]=y3[Sz3-1][1];
	A[9][3]=y4[Sz4-1][1];
	A[9][4]=y5[Sz5-1][1];
	A[9][5]=y6[Sz6-1][1];
	A[9][6]=y7[Sz7-1][1];
	A[9][7]=y8[Sz8-1][1];
	A[9][8]=y9[Sz9-1][1];
	A[9][9]=y10[Sz10-1][1];
	A[9][10]=y11[Sz11-1][1];
	// f 2nd (d2f/dr2)
	A[10][0]=y1[Sz1-1][2];
	A[10][1]=y2[Sz2-1][2];
	A[10][2]=y3[Sz3-1][2];
	A[10][3]=y4[Sz4-1][2];
	A[10][4]=y5[Sz5-1][2];
	A[10][5]=y6[Sz6-1][2];
	A[10][6]=y7[Sz7-1][2];
	A[10][7]=y8[Sz8-1][2];
	A[10][8]=y9[Sz9-1][2];
	A[10][9]=y10[Sz10-1][2];
	A[10][10]=y11[Sz11-1][2];
	// Define Solution Matrix for Problem #1
	B1.setlength(11);
	// d(IEP1)/dr = 0
	B1[0]=0-y12[Sz12-1][8];
	// d(IEP2)/dr = 0
	B1[1]=0-y12[Sz12-1][10];
	// d(IEP3)/dr = 0
	B1[2]=0-y12[Sz12-1][12];
	// d(IEP4)/dr = 0
	B1[3]=0-y12[Sz12-1][14];
	// d(IEP5)/dr = 0
	B1[4]=0-y12[Sz12-1][16];
	// d(IEP6)/dr = 0
	B1[5]=0-y12[Sz12-1][18];
	// d(IEP7)/dr = 0
	B1[6]=0-y12[Sz12-1][20];
	// d(IEP8)/dr = 0
	B1[7]=0-y12[Sz12-1][22];
	// d(IEP9)/dr = 0
	B1[8]=0-y12[Sz12-1][24];
	// df/dr = -Radius/2
	B1[9]=-a/2 - y12[Sz12-1][1];
	// d2f/dr2 = -0.5
	B1[10]=-0.5 - y12[Sz12-1][2];
	// Create Output Parameters
	alglib::ae_int_t info;
	alglib::densesolverreport rep;
	alglib::rmatrixsolve(A,11,B1,info,rep,C1);
	if(VERBOSE)
	{cout<<"\n";
/*
	cout<<C1[0]*A[0][0] + C1[1]*A[0][1] + C1[2]*A[0][2] + C1[3]*A[0][3] + C1[4]*A[0][4] + C1[5]*A[0][5] + C1[6]*A[0][6] + C1[7]*A[0][7] + C1[8]*A[0][8] + C1[9]*A[0][9] + y11[Sz11-1][8]<<endl;
	cout<<C1[0]*A[1][0] + C1[1]*A[1][1] + C1[2]*A[1][2] + C1[3]*A[1][3] + C1[4]*A[1][4] + C1[5]*A[1][5] + C1[6]*A[1][6] + C1[7]*A[1][7] + C1[8]*A[1][8] + C1[9]*A[1][9] + y11[Sz11-1][10]<<endl;
	cout<<C1[0]*A[2][0] + C1[1]*A[2][1] + C1[2]*A[2][2] + C1[3]*A[2][3] + C1[4]*A[2][4] + C1[5]*A[2][5] + C1[6]*A[2][6] + C1[7]*A[2][7] + C1[8]*A[2][8] + C1[9]*A[2][9] + y11[Sz11-1][12]<<endl;
	cout<<C1[0]*A[3][0] + C1[1]*A[3][1] + C1[2]*A[3][2] + C1[3]*A[3][3] + C1[4]*A[3][4] + C1[5]*A[3][5] + C1[6]*A[3][6] + C1[7]*A[3][7] + C1[8]*A[3][8] + C1[9]*A[3][9] + y11[Sz11-1][14]<<endl;
	cout<<C1[0]*A[4][0] + C1[1]*A[4][1] + C1[2]*A[4][2] + C1[3]*A[4][3] + C1[4]*A[4][4] + C1[5]*A[4][5] + C1[6]*A[4][6] + C1[7]*A[4][7] + C1[8]*A[4][8] + C1[9]*A[4][9] + y11[Sz11-1][16]<<endl;
	cout<<C1[0]*A[5][0] + C1[1]*A[5][1] + C1[2]*A[5][2] + C1[3]*A[5][3] + C1[4]*A[5][4] + C1[5]*A[5][5] + C1[6]*A[5][6] + C1[7]*A[5][7] + C1[8]*A[5][8] + C1[9]*A[5][9] + y11[Sz11-1][18]<<endl;
	cout<<C1[0]*A[6][0] + C1[1]*A[6][1] + C1[2]*A[6][2] + C1[3]*A[6][3] + C1[4]*A[6][4] + C1[5]*A[6][5] + C1[6]*A[6][6] + C1[7]*A[6][7] + C1[8]*A[6][8] + C1[9]*A[6][9] + y11[Sz11-1][20]<<endl;
	cout<<C1[0]*A[7][0] + C1[1]*A[7][1] + C1[2]*A[7][2] + C1[3]*A[7][3] + C1[4]*A[7][4] + C1[5]*A[7][5] + C1[6]*A[7][6] + C1[7]*A[7][7] + C1[8]*A[7][8] + C1[9]*A[7][9] + y11[Sz11-1][22]<<endl;
	cout<<C1[0]*A[8][0] + C1[1]*A[8][1] + C1[2]*A[8][2] + C1[3]*A[8][3] + C1[4]*A[8][4] + C1[5]*A[8][5] + C1[6]*A[8][6] + C1[7]*A[8][7] + C1[8]*A[8][8] + C1[9]*A[8][9] + y11[Sz11-1][1]<<endl;
	cout<<C1[0]*A[9][0] + C1[1]*A[9][1] + C1[2]*A[9][2] + C1[3]*A[9][3] + C1[4]*A[9][4] + C1[5]*A[9][5] + C1[6]*A[9][6] + C1[7]*A[9][7] + C1[8]*A[9][8] + C1[9]*A[9][9] + y11[Sz11-1][2]<<endl;
*/
	cout<<"Done!"<<endl;
	cout<<"C1_1 = "<<C1[0]<<endl;
	cout<<"C2_1 = "<<C1[1]<<endl;
	cout<<"C3_1 = "<<C1[2]<<endl;
	cout<<"C4_1 = "<<C1[3]<<endl;
	cout<<"C5_1 = "<<C1[4]<<endl;
	cout<<"C6_1 = "<<C1[5]<<endl;
	cout<<"C7_1 = "<<C1[6]<<endl;
	cout<<"C8_1 = "<<C1[7]<<endl;
	cout<<"C9_1 = "<<C1[8]<<endl;
	cout<<"C10_1 = "<<C1[9]<<endl;}

	if(VERBOSE){cout<<"Solving Electric Field Problem...";}
	// F Function
	y[0]=0;y[1]=0;y[2]=0;y[3]=0;y[4]=0;
	// Poisson-Boltzmann Equation for Equilibrium Potential
	y[5]=C*exp(-r0/Debye)/r0;y[6]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// First Ion
	y[7]=0;y[8]=0;
	// Second Ion
	y[9]=0;y[10]=0;
	// Third Ion
	y[11]=0;y[12]=0;
	// Fourth Ion
	y[13]=0;y[14]=0;
	// Fifth Ion
	y[15]=0;y[16]=0;
	// Sixth Ion
	y[17]=0;y[18]=0;
	// Seventh Ion
	y[19]=0;y[20]=0;
	// Eigth Ion
	y[21]=0;y[22]=0;
	// Ninth Ion
	y[23]=0;y[24]=0;
	// Constants
	y[25]=S.temperature;y[26]=S.numIon;
	// Fist Ion Properties
	y[27]=S.ionVal[0];y[28]=S.ionConc[0]*1000;y[29]=S.ionRad[0]*1e-10;
	// Second Ion Properties
	y[30]=S.ionVal[1];y[31]=S.ionConc[1]*1000;y[32]=S.ionRad[1]*1e-10;
	// Third Ion Properties
	y[33]=S.ionVal[2];y[34]=S.ionConc[2]*1000;y[35]=S.ionRad[2]*1e-10;
	// Fourth Ion Properties
	y[36]=S.ionVal[3];y[37]=S.ionConc[3]*1000;y[38]=S.ionRad[3]*1e-10;
	// Fifth Ion Properties
	y[39]=S.ionVal[4];y[40]=S.ionConc[4]*1000;y[41]=S.ionRad[4]*1e-10;
	// Sixth Ion Properties
	y[42]=S.ionVal[5];y[43]=S.ionConc[5]*1000;y[44]=S.ionRad[5]*1e-10;
	// Seventh Ion Properties
	y[45]=S.ionVal[6];y[46]=S.ionConc[6]*1000;y[47]=S.ionRad[6]*1e-10;
	// Eigth Ion Properties
	y[48]=S.ionVal[7];y[49]=S.ionConc[7]*1000;y[50]=S.ionRad[7]*1e-10;
	// Ninth Ion Properties
	y[51]=S.ionVal[8];y[52]=S.ionConc[8]*1000;y[53]=S.ionRad[8]*1e-10;
	// Solution Properties
	y[54]=S.dielectric;y[55]=Debye;y[56]=S.viscosity;
	// Solve InHomogeneous Form
	size_t steps13=integrate_adaptive(controlled_stepper,inhomogeneous_Prob2_9ion,y,r0,rf,dr,push_back_state_and_time(y13,r13));
	int Sz13=steps13+1;
	if(VERBOSE){cout<<"Done! ("<<Sz13<<" points)"<<endl;}

	if(VERBOSE){cout<<"Calculating Asymptotic Constants...";}
	alglib::real_1d_array C2,B2;
	// d(IEP1)/dr
	A[0][0]=y1[Sz1-1][8];A[0][1]=y2[Sz2-1][8];A[0][2]=y3[Sz3-1][8];A[0][3]=y4[Sz4-1][8];A[0][4]=y5[Sz5-1][8];A[0][5]=y6[Sz6-1][8];A[0][6]=y7[Sz7-1][8];A[0][7]=y8[Sz8-1][8];
	A[0][8]=y9[Sz9-1][8];A[0][9]=y10[Sz10-1][8];A[0][10]=y11[Sz11-1][8];
	// d(IEP2)/dr
	A[1][0]=y1[Sz1-1][10];A[1][1]=y2[Sz2-1][10];A[1][2]=y3[Sz3-1][10];A[1][3]=y4[Sz4-1][10];A[1][4]=y5[Sz5-1][10];A[1][5]=y6[Sz6-1][10];A[1][6]=y7[Sz7-1][10];A[1][7]=y8[Sz8-1][10];
	A[1][8]=y9[Sz9-1][10];A[1][9]=y10[Sz10-1][10];A[1][10]=y11[Sz11-1][10];
	// d(IEP3)/dr
	A[2][0]=y1[Sz1-1][12];A[2][1]=y2[Sz2-1][12];A[2][2]=y3[Sz3-1][12];A[2][3]=y4[Sz4-1][12];A[2][4]=y5[Sz5-1][12];A[2][5]=y6[Sz6-1][12];A[2][6]=y7[Sz7-1][12];A[2][7]=y8[Sz8-1][12];
	A[2][8]=y9[Sz9-1][12];A[2][9]=y10[Sz10-1][12];A[2][10]=y11[Sz11-1][12];
	// d(IEP4)/dr
	A[3][0]=y1[Sz1-1][14];A[3][1]=y2[Sz2-1][14];A[3][2]=y3[Sz3-1][14];A[3][3]=y4[Sz4-1][14];A[3][4]=y5[Sz5-1][14];A[3][5]=y6[Sz6-1][14];A[3][6]=y7[Sz7-1][14];A[3][7]=y8[Sz8-1][14];
	A[3][8]=y9[Sz9-1][14];A[3][9]=y10[Sz10-1][14];A[3][10]=y11[Sz11-1][14];
	// d(IEP5)/dr
	A[4][0]=y1[Sz1-1][16];A[4][1]=y2[Sz2-1][16];A[4][2]=y3[Sz3-1][16];A[4][3]=y4[Sz4-1][16];A[4][4]=y5[Sz5-1][16];A[4][5]=y6[Sz6-1][16];A[4][6]=y7[Sz7-1][16];A[4][7]=y8[Sz8-1][16];
	A[4][8]=y9[Sz9-1][16];A[4][9]=y10[Sz10-1][16];A[4][10]=y11[Sz11-1][16];
	// d(IEP6)/dr
	A[5][0]=y1[Sz1-1][18];A[5][1]=y2[Sz2-1][18];A[5][2]=y3[Sz3-1][18];A[5][3]=y4[Sz4-1][18];A[5][4]=y5[Sz5-1][18];A[5][5]=y6[Sz6-1][18];A[5][6]=y7[Sz7-1][18];A[5][7]=y8[Sz8-1][18];
	A[5][8]=y9[Sz9-1][18];A[5][9]=y10[Sz10-1][18];A[5][10]=y11[Sz11-1][18];
	// d(IEP7)/dr
	A[6][0]=y1[Sz1-1][20];
	A[6][1]=y2[Sz2-1][20];
	A[6][2]=y3[Sz3-1][20];
	A[6][3]=y4[Sz4-1][20];
	A[6][4]=y5[Sz5-1][20];
	A[6][5]=y6[Sz6-1][20];
	A[6][6]=y7[Sz7-1][20];
	A[6][7]=y8[Sz8-1][20];
	A[6][8]=y9[Sz9-1][20];
	A[6][9]=y10[Sz10-1][20];
	A[6][10]=y11[Sz11-1][20];
	// d(IEP8)/dr
	A[7][0]=y1[Sz1-1][22];
	A[7][1]=y2[Sz2-1][22];
	A[7][2]=y3[Sz3-1][22];
	A[7][3]=y4[Sz4-1][22];
	A[7][4]=y5[Sz5-1][22];
	A[7][5]=y6[Sz6-1][22];
	A[7][6]=y7[Sz7-1][22];
	A[7][7]=y8[Sz8-1][22];
	A[7][8]=y9[Sz9-1][22];
	A[7][9]=y10[Sz10-1][22];
	A[7][10]=y11[Sz11-1][22];
	// d(IEP9)/dr
	A[8][0]=y1[Sz1-1][24];
	A[8][1]=y2[Sz2-1][24];
	A[8][2]=y3[Sz3-1][24];
	A[8][3]=y4[Sz4-1][24];
	A[8][4]=y5[Sz5-1][24];
	A[8][5]=y6[Sz6-1][24];
	A[8][6]=y7[Sz7-1][24];
	A[8][7]=y8[Sz8-1][24];
	A[8][8]=y9[Sz9-1][24];
	A[8][9]=y10[Sz10-1][24];
	A[8][10]=y11[Sz11-1][24];
	// f 1st (df/dr)
	A[9][0]=y1[Sz1-1][1];
	A[9][1]=y2[Sz2-1][1];
	A[9][2]=y3[Sz3-1][1];
	A[9][3]=y4[Sz4-1][1];
	A[9][4]=y5[Sz5-1][1];
	A[9][5]=y6[Sz6-1][1];
	A[9][6]=y7[Sz7-1][1];
	A[9][7]=y8[Sz8-1][1];
	A[9][8]=y9[Sz9-1][1];
	A[9][9]=y10[Sz10-1][1];
	A[9][10]=y11[Sz11-1][1];
	// f 2nd (d2f/dr2)
	A[10][0]=y1[Sz1-1][2];
	A[10][1]=y2[Sz2-1][2];
	A[10][2]=y3[Sz3-1][2];
	A[10][3]=y4[Sz4-1][2];
	A[10][4]=y5[Sz5-1][2];
	A[10][5]=y6[Sz6-1][2];
	A[10][6]=y7[Sz7-1][2];
	A[10][7]=y8[Sz8-1][2];
	A[10][8]=y9[Sz9-1][2];
	A[10][9]=y10[Sz10-1][2];
	A[10][10]=y11[Sz11-1][2];
	// Define Solution Matrix for Problem #2
	B2.setlength(11);
	// d(IEP1)/dr = -1
	B2[0]=-1-y13[Sz13-1][8];
	// d(IEP2)/dr = -1
	B2[1]=-1-y13[Sz13-1][10];
	// d(IEP3)/dr = -1
	B2[2]=-1-y13[Sz13-1][12];
	// d(IEP4)/dr = -1
	B2[3]=-1-y13[Sz13-1][14];
	// d(IEP5)/dr = -1
	B2[4]=-1-y13[Sz13-1][16];
	// d(IEP6)/dr = -1
	B2[5]=-1-y13[Sz13-1][18];
	// d(IEP7)/dr = -1
	B2[6]=-1-y13[Sz13-1][20];
	// d(IEP8)/dr = -1
	B2[7]=-1-y13[Sz13-1][22];
	// d(IEP9)/dr = -1
	B2[8]=-1-y13[Sz13-1][24];
	// df/dr = 0
	B2[9]=0-y13[Sz13-1][1];
	// d2f/dr2 = 0
	B2[10]=0-y13[Sz13-1][2];
	// Create Output Parameters
	alglib::rmatrixsolve(A,11,B2,info,rep,C2);
	if(VERBOSE)
	{cout<<"\n";
/*	cout<<C2[0]*A[0][0] + C2[1]*A[0][1] + C2[2]*A[0][2] + C2[3]*A[0][3] + C2[4]*A[0][4] + C2[5]*A[0][5] + C2[6]*A[0][6] + C2[7]*A[0][7] + C2[8]*A[0][8] + C2[9]*A[0][9] + y12[Sz12-1][8]<<endl;
	cout<<C2[0]*A[1][0] + C2[1]*A[1][1] + C2[2]*A[1][2] + C2[3]*A[1][3] + C2[4]*A[1][4] + C2[5]*A[1][5] + C2[6]*A[1][6] + C2[7]*A[1][7] + C2[8]*A[1][8] + C2[9]*A[1][9] + y12[Sz12-1][10]<<endl;
	cout<<C2[0]*A[2][0] + C2[1]*A[2][1] + C2[2]*A[2][2] + C2[3]*A[2][3] + C2[4]*A[2][4] + C2[5]*A[2][5] + C2[6]*A[2][6] + C2[7]*A[2][7] + C2[8]*A[2][8] + C2[9]*A[2][9] + y12[Sz12-1][12]<<endl;
	cout<<C2[0]*A[3][0] + C2[1]*A[3][1] + C2[2]*A[3][2] + C2[3]*A[3][3] + C2[4]*A[3][4] + C2[5]*A[3][5] + C2[6]*A[3][6] + C2[7]*A[3][7] + C2[8]*A[3][8] + C2[9]*A[3][9] + y12[Sz12-1][14]<<endl;
	cout<<C2[0]*A[4][0] + C2[1]*A[4][1] + C2[2]*A[4][2] + C2[3]*A[4][3] + C2[4]*A[4][4] + C2[5]*A[4][5] + C2[6]*A[4][6] + C2[7]*A[4][7] + C2[8]*A[4][8] + C2[9]*A[4][9] + y12[Sz12-1][16]<<endl;
	cout<<C2[0]*A[5][0] + C2[1]*A[5][1] + C2[2]*A[5][2] + C2[3]*A[5][3] + C2[4]*A[5][4] + C2[5]*A[5][5] + C2[6]*A[5][6] + C2[7]*A[5][7] + C2[8]*A[5][8] + C2[9]*A[5][9] + y12[Sz12-1][18]<<endl;
	cout<<C2[0]*A[6][0] + C2[1]*A[6][1] + C2[2]*A[6][2] + C2[3]*A[6][3] + C2[4]*A[6][4] + C2[5]*A[6][5] + C2[6]*A[6][6] + C2[7]*A[6][7] + C2[8]*A[6][8] + C2[9]*A[6][9] + y12[Sz12-1][20]<<endl;
	cout<<C2[0]*A[7][0] + C2[1]*A[7][1] + C2[2]*A[7][2] + C2[3]*A[7][3] + C2[4]*A[7][4] + C2[5]*A[7][5] + C2[6]*A[7][6] + C2[7]*A[7][7] + C2[8]*A[7][8] + C2[9]*A[7][9] + y12[Sz12-1][22]<<endl;
	cout<<C2[0]*A[8][0] + C2[1]*A[8][1] + C2[2]*A[8][2] + C2[3]*A[8][3] + C2[4]*A[8][4] + C2[5]*A[8][5] + C2[6]*A[8][6] + C2[7]*A[8][7] + C2[8]*A[8][8] + C2[9]*A[8][9] + y12[Sz12-1][1]<<endl;
	cout<<C2[0]*A[9][0] + C2[1]*A[9][1] + C2[2]*A[9][2] + C2[3]*A[9][3] + C2[4]*A[9][4] + C2[5]*A[9][5] + C2[6]*A[9][6] + C2[7]*A[9][7] + C2[8]*A[9][8] + C2[9]*A[9][9] + y12[Sz12-1][2]<<endl;
*/
	cout<<"Done!"<<endl;
	cout<<"C1_2 = "<<C2[0]<<endl;
	cout<<"C2_2 = "<<C2[1]<<endl;
	cout<<"C3_2 = "<<C2[2]<<endl;
	cout<<"C4_2 = "<<C2[3]<<endl;
	cout<<"C5_2 = "<<C2[4]<<endl;
	cout<<"C6_2 = "<<C2[5]<<endl;
	cout<<"C7_2 = "<<C2[6]<<endl;
	cout<<"C8_2 = "<<C2[7]<<endl;
	cout<<"C9_2 = "<<C2[8]<<endl;
	cout<<"C10_2 = "<<C2[9]<<endl;}

	double mobility=-C2[9]/C1[9];
	
	if(VERBOSE)
		{cout<<"\n\nElectrophoretic Mobility:\t"<<mobility<<" m^2/Vs\n";
		cout<<"ka:\t\t"<<a/Debye<<endl;
		cout<<"Zeta Potential:\t"<<ZP<<" V\n";
		cout<<"E:\t\t"<<3*S.viscosity*ec*mobility/(2*eo*S.dielectric*kb*S.temperature)<<endl;
		cout<<"y:\t\t"<<ec*ZP/(kb*S.temperature)<<endl;}

	return mobility;}

// INPUT: Zeta Potential (Zeta) [Volts]
// INPUT: Initial Position (r0) [meters]
// INPUT: Final Position (rf) [meters]
// INPUT: Integration Interval (dr) [meters]
// INPUT: Debye Length (k) [meters]
// INPUT: Temperature (Temp) [Kelvin]
// INPUT: Ion Concentrations (ion_conc) [Molar]
double calc_PBE_coefficient(double Zeta,double &r0,double rf,double &dr,Solution S,Error E,bool VERBOSE)
	{// Convert Debye Length to meters
	double k=S.debyeLength*1e-10;

	double abs_err=E.absolute;
	double rel_err=E.relative;
	double a_x=E.a_x;
	double a_dxdt=E.a_dxdt;
	
	controlled_stepper_type controlled_stepper(default_error_checker<double,range_algebra,default_operations>(abs_err,rel_err,a_x,a_dxdt));
	
	int N=5+2*S.numIon;	
	state_type y(N);
	// Potential [V]
	// y[0]=C*exp(-r0/Debye)/r0;
	// d(Potential)/dr
	// y[1]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// Constants
	// y[2]=S.temperature;		// Temperature [Kevlin]
	// y[3]=S.numIon;
	// y[4]=S.dielectric;
	// Ion Data
	//for(int i=0;i<S.numIon;i++)
	//	{// Ion Valence
	//	y[5+2*i]=S.ionVal[i];
	// Ion Concentration [milli-Molar] (or equalivalently [mol/meter^3])
	//	y[6+2*i]=S.ionConc[i]*1000;}}

	vector<state_type> y1,y2,y3;	// dependent variables (defined above)
	vector<double> r1,r2,r3;
	double C1,reductionFactor=1e12;
	bool RUNNING=true;
	size_t steps;
	int Sz1,Counter=0;
	while(RUNNING)
		{C1=(Zeta*r0/exp(-r0/k))/reductionFactor;
		if(VERBOSE){cout<<"Solving Poisson Boltzman Equation...\nFirst Guess:\tC = "<<C1<<"...";}
		initialize_PBE(y,r0,C1,S);
		steps=integrate_adaptive(controlled_stepper,poisson_boltzmann,y,r0,rf,dr,push_back_state_and_time(y1,r1));
		Sz1=steps+1;
		if(!isnan(y1[Sz1-1][0]))
			{// Good Choice of C1
			RUNNING=false;break;}
		else
			{Counter++;
			if(Counter>=MAX_PBE_ITERATIONS){return nan("");}
			// NaN Error
			if(VERBOSE){cout<<"Output NaN! Retrying...\n";}
			// Increase Reduction Factor
			reductionFactor*=10;
			y1.clear(); r1.clear();}
		}
	double Err1=Zeta-y1[Sz1-1][0];
	if(VERBOSE){cout<<"Done! ("<<Sz1<<" points)\t Calculated: "<<y1[Sz1-1][0]<<endl;}
	y1.clear(); r1.clear();

	//double C2=Zeta*r0/exp(-r0/k)/1e8;
	double C2=Zeta*r0/exp(-r0/k)/(reductionFactor*1e4);
	if(VERBOSE){cout<<"Second Guess:\tC = "<<C2<<"...";}
	initialize_PBE(y,r0,C2,S);
	steps=integrate_adaptive(controlled_stepper,poisson_boltzmann,y,r0,rf,dr,push_back_state_and_time(y2,r2));
	int Sz2=steps+1;
	double Err2=Zeta-y2[Sz2-1][0];
	if(VERBOSE){cout<<"Done! ("<<Sz2<<" points)\t Calculated: "<<y2[Sz2-1][0]<<endl;}
	y2.clear(); r2.clear();

	// Guess Coefficient Assuming Linear Relationship
	//double C=(C1-C2)*(Zeta-y2[Sz2-1][0])/(y1[Sz1-1][0]-y2[Sz2-1][0])+C2;
	double C;
	// Acceptable Error
	double Err3;
	RUNNING=true;
	bool nanCHECKING=true;
	int Sz3;
	Counter=0;
	while(RUNNING)
		{// Define New Coefficient Based on Error (C2=next to last,C1=last)
		C=(C2-C1)*(Err2/2-Err1)/(Err2-Err1)+C1;
		if(VERBOSE){cout<<"Next Guess:\tC = "<<C<<"...";}
		nanCHECKING=true;
		while(nanCHECKING)
			{initialize_PBE(y,r0,C,S);
			steps=integrate_adaptive(controlled_stepper,poisson_boltzmann,y,r0,rf,dr,push_back_state_and_time(y3,r3));
			Sz3=steps+1;
			if(!isnan(y3[Sz3-1][0]))
				{// Good Choice of C
				nanCHECKING=false;break;}
			else
				{Counter++;
				if(Counter>=MAX_PBE_ITERATIONS){return nan("");}
				// NaN Error
				if(VERBOSE){cout<<"Output NaN! Retrying...\n";}
				// Reduce C
				C/=2;
				y3.clear();r3.clear();}
			}
		Err3=Zeta-y3[Sz3-1][0];
		if(VERBOSE){cout<<"Done! ("<<Sz3<<" points)\t|Calculated: "<<y3[Sz3-1][0]<<"|Error %: "<<abs(Err3/Zeta)<<"|"<<ACCEPTED_ERROR_PERCENT<<endl;}
		
		if(abs(Err3/Zeta)>ACCEPTED_ERROR_PERCENT)
			{// Update Coefficient Before Last
			C1=C2;Err1=Err2;
			// Update Last Coefficient
			C2=C;Err2=Err3;			
			// Clear Memory
			y3.clear();r3.clear();}
		else{RUNNING=false;break;}
		}

	return C;}

	// y[0] = f
	// y[1] = df/dr
	// y[2] = d2f/dr2
	// y[3] = d3f/dr3
	// y[4] = d4f/dr4
	// Equilibrium Electric Pontential
	// y[5] = potential
	// y[6] = d(potential)/dr
	// Induced Electrochemical Potential Function (9 ion)
	// y[7] = IEP1
	// y[8] = d(IEP1)/dr
	// y[9] = IEP2
	// y[10] = d(IEP2)/dr
	// y[11] = IEP3
	// y[12] = d(IEP3)/dr
	// y[13] = IEP4
	// y[14] = d(IEP4)/dr
	// y[15] = IEP5
	// y[16] = d(IEP5)/dr
	// y[17] = IEP6
	// y[18] = d(IEP6)/dr
	// y[19] = IEP7
	// y[20] = d(IEP7)/dr
	// y[21] = IEP8
	// y[22] = d(IEP8)/dr
	// y[23] = IEP9
	// y[24] = d(IEP9)/dr
	// Constants
	// y[25] = Temp					// [Kelvin]
	// y[26] = numIon
	// Ion Properties
	// y[27] = Ion1.val;		
	// y[28] = Ion1.conc;		// mM [mol/m^3]
	// y[29] = Ion1.radius;		// meters
	// y[30] = Ion2.val;
	// y[31] = Ion2.conc;
	// y[32] = Ion2.radius;
	// y[33] = Ion3.val;
	// y[34] = Ion3.conc;
	// y[35] = Ion3.radius;
	// y[36] = Ion4.val;
	// y[37] = Ion4.conc;
	// y[38] = Ion4.radius;
	// y[39] = Ion5.val;
	// y[40] = Ion5.conc;
	// y[41] = Ion5.radius;
	// y[42] = Ion6.val;
	// y[43] = Ion6.conc;
	// y[44] = Ion6.radius;
	// y[45] = Ion7.val;
	// y[46] = Ion7.conc;
	// y[47] = Ion7.radius;
	// y[48] = Ion8.val;
	// y[49] = Ion8.conc;
	// y[50] = Ion8.radius;
	// y[51] = Ion9.val;
	// y[52] = Ion9.conc;
	// y[53] = Ion9.radius;
	// Solution Properties
	// y[54] = relative dielectric	[dimensionless]
	// y[55] = Debye Length [meters]
	// y[56] = viscosity  [Pa s]
void homogeneous_form_9ion(const state_type &y,state_type &dy,const double r)
	{double T=y[25];									// temperature [Kelvin]
	double viscosity=y[56];							// [Newton*second/meter^2]
	// Organize Ion Data
	int numIon=y[26];	
	double* ion_conc=new double[numIon];
	int* ion_val=new int[numIon];
	double* ion_rad=new double[numIon];
	double* ion_mob=new double[numIon];
	double* ion_fc=new double[numIon];
	// 1st Ion Properties
	ion_val[0]=y[27];
   ion_conc[0]=y[28];  		// mM or mol/m^3	    
	ion_rad[0]=y[29];		// meters
	ion_mob[0]=calc_Ion_Mobility(ion_val[0],ion_rad[0],viscosity);
	ion_fc[0]=calc_Ion_Friction_Coefficient(ion_val[0],ion_mob[0]);
	// 2nd Ion Properties
	ion_val[1]=y[30];
   ion_conc[1]=y[31];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[1]=y[32];													// [meter]
	ion_mob[1]=calc_Ion_Mobility(ion_val[1],ion_rad[1],viscosity);		// [meter^2/Volt*second]
	ion_fc[1]=calc_Ion_Friction_Coefficient(ion_val[1],ion_mob[1]);		// [Newton*second/meter]
	// 3rd Ion Properties
	ion_val[2]=y[33];
   ion_conc[2]=y[34];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[2]=y[35];													// [meter]
	ion_mob[2]=calc_Ion_Mobility(ion_val[2],ion_rad[2],viscosity);		// [meter^2/Volt*second]
	ion_fc[2]=calc_Ion_Friction_Coefficient(ion_val[2],ion_mob[2]);		// [Newton*second/meter]
	// 4th Ion Properties
	ion_val[3]=y[36];
   ion_conc[3]=y[37];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[3]=y[38];													// [meter]
	ion_mob[3]=calc_Ion_Mobility(ion_val[3],ion_rad[3],viscosity);		// [meter^2/Volt*second]
	ion_fc[3]=calc_Ion_Friction_Coefficient(ion_val[3],ion_mob[3]);		// [Newton*second/meter]
	// 5th Ion Properties
	ion_val[4]=y[39];
   ion_conc[4]=y[40];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[4]=y[41];													// [meter]
	ion_mob[4]=calc_Ion_Mobility(ion_val[4],ion_rad[4],viscosity);		// [meter^2/Volt*second]
	ion_fc[4]=calc_Ion_Friction_Coefficient(ion_val[4],ion_mob[4]);		// [Newton*second/meter]
	// 6th Ion Properties
	ion_val[5]=y[42];
   ion_conc[5]=y[43];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[5]=y[44];													// [meter]
	ion_mob[5]=calc_Ion_Mobility(ion_val[5],ion_rad[5],viscosity);		// [meter^2/Volt*second]
	ion_fc[5]=calc_Ion_Friction_Coefficient(ion_val[5],ion_mob[5]);		// [Newton*second/meter]
	// 7th Ion Properties
	ion_val[6]=y[45];
   ion_conc[6]=y[46];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[6]=y[47];													// [meter]
	ion_mob[6]=calc_Ion_Mobility(ion_val[6],ion_rad[6],viscosity);		// [meter^2/Volt*second]
	ion_fc[6]=calc_Ion_Friction_Coefficient(ion_val[6],ion_mob[6]);		// [Newton*second/meter]
	// 8th Ion Properties
	ion_val[7]=y[48];
   ion_conc[7]=y[49];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[7]=y[50];													// [meter]
	ion_mob[7]=calc_Ion_Mobility(ion_val[7],ion_rad[7],viscosity);		// [meter^2/Volt*second]
	ion_fc[7]=calc_Ion_Friction_Coefficient(ion_val[7],ion_mob[7]);		// [Newton*second/meter]
	// 9th Ion Properties
	ion_val[8]=y[51];
   ion_conc[8]=y[52];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[8]=y[53];													// [meter]
	ion_mob[8]=calc_Ion_Mobility(ion_val[8],ion_rad[8],viscosity);		// [meter^2/Volt*second]
	ion_fc[8]=calc_Ion_Friction_Coefficient(ion_val[8],ion_mob[8]);		// [Newton*second/meter]

	double Debye=y[55];				// meters	
	double dielectric=y[54];
	// Convert Concentration to Number Density (particles per volume (m^3))
	ion_conc[0]*=Na;
	ion_conc[1]*=Na;
	ion_conc[2]*=Na;
	ion_conc[3]*=Na;
	ion_conc[4]*=Na;
	ion_conc[5]*=Na;
	ion_conc[6]*=Na;
	ion_conc[7]*=Na;
	ion_conc[8]*=Na;
	// Calculation Constants
	double A;
	int ionIndex;
    // Linearized Governing Equations
	// F FUNCTION
	// df/dr = y[1]
	dy[0]=y[1];
	// d2f/dr2 = y[2]
	dy[1]=y[2];
	// d3f/dr3 = y[3]
	dy[2]=y[3];
	// d4f/dr4 = y[4]
	dy[3]=y[4];
	// d5f/dr5
	// 1st Ion Equilibrium Number Density
	double dN1_dr=(-ion_conc[0]*ion_val[0]*ec/(kb*T))*y[6]*exp(-ec*ion_val[0]*y[5]/(kb*T));
	double trm1=ion_val[0]*ec*dN1_dr*y[7];
	// 2nd Ion Equilibrium Number Density
	double dN2_dr=(-ion_conc[1]*ion_val[1]*ec/(kb*T))*y[6]*exp(-ec*ion_val[1]*y[5]/(kb*T));
	double trm2=ion_val[1]*ec*dN2_dr*y[9];
	// 3rd Ion Equilibrium Number Density
	double dN3_dr=(-ion_conc[2]*ion_val[2]*ec/(kb*T))*y[6]*exp(-ec*ion_val[2]*y[5]/(kb*T));
	double trm3=ion_val[2]*ec*dN3_dr*y[11];
	// 4th Ion Equilibrium Number Density
	double dN4_dr=(-ion_conc[3]*ion_val[3]*ec/(kb*T))*y[6]*exp(-ec*ion_val[3]*y[5]/(kb*T));
	double trm4=ion_val[3]*ec*dN4_dr*y[13];
	// 5th Ion Equilibrium Number Density
	double dN5_dr=(-ion_conc[4]*ion_val[4]*ec/(kb*T))*y[6]*exp(-ec*ion_val[4]*y[5]/(kb*T));
	double trm5=ion_val[4]*ec*dN5_dr*y[15];
	// 6th Ion Equilibrium Number Density
	double dN6_dr=(-ion_conc[5]*ion_val[5]*ec/(kb*T))*y[6]*exp(-ec*ion_val[5]*y[5]/(kb*T));
	double trm6=ion_val[5]*ec*dN6_dr*y[17];
	// 7th Ion Equilibrium Number Density
	double dN7_dr=(-ion_conc[6]*ion_val[6]*ec/(kb*T))*y[6]*exp(-ec*ion_val[6]*y[5]/(kb*T));
	double trm7=ion_val[6]*ec*dN7_dr*y[19];
	// 8th Ion Equilibrium Number Density
	double dN8_dr=(-ion_conc[7]*ion_val[7]*ec/(kb*T))*y[6]*exp(-ec*ion_val[7]*y[5]/(kb*T));
	double trm8=ion_val[7]*ec*dN8_dr*y[21];
	// 9th Ion Equilibrium Number Density
	double dN9_dr=(-ion_conc[8]*ion_val[8]*ec/(kb*T))*y[6]*exp(-ec*ion_val[8]*y[5]/(kb*T));
	double trm9=ion_val[8]*ec*dN8_dr*y[23];
	//
	dy[4]=-4*y[4]/r + 4*y[3]/(r*r) + (trm1+trm2+trm3+trm4+trm5+trm6+trm7+trm8)/(viscosity*r);
	// EQUILIBRIUM POTENTIAL
	// d(potential)/dr = y[6]
	dy[5]=y[6];
	// d2(potential)/dr2
	A=0;
	for(int i=0;i<numIon;i++){A+=ion_val[i]*ion_conc[i]*exp(-ec*ion_val[i]*y[5]/(kb*T));}
	dy[6]=-ec*A/(dielectric*eo) - 2*y[6]/r;
	// INDUCED ELECTROCHEMICAL POTENTIAL FUNCTION (2 ions)
	// 1st Ion
	// d(IEP)/dr
   dy[7]=y[8];
	// d2(IEP)/dr2
	A=(ion_val[0]*ec/(kb*T))*y[6];
   dy[8]=-2*y[8]/r + 2*y[7]/(r*r) + A*(y[8] - (2*ion_fc[0]/(r*ion_val[0]*ec))*y[1]);
	// 2nd Ion
	// d(IEP)/dr
   dy[9]=y[10];
	// d2(IEP)/dr2
	A=(ion_val[1]*ec/(kb*T))*y[6];
   dy[10]=-2*y[10]/r + 2*y[9]/(r*r) + A*(y[10] - (2*ion_fc[1]/(r*ion_val[1]*ec))*y[1]);
	// 3rd Ion
	// d(IEP)/dr
   dy[11]=y[12];
	// d2(IEP)/dr2
	A=(ion_val[2]*ec/(kb*T))*y[6];
   dy[12]=-2*y[12]/r + 2*y[11]/(r*r) + A*(y[12] - (2*ion_fc[2]/(r*ion_val[2]*ec))*y[1]);
	// 4th Ion
	// d(IEP)/dr
   dy[13]=y[14];
	// d2(IEP)/dr2
	A=(ion_val[3]*ec/(kb*T))*y[6];
   dy[14]=-2*y[14]/r + 2*y[13]/(r*r) + A*(y[14] - (2*ion_fc[3]/(r*ion_val[3]*ec))*y[1]);
	// 5th Ion
	// d(IEP)/dr
   dy[15]=y[16];
	// d2(IEP)/dr2
	A=(ion_val[4]*ec/(kb*T))*y[6];
   dy[16]=-2*y[16]/r + 2*y[15]/(r*r) + A*(y[16] - (2*ion_fc[4]/(r*ion_val[4]*ec))*y[1]);
	// 6th Ion
	// d(IEP)/dr
   dy[17]=y[18];
	// d2(IEP)/dr2
	A=(ion_val[5]*ec/(kb*T))*y[6];
   dy[18]=-2*y[18]/r + 2*y[17]/(r*r) + A*(y[18] - (2*ion_fc[5]/(r*ion_val[5]*ec))*y[1]);
	// 7th Ion
	// d(IEP)/dr
   dy[19]=y[20];
	// d2(IEP)/dr2
	A=(ion_val[6]*ec/(kb*T))*y[6];
   dy[20]=-2*y[20]/r + 2*y[19]/(r*r) + A*(y[20] - (2*ion_fc[6]/(r*ion_val[6]*ec))*y[1]);
	// 8th Ion
	// d(IEP)/dr
   dy[21]=y[22];
	// d2(IEP)/dr2
	A=(ion_val[7]*ec/(kb*T))*y[6];
   dy[22]=-2*y[22]/r + 2*y[21]/(r*r) + A*(y[22] - (2*ion_fc[7]/(r*ion_val[7]*ec))*y[1]);
	// 9th Ion
	// d(IEP)/dr
   dy[23]=y[24];
	// d2(IEP)/dr2
	A=(ion_val[8]*ec/(kb*T))*y[6];
   dy[24]=-2*y[24]/r + 2*y[23]/(r*r) + A*(y[24] - (2*ion_fc[8]/(r*ion_val[8]*ec))*y[1]);

	// Clear Memory
	delete [] ion_conc;delete [] ion_val;delete [] ion_rad;delete [] ion_mob;delete [] ion_fc;}

void inhomogeneous_Prob1_9ion(const state_type &y,state_type &dy,const double r)
	{double T=y[25];									// temperature [Kelvin]
	double viscosity=y[56];							// [Newton*second/meter^2]
	// Organize Ion Data
	int numIon=y[26];	
	double* ion_conc=new double[numIon];
	int* ion_val=new int[numIon];
	double* ion_rad=new double[numIon];
	double* ion_mob=new double[numIon];
	double* ion_fc=new double[numIon];
	// 1st Ion Properties
	ion_val[0]=y[27];
   ion_conc[0]=y[28];  		// mM or mol/m^3	    
	ion_rad[0]=y[29];		// meters
	ion_mob[0]=calc_Ion_Mobility(ion_val[0],ion_rad[0],viscosity);
	ion_fc[0]=calc_Ion_Friction_Coefficient(ion_val[0],ion_mob[0]);
	// 2nd Ion Properties
	ion_val[1]=y[30];
   ion_conc[1]=y[31];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[1]=y[32];													// [meter]
	ion_mob[1]=calc_Ion_Mobility(ion_val[1],ion_rad[1],viscosity);		// [meter^2/Volt*second]
	ion_fc[1]=calc_Ion_Friction_Coefficient(ion_val[1],ion_mob[1]);		// [Newton*second/meter]
	// 3rd Ion Properties
	ion_val[2]=y[33];
   ion_conc[2]=y[34];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[2]=y[35];													// [meter]
	ion_mob[2]=calc_Ion_Mobility(ion_val[2],ion_rad[2],viscosity);		// [meter^2/Volt*second]
	ion_fc[2]=calc_Ion_Friction_Coefficient(ion_val[2],ion_mob[2]);		// [Newton*second/meter]
	// 4th Ion Properties
	ion_val[3]=y[36];
   ion_conc[3]=y[37];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[3]=y[38];													// [meter]
	ion_mob[3]=calc_Ion_Mobility(ion_val[3],ion_rad[3],viscosity);		// [meter^2/Volt*second]
	ion_fc[3]=calc_Ion_Friction_Coefficient(ion_val[3],ion_mob[3]);		// [Newton*second/meter]
	// 5th Ion Properties
	ion_val[4]=y[39];
   ion_conc[4]=y[40];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[4]=y[41];													// [meter]
	ion_mob[4]=calc_Ion_Mobility(ion_val[4],ion_rad[4],viscosity);		// [meter^2/Volt*second]
	ion_fc[4]=calc_Ion_Friction_Coefficient(ion_val[4],ion_mob[4]);		// [Newton*second/meter]
	// 6th Ion Properties
	ion_val[5]=y[42];
   ion_conc[5]=y[43];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[5]=y[44];													// [meter]
	ion_mob[5]=calc_Ion_Mobility(ion_val[5],ion_rad[5],viscosity);		// [meter^2/Volt*second]
	ion_fc[5]=calc_Ion_Friction_Coefficient(ion_val[5],ion_mob[5]);		// [Newton*second/meter]
	// 7th Ion Properties
	ion_val[6]=y[45];
   ion_conc[6]=y[46];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[6]=y[47];													// [meter]
	ion_mob[6]=calc_Ion_Mobility(ion_val[6],ion_rad[6],viscosity);		// [meter^2/Volt*second]
	ion_fc[6]=calc_Ion_Friction_Coefficient(ion_val[6],ion_mob[6]);		// [Newton*second/meter]
	// 8th Ion Properties
	ion_val[7]=y[48];
   ion_conc[7]=y[49];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[7]=y[50];													// [meter]
	ion_mob[7]=calc_Ion_Mobility(ion_val[7],ion_rad[7],viscosity);		// [meter^2/Volt*second]
	ion_fc[7]=calc_Ion_Friction_Coefficient(ion_val[7],ion_mob[7]);		// [Newton*second/meter]
	// 9th Ion Properties
	ion_val[8]=y[51];
   ion_conc[8]=y[52];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[8]=y[53];													// [meter]
	ion_mob[8]=calc_Ion_Mobility(ion_val[8],ion_rad[8],viscosity);		// [meter^2/Volt*second]
	ion_fc[8]=calc_Ion_Friction_Coefficient(ion_val[8],ion_mob[8]);		// [Newton*second/meter]

	double Debye=y[55];				// meters	
	double dielectric=y[54];
	// Convert Concentration to Number Density (particles per volume (m^3))
	ion_conc[0]*=Na;
	ion_conc[1]*=Na;
	ion_conc[2]*=Na;
	ion_conc[3]*=Na;
	ion_conc[4]*=Na;
	ion_conc[5]*=Na;
	ion_conc[6]*=Na;
	ion_conc[7]*=Na;
	ion_conc[8]*=Na;
	// Calculation Constants
	double A,dN_dr;
	int ionIndex;
	// Linearized Governing Equations
	// F FUNCTION
	// df/dr = y[1]
	dy[0]=y[1];
	// d2f/dr2 = y[2]
	dy[1]=y[2];
	// d3f/dr3 = y[3]
	dy[2]=y[3];
	// d4f/dr4 = y[4]
	dy[3]=y[4];
	// d5f/dr5
	A=0;
	for(int i=0;i<numIon;i++)
		{// Ion Equilibrium Number Density
		dN_dr=(-ion_conc[i]*ion_val[i]*ec/(kb*T))*y[6]*exp(-ec*ion_val[i]*y[5]/(kb*T));
		// Ion Contribution
		ionIndex=7+2*i; 
		A+=ion_val[i]*ec*dN_dr*y[ionIndex];}
    dy[4]=-4*y[4]/r + 4*y[3]/(r*r) + A/(viscosity*r);
	// EQUILIBRIUM POTENTIAL
	// d(potential)/dr = y[6]
	dy[5]=y[6];
	// d2(potential)/dr2
	A=0;
	for(int i=0;i<numIon;i++){A+=ion_val[i]*ion_conc[i]*exp(-ec*ion_val[i]*y[5]/(kb*T));}
	dy[6]=-ec*A/(dielectric*eo) - 2*y[6]/r;
	// INDUCED ELECTROCHEMICAL POTENTIAL FUNCTION (2 ions)
	// 1st Ion
	// d(IEP)/dr = y[8]
   dy[7]=y[8];
	// d2(IEP)/dr2
	A=(ion_val[0]*ec/(kb*T))*y[6];
   dy[8]=-2*y[8]/r + 2*y[7]/(r*r) + A*(y[8] - (2*ion_fc[0]/(r*ion_val[0]*ec))*y[1] - ion_fc[0]/(ion_val[0]*ec));
	// 2nd Ion
	// d(IEP)/dr = y[10]
   dy[9]=y[10];
	// d2(IEP)/dr2
	A=(ion_val[1]*ec/(kb*T))*y[6];
   dy[10]=-2*y[10]/r + 2*y[9]/(r*r) + A*(y[10] - (2*ion_fc[1]/(r*ion_val[1]*ec))*y[1] - ion_fc[1]/(ion_val[1]*ec));
	// 3rd Ion
	// d(IEP)/dr
   dy[11]=y[12];
	// d2(IEP)/dr2
	A=(ion_val[2]*ec/(kb*T))*y[6];
   dy[12]=-2*y[12]/r + 2*y[11]/(r*r) + A*(y[12] - (2*ion_fc[2]/(r*ion_val[2]*ec))*y[1] - ion_fc[2]/(ion_val[2]*ec));
	// 4th Ion
	// d(IEP)/dr
   dy[13]=y[14];
	// d2(IEP)/dr2
	A=(ion_val[3]*ec/(kb*T))*y[6];
   dy[14]=-2*y[14]/r + 2*y[13]/(r*r) + A*(y[14] - (2*ion_fc[3]/(r*ion_val[3]*ec))*y[1] - ion_fc[3]/(ion_val[3]*ec));
	// 5th Ion
	// d(IEP)/dr
   dy[15]=y[16];
	// d2(IEP)/dr2
	A=(ion_val[4]*ec/(kb*T))*y[6];
   dy[16]=-2*y[16]/r + 2*y[15]/(r*r) + A*(y[16] - (2*ion_fc[4]/(r*ion_val[4]*ec))*y[1] - ion_fc[4]/(ion_val[4]*ec));
	// 6th Ion
	// d(IEP)/dr
   dy[17]=y[18];
	// d2(IEP)/dr2
	A=(ion_val[5]*ec/(kb*T))*y[6];
   dy[18]=-2*y[18]/r + 2*y[17]/(r*r) + A*(y[18] - (2*ion_fc[5]/(r*ion_val[5]*ec))*y[1] - ion_fc[5]/(ion_val[5]*ec));
	// 7th Ion
	// d(IEP)/dr
   dy[19]=y[20];
	// d2(IEP)/dr2
	A=(ion_val[6]*ec/(kb*T))*y[6];
   dy[20]=-2*y[20]/r + 2*y[19]/(r*r) + A*(y[20] - (2*ion_fc[6]/(r*ion_val[6]*ec))*y[1] - ion_fc[6]/(ion_val[6]*ec));
	// 8th Ion
	// d(IEP)/dr
   dy[21]=y[22];
	// d2(IEP)/dr2
	A=(ion_val[7]*ec/(kb*T))*y[6];
   dy[22]=-2*y[22]/r + 2*y[21]/(r*r) + A*(y[22] - (2*ion_fc[7]/(r*ion_val[7]*ec))*y[1] - ion_fc[7]/(ion_val[7]*ec));
	// 9th Ion
	// d(IEP)/dr
   dy[23]=y[24];
	// d2(IEP)/dr2
	A=(ion_val[8]*ec/(kb*T))*y[6];
   dy[24]=-2*y[24]/r + 2*y[23]/(r*r) + A*(y[24] - (2*ion_fc[8]/(r*ion_val[8]*ec))*y[1] - ion_fc[8]/(ion_val[8]*ec));

	// Clear Memory
	delete [] ion_conc;delete [] ion_val;delete [] ion_rad;delete [] ion_mob;delete [] ion_fc;}

void inhomogeneous_Prob2_9ion(const state_type &y,state_type &dy,const double r)
	{double T=y[25];									// temperature [Kelvin]
	double viscosity=y[56];							// [Newton*second/meter^2]
	// Organize Ion Data
	int numIon=y[26];	
	double* ion_conc=new double[numIon];
	int* ion_val=new int[numIon];
	double* ion_rad=new double[numIon];
	double* ion_mob=new double[numIon];
	double* ion_fc=new double[numIon];
	// 1st Ion Properties
	ion_val[0]=y[27];
   ion_conc[0]=y[28];  		// mM or mol/m^3	    
	ion_rad[0]=y[29];		// meters
	ion_mob[0]=calc_Ion_Mobility(ion_val[0],ion_rad[0],viscosity);
	ion_fc[0]=calc_Ion_Friction_Coefficient(ion_val[0],ion_mob[0]);
	// 2nd Ion Properties
	ion_val[1]=y[30];
   ion_conc[1]=y[31];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[1]=y[32];													// [meter]
	ion_mob[1]=calc_Ion_Mobility(ion_val[1],ion_rad[1],viscosity);		// [meter^2/Volt*second]
	ion_fc[1]=calc_Ion_Friction_Coefficient(ion_val[1],ion_mob[1]);		// [Newton*second/meter]
	// 3rd Ion Properties
	ion_val[2]=y[33];
   ion_conc[2]=y[34];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[2]=y[35];													// [meter]
	ion_mob[2]=calc_Ion_Mobility(ion_val[2],ion_rad[2],viscosity);		// [meter^2/Volt*second]
	ion_fc[2]=calc_Ion_Friction_Coefficient(ion_val[2],ion_mob[2]);		// [Newton*second/meter]
	// 4th Ion Properties
	ion_val[3]=y[36];
   ion_conc[3]=y[37];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[3]=y[38];													// [meter]
	ion_mob[3]=calc_Ion_Mobility(ion_val[3],ion_rad[3],viscosity);		// [meter^2/Volt*second]
	ion_fc[3]=calc_Ion_Friction_Coefficient(ion_val[3],ion_mob[3]);		// [Newton*second/meter]
	// 5th Ion Properties
	ion_val[4]=y[39];
   ion_conc[4]=y[40];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[4]=y[41];													// [meter]
	ion_mob[4]=calc_Ion_Mobility(ion_val[4],ion_rad[4],viscosity);		// [meter^2/Volt*second]
	ion_fc[4]=calc_Ion_Friction_Coefficient(ion_val[4],ion_mob[4]);		// [Newton*second/meter]
	// 6th Ion Properties
	ion_val[5]=y[42];
   ion_conc[5]=y[43];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[5]=y[44];													// [meter]
	ion_mob[5]=calc_Ion_Mobility(ion_val[5],ion_rad[5],viscosity);		// [meter^2/Volt*second]
	ion_fc[5]=calc_Ion_Friction_Coefficient(ion_val[5],ion_mob[5]);		// [Newton*second/meter]
	// 7th Ion Properties
	ion_val[6]=y[45];
   ion_conc[6]=y[46];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[6]=y[47];													// [meter]
	ion_mob[6]=calc_Ion_Mobility(ion_val[6],ion_rad[6],viscosity);		// [meter^2/Volt*second]
	ion_fc[6]=calc_Ion_Friction_Coefficient(ion_val[6],ion_mob[6]);		// [Newton*second/meter]
	// 8th Ion Properties
	ion_val[7]=y[48];
   ion_conc[7]=y[49];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[7]=y[50];													// [meter]
	ion_mob[7]=calc_Ion_Mobility(ion_val[7],ion_rad[7],viscosity);		// [meter^2/Volt*second]
	ion_fc[7]=calc_Ion_Friction_Coefficient(ion_val[7],ion_mob[7]);		// [Newton*second/meter]
	// 9th Ion Properties
	ion_val[8]=y[51];
   ion_conc[8]=y[52];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[8]=y[53];													// [meter]
	ion_mob[8]=calc_Ion_Mobility(ion_val[8],ion_rad[8],viscosity);		// [meter^2/Volt*second]
	ion_fc[8]=calc_Ion_Friction_Coefficient(ion_val[8],ion_mob[8]);		// [Newton*second/meter]

	double Debye=y[55];				// meters	
	double dielectric=y[54];
	// Convert Concentration to Number Density (particles per volume (m^3))
	ion_conc[0]*=Na;
	ion_conc[1]*=Na;
	ion_conc[2]*=Na;
	ion_conc[3]*=Na;
	ion_conc[4]*=Na;
	ion_conc[5]*=Na;
	ion_conc[6]*=Na;
	ion_conc[7]*=Na;
	ion_conc[8]*=Na;
    // Calculation Constants
	double A,dN_dr;
	int ionIndex;
    // Linearized Governing Equations
	// F FUNCTION
	// df/dr = y[1]
	dy[0]=y[1];
	// d2f/dr2 = y[2]
	dy[1]=y[2];
	// d3f/dr3 = y[3]
	dy[2]=y[3];
	// d4f/dr4 = y[4]
	dy[3]=y[4];
	// d5f/dr5
	A=0;
	for(int i=0;i<numIon;i++)
		{// Ion Equilibrium Number Density
		dN_dr=(-ion_conc[i]*ion_val[i]*ec/(kb*T))*y[6]*exp(-ec*ion_val[i]*y[5]/(kb*T));
		// Ion Contribution
		ionIndex=7+2*i; 
		A+=ion_val[i]*ec*dN_dr*(y[ionIndex]+r);}
   dy[4]=-4*y[4]/r + 4*y[3]/(r*r) + A/(viscosity*r);
	// EQUILIBRIUM POTENTIAL
	// d(potential)/dr = y[6]
	dy[5]=y[6];
	// d2(potential)/dr2
	A=0;
	for(int i=0;i<numIon;i++){A+=ion_val[i]*ion_conc[i]*exp(-ec*ion_val[i]*y[5]/(kb*T));}
	dy[6]=-ec*A/(dielectric*eo) - 2*y[6]/r;
	// INDUCED ELECTROCHEMICAL POTENTIAL FUNCTION (2 ions)
	// 1st Ion
	// d(IEP)/dr = y[8]
   dy[7]=y[8];
	// d2(IEP)/dr2
	A=(ion_val[0]*ec/(kb*T))*y[6];
   dy[8]=-2*y[8]/r + 2*y[7]/(r*r) + A*(y[8] - (2*ion_fc[0]/(r*ion_val[0]*ec))*y[1] + 1);
	// 2nd Ion
	// d(IEP)/dr = y[10]
   dy[9]=y[10];
	// d2(IEP)/dr2
	A=(ion_val[1]*ec/(kb*T))*y[6];
   dy[10]=-2*y[10]/r + 2*y[9]/(r*r) + A*(y[10] - (2*ion_fc[1]/(r*ion_val[1]*ec))*y[1] + 1);
	// 3rd Ion
	// d(IEP)/dr
   dy[11]=y[12];
	// d2(IEP)/dr2
	A=(ion_val[2]*ec/(kb*T))*y[6];
   dy[12]=-2*y[12]/r + 2*y[11]/(r*r) + A*(y[12] - (2*ion_fc[2]/(r*ion_val[2]*ec))*y[1] + 1);
	// 4th Ion
	// d(IEP)/dr
   dy[13]=y[14];
	// d2(IEP)/dr2
	A=(ion_val[3]*ec/(kb*T))*y[6];
   dy[14]=-2*y[14]/r + 2*y[13]/(r*r) + A*(y[14] - (2*ion_fc[3]/(r*ion_val[3]*ec))*y[1] + 1);
	// 5th Ion
	// d(IEP)/dr
   dy[15]=y[16];
	// d2(IEP)/dr2
	A=(ion_val[4]*ec/(kb*T))*y[6];
   dy[16]=-2*y[16]/r + 2*y[15]/(r*r) + A*(y[16] - (2*ion_fc[4]/(r*ion_val[4]*ec))*y[1] + 1);
	// 6th Ion
	// d(IEP)/dr
   dy[17]=y[18];
	// d2(IEP)/dr2
	A=(ion_val[5]*ec/(kb*T))*y[6];
   dy[18]=-2*y[18]/r + 2*y[17]/(r*r) + A*(y[18] - (2*ion_fc[5]/(r*ion_val[5]*ec))*y[1] + 1);
	// 7th Ion
	// d(IEP)/dr
   dy[19]=y[20];
	// d2(IEP)/dr2
	A=(ion_val[6]*ec/(kb*T))*y[6];
   dy[20]=-2*y[20]/r + 2*y[19]/(r*r) + A*(y[20] - (2*ion_fc[6]/(r*ion_val[6]*ec))*y[1] + 1);
	// 8th Ion
	// d(IEP)/dr
   dy[21]=y[22];
	// d2(IEP)/dr2
	A=(ion_val[7]*ec/(kb*T))*y[6];
   dy[22]=-2*y[22]/r + 2*y[21]/(r*r) + A*(y[22] - (2*ion_fc[7]/(r*ion_val[7]*ec))*y[1] + 1);
	// 9th Ion
	// d(IEP)/dr
   dy[23]=y[24];
	// d2(IEP)/dr2
	A=(ion_val[8]*ec/(kb*T))*y[6];
   dy[24]=-2*y[24]/r + 2*y[23]/(r*r) + A*(y[24] - (2*ion_fc[8]/(r*ion_val[8]*ec))*y[1] + 1);

	// Clear Memory
	delete [] ion_conc;delete [] ion_val;delete [] ion_rad;delete [] ion_mob;delete [] ion_fc;}


	// y[0] = f
	// y[1] = df/dr
	// y[2] = d2f/dr2
	// y[3] = d3f/dr3
	// y[4] = d4f/dr4
	// Equilibrium Electric Pontential
	// y[5] = potential
	// y[6] = d(potential)/dr
	// Induced Electrochemical Potential Function (3 ion)
	// y[7] = IEP1
	// y[8] = d(IEP1)/dr
	// y[9] = IEP2
	// y[10] = d(IEP2)/dr
	// y[11] = IEP3
	// y[12] = d(IEP3)/dr
	// y[13] = IEP4
	// y[14] = d(IEP4)/dr
	// y[15] = IEP5
	// y[16] = d(IEP5)/dr
	// y[17] = IEP6
	// y[18] = d(IEP6)/dr
	// y[19] = IEP7
	// y[20] = d(IEP7)/dr
	// y[21] = IEP8
	// y[22] = d(IEP8)/dr
	// Constants
	// y[23] = Temp					// [Kelvin]
	// y[24] = numIon
	// Ion Properties
	// y[25] = Ion1.val;		
	// y[26] = Ion1.conc;		// mM [mol/m^3]
	// y[27] = Ion1.radius;		// meters
	// y[28] = Ion2.val;
	// y[29] = Ion2.conc;
	// y[30] = Ion2.radius;
	// y[31] = Ion3.val;
	// y[32] = Ion3.conc;
	// y[33] = Ion3.radius;
	// y[34] = Ion4.val;
	// y[35] = Ion4.conc;
	// y[36] = Ion4.radius;
	// y[37] = Ion5.val;
	// y[38] = Ion5.conc;
	// y[39] = Ion5.radius;
	// y[40] = Ion6.val;
	// y[41] = Ion6.conc;
	// y[42] = Ion6.radius;
	// y[43] = Ion7.val;
	// y[44] = Ion7.conc;
	// y[45] = Ion7.radius;
	// y[46] = Ion8.val;
	// y[47] = Ion8.conc;
	// y[48] = Ion8.radius;
	// Solution Properties
	// y[49] = relative dielectric	[dimensionless]
	// y[50] = Debye Length [meters]
	// y[51] = viscosity  [Pa s]
void homogeneous_form_8ion(const state_type &y,state_type &dy,const double r)
	{double T=y[23];									// temperature [Kelvin]
	double viscosity=y[51];							// [Newton*second/meter^2]
	// Organize Ion Data
	int numIon=y[24];	
	double* ion_conc=new double[numIon];
	int* ion_val=new int[numIon];
	double* ion_rad=new double[numIon];
	double* ion_mob=new double[numIon];
	double* ion_fc=new double[numIon];
	// 1st Ion Properties
	ion_val[0]=y[25];
   ion_conc[0]=y[26];  		// mM or mol/m^3	    
	ion_rad[0]=y[27];		// meters
	ion_mob[0]=calc_Ion_Mobility(ion_val[0],ion_rad[0],viscosity);
	ion_fc[0]=calc_Ion_Friction_Coefficient(ion_val[0],ion_mob[0]);
	// 2nd Ion Properties
	ion_val[1]=y[28];
   ion_conc[1]=y[29];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[1]=y[30];													// [meter]
	ion_mob[1]=calc_Ion_Mobility(ion_val[1],ion_rad[1],viscosity);		// [meter^2/Volt*second]
	ion_fc[1]=calc_Ion_Friction_Coefficient(ion_val[1],ion_mob[1]);		// [Newton*second/meter]
	// 3rd Ion Properties
	ion_val[2]=y[31];
   ion_conc[2]=y[32];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[2]=y[33];													// [meter]
	ion_mob[2]=calc_Ion_Mobility(ion_val[2],ion_rad[2],viscosity);		// [meter^2/Volt*second]
	ion_fc[2]=calc_Ion_Friction_Coefficient(ion_val[2],ion_mob[2]);		// [Newton*second/meter]
	// 4th Ion Properties
	ion_val[3]=y[34];
   ion_conc[3]=y[35];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[3]=y[36];													// [meter]
	ion_mob[3]=calc_Ion_Mobility(ion_val[3],ion_rad[3],viscosity);		// [meter^2/Volt*second]
	ion_fc[3]=calc_Ion_Friction_Coefficient(ion_val[3],ion_mob[3]);		// [Newton*second/meter]
	// 5th Ion Properties
	ion_val[4]=y[37];
   ion_conc[4]=y[38];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[4]=y[39];													// [meter]
	ion_mob[4]=calc_Ion_Mobility(ion_val[4],ion_rad[4],viscosity);		// [meter^2/Volt*second]
	ion_fc[4]=calc_Ion_Friction_Coefficient(ion_val[4],ion_mob[4]);		// [Newton*second/meter]
	// 6th Ion Properties
	ion_val[5]=y[40];
   ion_conc[5]=y[41];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[5]=y[42];													// [meter]
	ion_mob[5]=calc_Ion_Mobility(ion_val[5],ion_rad[5],viscosity);		// [meter^2/Volt*second]
	ion_fc[5]=calc_Ion_Friction_Coefficient(ion_val[5],ion_mob[5]);		// [Newton*second/meter]
	// 7th Ion Properties
	ion_val[6]=y[43];
   ion_conc[6]=y[44];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[6]=y[45];													// [meter]
	ion_mob[6]=calc_Ion_Mobility(ion_val[6],ion_rad[6],viscosity);		// [meter^2/Volt*second]
	ion_fc[6]=calc_Ion_Friction_Coefficient(ion_val[6],ion_mob[6]);		// [Newton*second/meter]
	// 8th Ion Properties
	ion_val[7]=y[46];
   ion_conc[7]=y[47];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[7]=y[48];													// [meter]
	ion_mob[7]=calc_Ion_Mobility(ion_val[7],ion_rad[7],viscosity);		// [meter^2/Volt*second]
	ion_fc[7]=calc_Ion_Friction_Coefficient(ion_val[7],ion_mob[7]);		// [Newton*second/meter]

	double Debye=y[50];				// meters	
	double dielectric=y[49];
	// Convert Concentration to Number Density (particles per volume (m^3))
	ion_conc[0]*=Na;
	ion_conc[1]*=Na;
	ion_conc[2]*=Na;
	ion_conc[3]*=Na;
	ion_conc[4]*=Na;
	ion_conc[5]*=Na;
	ion_conc[6]*=Na;
	ion_conc[7]*=Na;
	// Calculation Constants
	double A;
	int ionIndex;
    // Linearized Governing Equations
	// F FUNCTION
	// df/dr = y[1]
	dy[0]=y[1];
	// d2f/dr2 = y[2]
	dy[1]=y[2];
	// d3f/dr3 = y[3]
	dy[2]=y[3];
	// d4f/dr4 = y[4]
	dy[3]=y[4];
	// d5f/dr5
	// 1st Ion Equilibrium Number Density
	double dN1_dr=(-ion_conc[0]*ion_val[0]*ec/(kb*T))*y[6]*exp(-ec*ion_val[0]*y[5]/(kb*T));
	double trm1=ion_val[0]*ec*dN1_dr*y[7];
	// 2nd Ion Equilibrium Number Density
	double dN2_dr=(-ion_conc[1]*ion_val[1]*ec/(kb*T))*y[6]*exp(-ec*ion_val[1]*y[5]/(kb*T));
	double trm2=ion_val[1]*ec*dN2_dr*y[9];
	// 3rd Ion Equilibrium Number Density
	double dN3_dr=(-ion_conc[2]*ion_val[2]*ec/(kb*T))*y[6]*exp(-ec*ion_val[2]*y[5]/(kb*T));
	double trm3=ion_val[2]*ec*dN3_dr*y[11];
	// 4th Ion Equilibrium Number Density
	double dN4_dr=(-ion_conc[3]*ion_val[3]*ec/(kb*T))*y[6]*exp(-ec*ion_val[3]*y[5]/(kb*T));
	double trm4=ion_val[3]*ec*dN4_dr*y[13];
	// 5th Ion Equilibrium Number Density
	double dN5_dr=(-ion_conc[4]*ion_val[4]*ec/(kb*T))*y[6]*exp(-ec*ion_val[4]*y[5]/(kb*T));
	double trm5=ion_val[4]*ec*dN5_dr*y[15];
	// 6th Ion Equilibrium Number Density
	double dN6_dr=(-ion_conc[5]*ion_val[5]*ec/(kb*T))*y[6]*exp(-ec*ion_val[5]*y[5]/(kb*T));
	double trm6=ion_val[5]*ec*dN6_dr*y[17];
	// 7th Ion Equilibrium Number Density
	double dN7_dr=(-ion_conc[6]*ion_val[6]*ec/(kb*T))*y[6]*exp(-ec*ion_val[6]*y[5]/(kb*T));
	double trm7=ion_val[6]*ec*dN7_dr*y[19];
	// 8th Ion Equilibrium Number Density
	double dN8_dr=(-ion_conc[7]*ion_val[7]*ec/(kb*T))*y[6]*exp(-ec*ion_val[7]*y[5]/(kb*T));
	double trm8=ion_val[7]*ec*dN8_dr*y[21];
	//
	dy[4]=-4*y[4]/r + 4*y[3]/(r*r) + (trm1+trm2+trm3+trm4+trm5+trm6+trm7+trm8)/(viscosity*r);
	// EQUILIBRIUM POTENTIAL
	// d(potential)/dr = y[6]
	dy[5]=y[6];
	// d2(potential)/dr2
	A=0;
	for(int i=0;i<numIon;i++){A+=ion_val[i]*ion_conc[i]*exp(-ec*ion_val[i]*y[5]/(kb*T));}
	dy[6]=-ec*A/(dielectric*eo) - 2*y[6]/r;
	// INDUCED ELECTROCHEMICAL POTENTIAL FUNCTION (2 ions)
	// 1st Ion
	// d(IEP)/dr
   dy[7]=y[8];
	// d2(IEP)/dr2
	A=(ion_val[0]*ec/(kb*T))*y[6];
   dy[8]=-2*y[8]/r + 2*y[7]/(r*r) + A*(y[8] - (2*ion_fc[0]/(r*ion_val[0]*ec))*y[1]);
	// 2nd Ion
	// d(IEP)/dr
   dy[9]=y[10];
	// d2(IEP)/dr2
	A=(ion_val[1]*ec/(kb*T))*y[6];
   dy[10]=-2*y[10]/r + 2*y[9]/(r*r) + A*(y[10] - (2*ion_fc[1]/(r*ion_val[1]*ec))*y[1]);
	// 3rd Ion
	// d(IEP)/dr
   dy[11]=y[12];
	// d2(IEP)/dr2
	A=(ion_val[2]*ec/(kb*T))*y[6];
   dy[12]=-2*y[12]/r + 2*y[11]/(r*r) + A*(y[12] - (2*ion_fc[2]/(r*ion_val[2]*ec))*y[1]);
	// 4th Ion
	// d(IEP)/dr
   dy[13]=y[14];
	// d2(IEP)/dr2
	A=(ion_val[3]*ec/(kb*T))*y[6];
   dy[14]=-2*y[14]/r + 2*y[13]/(r*r) + A*(y[14] - (2*ion_fc[3]/(r*ion_val[3]*ec))*y[1]);
	// 5th Ion
	// d(IEP)/dr
   dy[15]=y[16];
	// d2(IEP)/dr2
	A=(ion_val[4]*ec/(kb*T))*y[6];
   dy[16]=-2*y[16]/r + 2*y[15]/(r*r) + A*(y[16] - (2*ion_fc[4]/(r*ion_val[4]*ec))*y[1]);
	// 6th Ion
	// d(IEP)/dr
   dy[17]=y[18];
	// d2(IEP)/dr2
	A=(ion_val[5]*ec/(kb*T))*y[6];
   dy[18]=-2*y[18]/r + 2*y[17]/(r*r) + A*(y[18] - (2*ion_fc[5]/(r*ion_val[5]*ec))*y[1]);
	// 7th Ion
	// d(IEP)/dr
   dy[19]=y[20];
	// d2(IEP)/dr2
	A=(ion_val[6]*ec/(kb*T))*y[6];
   dy[20]=-2*y[20]/r + 2*y[19]/(r*r) + A*(y[20] - (2*ion_fc[6]/(r*ion_val[6]*ec))*y[1]);
	// 8th Ion
	// d(IEP)/dr
   dy[21]=y[22];
	// d2(IEP)/dr2
	A=(ion_val[7]*ec/(kb*T))*y[6];
   dy[22]=-2*y[22]/r + 2*y[21]/(r*r) + A*(y[22] - (2*ion_fc[7]/(r*ion_val[7]*ec))*y[1]);

	// Clear Memory
	delete [] ion_conc;delete [] ion_val;delete [] ion_rad;delete [] ion_mob;delete [] ion_fc;}

void inhomogeneous_Prob1_8ion(const state_type &y,state_type &dy,const double r)
	{double T=y[23];									// temperature [Kelvin]
	double viscosity=y[51];							// [Newton*second/meter^2]
	// Organize Ion Data
	int numIon=y[24];	
	double* ion_conc=new double[numIon];
	int* ion_val=new int[numIon];
	double* ion_rad=new double[numIon];
	double* ion_mob=new double[numIon];
	double* ion_fc=new double[numIon];
	// 1st Ion Properties
	ion_val[0]=y[25];
   ion_conc[0]=y[26];  		// mM or mol/m^3	    
	ion_rad[0]=y[27];		// meters
	ion_mob[0]=calc_Ion_Mobility(ion_val[0],ion_rad[0],viscosity);
	ion_fc[0]=calc_Ion_Friction_Coefficient(ion_val[0],ion_mob[0]);
	// 2nd Ion Properties
	ion_val[1]=y[28];
   ion_conc[1]=y[29];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[1]=y[30];													// [meter]
	ion_mob[1]=calc_Ion_Mobility(ion_val[1],ion_rad[1],viscosity);		// [meter^2/Volt*second]
	ion_fc[1]=calc_Ion_Friction_Coefficient(ion_val[1],ion_mob[1]);		// [Newton*second/meter]
	// 3rd Ion Properties
	ion_val[2]=y[31];
   ion_conc[2]=y[32];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[2]=y[33];													// [meter]
	ion_mob[2]=calc_Ion_Mobility(ion_val[2],ion_rad[2],viscosity);		// [meter^2/Volt*second]
	ion_fc[2]=calc_Ion_Friction_Coefficient(ion_val[2],ion_mob[2]);		// [Newton*second/meter]
	// 4th Ion Properties
	ion_val[3]=y[34];
   ion_conc[3]=y[35];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[3]=y[36];													// [meter]
	ion_mob[3]=calc_Ion_Mobility(ion_val[3],ion_rad[3],viscosity);		// [meter^2/Volt*second]
	ion_fc[3]=calc_Ion_Friction_Coefficient(ion_val[3],ion_mob[3]);		// [Newton*second/meter]
	// 5th Ion Properties
	ion_val[4]=y[37];
   ion_conc[4]=y[38];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[4]=y[39];													// [meter]
	ion_mob[4]=calc_Ion_Mobility(ion_val[4],ion_rad[4],viscosity);		// [meter^2/Volt*second]
	ion_fc[4]=calc_Ion_Friction_Coefficient(ion_val[4],ion_mob[4]);		// [Newton*second/meter]
	// 6th Ion Properties
	ion_val[5]=y[40];
   ion_conc[5]=y[41];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[5]=y[42];													// [meter]
	ion_mob[5]=calc_Ion_Mobility(ion_val[5],ion_rad[5],viscosity);		// [meter^2/Volt*second]
	ion_fc[5]=calc_Ion_Friction_Coefficient(ion_val[5],ion_mob[5]);		// [Newton*second/meter]
	// 7th Ion Properties
	ion_val[6]=y[43];
   ion_conc[6]=y[44];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[6]=y[45];													// [meter]
	ion_mob[6]=calc_Ion_Mobility(ion_val[6],ion_rad[6],viscosity);		// [meter^2/Volt*second]
	ion_fc[6]=calc_Ion_Friction_Coefficient(ion_val[6],ion_mob[6]);		// [Newton*second/meter]
	// 8th Ion Properties
	ion_val[7]=y[46];
   ion_conc[7]=y[47];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[7]=y[48];													// [meter]
	ion_mob[7]=calc_Ion_Mobility(ion_val[7],ion_rad[7],viscosity);		// [meter^2/Volt*second]
	ion_fc[7]=calc_Ion_Friction_Coefficient(ion_val[7],ion_mob[7]);		// [Newton*second/meter]

	double Debye=y[50];				// meters	
	double dielectric=y[49];
	// Convert Concentration to Number Density (particles per volume (m^3))
	ion_conc[0]*=Na;
	ion_conc[1]*=Na;
	ion_conc[2]*=Na;
	ion_conc[3]*=Na;
	ion_conc[4]*=Na;
	ion_conc[5]*=Na;
	ion_conc[6]*=Na;
	ion_conc[7]*=Na;
	// Calculation Constants
	double A,dN_dr;
	int ionIndex;
	// Linearized Governing Equations
	// F FUNCTION
	// df/dr = y[1]
	dy[0]=y[1];
	// d2f/dr2 = y[2]
	dy[1]=y[2];
	// d3f/dr3 = y[3]
	dy[2]=y[3];
	// d4f/dr4 = y[4]
	dy[3]=y[4];
	// d5f/dr5
	A=0;
	for(int i=0;i<numIon;i++)
		{// Ion Equilibrium Number Density
		dN_dr=(-ion_conc[i]*ion_val[i]*ec/(kb*T))*y[6]*exp(-ec*ion_val[i]*y[5]/(kb*T));
		// Ion Contribution
		ionIndex=7+2*i; 
		A+=ion_val[i]*ec*dN_dr*y[ionIndex];}
    dy[4]=-4*y[4]/r + 4*y[3]/(r*r) + A/(viscosity*r);
	// EQUILIBRIUM POTENTIAL
	// d(potential)/dr = y[6]
	dy[5]=y[6];
	// d2(potential)/dr2
	A=0;
	for(int i=0;i<numIon;i++){A+=ion_val[i]*ion_conc[i]*exp(-ec*ion_val[i]*y[5]/(kb*T));}
	dy[6]=-ec*A/(dielectric*eo) - 2*y[6]/r;
	// INDUCED ELECTROCHEMICAL POTENTIAL FUNCTION (2 ions)
	// 1st Ion
	// d(IEP)/dr = y[8]
   dy[7]=y[8];
	// d2(IEP)/dr2
	A=(ion_val[0]*ec/(kb*T))*y[6];
   dy[8]=-2*y[8]/r + 2*y[7]/(r*r) + A*(y[8] - (2*ion_fc[0]/(r*ion_val[0]*ec))*y[1] - ion_fc[0]/(ion_val[0]*ec));
	// 2nd Ion
	// d(IEP)/dr = y[10]
   dy[9]=y[10];
	// d2(IEP)/dr2
	A=(ion_val[1]*ec/(kb*T))*y[6];
   dy[10]=-2*y[10]/r + 2*y[9]/(r*r) + A*(y[10] - (2*ion_fc[1]/(r*ion_val[1]*ec))*y[1] - ion_fc[1]/(ion_val[1]*ec));
	// 3rd Ion
	// d(IEP)/dr
   dy[11]=y[12];
	// d2(IEP)/dr2
	A=(ion_val[2]*ec/(kb*T))*y[6];
   dy[12]=-2*y[12]/r + 2*y[11]/(r*r) + A*(y[12] - (2*ion_fc[2]/(r*ion_val[2]*ec))*y[1] - ion_fc[2]/(ion_val[2]*ec));
	// 4th Ion
	// d(IEP)/dr
   dy[13]=y[14];
	// d2(IEP)/dr2
	A=(ion_val[3]*ec/(kb*T))*y[6];
   dy[14]=-2*y[14]/r + 2*y[13]/(r*r) + A*(y[14] - (2*ion_fc[3]/(r*ion_val[3]*ec))*y[1] - ion_fc[3]/(ion_val[3]*ec));
	// 5th Ion
	// d(IEP)/dr
   dy[15]=y[16];
	// d2(IEP)/dr2
	A=(ion_val[4]*ec/(kb*T))*y[6];
   dy[16]=-2*y[16]/r + 2*y[15]/(r*r) + A*(y[16] - (2*ion_fc[4]/(r*ion_val[4]*ec))*y[1] - ion_fc[4]/(ion_val[4]*ec));
	// 6th Ion
	// d(IEP)/dr
   dy[17]=y[18];
	// d2(IEP)/dr2
	A=(ion_val[5]*ec/(kb*T))*y[6];
   dy[18]=-2*y[18]/r + 2*y[17]/(r*r) + A*(y[18] - (2*ion_fc[5]/(r*ion_val[5]*ec))*y[1] - ion_fc[5]/(ion_val[5]*ec));
	// 7th Ion
	// d(IEP)/dr
   dy[19]=y[20];
	// d2(IEP)/dr2
	A=(ion_val[6]*ec/(kb*T))*y[6];
   dy[20]=-2*y[20]/r + 2*y[19]/(r*r) + A*(y[20] - (2*ion_fc[6]/(r*ion_val[6]*ec))*y[1] - ion_fc[6]/(ion_val[6]*ec));
	// 8th Ion
	// d(IEP)/dr
   dy[21]=y[22];
	// d2(IEP)/dr2
	A=(ion_val[7]*ec/(kb*T))*y[6];
   dy[22]=-2*y[22]/r + 2*y[21]/(r*r) + A*(y[22] - (2*ion_fc[7]/(r*ion_val[7]*ec))*y[1] - ion_fc[7]/(ion_val[7]*ec));

	// Clear Memory
	delete [] ion_conc;delete [] ion_val;delete [] ion_rad;delete [] ion_mob;delete [] ion_fc;}

void inhomogeneous_Prob2_8ion(const state_type &y,state_type &dy,const double r)
	{double T=y[23];									// temperature [Kelvin]
	double viscosity=y[51];							// [Newton*second/meter^2]
	// Organize Ion Data
	int numIon=y[24];	
	double* ion_conc=new double[numIon];
	int* ion_val=new int[numIon];
	double* ion_rad=new double[numIon];
	double* ion_mob=new double[numIon];
	double* ion_fc=new double[numIon];
	// 1st Ion Properties
	ion_val[0]=y[25];
   ion_conc[0]=y[26];  		// mM or mol/m^3	    
	ion_rad[0]=y[27];		// meters
	ion_mob[0]=calc_Ion_Mobility(ion_val[0],ion_rad[0],viscosity);
	ion_fc[0]=calc_Ion_Friction_Coefficient(ion_val[0],ion_mob[0]);
	// 2nd Ion Properties
	ion_val[1]=y[28];
   ion_conc[1]=y[29];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[1]=y[30];													// [meter]
	ion_mob[1]=calc_Ion_Mobility(ion_val[1],ion_rad[1],viscosity);		// [meter^2/Volt*second]
	ion_fc[1]=calc_Ion_Friction_Coefficient(ion_val[1],ion_mob[1]);		// [Newton*second/meter]
	// 3rd Ion Properties
	ion_val[2]=y[31];
   ion_conc[2]=y[32];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[2]=y[33];													// [meter]
	ion_mob[2]=calc_Ion_Mobility(ion_val[2],ion_rad[2],viscosity);		// [meter^2/Volt*second]
	ion_fc[2]=calc_Ion_Friction_Coefficient(ion_val[2],ion_mob[2]);		// [Newton*second/meter]
	// 4th Ion Properties
	ion_val[3]=y[34];
   ion_conc[3]=y[35];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[3]=y[36];													// [meter]
	ion_mob[3]=calc_Ion_Mobility(ion_val[3],ion_rad[3],viscosity);		// [meter^2/Volt*second]
	ion_fc[3]=calc_Ion_Friction_Coefficient(ion_val[3],ion_mob[3]);		// [Newton*second/meter]
	// 5th Ion Properties
	ion_val[4]=y[37];
   ion_conc[4]=y[38];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[4]=y[39];													// [meter]
	ion_mob[4]=calc_Ion_Mobility(ion_val[4],ion_rad[4],viscosity);		// [meter^2/Volt*second]
	ion_fc[4]=calc_Ion_Friction_Coefficient(ion_val[4],ion_mob[4]);		// [Newton*second/meter]
	// 6th Ion Properties
	ion_val[5]=y[40];
   ion_conc[5]=y[41];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[5]=y[42];													// [meter]
	ion_mob[5]=calc_Ion_Mobility(ion_val[5],ion_rad[5],viscosity);		// [meter^2/Volt*second]
	ion_fc[5]=calc_Ion_Friction_Coefficient(ion_val[5],ion_mob[5]);		// [Newton*second/meter]
	// 7th Ion Properties
	ion_val[6]=y[43];
   ion_conc[6]=y[44];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[6]=y[45];													// [meter]
	ion_mob[6]=calc_Ion_Mobility(ion_val[6],ion_rad[6],viscosity);		// [meter^2/Volt*second]
	ion_fc[6]=calc_Ion_Friction_Coefficient(ion_val[6],ion_mob[6]);		// [Newton*second/meter]
	// 8th Ion Properties
	ion_val[7]=y[46];
   ion_conc[7]=y[47];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[7]=y[48];													// [meter]
	ion_mob[7]=calc_Ion_Mobility(ion_val[7],ion_rad[7],viscosity);		// [meter^2/Volt*second]
	ion_fc[7]=calc_Ion_Friction_Coefficient(ion_val[7],ion_mob[7]);		// [Newton*second/meter]

	double Debye=y[50];				// meters	
	double dielectric=y[49];
	// Convert Concentration to Number Density (particles per volume (m^3))
	ion_conc[0]*=Na;
	ion_conc[1]*=Na;
	ion_conc[2]*=Na;
	ion_conc[3]*=Na;
	ion_conc[4]*=Na;
	ion_conc[5]*=Na;
	ion_conc[6]*=Na;
	ion_conc[7]*=Na;
    // Calculation Constants
	double A,dN_dr;
	int ionIndex;
    // Linearized Governing Equations
	// F FUNCTION
	// df/dr = y[1]
	dy[0]=y[1];
	// d2f/dr2 = y[2]
	dy[1]=y[2];
	// d3f/dr3 = y[3]
	dy[2]=y[3];
	// d4f/dr4 = y[4]
	dy[3]=y[4];
	// d5f/dr5
	A=0;
	for(int i=0;i<numIon;i++)
		{// Ion Equilibrium Number Density
		dN_dr=(-ion_conc[i]*ion_val[i]*ec/(kb*T))*y[6]*exp(-ec*ion_val[i]*y[5]/(kb*T));
		// Ion Contribution
		ionIndex=7+2*i; 
		A+=ion_val[i]*ec*dN_dr*(y[ionIndex]+r);}
   dy[4]=-4*y[4]/r + 4*y[3]/(r*r) + A/(viscosity*r);
	// EQUILIBRIUM POTENTIAL
	// d(potential)/dr = y[6]
	dy[5]=y[6];
	// d2(potential)/dr2
	A=0;
	for(int i=0;i<numIon;i++){A+=ion_val[i]*ion_conc[i]*exp(-ec*ion_val[i]*y[5]/(kb*T));}
	dy[6]=-ec*A/(dielectric*eo) - 2*y[6]/r;
	// INDUCED ELECTROCHEMICAL POTENTIAL FUNCTION (2 ions)
	// 1st Ion
	// d(IEP)/dr = y[8]
   dy[7]=y[8];
	// d2(IEP)/dr2
	A=(ion_val[0]*ec/(kb*T))*y[6];
   dy[8]=-2*y[8]/r + 2*y[7]/(r*r) + A*(y[8] - (2*ion_fc[0]/(r*ion_val[0]*ec))*y[1] + 1);
	// 2nd Ion
	// d(IEP)/dr = y[10]
   dy[9]=y[10];
	// d2(IEP)/dr2
	A=(ion_val[1]*ec/(kb*T))*y[6];
   dy[10]=-2*y[10]/r + 2*y[9]/(r*r) + A*(y[10] - (2*ion_fc[1]/(r*ion_val[1]*ec))*y[1] + 1);
	// 3rd Ion
	// d(IEP)/dr
   dy[11]=y[12];
	// d2(IEP)/dr2
	A=(ion_val[2]*ec/(kb*T))*y[6];
   dy[12]=-2*y[12]/r + 2*y[11]/(r*r) + A*(y[12] - (2*ion_fc[2]/(r*ion_val[2]*ec))*y[1] + 1);
	// 4th Ion
	// d(IEP)/dr
   dy[13]=y[14];
	// d2(IEP)/dr2
	A=(ion_val[3]*ec/(kb*T))*y[6];
   dy[14]=-2*y[14]/r + 2*y[13]/(r*r) + A*(y[14] - (2*ion_fc[3]/(r*ion_val[3]*ec))*y[1] + 1);
	// 5th Ion
	// d(IEP)/dr
   dy[15]=y[16];
	// d2(IEP)/dr2
	A=(ion_val[4]*ec/(kb*T))*y[6];
   dy[16]=-2*y[16]/r + 2*y[15]/(r*r) + A*(y[16] - (2*ion_fc[4]/(r*ion_val[4]*ec))*y[1] + 1);
	// 6th Ion
	// d(IEP)/dr
   dy[17]=y[18];
	// d2(IEP)/dr2
	A=(ion_val[5]*ec/(kb*T))*y[6];
   dy[18]=-2*y[18]/r + 2*y[17]/(r*r) + A*(y[18] - (2*ion_fc[5]/(r*ion_val[5]*ec))*y[1] + 1);
	// 7th Ion
	// d(IEP)/dr
   dy[19]=y[20];
	// d2(IEP)/dr2
	A=(ion_val[6]*ec/(kb*T))*y[6];
   dy[20]=-2*y[20]/r + 2*y[19]/(r*r) + A*(y[20] - (2*ion_fc[6]/(r*ion_val[6]*ec))*y[1] + 1);
	// 8th Ion
	// d(IEP)/dr
   dy[21]=y[22];
	// d2(IEP)/dr2
	A=(ion_val[7]*ec/(kb*T))*y[6];
   dy[22]=-2*y[22]/r + 2*y[21]/(r*r) + A*(y[22] - (2*ion_fc[7]/(r*ion_val[7]*ec))*y[1] + 1);

	// Clear Memory
	delete [] ion_conc;delete [] ion_val;delete [] ion_rad;delete [] ion_mob;delete [] ion_fc;}

	// y[0] = f
	// y[1] = df/dr
	// y[2] = d2f/dr2
	// y[3] = d3f/dr3
	// y[4] = d4f/dr4
	// Equilibrium Electric Pontential
	// y[5] = potential
	// y[6] = d(potential)/dr
	// Induced Electrochemical Potential Function (3 ion)
	// y[7] = IEP1
	// y[8] = d(IEP1)/dr
	// y[9] = IEP2
	// y[10] = d(IEP2)/dr
	// y[11] = IEP3
	// y[12] = d(IEP3)/dr
	// y[13] = IEP4
	// y[14] = d(IEP4)/dr
	// y[15] = IEP5
	// y[16] = d(IEP5)/dr
	// y[17] = IEP6
	// y[18] = d(IEP6)/dr
	// y[19] = IEP7
	// y[20] = d(IEP7)/dr
	// Constants
	// y[21] = Temp					// [Kelvin]
	// y[22] = numIon
	// Ion Properties
	// y[23] = Ion1.val;		
	// y[24] = Ion1.conc;		// mM [mol/m^3]
	// y[25] = Ion1.radius;		// meters
	// y[26] = Ion2.val;
	// y[27] = Ion2.conc;
	// y[28] = Ion2.radius;
	// y[29] = Ion3.val;
	// y[30] = Ion3.conc;
	// y[31] = Ion3.radius;
	// y[32] = Ion4.val;
	// y[33] = Ion4.conc;
	// y[34] = Ion4.radius;
	// y[35] = Ion5.val;
	// y[36] = Ion5.conc;
	// y[37] = Ion5.radius;
	// y[38] = Ion6.val;
	// y[39] = Ion6.conc;
	// y[40] = Ion6.radius;
	// y[41] = Ion7.val;
	// y[42] = Ion7.conc;
	// y[43] = Ion7.radius;
	// Solution Properties
	// y[44] = relative dielectric	[dimensionless]
	// y[45] = Debye Length [meters]
	// y[46] = viscosity  [Pa s]
void homogeneous_form_7ion(const state_type &y,state_type &dy,const double r)
	{double T=y[21];									// temperature [Kelvin]
	double viscosity=y[46];							// [Newton*second/meter^2]
	// Organize Ion Data
	int numIon=y[22];	
	double* ion_conc=new double[numIon];
	int* ion_val=new int[numIon];
	double* ion_rad=new double[numIon];
	double* ion_mob=new double[numIon];
	double* ion_fc=new double[numIon];
	// 1st Ion Properties
	ion_val[0]=y[23];
   ion_conc[0]=y[24];  		// mM or mol/m^3	    
	ion_rad[0]=y[25];		// meters
	ion_mob[0]=calc_Ion_Mobility(ion_val[0],ion_rad[0],viscosity);
	ion_fc[0]=calc_Ion_Friction_Coefficient(ion_val[0],ion_mob[0]);
	// 2nd Ion Properties
	ion_val[1]=y[26];
   ion_conc[1]=y[27];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[1]=y[28];													// [meter]
	ion_mob[1]=calc_Ion_Mobility(ion_val[1],ion_rad[1],viscosity);		// [meter^2/Volt*second]
	ion_fc[1]=calc_Ion_Friction_Coefficient(ion_val[1],ion_mob[1]);		// [Newton*second/meter]
	// 3rd Ion Properties
	ion_val[2]=y[29];
   ion_conc[2]=y[30];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[2]=y[31];													// [meter]
	ion_mob[2]=calc_Ion_Mobility(ion_val[2],ion_rad[2],viscosity);		// [meter^2/Volt*second]
	ion_fc[2]=calc_Ion_Friction_Coefficient(ion_val[2],ion_mob[2]);		// [Newton*second/meter]
	// 4th Ion Properties
	ion_val[3]=y[32];
   ion_conc[3]=y[33];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[3]=y[34];													// [meter]
	ion_mob[3]=calc_Ion_Mobility(ion_val[3],ion_rad[3],viscosity);		// [meter^2/Volt*second]
	ion_fc[3]=calc_Ion_Friction_Coefficient(ion_val[3],ion_mob[3]);		// [Newton*second/meter]
	// 5th Ion Properties
	ion_val[4]=y[35];
   ion_conc[4]=y[36];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[4]=y[37];													// [meter]
	ion_mob[4]=calc_Ion_Mobility(ion_val[4],ion_rad[4],viscosity);		// [meter^2/Volt*second]
	ion_fc[4]=calc_Ion_Friction_Coefficient(ion_val[4],ion_mob[4]);		// [Newton*second/meter]
	// 6th Ion Properties
	ion_val[5]=y[38];
   ion_conc[5]=y[39];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[5]=y[40];													// [meter]
	ion_mob[5]=calc_Ion_Mobility(ion_val[5],ion_rad[5],viscosity);		// [meter^2/Volt*second]
	ion_fc[5]=calc_Ion_Friction_Coefficient(ion_val[5],ion_mob[5]);		// [Newton*second/meter]
	// 7th Ion Properties
	ion_val[6]=y[41];
   ion_conc[6]=y[42];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[6]=y[43];													// [meter]
	ion_mob[6]=calc_Ion_Mobility(ion_val[6],ion_rad[6],viscosity);		// [meter^2/Volt*second]
	ion_fc[6]=calc_Ion_Friction_Coefficient(ion_val[6],ion_mob[6]);		// [Newton*second/meter]

	double Debye=y[45];				// meters	
	double dielectric=y[44];
	// Convert Concentration to Number Density (particles per volume (m^3))
	ion_conc[0]*=Na;
	ion_conc[1]*=Na;
	ion_conc[2]*=Na;
	ion_conc[3]*=Na;
	ion_conc[4]*=Na;
	ion_conc[5]*=Na;
	ion_conc[6]*=Na;
	// Calculation Constants
	double A;
	int ionIndex;
    // Linearized Governing Equations
	// F FUNCTION
	// df/dr = y[1]
	dy[0]=y[1];
	// d2f/dr2 = y[2]
	dy[1]=y[2];
	// d3f/dr3 = y[3]
	dy[2]=y[3];
	// d4f/dr4 = y[4]
	dy[3]=y[4];
	// d5f/dr5
	// 1st Ion Equilibrium Number Density
	double dN1_dr=(-ion_conc[0]*ion_val[0]*ec/(kb*T))*y[6]*exp(-ec*ion_val[0]*y[5]/(kb*T));
	double trm1=ion_val[0]*ec*dN1_dr*y[7];
	// 2nd Ion Equilibrium Number Density
	double dN2_dr=(-ion_conc[1]*ion_val[1]*ec/(kb*T))*y[6]*exp(-ec*ion_val[1]*y[5]/(kb*T));
	double trm2=ion_val[1]*ec*dN2_dr*y[9];
	// 3rd Ion Equilibrium Number Density
	double dN3_dr=(-ion_conc[2]*ion_val[2]*ec/(kb*T))*y[6]*exp(-ec*ion_val[2]*y[5]/(kb*T));
	double trm3=ion_val[2]*ec*dN3_dr*y[11];
	// 4th Ion Equilibrium Number Density
	double dN4_dr=(-ion_conc[3]*ion_val[3]*ec/(kb*T))*y[6]*exp(-ec*ion_val[3]*y[5]/(kb*T));
	double trm4=ion_val[3]*ec*dN4_dr*y[13];
	// 5th Ion Equilibrium Number Density
	double dN5_dr=(-ion_conc[4]*ion_val[4]*ec/(kb*T))*y[6]*exp(-ec*ion_val[4]*y[5]/(kb*T));
	double trm5=ion_val[4]*ec*dN5_dr*y[15];
	// 6th Ion Equilibrium Number Density
	double dN6_dr=(-ion_conc[5]*ion_val[5]*ec/(kb*T))*y[6]*exp(-ec*ion_val[5]*y[5]/(kb*T));
	double trm6=ion_val[5]*ec*dN6_dr*y[17];
	// 7th Ion Equilibrium Number Density
	double dN7_dr=(-ion_conc[6]*ion_val[6]*ec/(kb*T))*y[6]*exp(-ec*ion_val[6]*y[5]/(kb*T));
	double trm7=ion_val[6]*ec*dN7_dr*y[19];
	//
	dy[4]=-4*y[4]/r + 4*y[3]/(r*r) + (trm1+trm2+trm3+trm4+trm5+trm6+trm7)/(viscosity*r);
	// EQUILIBRIUM POTENTIAL
	// d(potential)/dr = y[6]
	dy[5]=y[6];
	// d2(potential)/dr2
	A=0;
	for(int i=0;i<numIon;i++){A+=ion_val[i]*ion_conc[i]*exp(-ec*ion_val[i]*y[5]/(kb*T));}
	dy[6]=-ec*A/(dielectric*eo) - 2*y[6]/r;
	// INDUCED ELECTROCHEMICAL POTENTIAL FUNCTION (2 ions)
	// 1st Ion
	// d(IEP)/dr
   dy[7]=y[8];
	// d2(IEP)/dr2
	A=(ion_val[0]*ec/(kb*T))*y[6];
   dy[8]=-2*y[8]/r + 2*y[7]/(r*r) + A*(y[8] - (2*ion_fc[0]/(r*ion_val[0]*ec))*y[1]);
	// 2nd Ion
	// d(IEP)/dr
   dy[9]=y[10];
	// d2(IEP)/dr2
	A=(ion_val[1]*ec/(kb*T))*y[6];
   dy[10]=-2*y[10]/r + 2*y[9]/(r*r) + A*(y[10] - (2*ion_fc[1]/(r*ion_val[1]*ec))*y[1]);
	// 3rd Ion
	// d(IEP)/dr
   dy[11]=y[12];
	// d2(IEP)/dr2
	A=(ion_val[2]*ec/(kb*T))*y[6];
   dy[12]=-2*y[12]/r + 2*y[11]/(r*r) + A*(y[12] - (2*ion_fc[2]/(r*ion_val[2]*ec))*y[1]);
	// 4th Ion
	// d(IEP)/dr
   dy[13]=y[14];
	// d2(IEP)/dr2
	A=(ion_val[3]*ec/(kb*T))*y[6];
   dy[14]=-2*y[14]/r + 2*y[13]/(r*r) + A*(y[14] - (2*ion_fc[3]/(r*ion_val[3]*ec))*y[1]);
	// 5th Ion
	// d(IEP)/dr
   dy[15]=y[16];
	// d2(IEP)/dr2
	A=(ion_val[4]*ec/(kb*T))*y[6];
   dy[16]=-2*y[16]/r + 2*y[15]/(r*r) + A*(y[16] - (2*ion_fc[4]/(r*ion_val[4]*ec))*y[1]);
	// 6th Ion
	// d(IEP)/dr
   dy[17]=y[18];
	// d2(IEP)/dr2
	A=(ion_val[5]*ec/(kb*T))*y[6];
   dy[18]=-2*y[18]/r + 2*y[17]/(r*r) + A*(y[18] - (2*ion_fc[5]/(r*ion_val[5]*ec))*y[1]);
	// 7th Ion
	// d(IEP)/dr
   dy[19]=y[20];
	// d2(IEP)/dr2
	A=(ion_val[6]*ec/(kb*T))*y[6];
   dy[20]=-2*y[20]/r + 2*y[19]/(r*r) + A*(y[20] - (2*ion_fc[6]/(r*ion_val[6]*ec))*y[1]);

	// Clear Memory
	delete [] ion_conc;delete [] ion_val;delete [] ion_rad;delete [] ion_mob;delete [] ion_fc;}

void inhomogeneous_Prob1_7ion(const state_type &y,state_type &dy,const double r)
	{double T=y[21];									// temperature [Kelvin]
	double viscosity=y[46];							// [Newton*second/meter^2]
	// Organize Ion Data
	int numIon=y[22];	
	double* ion_conc=new double[numIon];
	int* ion_val=new int[numIon];
	double* ion_rad=new double[numIon];
	double* ion_mob=new double[numIon];
	double* ion_fc=new double[numIon];
	// 1st Ion Properties
	ion_val[0]=y[23];
   ion_conc[0]=y[24];  		// mM or mol/m^3	    
	ion_rad[0]=y[25];		// meters
	ion_mob[0]=calc_Ion_Mobility(ion_val[0],ion_rad[0],viscosity);
	ion_fc[0]=calc_Ion_Friction_Coefficient(ion_val[0],ion_mob[0]);
	// 2nd Ion Properties
	ion_val[1]=y[26];
   ion_conc[1]=y[27];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[1]=y[28];													// [meter]
	ion_mob[1]=calc_Ion_Mobility(ion_val[1],ion_rad[1],viscosity);		// [meter^2/Volt*second]
	ion_fc[1]=calc_Ion_Friction_Coefficient(ion_val[1],ion_mob[1]);		// [Newton*second/meter]
	// 3rd Ion Properties
	ion_val[2]=y[29];
   ion_conc[2]=y[30];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[2]=y[31];													// [meter]
	ion_mob[2]=calc_Ion_Mobility(ion_val[2],ion_rad[2],viscosity);		// [meter^2/Volt*second]
	ion_fc[2]=calc_Ion_Friction_Coefficient(ion_val[2],ion_mob[2]);		// [Newton*second/meter]
	// 4th Ion Properties
	ion_val[3]=y[32];
   ion_conc[3]=y[33];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[3]=y[34];													// [meter]
	ion_mob[3]=calc_Ion_Mobility(ion_val[3],ion_rad[3],viscosity);		// [meter^2/Volt*second]
	ion_fc[3]=calc_Ion_Friction_Coefficient(ion_val[3],ion_mob[3]);		// [Newton*second/meter]
	// 5th Ion Properties
	ion_val[4]=y[35];
   ion_conc[4]=y[36];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[4]=y[37];													// [meter]
	ion_mob[4]=calc_Ion_Mobility(ion_val[4],ion_rad[4],viscosity);		// [meter^2/Volt*second]
	ion_fc[4]=calc_Ion_Friction_Coefficient(ion_val[4],ion_mob[4]);		// [Newton*second/meter]
	// 6th Ion Properties
	ion_val[5]=y[38];
   ion_conc[5]=y[39];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[5]=y[40];													// [meter]
	ion_mob[5]=calc_Ion_Mobility(ion_val[5],ion_rad[5],viscosity);		// [meter^2/Volt*second]
	ion_fc[5]=calc_Ion_Friction_Coefficient(ion_val[5],ion_mob[5]);		// [Newton*second/meter]
	// 7th Ion Properties
	ion_val[6]=y[41];
   ion_conc[6]=y[42];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[6]=y[43];													// [meter]
	ion_mob[6]=calc_Ion_Mobility(ion_val[6],ion_rad[6],viscosity);		// [meter^2/Volt*second]
	ion_fc[6]=calc_Ion_Friction_Coefficient(ion_val[6],ion_mob[6]);		// [Newton*second/meter]

	double Debye=y[45];				// meters	
	double dielectric=y[44];
	// Convert Concentration to Number Density (particles per volume (m^3))
	ion_conc[0]*=Na;
	ion_conc[1]*=Na;
	ion_conc[2]*=Na;
	ion_conc[3]*=Na;
	ion_conc[4]*=Na;
	ion_conc[5]*=Na;
	ion_conc[6]*=Na;
	// Calculation Constants
	double A,dN_dr;
	int ionIndex;
	// Linearized Governing Equations
	// F FUNCTION
	// df/dr = y[1]
	dy[0]=y[1];
	// d2f/dr2 = y[2]
	dy[1]=y[2];
	// d3f/dr3 = y[3]
	dy[2]=y[3];
	// d4f/dr4 = y[4]
	dy[3]=y[4];
	// d5f/dr5
	A=0;
	for(int i=0;i<numIon;i++)
		{// Ion Equilibrium Number Density
		dN_dr=(-ion_conc[i]*ion_val[i]*ec/(kb*T))*y[6]*exp(-ec*ion_val[i]*y[5]/(kb*T));
		// Ion Contribution
		ionIndex=7+2*i; 
		A+=ion_val[i]*ec*dN_dr*y[ionIndex];}
    dy[4]=-4*y[4]/r + 4*y[3]/(r*r) + A/(viscosity*r);
	// EQUILIBRIUM POTENTIAL
	// d(potential)/dr = y[6]
	dy[5]=y[6];
	// d2(potential)/dr2
	A=0;
	for(int i=0;i<numIon;i++){A+=ion_val[i]*ion_conc[i]*exp(-ec*ion_val[i]*y[5]/(kb*T));}
	dy[6]=-ec*A/(dielectric*eo) - 2*y[6]/r;
	// INDUCED ELECTROCHEMICAL POTENTIAL FUNCTION (2 ions)
	// 1st Ion
	// d(IEP)/dr = y[8]
   dy[7]=y[8];
	// d2(IEP)/dr2
	A=(ion_val[0]*ec/(kb*T))*y[6];
   dy[8]=-2*y[8]/r + 2*y[7]/(r*r) + A*(y[8] - (2*ion_fc[0]/(r*ion_val[0]*ec))*y[1] - ion_fc[0]/(ion_val[0]*ec));
	// 2nd Ion
	// d(IEP)/dr = y[10]
   dy[9]=y[10];
	// d2(IEP)/dr2
	A=(ion_val[1]*ec/(kb*T))*y[6];
   dy[10]=-2*y[10]/r + 2*y[9]/(r*r) + A*(y[10] - (2*ion_fc[1]/(r*ion_val[1]*ec))*y[1] - ion_fc[1]/(ion_val[1]*ec));
	// 3rd Ion
	// d(IEP)/dr
   dy[11]=y[12];
	// d2(IEP)/dr2
	A=(ion_val[2]*ec/(kb*T))*y[6];
   dy[12]=-2*y[12]/r + 2*y[11]/(r*r) + A*(y[12] - (2*ion_fc[2]/(r*ion_val[2]*ec))*y[1] - ion_fc[2]/(ion_val[2]*ec));
	// 4th Ion
	// d(IEP)/dr
   dy[13]=y[14];
	// d2(IEP)/dr2
	A=(ion_val[3]*ec/(kb*T))*y[6];
   dy[14]=-2*y[14]/r + 2*y[13]/(r*r) + A*(y[14] - (2*ion_fc[3]/(r*ion_val[3]*ec))*y[1] - ion_fc[3]/(ion_val[3]*ec));
	// 5th Ion
	// d(IEP)/dr
   dy[15]=y[16];
	// d2(IEP)/dr2
	A=(ion_val[4]*ec/(kb*T))*y[6];
   dy[16]=-2*y[16]/r + 2*y[15]/(r*r) + A*(y[16] - (2*ion_fc[4]/(r*ion_val[4]*ec))*y[1] - ion_fc[4]/(ion_val[4]*ec));
	// 6th Ion
	// d(IEP)/dr
   dy[17]=y[18];
	// d2(IEP)/dr2
	A=(ion_val[5]*ec/(kb*T))*y[6];
   dy[18]=-2*y[18]/r + 2*y[17]/(r*r) + A*(y[18] - (2*ion_fc[5]/(r*ion_val[5]*ec))*y[1] - ion_fc[5]/(ion_val[5]*ec));
	// 7th Ion
	// d(IEP)/dr
   dy[19]=y[20];
	// d2(IEP)/dr2
	A=(ion_val[6]*ec/(kb*T))*y[6];
   dy[20]=-2*y[20]/r + 2*y[19]/(r*r) + A*(y[20] - (2*ion_fc[6]/(r*ion_val[6]*ec))*y[1] - ion_fc[6]/(ion_val[6]*ec));

	// Clear Memory
	delete [] ion_conc;delete [] ion_val;delete [] ion_rad;delete [] ion_mob;delete [] ion_fc;}

void inhomogeneous_Prob2_7ion(const state_type &y,state_type &dy,const double r)
	{double T=y[21];									// temperature [Kelvin]
	double viscosity=y[46];							// [Newton*second/meter^2]
	// Organize Ion Data
	int numIon=y[22];	
	double* ion_conc=new double[numIon];
	int* ion_val=new int[numIon];
	double* ion_rad=new double[numIon];
	double* ion_mob=new double[numIon];
	double* ion_fc=new double[numIon];
	// 1st Ion Properties
	ion_val[0]=y[23];
   ion_conc[0]=y[24];  		// mM or mol/m^3	    
	ion_rad[0]=y[25];		// meters
	ion_mob[0]=calc_Ion_Mobility(ion_val[0],ion_rad[0],viscosity);
	ion_fc[0]=calc_Ion_Friction_Coefficient(ion_val[0],ion_mob[0]);
	// 2nd Ion Properties
	ion_val[1]=y[26];
   ion_conc[1]=y[27];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[1]=y[28];													// [meter]
	ion_mob[1]=calc_Ion_Mobility(ion_val[1],ion_rad[1],viscosity);		// [meter^2/Volt*second]
	ion_fc[1]=calc_Ion_Friction_Coefficient(ion_val[1],ion_mob[1]);		// [Newton*second/meter]
	// 3rd Ion Properties
	ion_val[2]=y[29];
   ion_conc[2]=y[30];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[2]=y[31];													// [meter]
	ion_mob[2]=calc_Ion_Mobility(ion_val[2],ion_rad[2],viscosity);		// [meter^2/Volt*second]
	ion_fc[2]=calc_Ion_Friction_Coefficient(ion_val[2],ion_mob[2]);		// [Newton*second/meter]
	// 4th Ion Properties
	ion_val[3]=y[32];
   ion_conc[3]=y[33];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[3]=y[34];													// [meter]
	ion_mob[3]=calc_Ion_Mobility(ion_val[3],ion_rad[3],viscosity);		// [meter^2/Volt*second]
	ion_fc[3]=calc_Ion_Friction_Coefficient(ion_val[3],ion_mob[3]);		// [Newton*second/meter]
	// 5th Ion Properties
	ion_val[4]=y[35];
   ion_conc[4]=y[36];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[4]=y[37];													// [meter]
	ion_mob[4]=calc_Ion_Mobility(ion_val[4],ion_rad[4],viscosity);		// [meter^2/Volt*second]
	ion_fc[4]=calc_Ion_Friction_Coefficient(ion_val[4],ion_mob[4]);		// [Newton*second/meter]
	// 6th Ion Properties
	ion_val[5]=y[38];
   ion_conc[5]=y[39];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[5]=y[40];													// [meter]
	ion_mob[5]=calc_Ion_Mobility(ion_val[5],ion_rad[5],viscosity);		// [meter^2/Volt*second]
	ion_fc[5]=calc_Ion_Friction_Coefficient(ion_val[5],ion_mob[5]);		// [Newton*second/meter]
	// 7th Ion Properties
	ion_val[6]=y[41];
   ion_conc[6]=y[42];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[6]=y[43];													// [meter]
	ion_mob[6]=calc_Ion_Mobility(ion_val[6],ion_rad[6],viscosity);		// [meter^2/Volt*second]
	ion_fc[6]=calc_Ion_Friction_Coefficient(ion_val[6],ion_mob[6]);		// [Newton*second/meter]

	double Debye=y[45];				// meters	
	double dielectric=y[44];
	// Convert Concentration to Number Density (particles per volume (m^3))
	ion_conc[0]*=Na;
	ion_conc[1]*=Na;
	ion_conc[2]*=Na;
	ion_conc[3]*=Na;
	ion_conc[4]*=Na;
	ion_conc[5]*=Na;
	ion_conc[6]*=Na;
    // Calculation Constants
	double A,dN_dr;
	int ionIndex;
    // Linearized Governing Equations
	// F FUNCTION
	// df/dr = y[1]
	dy[0]=y[1];
	// d2f/dr2 = y[2]
	dy[1]=y[2];
	// d3f/dr3 = y[3]
	dy[2]=y[3];
	// d4f/dr4 = y[4]
	dy[3]=y[4];
	// d5f/dr5
	A=0;
	for(int i=0;i<numIon;i++)
		{// Ion Equilibrium Number Density
		dN_dr=(-ion_conc[i]*ion_val[i]*ec/(kb*T))*y[6]*exp(-ec*ion_val[i]*y[5]/(kb*T));
		// Ion Contribution
		ionIndex=7+2*i; 
		A+=ion_val[i]*ec*dN_dr*(y[ionIndex]+r);}
   dy[4]=-4*y[4]/r + 4*y[3]/(r*r) + A/(viscosity*r);
	// EQUILIBRIUM POTENTIAL
	// d(potential)/dr = y[6]
	dy[5]=y[6];
	// d2(potential)/dr2
	A=0;
	for(int i=0;i<numIon;i++){A+=ion_val[i]*ion_conc[i]*exp(-ec*ion_val[i]*y[5]/(kb*T));}
	dy[6]=-ec*A/(dielectric*eo) - 2*y[6]/r;
	// INDUCED ELECTROCHEMICAL POTENTIAL FUNCTION (2 ions)
	// 1st Ion
	// d(IEP)/dr = y[8]
   dy[7]=y[8];
	// d2(IEP)/dr2
	A=(ion_val[0]*ec/(kb*T))*y[6];
   dy[8]=-2*y[8]/r + 2*y[7]/(r*r) + A*(y[8] - (2*ion_fc[0]/(r*ion_val[0]*ec))*y[1] + 1);
	// 2nd Ion
	// d(IEP)/dr = y[10]
   dy[9]=y[10];
	// d2(IEP)/dr2
	A=(ion_val[1]*ec/(kb*T))*y[6];
   dy[10]=-2*y[10]/r + 2*y[9]/(r*r) + A*(y[10] - (2*ion_fc[1]/(r*ion_val[1]*ec))*y[1] + 1);
	// 3rd Ion
	// d(IEP)/dr
   dy[11]=y[12];
	// d2(IEP)/dr2
	A=(ion_val[2]*ec/(kb*T))*y[6];
   dy[12]=-2*y[12]/r + 2*y[11]/(r*r) + A*(y[12] - (2*ion_fc[2]/(r*ion_val[2]*ec))*y[1] + 1);
	// 4th Ion
	// d(IEP)/dr
   dy[13]=y[14];
	// d2(IEP)/dr2
	A=(ion_val[3]*ec/(kb*T))*y[6];
   dy[14]=-2*y[14]/r + 2*y[13]/(r*r) + A*(y[14] - (2*ion_fc[3]/(r*ion_val[3]*ec))*y[1] + 1);
	// 5th Ion
	// d(IEP)/dr
   dy[15]=y[16];
	// d2(IEP)/dr2
	A=(ion_val[4]*ec/(kb*T))*y[6];
   dy[16]=-2*y[16]/r + 2*y[15]/(r*r) + A*(y[16] - (2*ion_fc[4]/(r*ion_val[4]*ec))*y[1] + 1);
	// 6th Ion
	// d(IEP)/dr
   dy[17]=y[18];
	// d2(IEP)/dr2
	A=(ion_val[5]*ec/(kb*T))*y[6];
   dy[18]=-2*y[18]/r + 2*y[17]/(r*r) + A*(y[18] - (2*ion_fc[5]/(r*ion_val[5]*ec))*y[1] + 1);
	// 7th Ion
	// d(IEP)/dr
   dy[19]=y[20];
	// d2(IEP)/dr2
	A=(ion_val[6]*ec/(kb*T))*y[6];
   dy[20]=-2*y[20]/r + 2*y[19]/(r*r) + A*(y[20] - (2*ion_fc[6]/(r*ion_val[6]*ec))*y[1] + 1);

	// Clear Memory
	delete [] ion_conc;delete [] ion_val;delete [] ion_rad;delete [] ion_mob;delete [] ion_fc;}

	// y[0] = f
	// y[1] = df/dr
	// y[2] = d2f/dr2
	// y[3] = d3f/dr3
	// y[4] = d4f/dr4
	// Equilibrium Electric Pontential
	// y[5] = potential
	// y[6] = d(potential)/dr
	// Induced Electrochemical Potential Function (3 ion)
	// y[7] = IEP1
	// y[8] = d(IEP1)/dr
	// y[9] = IEP2
	// y[10] = d(IEP2)/dr
	// y[11] = IEP3
	// y[12] = d(IEP3)/dr
	// y[13] = IEP4
	// y[14] = d(IEP4)/dr
	// y[15] = IEP5
	// y[16] = d(IEP5)/dr
	// y[17] = IEP6
	// y[18] = d(IEP6)/dr
	// Constants
	// y[19] = Temp					// [Kelvin]
	// y[20] = numIon
	// Ion Properties
	// y[21] = Ion1.val;		
	// y[22] = Ion1.conc;		// mM [mol/m^3]
	// y[23] = Ion1.radius;		// meters
	// y[24] = Ion2.val;
	// y[25] = Ion2.conc;
	// y[26] = Ion2.radius;
	// y[27] = Ion3.val;
	// y[28] = Ion3.conc;
	// y[29] = Ion3.radius;
	// y[30] = Ion4.val;
	// y[31] = Ion4.conc;
	// y[32] = Ion4.radius;
	// y[33] = Ion5.val;
	// y[34] = Ion5.conc;
	// y[35] = Ion5.radius;
	// y[36] = Ion6.val;
	// y[37] = Ion6.conc;
	// y[38] = Ion6.radius;
	// Solution Properties
	// y[39] = relative dielectric	[dimensionless]
	// y[40] = Debye Length [meters]
	// y[41] = viscosity  [Pa s]
void homogeneous_form_6ion(const state_type &y,state_type &dy,const double r)
	{double T=y[19];									// temperature [Kelvin]
	double viscosity=y[41];							// [Newton*second/meter^2]
	// Organize Ion Data
	int numIon=y[20];	
	double* ion_conc=new double[numIon];
	int* ion_val=new int[numIon];
	double* ion_rad=new double[numIon];
	double* ion_mob=new double[numIon];
	double* ion_fc=new double[numIon];
	// 1st Ion Properties
	ion_val[0]=y[21];
   ion_conc[0]=y[22];  		// mM or mol/m^3	    
	ion_rad[0]=y[23];		// meters
	ion_mob[0]=calc_Ion_Mobility(ion_val[0],ion_rad[0],viscosity);
	ion_fc[0]=calc_Ion_Friction_Coefficient(ion_val[0],ion_mob[0]);
	// 2nd Ion Properties
	ion_val[1]=y[24];
   ion_conc[1]=y[25];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[1]=y[26];													// [meter]
	ion_mob[1]=calc_Ion_Mobility(ion_val[1],ion_rad[1],viscosity);		// [meter^2/Volt*second]
	ion_fc[1]=calc_Ion_Friction_Coefficient(ion_val[1],ion_mob[1]);		// [Newton*second/meter]
	// 3rd Ion Properties
	ion_val[2]=y[27];
   ion_conc[2]=y[28];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[2]=y[29];													// [meter]
	ion_mob[2]=calc_Ion_Mobility(ion_val[2],ion_rad[2],viscosity);		// [meter^2/Volt*second]
	ion_fc[2]=calc_Ion_Friction_Coefficient(ion_val[2],ion_mob[2]);		// [Newton*second/meter]
	// 4th Ion Properties
	ion_val[3]=y[30];
   ion_conc[3]=y[31];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[3]=y[32];													// [meter]
	ion_mob[3]=calc_Ion_Mobility(ion_val[3],ion_rad[3],viscosity);		// [meter^2/Volt*second]
	ion_fc[3]=calc_Ion_Friction_Coefficient(ion_val[3],ion_mob[3]);		// [Newton*second/meter]
	// 5th Ion Properties
	ion_val[4]=y[33];
   ion_conc[4]=y[34];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[4]=y[35];													// [meter]
	ion_mob[4]=calc_Ion_Mobility(ion_val[4],ion_rad[4],viscosity);		// [meter^2/Volt*second]
	ion_fc[4]=calc_Ion_Friction_Coefficient(ion_val[4],ion_mob[4]);		// [Newton*second/meter]
	// 6th Ion Properties
	ion_val[5]=y[36];
   ion_conc[5]=y[37];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[5]=y[38];													// [meter]
	ion_mob[5]=calc_Ion_Mobility(ion_val[5],ion_rad[5],viscosity);		// [meter^2/Volt*second]
	ion_fc[5]=calc_Ion_Friction_Coefficient(ion_val[5],ion_mob[5]);		// [Newton*second/meter]

	double Debye=y[40];				// meters	
	double dielectric=y[39];
	// Convert Concentration to Number Density (particles per volume (m^3))
	ion_conc[0]*=Na;
	ion_conc[1]*=Na;
	ion_conc[2]*=Na;
	ion_conc[3]*=Na;
	ion_conc[4]*=Na;
	ion_conc[5]*=Na;
	// Calculation Constants
	double A;
	int ionIndex;
    // Linearized Governing Equations
	// F FUNCTION
	// df/dr = y[1]
	dy[0]=y[1];
	// d2f/dr2 = y[2]
	dy[1]=y[2];
	// d3f/dr3 = y[3]
	dy[2]=y[3];
	// d4f/dr4 = y[4]
	dy[3]=y[4];
	// d5f/dr5
	// 1st Ion Equilibrium Number Density
	double dN1_dr=(-ion_conc[0]*ion_val[0]*ec/(kb*T))*y[6]*exp(-ec*ion_val[0]*y[5]/(kb*T));
	double trm1=ion_val[0]*ec*dN1_dr*y[7];
	// 2nd Ion Equilibrium Number Density
	double dN2_dr=(-ion_conc[1]*ion_val[1]*ec/(kb*T))*y[6]*exp(-ec*ion_val[1]*y[5]/(kb*T));
	double trm2=ion_val[1]*ec*dN2_dr*y[9];
	// 3rd Ion Equilibrium Number Density
	double dN3_dr=(-ion_conc[2]*ion_val[2]*ec/(kb*T))*y[6]*exp(-ec*ion_val[2]*y[5]/(kb*T));
	double trm3=ion_val[2]*ec*dN3_dr*y[11];
	// 4th Ion Equilibrium Number Density
	double dN4_dr=(-ion_conc[3]*ion_val[3]*ec/(kb*T))*y[6]*exp(-ec*ion_val[3]*y[5]/(kb*T));
	double trm4=ion_val[3]*ec*dN4_dr*y[13];
	// 5th Ion Equilibrium Number Density
	double dN5_dr=(-ion_conc[4]*ion_val[4]*ec/(kb*T))*y[6]*exp(-ec*ion_val[4]*y[5]/(kb*T));
	double trm5=ion_val[4]*ec*dN5_dr*y[15];
	// 6th Ion Equilibrium Number Density
	double dN6_dr=(-ion_conc[5]*ion_val[5]*ec/(kb*T))*y[6]*exp(-ec*ion_val[5]*y[5]/(kb*T));
	double trm6=ion_val[5]*ec*dN6_dr*y[17];
	//
	dy[4]=-4*y[4]/r + 4*y[3]/(r*r) + (trm1+trm2+trm3+trm4+trm5+trm6)/(viscosity*r);
	// EQUILIBRIUM POTENTIAL
	// d(potential)/dr = y[6]
	dy[5]=y[6];
	// d2(potential)/dr2
	A=0;
	for(int i=0;i<numIon;i++){A+=ion_val[i]*ion_conc[i]*exp(-ec*ion_val[i]*y[5]/(kb*T));}
	dy[6]=-ec*A/(dielectric*eo) - 2*y[6]/r;
	// INDUCED ELECTROCHEMICAL POTENTIAL FUNCTION (2 ions)
	// 1st Ion
	// d(IEP)/dr
   dy[7]=y[8];
	// d2(IEP)/dr2
	A=(ion_val[0]*ec/(kb*T))*y[6];
   dy[8]=-2*y[8]/r + 2*y[7]/(r*r) + A*(y[8] - (2*ion_fc[0]/(r*ion_val[0]*ec))*y[1]);
	// 2nd Ion
	// d(IEP)/dr
   dy[9]=y[10];
	// d2(IEP)/dr2
	A=(ion_val[1]*ec/(kb*T))*y[6];
   dy[10]=-2*y[10]/r + 2*y[9]/(r*r) + A*(y[10] - (2*ion_fc[1]/(r*ion_val[1]*ec))*y[1]);
	// 3rd Ion
	// d(IEP)/dr
   dy[11]=y[12];
	// d2(IEP)/dr2
	A=(ion_val[2]*ec/(kb*T))*y[6];
   dy[12]=-2*y[12]/r + 2*y[11]/(r*r) + A*(y[12] - (2*ion_fc[2]/(r*ion_val[2]*ec))*y[1]);
	// 4th Ion
	// d(IEP)/dr
   dy[13]=y[14];
	// d2(IEP)/dr2
	A=(ion_val[3]*ec/(kb*T))*y[6];
   dy[14]=-2*y[14]/r + 2*y[13]/(r*r) + A*(y[14] - (2*ion_fc[3]/(r*ion_val[3]*ec))*y[1]);
	// 5th Ion
	// d(IEP)/dr
   dy[15]=y[16];
	// d2(IEP)/dr2
	A=(ion_val[4]*ec/(kb*T))*y[6];
   dy[16]=-2*y[16]/r + 2*y[15]/(r*r) + A*(y[16] - (2*ion_fc[4]/(r*ion_val[4]*ec))*y[1]);
	// 6th Ion
	// d(IEP)/dr
   dy[17]=y[18];
	// d2(IEP)/dr2
	A=(ion_val[5]*ec/(kb*T))*y[6];
   dy[18]=-2*y[18]/r + 2*y[17]/(r*r) + A*(y[18] - (2*ion_fc[5]/(r*ion_val[5]*ec))*y[1]);

	// Clear Memory
	delete [] ion_conc;delete [] ion_val;delete [] ion_rad;delete [] ion_mob;delete [] ion_fc;}

void inhomogeneous_Prob1_6ion(const state_type &y,state_type &dy,const double r)
	{double T=y[19];									// temperature [Kelvin]
	double viscosity=y[41];							// [Newton*second/meter^2]
	// Organize Ion Data
	int numIon=y[20];	
	double* ion_conc=new double[numIon];
	int* ion_val=new int[numIon];
	double* ion_rad=new double[numIon];
	double* ion_mob=new double[numIon];
	double* ion_fc=new double[numIon];
	// 1st Ion Properties
	ion_val[0]=y[21];
   ion_conc[0]=y[22];  		// mM or mol/m^3	    
	ion_rad[0]=y[23];		// meters
	ion_mob[0]=calc_Ion_Mobility(ion_val[0],ion_rad[0],viscosity);
	ion_fc[0]=calc_Ion_Friction_Coefficient(ion_val[0],ion_mob[0]);
	// 2nd Ion Properties
	ion_val[1]=y[24];
   ion_conc[1]=y[25];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[1]=y[26];													// [meter]
	ion_mob[1]=calc_Ion_Mobility(ion_val[1],ion_rad[1],viscosity);		// [meter^2/Volt*second]
	ion_fc[1]=calc_Ion_Friction_Coefficient(ion_val[1],ion_mob[1]);		// [Newton*second/meter]
	// 3rd Ion Properties
	ion_val[2]=y[27];
   ion_conc[2]=y[28];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[2]=y[29];													// [meter]
	ion_mob[2]=calc_Ion_Mobility(ion_val[2],ion_rad[2],viscosity);		// [meter^2/Volt*second]
	ion_fc[2]=calc_Ion_Friction_Coefficient(ion_val[2],ion_mob[2]);		// [Newton*second/meter]
	// 4th Ion Properties
	ion_val[3]=y[30];
   ion_conc[3]=y[31];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[3]=y[32];													// [meter]
	ion_mob[3]=calc_Ion_Mobility(ion_val[3],ion_rad[3],viscosity);		// [meter^2/Volt*second]
	ion_fc[3]=calc_Ion_Friction_Coefficient(ion_val[3],ion_mob[3]);		// [Newton*second/meter]
	// 5th Ion Properties
	ion_val[4]=y[33];
   ion_conc[4]=y[34];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[4]=y[35];													// [meter]
	ion_mob[4]=calc_Ion_Mobility(ion_val[4],ion_rad[4],viscosity);		// [meter^2/Volt*second]
	ion_fc[4]=calc_Ion_Friction_Coefficient(ion_val[4],ion_mob[4]);		// [Newton*second/meter]
	// 6th Ion Properties
	ion_val[5]=y[36];
   ion_conc[5]=y[37];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[5]=y[38];													// [meter]
	ion_mob[5]=calc_Ion_Mobility(ion_val[5],ion_rad[5],viscosity);		// [meter^2/Volt*second]
	ion_fc[5]=calc_Ion_Friction_Coefficient(ion_val[5],ion_mob[5]);		// [Newton*second/meter]

	double Debye=y[40];	// meters	
	double dielectric=y[39];
	// Convert Concentration to Number Density (particles per volume (m^3))
	ion_conc[0]*=Na;
	ion_conc[1]*=Na;
   ion_conc[2]*=Na;
	ion_conc[3]*=Na;
	ion_conc[4]*=Na;
	ion_conc[5]*=Na;
	// Calculation Constants
	double A,dN_dr;
	int ionIndex;
	// Linearized Governing Equations
	// F FUNCTION
	// df/dr = y[1]
	dy[0]=y[1];
	// d2f/dr2 = y[2]
	dy[1]=y[2];
	// d3f/dr3 = y[3]
	dy[2]=y[3];
	// d4f/dr4 = y[4]
	dy[3]=y[4];
	// d5f/dr5
	A=0;
	for(int i=0;i<numIon;i++)
		{// Ion Equilibrium Number Density
		dN_dr=(-ion_conc[i]*ion_val[i]*ec/(kb*T))*y[6]*exp(-ec*ion_val[i]*y[5]/(kb*T));
		// Ion Contribution
		ionIndex=7+2*i; 
		A+=ion_val[i]*ec*dN_dr*y[ionIndex];}
    dy[4]=-4*y[4]/r + 4*y[3]/(r*r) + A/(viscosity*r);
	// EQUILIBRIUM POTENTIAL
	// d(potential)/dr = y[6]
	dy[5]=y[6];
	// d2(potential)/dr2
	A=0;
	for(int i=0;i<numIon;i++){A+=ion_val[i]*ion_conc[i]*exp(-ec*ion_val[i]*y[5]/(kb*T));}
	dy[6]=-ec*A/(dielectric*eo) - 2*y[6]/r;
	// INDUCED ELECTROCHEMICAL POTENTIAL FUNCTION (2 ions)
	// 1st Ion
	// d(IEP)/dr = y[8]
   dy[7]=y[8];
	// d2(IEP)/dr2
	A=(ion_val[0]*ec/(kb*T))*y[6];
   dy[8]=-2*y[8]/r + 2*y[7]/(r*r) + A*(y[8] - (2*ion_fc[0]/(r*ion_val[0]*ec))*y[1] - ion_fc[0]/(ion_val[0]*ec));
	// 2nd Ion
	// d(IEP)/dr = y[10]
   dy[9]=y[10];
	// d2(IEP)/dr2
	A=(ion_val[1]*ec/(kb*T))*y[6];
   dy[10]=-2*y[10]/r + 2*y[9]/(r*r) + A*(y[10] - (2*ion_fc[1]/(r*ion_val[1]*ec))*y[1] - ion_fc[1]/(ion_val[1]*ec));
	// 3rd Ion
	// d(IEP)/dr
   dy[11]=y[12];
	// d2(IEP)/dr2
	A=(ion_val[2]*ec/(kb*T))*y[6];
   dy[12]=-2*y[12]/r + 2*y[11]/(r*r) + A*(y[12] - (2*ion_fc[2]/(r*ion_val[2]*ec))*y[1] - ion_fc[2]/(ion_val[2]*ec));
	// 4th Ion
	// d(IEP)/dr
   dy[13]=y[14];
	// d2(IEP)/dr2
	A=(ion_val[3]*ec/(kb*T))*y[6];
   dy[14]=-2*y[14]/r + 2*y[13]/(r*r) + A*(y[14] - (2*ion_fc[3]/(r*ion_val[3]*ec))*y[1] - ion_fc[3]/(ion_val[3]*ec));
	// 5th Ion
	// d(IEP)/dr
   dy[15]=y[16];
	// d2(IEP)/dr2
	A=(ion_val[4]*ec/(kb*T))*y[6];
   dy[16]=-2*y[16]/r + 2*y[15]/(r*r) + A*(y[16] - (2*ion_fc[4]/(r*ion_val[4]*ec))*y[1] - ion_fc[4]/(ion_val[4]*ec));
	// 6th Ion
	// d(IEP)/dr
   dy[17]=y[18];
	// d2(IEP)/dr2
	A=(ion_val[5]*ec/(kb*T))*y[6];
   dy[18]=-2*y[18]/r + 2*y[17]/(r*r) + A*(y[18] - (2*ion_fc[5]/(r*ion_val[5]*ec))*y[1] - ion_fc[5]/(ion_val[5]*ec));

	// Clear Memory
	delete [] ion_conc;delete [] ion_val;delete [] ion_rad;delete [] ion_mob;delete [] ion_fc;}

void inhomogeneous_Prob2_6ion(const state_type &y,state_type &dy,const double r)
	{double T=y[19];								// temperature [Kelvin]
	double viscosity=y[41];						// [Newton*second/meter^2]
	// Organize Ion Data
	int numIon=y[20];	
	double* ion_conc=new double[numIon];
	int* ion_val=new int[numIon];
	double* ion_rad=new double[numIon];
	double* ion_mob=new double[numIon];
	double* ion_fc=new double[numIon];
	// 1st Ion Properties
	ion_val[0]=y[21];
   ion_conc[0]=y[22];  		// mM or mol/m^3	    
	ion_rad[0]=y[23];		// meters
	ion_mob[0]=calc_Ion_Mobility(ion_val[0],ion_rad[0],viscosity);
	ion_fc[0]=calc_Ion_Friction_Coefficient(ion_val[0],ion_mob[0]);
	// 2nd Ion Properties
	ion_val[1]=y[24];
   ion_conc[1]=y[25];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[1]=y[26];													// [meter]
	ion_mob[1]=calc_Ion_Mobility(ion_val[1],ion_rad[1],viscosity);		// [meter^2/Volt*second]
	ion_fc[1]=calc_Ion_Friction_Coefficient(ion_val[1],ion_mob[1]);		// [Newton*second/meter]
	// 3rd Ion Properties
	ion_val[2]=y[27];
   ion_conc[2]=y[28];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[2]=y[29];													// [meter]
	ion_mob[2]=calc_Ion_Mobility(ion_val[2],ion_rad[2],viscosity);		// [meter^2/Volt*second]
	ion_fc[2]=calc_Ion_Friction_Coefficient(ion_val[2],ion_mob[2]);		// [Newton*second/meter]
	// 4th Ion Properties
	ion_val[3]=y[30];
   ion_conc[3]=y[31];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[3]=y[32];													// [meter]
	ion_mob[3]=calc_Ion_Mobility(ion_val[3],ion_rad[3],viscosity);		// [meter^2/Volt*second]
	ion_fc[3]=calc_Ion_Friction_Coefficient(ion_val[3],ion_mob[3]);		// [Newton*second/meter]
	// 5th Ion Properties
	ion_val[4]=y[33];
   ion_conc[4]=y[34];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[4]=y[35];													// [meter]
	ion_mob[4]=calc_Ion_Mobility(ion_val[4],ion_rad[4],viscosity);		// [meter^2/Volt*second]
	ion_fc[4]=calc_Ion_Friction_Coefficient(ion_val[4],ion_mob[4]);		// [Newton*second/meter]
	// 6th Ion Properties
	ion_val[5]=y[36];
   ion_conc[5]=y[37];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[5]=y[38];													// [meter]
	ion_mob[5]=calc_Ion_Mobility(ion_val[5],ion_rad[5],viscosity);		// [meter^2/Volt*second]
	ion_fc[5]=calc_Ion_Friction_Coefficient(ion_val[5],ion_mob[5]);		// [Newton*second/meter]

	double Debye=y[40];	// meters	
	double dielectric=y[39];
	// Convert Concentration to Number Density (particles per volume (m^3))
	ion_conc[0]*=Na;
	ion_conc[1]*=Na;
   ion_conc[2]*=Na;
	ion_conc[3]*=Na;
	ion_conc[4]*=Na;
	ion_conc[5]*=Na;
    // Calculation Constants
	double A,dN_dr;
	int ionIndex;
    // Linearized Governing Equations
	// F FUNCTION
	// df/dr = y[1]
	dy[0]=y[1];
	// d2f/dr2 = y[2]
	dy[1]=y[2];
	// d3f/dr3 = y[3]
	dy[2]=y[3];
	// d4f/dr4 = y[4]
	dy[3]=y[4];
	// d5f/dr5
	A=0;
	for(int i=0;i<numIon;i++)
		{// Ion Equilibrium Number Density
		dN_dr=(-ion_conc[i]*ion_val[i]*ec/(kb*T))*y[6]*exp(-ec*ion_val[i]*y[5]/(kb*T));
		// Ion Contribution
		ionIndex=7+2*i; 
		A+=ion_val[i]*ec*dN_dr*(y[ionIndex]+r);}
   dy[4]=-4*y[4]/r + 4*y[3]/(r*r) + A/(viscosity*r);
	// EQUILIBRIUM POTENTIAL
	// d(potential)/dr = y[6]
	dy[5]=y[6];
	// d2(potential)/dr2
	A=0;
	for(int i=0;i<numIon;i++){A+=ion_val[i]*ion_conc[i]*exp(-ec*ion_val[i]*y[5]/(kb*T));}
	dy[6]=-ec*A/(dielectric*eo) - 2*y[6]/r;
	// INDUCED ELECTROCHEMICAL POTENTIAL FUNCTION (2 ions)
	// 1st Ion
	// d(IEP)/dr = y[8]
   dy[7]=y[8];
	// d2(IEP)/dr2
	A=(ion_val[0]*ec/(kb*T))*y[6];
   dy[8]=-2*y[8]/r + 2*y[7]/(r*r) + A*(y[8] - (2*ion_fc[0]/(r*ion_val[0]*ec))*y[1] + 1);
	// 2nd Ion
	// d(IEP)/dr = y[10]
   dy[9]=y[10];
	// d2(IEP)/dr2
	A=(ion_val[1]*ec/(kb*T))*y[6];
   dy[10]=-2*y[10]/r + 2*y[9]/(r*r) + A*(y[10] - (2*ion_fc[1]/(r*ion_val[1]*ec))*y[1] + 1);
	// 3rd Ion
	// d(IEP)/dr
   dy[11]=y[12];
	// d2(IEP)/dr2
	A=(ion_val[2]*ec/(kb*T))*y[6];
   dy[12]=-2*y[12]/r + 2*y[11]/(r*r) + A*(y[12] - (2*ion_fc[2]/(r*ion_val[2]*ec))*y[1] + 1);
	// 4th Ion
	// d(IEP)/dr
   dy[13]=y[14];
	// d2(IEP)/dr2
	A=(ion_val[3]*ec/(kb*T))*y[6];
   dy[14]=-2*y[14]/r + 2*y[13]/(r*r) + A*(y[14] - (2*ion_fc[3]/(r*ion_val[3]*ec))*y[1] + 1);
	// 5th Ion
	// d(IEP)/dr
   dy[15]=y[16];
	// d2(IEP)/dr2
	A=(ion_val[4]*ec/(kb*T))*y[6];
   dy[16]=-2*y[16]/r + 2*y[15]/(r*r) + A*(y[16] - (2*ion_fc[4]/(r*ion_val[4]*ec))*y[1] + 1);
	// 6th Ion
	// d(IEP)/dr
   dy[17]=y[18];
	// d2(IEP)/dr2
	A=(ion_val[5]*ec/(kb*T))*y[6];
   dy[18]=-2*y[18]/r + 2*y[17]/(r*r) + A*(y[18] - (2*ion_fc[5]/(r*ion_val[5]*ec))*y[1] + 1);

	// Clear Memory
	delete [] ion_conc;delete [] ion_val;delete [] ion_rad;delete [] ion_mob;delete [] ion_fc;}

	// y[0] = f
	// y[1] = df/dr
	// y[2] = d2f/dr2
	// y[3] = d3f/dr3
	// y[4] = d4f/dr4
	// Equilibrium Electric Pontential
	// y[5] = potential
	// y[6] = d(potential)/dr
	// Induced Electrochemical Potential Function (3 ion)
	// y[7] = IEP1
	// y[8] = d(IEP1)/dr
	// y[9] = IEP2
	// y[10] = d(IEP2)/dr
	// y[11] = IEP3
	// y[12] = d(IEP3)/dr
	// y[13] = IEP4
	// y[14] = d(IEP4)/dr
	// y[15] = IEP5
	// y[16] = d(IEP5)/dr
	// Constants
	// y[17] = Temp					// [Kelvin]
	// y[18] = numIon
	// Ion Properties
	// y[19] = Ion1.val;		
	// y[20] = Ion1.conc;		// mM [mol/m^3]
	// y[21] = Ion1.radius;		// meters
	// y[22] = Ion2.val;
	// y[23] = Ion2.conc;
	// y[24] = Ion2.radius;
	// y[25] = Ion3.val;
	// y[26] = Ion3.conc;
	// y[27] = Ion3.radius;
	// y[28] = Ion4.val;
	// y[29] = Ion4.conc;
	// y[30] = Ion4.radius;
	// y[31] = Ion5.val;
	// y[32] = Ion5.conc;
	// y[33] = Ion5.radius;
	// Solution Properties
	// y[34] = relative dielectric	[dimensionless]
	// y[35] = Debye Length [meters]
	// y[36] = viscosity  [Pa s]
void homogeneous_form_5ion(const state_type &y,state_type &dy,const double r)
	{double T=y[17];									// temperature [Kelvin]
	double viscosity=y[36];							// [Newton*second/meter^2]
	// Organize Ion Data
	int numIon=y[18];	
	double* ion_conc=new double[numIon];
	int* ion_val=new int[numIon];
	double* ion_rad=new double[numIon];
	double* ion_mob=new double[numIon];
	double* ion_fc=new double[numIon];
	// 1st Ion Properties
	ion_val[0]=y[19];
   ion_conc[0]=y[20];  		// mM or mol/m^3	    
	ion_rad[0]=y[21];		// meters
	ion_mob[0]=calc_Ion_Mobility(ion_val[0],ion_rad[0],viscosity);
	ion_fc[0]=calc_Ion_Friction_Coefficient(ion_val[0],ion_mob[0]);
	// 2nd Ion Properties
	ion_val[1]=y[22];
   ion_conc[1]=y[23];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[1]=y[24];													// [meter]
	ion_mob[1]=calc_Ion_Mobility(ion_val[1],ion_rad[1],viscosity);		// [meter^2/Volt*second]
	ion_fc[1]=calc_Ion_Friction_Coefficient(ion_val[1],ion_mob[1]);		// [Newton*second/meter]
	// 3rd Ion Properties
	ion_val[2]=y[25];
   ion_conc[2]=y[26];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[2]=y[27];													// [meter]
	ion_mob[2]=calc_Ion_Mobility(ion_val[2],ion_rad[2],viscosity);		// [meter^2/Volt*second]
	ion_fc[2]=calc_Ion_Friction_Coefficient(ion_val[2],ion_mob[2]);		// [Newton*second/meter]
	// 4th Ion Properties
	ion_val[3]=y[28];
   ion_conc[3]=y[29];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[3]=y[30];													// [meter]
	ion_mob[3]=calc_Ion_Mobility(ion_val[3],ion_rad[3],viscosity);		// [meter^2/Volt*second]
	ion_fc[3]=calc_Ion_Friction_Coefficient(ion_val[3],ion_mob[3]);		// [Newton*second/meter]
	// 5th Ion Properties
	ion_val[4]=y[31];
   ion_conc[4]=y[32];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[4]=y[33];													// [meter]
	ion_mob[4]=calc_Ion_Mobility(ion_val[4],ion_rad[4],viscosity);		// [meter^2/Volt*second]
	ion_fc[4]=calc_Ion_Friction_Coefficient(ion_val[4],ion_mob[4]);		// [Newton*second/meter]

	double Debye=y[35];				// meters	
	double dielectric=y[34];
	// Convert Concentration to Number Density (particles per volume (m^3))
	ion_conc[0]*=Na;
	ion_conc[1]*=Na;
	ion_conc[2]*=Na;
	ion_conc[3]*=Na;
	ion_conc[4]*=Na;
	// Calculation Constants
	double A;
	int ionIndex;
    // Linearized Governing Equations
	// F FUNCTION
	// df/dr = y[1]
	dy[0]=y[1];
	// d2f/dr2 = y[2]
	dy[1]=y[2];
	// d3f/dr3 = y[3]
	dy[2]=y[3];
	// d4f/dr4 = y[4]
	dy[3]=y[4];
	// d5f/dr5
	// 1st Ion Equilibrium Number Density
	double dN1_dr=(-ion_conc[0]*ion_val[0]*ec/(kb*T))*y[6]*exp(-ec*ion_val[0]*y[5]/(kb*T));
	double trm1=ion_val[0]*ec*dN1_dr*y[7];
	// 2nd Ion Equilibrium Number Density
	double dN2_dr=(-ion_conc[1]*ion_val[1]*ec/(kb*T))*y[6]*exp(-ec*ion_val[1]*y[5]/(kb*T));
	double trm2=ion_val[1]*ec*dN2_dr*y[9];
	// 3rd Ion Equilibrium Number Density
	double dN3_dr=(-ion_conc[2]*ion_val[2]*ec/(kb*T))*y[6]*exp(-ec*ion_val[2]*y[5]/(kb*T));
	double trm3=ion_val[2]*ec*dN3_dr*y[11];
	// 4th Ion Equilibrium Number Density
	double dN4_dr=(-ion_conc[3]*ion_val[3]*ec/(kb*T))*y[6]*exp(-ec*ion_val[3]*y[5]/(kb*T));
	double trm4=ion_val[3]*ec*dN4_dr*y[13];
	// 5th Ion Equilibrium Number Density
	double dN5_dr=(-ion_conc[4]*ion_val[4]*ec/(kb*T))*y[6]*exp(-ec*ion_val[4]*y[5]/(kb*T));
	double trm5=ion_val[4]*ec*dN5_dr*y[15];
	//
	dy[4]=-4*y[4]/r + 4*y[3]/(r*r) + (trm1+trm2+trm3+trm4+trm5)/(viscosity*r);
	// EQUILIBRIUM POTENTIAL
	// d(potential)/dr = y[6]
	dy[5]=y[6];
	// d2(potential)/dr2
	A=0;
	for(int i=0;i<numIon;i++){A+=ion_val[i]*ion_conc[i]*exp(-ec*ion_val[i]*y[5]/(kb*T));}
	dy[6]=-ec*A/(dielectric*eo) - 2*y[6]/r;
	// INDUCED ELECTROCHEMICAL POTENTIAL FUNCTION (2 ions)
	// 1st Ion
	// d(IEP)/dr
   dy[7]=y[8];
	// d2(IEP)/dr2
	A=(ion_val[0]*ec/(kb*T))*y[6];
   dy[8]=-2*y[8]/r + 2*y[7]/(r*r) + A*(y[8] - (2*ion_fc[0]/(r*ion_val[0]*ec))*y[1]);
	// 2nd Ion
	// d(IEP)/dr
   dy[9]=y[10];
	// d2(IEP)/dr2
	A=(ion_val[1]*ec/(kb*T))*y[6];
   dy[10]=-2*y[10]/r + 2*y[9]/(r*r) + A*(y[10] - (2*ion_fc[1]/(r*ion_val[1]*ec))*y[1]);
	// 3rd Ion
	// d(IEP)/dr
   dy[11]=y[12];
	// d2(IEP)/dr2
	A=(ion_val[2]*ec/(kb*T))*y[6];
   dy[12]=-2*y[12]/r + 2*y[11]/(r*r) + A*(y[12] - (2*ion_fc[2]/(r*ion_val[2]*ec))*y[1]);
	// 4th Ion
	// d(IEP)/dr
   dy[13]=y[14];
	// d2(IEP)/dr2
	A=(ion_val[3]*ec/(kb*T))*y[6];
   dy[14]=-2*y[14]/r + 2*y[13]/(r*r) + A*(y[14] - (2*ion_fc[3]/(r*ion_val[3]*ec))*y[1]);
	// 5th Ion
	// d(IEP)/dr
   dy[15]=y[16];
	// d2(IEP)/dr2
	A=(ion_val[4]*ec/(kb*T))*y[6];
   dy[16]=-2*y[16]/r + 2*y[15]/(r*r) + A*(y[16] - (2*ion_fc[4]/(r*ion_val[4]*ec))*y[1]);

	// Clear Memory
	delete [] ion_conc;delete [] ion_val;delete [] ion_rad;delete [] ion_mob;delete [] ion_fc;}

void inhomogeneous_Prob1_5ion(const state_type &y,state_type &dy,const double r)
	{double T=y[17];									// temperature [Kelvin]
	double viscosity=y[36];							// [Newton*second/meter^2]
	// Organize Ion Data
	int numIon=y[18];	
	double* ion_conc=new double[numIon];
	int* ion_val=new int[numIon];
	double* ion_rad=new double[numIon];
	double* ion_mob=new double[numIon];
	double* ion_fc=new double[numIon];
	// 1st Ion Properties
	ion_val[0]=y[19];
   ion_conc[0]=y[20];  		// mM or mol/m^3	    
	ion_rad[0]=y[21];		// meters
	ion_mob[0]=calc_Ion_Mobility(ion_val[0],ion_rad[0],viscosity);
	ion_fc[0]=calc_Ion_Friction_Coefficient(ion_val[0],ion_mob[0]);
	// 2nd Ion Properties
	ion_val[1]=y[22];
   ion_conc[1]=y[23];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[1]=y[24];													// [meter]
	ion_mob[1]=calc_Ion_Mobility(ion_val[1],ion_rad[1],viscosity);		// [meter^2/Volt*second]
	ion_fc[1]=calc_Ion_Friction_Coefficient(ion_val[1],ion_mob[1]);		// [Newton*second/meter]
	// 3rd Ion Properties
	ion_val[2]=y[25];
   ion_conc[2]=y[26];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[2]=y[27];													// [meter]
	ion_mob[2]=calc_Ion_Mobility(ion_val[2],ion_rad[2],viscosity);		// [meter^2/Volt*second]
	ion_fc[2]=calc_Ion_Friction_Coefficient(ion_val[2],ion_mob[2]);		// [Newton*second/meter]
	// 4th Ion Properties
	ion_val[3]=y[28];
   ion_conc[3]=y[29];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[3]=y[30];													// [meter]
	ion_mob[3]=calc_Ion_Mobility(ion_val[3],ion_rad[3],viscosity);		// [meter^2/Volt*second]
	ion_fc[3]=calc_Ion_Friction_Coefficient(ion_val[3],ion_mob[3]);		// [Newton*second/meter]
	// 5th Ion Properties
	ion_val[4]=y[31];
   ion_conc[4]=y[32];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[4]=y[33];													// [meter]
	ion_mob[4]=calc_Ion_Mobility(ion_val[4],ion_rad[4],viscosity);		// [meter^2/Volt*second]
	ion_fc[4]=calc_Ion_Friction_Coefficient(ion_val[4],ion_mob[4]);		// [Newton*second/meter]

	double Debye=y[35];	// meters	
	double dielectric=y[34];
	// Convert Concentration to Number Density (particles per volume (m^3))
	ion_conc[0]*=Na;
	ion_conc[1]*=Na;
   ion_conc[2]*=Na;
	ion_conc[3]*=Na;
	ion_conc[4]*=Na;
	// Calculation Constants
	double A,dN_dr;
	int ionIndex;

	// Linearized Governing Equations
	// F FUNCTION
	// df/dr = y[1]
	dy[0]=y[1];
	// d2f/dr2 = y[2]
	dy[1]=y[2];
	// d3f/dr3 = y[3]
	dy[2]=y[3];
	// d4f/dr4 = y[4]
	dy[3]=y[4];
	// d5f/dr5
	A=0;
	for(int i=0;i<numIon;i++)
		{// Ion Equilibrium Number Density
		dN_dr=(-ion_conc[i]*ion_val[i]*ec/(kb*T))*y[6]*exp(-ec*ion_val[i]*y[5]/(kb*T));
		// Ion Contribution
		ionIndex=7+2*i; 
		A+=ion_val[i]*ec*dN_dr*y[ionIndex];}
    dy[4]=-4*y[4]/r + 4*y[3]/(r*r) + A/(viscosity*r);
	// EQUILIBRIUM POTENTIAL
	// d(potential)/dr = y[6]
	dy[5]=y[6];
	// d2(potential)/dr2
	A=0;
	for(int i=0;i<numIon;i++){A+=ion_val[i]*ion_conc[i]*exp(-ec*ion_val[i]*y[5]/(kb*T));}
	dy[6]=-ec*A/(dielectric*eo) - 2*y[6]/r;
	// INDUCED ELECTROCHEMICAL POTENTIAL FUNCTION (2 ions)
	// 1st Ion
	// d(IEP)/dr = y[8]
   dy[7]=y[8];
	// d2(IEP)/dr2
	A=(ion_val[0]*ec/(kb*T))*y[6];
   dy[8]=-2*y[8]/r + 2*y[7]/(r*r) + A*(y[8] - (2*ion_fc[0]/(r*ion_val[0]*ec))*y[1] - ion_fc[0]/(ion_val[0]*ec));
	// 2nd Ion
	// d(IEP)/dr = y[10]
   dy[9]=y[10];
	// d2(IEP)/dr2
	A=(ion_val[1]*ec/(kb*T))*y[6];
   dy[10]=-2*y[10]/r + 2*y[9]/(r*r) + A*(y[10] - (2*ion_fc[1]/(r*ion_val[1]*ec))*y[1] - ion_fc[1]/(ion_val[1]*ec));
	// 3rd Ion
	// d(IEP)/dr
   dy[11]=y[12];
	// d2(IEP)/dr2
	A=(ion_val[2]*ec/(kb*T))*y[6];
   dy[12]=-2*y[12]/r + 2*y[11]/(r*r) + A*(y[12] - (2*ion_fc[2]/(r*ion_val[2]*ec))*y[1] - ion_fc[2]/(ion_val[2]*ec));
	// 4th Ion
	// d(IEP)/dr
   dy[13]=y[14];
	// d2(IEP)/dr2
	A=(ion_val[3]*ec/(kb*T))*y[6];
   dy[14]=-2*y[14]/r + 2*y[13]/(r*r) + A*(y[14] - (2*ion_fc[3]/(r*ion_val[3]*ec))*y[1] - ion_fc[3]/(ion_val[3]*ec));
	// 5th Ion
	// d(IEP)/dr
   dy[15]=y[16];
	// d2(IEP)/dr2
	A=(ion_val[4]*ec/(kb*T))*y[6];
   dy[16]=-2*y[16]/r + 2*y[15]/(r*r) + A*(y[16] - (2*ion_fc[4]/(r*ion_val[4]*ec))*y[1] - ion_fc[4]/(ion_val[4]*ec));

	// Clear Memory
	delete [] ion_conc;delete [] ion_val;delete [] ion_rad;delete [] ion_mob;delete [] ion_fc;}

void inhomogeneous_Prob2_5ion(const state_type &y,state_type &dy,const double r)
	{double T=y[17];								// temperature [Kelvin]
	double viscosity=y[36];						// [Newton*second/meter^2]
	// Organize Ion Data
	int numIon=y[18];	
	double* ion_conc=new double[numIon];
	int* ion_val=new int[numIon];
	double* ion_rad=new double[numIon];
	double* ion_mob=new double[numIon];
	double* ion_fc=new double[numIon];
	// 1st Ion Properties
	ion_val[0]=y[19];
   ion_conc[0]=y[20];  		// mM or mol/m^3	    
	ion_rad[0]=y[21];		// meters
	ion_mob[0]=calc_Ion_Mobility(ion_val[0],ion_rad[0],viscosity);
	ion_fc[0]=calc_Ion_Friction_Coefficient(ion_val[0],ion_mob[0]);
	// 2nd Ion Properties
	ion_val[1]=y[22];
   ion_conc[1]=y[23];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[1]=y[24];													// [meter]
	ion_mob[1]=calc_Ion_Mobility(ion_val[1],ion_rad[1],viscosity);		// [meter^2/Volt*second]
	ion_fc[1]=calc_Ion_Friction_Coefficient(ion_val[1],ion_mob[1]);		// [Newton*second/meter]
	// 3rd Ion Properties
	ion_val[2]=y[25];
   ion_conc[2]=y[26];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[2]=y[27];													// [meter]
	ion_mob[2]=calc_Ion_Mobility(ion_val[2],ion_rad[2],viscosity);		// [meter^2/Volt*second]
	ion_fc[2]=calc_Ion_Friction_Coefficient(ion_val[2],ion_mob[2]);		// [Newton*second/meter]
	// 4th Ion Properties
	ion_val[3]=y[28];
   ion_conc[3]=y[29];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[3]=y[30];													// [meter]
	ion_mob[3]=calc_Ion_Mobility(ion_val[3],ion_rad[3],viscosity);		// [meter^2/Volt*second]
	ion_fc[3]=calc_Ion_Friction_Coefficient(ion_val[3],ion_mob[3]);		// [Newton*second/meter]
	// 5th Ion Properties
	ion_val[4]=y[31];
   ion_conc[4]=y[32];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[4]=y[33];													// [meter]
	ion_mob[4]=calc_Ion_Mobility(ion_val[4],ion_rad[4],viscosity);		// [meter^2/Volt*second]
	ion_fc[4]=calc_Ion_Friction_Coefficient(ion_val[4],ion_mob[4]);		// [Newton*second/meter]

	double Debye=y[35];	// meters	
	double dielectric=y[34];
	// Convert Concentration to Number Density (particles per volume (m^3))
	ion_conc[0]*=Na;
	ion_conc[1]*=Na;
   ion_conc[2]*=Na;
	ion_conc[3]*=Na;
	ion_conc[4]*=Na;
    // Calculation Constants
	double A,dN_dr;
	int ionIndex;
    // Linearized Governing Equations
	// F FUNCTION
	// df/dr = y[1]
	dy[0]=y[1];
	// d2f/dr2 = y[2]
	dy[1]=y[2];
	// d3f/dr3 = y[3]
	dy[2]=y[3];
	// d4f/dr4 = y[4]
	dy[3]=y[4];
	// d5f/dr5
	A=0;
	for(int i=0;i<numIon;i++)
		{// Ion Equilibrium Number Density
		dN_dr=(-ion_conc[i]*ion_val[i]*ec/(kb*T))*y[6]*exp(-ec*ion_val[i]*y[5]/(kb*T));
		// Ion Contribution
		ionIndex=7+2*i; 
		A+=ion_val[i]*ec*dN_dr*(y[ionIndex]+r);}
   dy[4]=-4*y[4]/r + 4*y[3]/(r*r) + A/(viscosity*r);
	// EQUILIBRIUM POTENTIAL
	// d(potential)/dr = y[6]
	dy[5]=y[6];
	// d2(potential)/dr2
	A=0;
	for(int i=0;i<numIon;i++){A+=ion_val[i]*ion_conc[i]*exp(-ec*ion_val[i]*y[5]/(kb*T));}
	dy[6]=-ec*A/(dielectric*eo) - 2*y[6]/r;
	// INDUCED ELECTROCHEMICAL POTENTIAL FUNCTION (2 ions)
	// 1st Ion
	// d(IEP)/dr = y[8]
   dy[7]=y[8];
	// d2(IEP)/dr2
	A=(ion_val[0]*ec/(kb*T))*y[6];
   dy[8]=-2*y[8]/r + 2*y[7]/(r*r) + A*(y[8] - (2*ion_fc[0]/(r*ion_val[0]*ec))*y[1] + 1);
	// 2nd Ion
	// d(IEP)/dr = y[10]
   dy[9]=y[10];
	// d2(IEP)/dr2
	A=(ion_val[1]*ec/(kb*T))*y[6];
   dy[10]=-2*y[10]/r + 2*y[9]/(r*r) + A*(y[10] - (2*ion_fc[1]/(r*ion_val[1]*ec))*y[1] + 1);
	// 3rd Ion
	// d(IEP)/dr
   dy[11]=y[12];
	// d2(IEP)/dr2
	A=(ion_val[2]*ec/(kb*T))*y[6];
   dy[12]=-2*y[12]/r + 2*y[11]/(r*r) + A*(y[12] - (2*ion_fc[2]/(r*ion_val[2]*ec))*y[1] + 1);
	// 4th Ion
	// d(IEP)/dr
   dy[13]=y[14];
	// d2(IEP)/dr2
	A=(ion_val[3]*ec/(kb*T))*y[6];
   dy[14]=-2*y[14]/r + 2*y[13]/(r*r) + A*(y[14] - (2*ion_fc[3]/(r*ion_val[3]*ec))*y[1] + 1);
	// 5th Ion
	// d(IEP)/dr
   dy[15]=y[16];
	// d2(IEP)/dr2
	A=(ion_val[4]*ec/(kb*T))*y[6];
   dy[16]=-2*y[16]/r + 2*y[15]/(r*r) + A*(y[16] - (2*ion_fc[4]/(r*ion_val[4]*ec))*y[1] + 1);

	// Clear Memory
	delete [] ion_conc;delete [] ion_val;delete [] ion_rad;delete [] ion_mob;delete [] ion_fc;}

	// y[0] = f
	// y[1] = df/dr
	// y[2] = d2f/dr2
	// y[3] = d3f/dr3
	// y[4] = d4f/dr4
	// Equilibrium Electric Pontential
	// y[5] = potential
	// y[6] = d(potential)/dr
	// Induced Electrochemical Potential Function (3 ion)
	// y[7] = IEP1
	// y[8] = d(IEP1)/dr
	// y[9] = IEP2
	// y[10] = d(IEP2)/dr
	// y[11] = IEP3
	// y[12] = d(IEP3)/dr
	// y[13] = IEP4
	// y[14] = d(IEP4)/dr
	// Constants
	// y[15] = Temp					// [Kelvin]
	// y[16] = numIon
	// Ion Properties
	// y[17] = Ion1.val;		
	// y[18] = Ion1.conc;		// mM [mol/m^3]
	// y[19] = Ion1.radius;		// meters
	// y[20] = Ion2.val;
	// y[21] = Ion2.conc;
	// y[22] = Ion2.radius;
	// y[23] = Ion3.val;
	// y[24] = Ion3.conc;
	// y[25] = Ion3.radius;
	// y[26] = Ion4.val;
	// y[27] = Ion4.conc;
	// y[28] = Ion4.radius;
	// Solution Properties
	// y[29] = relative dielectric	[dimensionless]
	// y[30] = Debye Length [meters]
	// y[31] = viscosity  [Pa s]
void homogeneous_form_4ion(const state_type &y,state_type &dy,const double r)
	{double T=y[15];									// temperature [Kelvin]
	double viscosity=y[31];							// [Newton*second/meter^2]
	// Organize Ion Data
	int numIon=y[16];	
	double* ion_conc=new double[numIon];
	int* ion_val=new int[numIon];
	double* ion_rad=new double[numIon];
	double* ion_mob=new double[numIon];
	double* ion_fc=new double[numIon];
	// 1st Ion Properties
	ion_val[0]=y[17];
   ion_conc[0]=y[18];  		// mM or mol/m^3	    
	ion_rad[0]=y[19];		// meters
	ion_mob[0]=calc_Ion_Mobility(ion_val[0],ion_rad[0],viscosity);
	ion_fc[0]=calc_Ion_Friction_Coefficient(ion_val[0],ion_mob[0]);
	// 2nd Ion Properties
	ion_val[1]=y[20];
   ion_conc[1]=y[21];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[1]=y[22];													// [meter]
	ion_mob[1]=calc_Ion_Mobility(ion_val[1],ion_rad[1],viscosity);		// [meter^2/Volt*second]
	ion_fc[1]=calc_Ion_Friction_Coefficient(ion_val[1],ion_mob[1]);		// [Newton*second/meter]
	// 3rd Ion Properties
	ion_val[2]=y[23];
   ion_conc[2]=y[24];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[2]=y[25];													// [meter]
	ion_mob[2]=calc_Ion_Mobility(ion_val[2],ion_rad[2],viscosity);		// [meter^2/Volt*second]
	ion_fc[2]=calc_Ion_Friction_Coefficient(ion_val[2],ion_mob[2]);		// [Newton*second/meter]
	// 4th Ion Properties
	ion_val[3]=y[26];
   ion_conc[3]=y[27];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[3]=y[28];													// [meter]
	ion_mob[3]=calc_Ion_Mobility(ion_val[3],ion_rad[3],viscosity);		// [meter^2/Volt*second]
	ion_fc[3]=calc_Ion_Friction_Coefficient(ion_val[3],ion_mob[3]);		// [Newton*second/meter]

	double Debye=y[30];				// meters	
	double dielectric=y[29];
	// Convert Concentration to Number Density (particles per volume (m^3))
	ion_conc[0]*=Na;
	ion_conc[1]*=Na;
	ion_conc[2]*=Na;
	ion_conc[3]*=Na;
	// Calculation Constants
	double A;
	int ionIndex;
    // Linearized Governing Equations
	// F FUNCTION
	// df/dr = y[1]
	dy[0]=y[1];
	// d2f/dr2 = y[2]
	dy[1]=y[2];
	// d3f/dr3 = y[3]
	dy[2]=y[3];
	// d4f/dr4 = y[4]
	dy[3]=y[4];
	// d5f/dr5
	// 1st Ion Equilibrium Number Density
	double dN1_dr=(-ion_conc[0]*ion_val[0]*ec/(kb*T))*y[6]*exp(-ec*ion_val[0]*y[5]/(kb*T));
	double trm1=ion_val[0]*ec*dN1_dr*y[7];
	// 2nd Ion Equilibrium Number Density
	double dN2_dr=(-ion_conc[1]*ion_val[1]*ec/(kb*T))*y[6]*exp(-ec*ion_val[1]*y[5]/(kb*T));
	double trm2=ion_val[1]*ec*dN2_dr*y[9];
	// 3rd Ion Equilibrium Number Density
	double dN3_dr=(-ion_conc[2]*ion_val[2]*ec/(kb*T))*y[6]*exp(-ec*ion_val[2]*y[5]/(kb*T));
	double trm3=ion_val[2]*ec*dN3_dr*y[11];
	// 4th Ion Equilibrium Number Density
	double dN4_dr=(-ion_conc[3]*ion_val[3]*ec/(kb*T))*y[6]*exp(-ec*ion_val[3]*y[5]/(kb*T));
	double trm4=ion_val[3]*ec*dN4_dr*y[13];
	//
	dy[4]=-4*y[4]/r + 4*y[3]/(r*r) + (trm1+trm2+trm3+trm4)/(viscosity*r);
	// EQUILIBRIUM POTENTIAL
	// d(potential)/dr = y[6]
	dy[5]=y[6];
	// d2(potential)/dr2
	A=0;
	for(int i=0;i<numIon;i++){A+=ion_val[i]*ion_conc[i]*exp(-ec*ion_val[i]*y[5]/(kb*T));}
	dy[6]=-ec*A/(dielectric*eo) - 2*y[6]/r;
	// INDUCED ELECTROCHEMICAL POTENTIAL FUNCTION (2 ions)
	// 1st Ion
	// d(IEP)/dr
   dy[7]=y[8];
	// d2(IEP)/dr2
	A=(ion_val[0]*ec/(kb*T))*y[6];
   dy[8]=-2*y[8]/r + 2*y[7]/(r*r) + A*(y[8] - (2*ion_fc[0]/(r*ion_val[0]*ec))*y[1]);
	// 2nd Ion
	// d(IEP)/dr
   dy[9]=y[10];
	// d2(IEP)/dr2
	A=(ion_val[1]*ec/(kb*T))*y[6];
   dy[10]=-2*y[10]/r + 2*y[9]/(r*r) + A*(y[10] - (2*ion_fc[1]/(r*ion_val[1]*ec))*y[1]);
	// 3rd Ion
	// d(IEP)/dr
   dy[11]=y[12];
	// d2(IEP)/dr2
	A=(ion_val[2]*ec/(kb*T))*y[6];
   dy[12]=-2*y[12]/r + 2*y[11]/(r*r) + A*(y[12] - (2*ion_fc[2]/(r*ion_val[2]*ec))*y[1]);
	// 4th Ion
	// d(IEP)/dr
   dy[13]=y[14];
	// d2(IEP)/dr2
	A=(ion_val[3]*ec/(kb*T))*y[6];
   dy[14]=-2*y[14]/r + 2*y[13]/(r*r) + A*(y[14] - (2*ion_fc[3]/(r*ion_val[3]*ec))*y[1]);

	// Clear Memory
	delete [] ion_conc;delete [] ion_val;delete [] ion_rad;delete [] ion_mob;delete [] ion_fc;}

void inhomogeneous_Prob1_4ion(const state_type &y,state_type &dy,const double r)
	{double T=y[15];									// temperature [Kelvin]
	double viscosity=y[31];							// [Newton*second/meter^2]
	// Organize Ion Data
	int numIon=y[16];	
	double* ion_conc=new double[numIon];
	int* ion_val=new int[numIon];
	double* ion_rad=new double[numIon];
	double* ion_mob=new double[numIon];
	double* ion_fc=new double[numIon];
	// 1st Ion Properties
	ion_val[0]=y[17];
   ion_conc[0]=y[18];  		// mM or mol/m^3	    
	ion_rad[0]=y[19];		// meters
	ion_mob[0]=calc_Ion_Mobility(ion_val[0],ion_rad[0],viscosity);
	ion_fc[0]=calc_Ion_Friction_Coefficient(ion_val[0],ion_mob[0]);
	// 2nd Ion Properties
	ion_val[1]=y[20];
   ion_conc[1]=y[21];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[1]=y[22];													// [meter]
	ion_mob[1]=calc_Ion_Mobility(ion_val[1],ion_rad[1],viscosity);		// [meter^2/Volt*second]
	ion_fc[1]=calc_Ion_Friction_Coefficient(ion_val[1],ion_mob[1]);		// [Newton*second/meter]
	// 3rd Ion Properties
	ion_val[2]=y[23];
   ion_conc[2]=y[24];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[2]=y[25];													// [meter]
	ion_mob[2]=calc_Ion_Mobility(ion_val[2],ion_rad[2],viscosity);		// [meter^2/Volt*second]
	ion_fc[2]=calc_Ion_Friction_Coefficient(ion_val[2],ion_mob[2]);		// [Newton*second/meter]
	// 4th Ion Properties
	ion_val[3]=y[26];
   ion_conc[3]=y[27];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[3]=y[28];													// [meter]
	ion_mob[3]=calc_Ion_Mobility(ion_val[3],ion_rad[3],viscosity);		// [meter^2/Volt*second]
	ion_fc[3]=calc_Ion_Friction_Coefficient(ion_val[3],ion_mob[3]);		// [Newton*second/meter]

	double Debye=y[30];	// meters	
	double dielectric=y[29];
	// Convert Concentration to Number Density (particles per volume (m^3))
	ion_conc[0]*=Na;
	ion_conc[1]*=Na;
   ion_conc[2]*=Na;
	ion_conc[3]*=Na;
	// Calculation Constants
	double A,dN_dr;
	int ionIndex;

	// Linearized Governing Equations
	// F FUNCTION
	// df/dr = y[1]
	dy[0]=y[1];
	// d2f/dr2 = y[2]
	dy[1]=y[2];
	// d3f/dr3 = y[3]
	dy[2]=y[3];
	// d4f/dr4 = y[4]
	dy[3]=y[4];
	// d5f/dr5
	A=0;
	for(int i=0;i<numIon;i++)
		{// Ion Equilibrium Number Density
		dN_dr=(-ion_conc[i]*ion_val[i]*ec/(kb*T))*y[6]*exp(-ec*ion_val[i]*y[5]/(kb*T));
		// Ion Contribution
		ionIndex=7+2*i; 
		A+=ion_val[i]*ec*dN_dr*y[ionIndex];}
    dy[4]=-4*y[4]/r + 4*y[3]/(r*r) + A/(viscosity*r);
	// EQUILIBRIUM POTENTIAL
	// d(potential)/dr = y[6]
	dy[5]=y[6];
	// d2(potential)/dr2
	A=0;
	for(int i=0;i<numIon;i++){A+=ion_val[i]*ion_conc[i]*exp(-ec*ion_val[i]*y[5]/(kb*T));}
	dy[6]=-ec*A/(dielectric*eo) - 2*y[6]/r;
	// INDUCED ELECTROCHEMICAL POTENTIAL FUNCTION (2 ions)
	// 1st Ion
	// d(IEP)/dr = y[8]
   dy[7]=y[8];
	// d2(IEP)/dr2
	A=(ion_val[0]*ec/(kb*T))*y[6];
   dy[8]=-2*y[8]/r + 2*y[7]/(r*r) + A*(y[8] - (2*ion_fc[0]/(r*ion_val[0]*ec))*y[1] - ion_fc[0]/(ion_val[0]*ec));
	// 2nd Ion
	// d(IEP)/dr = y[10]
   dy[9]=y[10];
	// d2(IEP)/dr2
	A=(ion_val[1]*ec/(kb*T))*y[6];
   dy[10]=-2*y[10]/r + 2*y[9]/(r*r) + A*(y[10] - (2*ion_fc[1]/(r*ion_val[1]*ec))*y[1] - ion_fc[1]/(ion_val[1]*ec));
	// 3rd Ion
	// d(IEP)/dr
   dy[11]=y[12];
	// d2(IEP)/dr2
	A=(ion_val[2]*ec/(kb*T))*y[6];
   dy[12]=-2*y[12]/r + 2*y[11]/(r*r) + A*(y[12] - (2*ion_fc[2]/(r*ion_val[2]*ec))*y[1] - ion_fc[2]/(ion_val[2]*ec));
	// 4th Ion
	// d(IEP)/dr
   dy[13]=y[14];
	// d2(IEP)/dr2
	A=(ion_val[3]*ec/(kb*T))*y[6];
   dy[14]=-2*y[14]/r + 2*y[13]/(r*r) + A*(y[14] - (2*ion_fc[3]/(r*ion_val[3]*ec))*y[1] - ion_fc[3]/(ion_val[3]*ec));

	// Clear Memory
	delete [] ion_conc;delete [] ion_val;delete [] ion_rad;delete [] ion_mob;delete [] ion_fc;}

void inhomogeneous_Prob2_4ion(const state_type &y,state_type &dy,const double r)
	{double T=y[15];								// temperature [Kelvin]
	double viscosity=y[31];						// [Newton*second/meter^2]
	// Organize Ion Data
	int numIon=y[16];	
	double* ion_conc=new double[numIon];
	int* ion_val=new int[numIon];
	double* ion_rad=new double[numIon];
	double* ion_mob=new double[numIon];
	double* ion_fc=new double[numIon];
	// 1st Ion Properties
	ion_val[0]=y[17];
   ion_conc[0]=y[18];  		// mM or mol/m^3	    
	ion_rad[0]=y[19];		// meters
	ion_mob[0]=calc_Ion_Mobility(ion_val[0],ion_rad[0],viscosity);
	ion_fc[0]=calc_Ion_Friction_Coefficient(ion_val[0],ion_mob[0]);
	// 2nd Ion Properties
	ion_val[1]=y[20];
   ion_conc[1]=y[21];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[1]=y[22];													// [meter]
	ion_mob[1]=calc_Ion_Mobility(ion_val[1],ion_rad[1],viscosity);		// [meter^2/Volt*second]
	ion_fc[1]=calc_Ion_Friction_Coefficient(ion_val[1],ion_mob[1]);		// [Newton*second/meter]
	// 3rd Ion Properties
	ion_val[2]=y[23];
   ion_conc[2]=y[24];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[2]=y[25];													// [meter]
	ion_mob[2]=calc_Ion_Mobility(ion_val[2],ion_rad[2],viscosity);		// [meter^2/Volt*second]
	ion_fc[2]=calc_Ion_Friction_Coefficient(ion_val[2],ion_mob[2]);		// [Newton*second/meter]
	// 4th Ion Properties
	ion_val[3]=y[26];
   ion_conc[3]=y[27];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[3]=y[28];													// [meter]
	ion_mob[3]=calc_Ion_Mobility(ion_val[3],ion_rad[3],viscosity);		// [meter^2/Volt*second]
	ion_fc[3]=calc_Ion_Friction_Coefficient(ion_val[3],ion_mob[3]);		// [Newton*second/meter]

	double Debye=y[30];	// meters	
	double dielectric=y[29];
	// Convert Concentration to Number Density (particles per volume (m^3))
	ion_conc[0]*=Na;
	ion_conc[1]*=Na;
   ion_conc[2]*=Na;
	ion_conc[3]*=Na;
    // Calculation Constants
	double A,dN_dr;
	int ionIndex;
    // Linearized Governing Equations
	// F FUNCTION
	// df/dr = y[1]
	dy[0]=y[1];
	// d2f/dr2 = y[2]
	dy[1]=y[2];
	// d3f/dr3 = y[3]
	dy[2]=y[3];
	// d4f/dr4 = y[4]
	dy[3]=y[4];
	// d5f/dr5
	A=0;
	for(int i=0;i<numIon;i++)
		{// Ion Equilibrium Number Density
		dN_dr=(-ion_conc[i]*ion_val[i]*ec/(kb*T))*y[6]*exp(-ec*ion_val[i]*y[5]/(kb*T));
		// Ion Contribution
		ionIndex=7+2*i; 
		A+=ion_val[i]*ec*dN_dr*(y[ionIndex]+r);}
   dy[4]=-4*y[4]/r + 4*y[3]/(r*r) + A/(viscosity*r);
	// EQUILIBRIUM POTENTIAL
	// d(potential)/dr = y[6]
	dy[5]=y[6];
	// d2(potential)/dr2
	A=0;
	for(int i=0;i<numIon;i++){A+=ion_val[i]*ion_conc[i]*exp(-ec*ion_val[i]*y[5]/(kb*T));}
	dy[6]=-ec*A/(dielectric*eo) - 2*y[6]/r;
	// INDUCED ELECTROCHEMICAL POTENTIAL FUNCTION (2 ions)
	// 1st Ion
	// d(IEP)/dr = y[8]
   dy[7]=y[8];
	// d2(IEP)/dr2
	A=(ion_val[0]*ec/(kb*T))*y[6];
   dy[8]=-2*y[8]/r + 2*y[7]/(r*r) + A*(y[8] - (2*ion_fc[0]/(r*ion_val[0]*ec))*y[1] + 1);
	// 2nd Ion
	// d(IEP)/dr = y[10]
   dy[9]=y[10];
	// d2(IEP)/dr2
	A=(ion_val[1]*ec/(kb*T))*y[6];
   dy[10]=-2*y[10]/r + 2*y[9]/(r*r) + A*(y[10] - (2*ion_fc[1]/(r*ion_val[1]*ec))*y[1] + 1);
	// 3rd Ion
	// d(IEP)/dr
   dy[11]=y[12];
	// d2(IEP)/dr2
	A=(ion_val[2]*ec/(kb*T))*y[6];
   dy[12]=-2*y[12]/r + 2*y[11]/(r*r) + A*(y[12] - (2*ion_fc[2]/(r*ion_val[2]*ec))*y[1] + 1);
	// 4th Ion
	// d(IEP)/dr
   dy[13]=y[14];
	// d2(IEP)/dr2
	A=(ion_val[3]*ec/(kb*T))*y[6];
   dy[14]=-2*y[14]/r + 2*y[13]/(r*r) + A*(y[14] - (2*ion_fc[3]/(r*ion_val[3]*ec))*y[1] + 1);

	// Clear Memory
	delete [] ion_conc;delete [] ion_val;delete [] ion_rad;delete [] ion_mob;delete [] ion_fc;}

	// y[0] = f
	// y[1] = df/dr
	// y[2] = d2f/dr2
	// y[3] = d3f/dr3
	// y[4] = d4f/dr4
	// Equilibrium Electric Pontential
	// y[5] = potential
	// y[6] = d(potential)/dr
	// Induced Electrochemical Potential Function (3 ion)
	// y[7] = IEP1
	// y[8] = d(IEP1)/dr
	// y[9] = IEP2
	// y[10] = d(IEP2)/dr
	// y[11] = IEP3
	// y[12] = d(IEP3)/dr
	// Constants
	// y[13] = Temp					// [Kelvin]
	// y[14] = numIon
	// Ion Properties
	// y[15] = Ion1.val;		
	// y[16] = Ion1.conc;		// mM [mol/m^3]
	// y[17] = Ion1.radius;		// meters
	// y[18] = Ion2.val;
	// y[19] = Ion2.conc;
	// y[20] = Ion2.radius;
	// y[21] = Ion3.val;
	// y[22] = Ion3.conc;
	// y[23] = Ion3.radius;
	// Solution Properties
	// y[24] = relative dielectric	[dimensionless]
	// y[25] = Debye Length [meters]
	// y[26] = viscosity  [Pa s]
void homogeneous_form_3ion(const state_type &y,state_type &dy,const double r)
	{double T=y[13];									// temperature [Kelvin]
	double viscosity=y[26];							// [Newton*second/meter^2]
	// Organize Ion Data
	int numIon=y[14];	
	double* ion_conc=new double[numIon];
	int* ion_val=new int[numIon];
	double* ion_rad=new double[numIon];
	double* ion_mob=new double[numIon];
	double* ion_fc=new double[numIon];
	// 1st Ion Properties
	ion_val[0]=y[15];
   ion_conc[0]=y[16];  		// mM or mol/m^3	    
	ion_rad[0]=y[17];		// meters
	ion_mob[0]=calc_Ion_Mobility(ion_val[0],ion_rad[0],viscosity);
	ion_fc[0]=calc_Ion_Friction_Coefficient(ion_val[0],ion_mob[0]);
	// 2nd Ion Properties
	ion_val[1]=y[18];
   ion_conc[1]=y[19];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[1]=y[20];													// [meter]
	ion_mob[1]=calc_Ion_Mobility(ion_val[1],ion_rad[1],viscosity);		// [meter^2/Volt*second]
	ion_fc[1]=calc_Ion_Friction_Coefficient(ion_val[1],ion_mob[1]);		// [Newton*second/meter]
	// 3rd Ion Properties
	ion_val[2]=y[21];
   ion_conc[2]=y[22];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[2]=y[23];													// [meter]
	ion_mob[2]=calc_Ion_Mobility(ion_val[2],ion_rad[2],viscosity);		// [meter^2/Volt*second]
	ion_fc[2]=calc_Ion_Friction_Coefficient(ion_val[2],ion_mob[2]);		// [Newton*second/meter]

	double Debye=y[25];				// meters	
	double dielectric=y[24];
	// Convert Concentration to Number Density (particles per volume (m^3))
	ion_conc[0]*=Na;
	ion_conc[1]*=Na;
	ion_conc[2]*=Na;
	// Calculation Constants
	double A;
	int ionIndex;
    // Linearized Governing Equations
	// F FUNCTION
	// df/dr = y[1]
	dy[0]=y[1];
	// d2f/dr2 = y[2]
	dy[1]=y[2];
	// d3f/dr3 = y[3]
	dy[2]=y[3];
	// d4f/dr4 = y[4]
	dy[3]=y[4];
	// d5f/dr5
	// 1st Ion Equilibrium Number Density
	double dN1_dr=(-ion_conc[0]*ion_val[0]*ec/(kb*T))*y[6]*exp(-ec*ion_val[0]*y[5]/(kb*T));
	double trm1=ion_val[0]*ec*dN1_dr*y[7];
	// 2nd Ion Equilibrium Number Density
	double dN2_dr=(-ion_conc[1]*ion_val[1]*ec/(kb*T))*y[6]*exp(-ec*ion_val[1]*y[5]/(kb*T));
	double trm2=ion_val[1]*ec*dN2_dr*y[9];
	// 3rd Ion Equilibrium Number Density
	double dN3_dr=(-ion_conc[2]*ion_val[2]*ec/(kb*T))*y[6]*exp(-ec*ion_val[2]*y[5]/(kb*T));
	double trm3=ion_val[2]*ec*dN3_dr*y[11];
	//
	dy[4]=-4*y[4]/r + 4*y[3]/(r*r) + (trm1+trm2+trm3)/(viscosity*r);
	// EQUILIBRIUM POTENTIAL
	// d(potential)/dr = y[6]
	dy[5]=y[6];
	// d2(potential)/dr2
	A=0;
	for(int i=0;i<numIon;i++){A+=ion_val[i]*ion_conc[i]*exp(-ec*ion_val[i]*y[5]/(kb*T));}
	dy[6]=-ec*A/(dielectric*eo) - 2*y[6]/r;
	// INDUCED ELECTROCHEMICAL POTENTIAL FUNCTION (2 ions)
	// 1st Ion
	// d(IEP)/dr
   dy[7]=y[8];
	// d2(IEP)/dr2
	A=(ion_val[0]*ec/(kb*T))*y[6];
   dy[8]=-2*y[8]/r + 2*y[7]/(r*r) + A*(y[8] - (2*ion_fc[0]/(r*ion_val[0]*ec))*y[1]);
	// 2nd Ion
	// d(IEP)/dr
   dy[9]=y[10];
	// d2(IEP)/dr2
	A=(ion_val[1]*ec/(kb*T))*y[6];
   dy[10]=-2*y[10]/r + 2*y[9]/(r*r) + A*(y[10] - (2*ion_fc[1]/(r*ion_val[1]*ec))*y[1]);
	// 3rd Ion
	// d(IEP)/dr
   dy[11]=y[12];
	// d2(IEP)/dr2
	A=(ion_val[2]*ec/(kb*T))*y[6];
   dy[12]=-2*y[12]/r + 2*y[11]/(r*r) + A*(y[12] - (2*ion_fc[2]/(r*ion_val[2]*ec))*y[1]);

	// Clear Memory
	delete [] ion_conc;delete [] ion_val;delete [] ion_rad;delete [] ion_mob;delete [] ion_fc;}

void inhomogeneous_Prob1_3ion(const state_type &y,state_type &dy,const double r)
	{double T=y[13];									// temperature [Kelvin]
	double viscosity=y[26];							// [Newton*second/meter^2]
	// Organize Ion Data
	int numIon=y[14];	
	double* ion_conc=new double[numIon];
	int* ion_val=new int[numIon];
	double* ion_rad=new double[numIon];
	double* ion_mob=new double[numIon];
	double* ion_fc=new double[numIon];
	// 1st Ion Properties
	ion_val[0]=y[15];
   ion_conc[0]=y[16];  		// mM or mol/m^3	    
	ion_rad[0]=y[17];		// meters
	ion_mob[0]=calc_Ion_Mobility(ion_val[0],ion_rad[0],viscosity);
	ion_fc[0]=calc_Ion_Friction_Coefficient(ion_val[0],ion_mob[0]);
	// 2nd Ion Properties
	ion_val[1]=y[18];
   ion_conc[1]=y[19];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[1]=y[20];													// [meter]
	ion_mob[1]=calc_Ion_Mobility(ion_val[1],ion_rad[1],viscosity);		// [meter^2/Volt*second]
	ion_fc[1]=calc_Ion_Friction_Coefficient(ion_val[1],ion_mob[1]);		// [Newton*second/meter]
	// 3rd Ion Properties
	ion_val[2]=y[21];
   ion_conc[2]=y[22];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[2]=y[23];													// [meter]
	ion_mob[2]=calc_Ion_Mobility(ion_val[2],ion_rad[2],viscosity);		// [meter^2/Volt*second]
	ion_fc[2]=calc_Ion_Friction_Coefficient(ion_val[2],ion_mob[2]);		// [Newton*second/meter]

	double Debye=y[25];	// meters	
	double dielectric=y[24];
	// Convert Concentration to Number Density (particles per volume (m^3))
	ion_conc[0]*=Na;
	ion_conc[1]*=Na;
   ion_conc[2]*=Na;
	// Calculation Constants
	double A,dN_dr;
	int ionIndex;

	// Linearized Governing Equations
	// F FUNCTION
	// df/dr = y[1]
	dy[0]=y[1];
	// d2f/dr2 = y[2]
	dy[1]=y[2];
	// d3f/dr3 = y[3]
	dy[2]=y[3];
	// d4f/dr4 = y[4]
	dy[3]=y[4];
	// d5f/dr5
	A=0;
	for(int i=0;i<numIon;i++)
		{// Ion Equilibrium Number Density
		dN_dr=(-ion_conc[i]*ion_val[i]*ec/(kb*T))*y[6]*exp(-ec*ion_val[i]*y[5]/(kb*T));
		// Ion Contribution
		ionIndex=7+2*i; 
		A+=ion_val[i]*ec*dN_dr*y[ionIndex];}
    dy[4]=-4*y[4]/r + 4*y[3]/(r*r) + A/(viscosity*r);
	// EQUILIBRIUM POTENTIAL
	// d(potential)/dr = y[6]
	dy[5]=y[6];
	// d2(potential)/dr2
	A=0;
	for(int i=0;i<numIon;i++){A+=ion_val[i]*ion_conc[i]*exp(-ec*ion_val[i]*y[5]/(kb*T));}
	dy[6]=-ec*A/(dielectric*eo) - 2*y[6]/r;
	// INDUCED ELECTROCHEMICAL POTENTIAL FUNCTION (2 ions)
	// 1st Ion
	// d(IEP)/dr = y[8]
   dy[7]=y[8];
	// d2(IEP)/dr2
	A=(ion_val[0]*ec/(kb*T))*y[6];
   dy[8]=-2*y[8]/r + 2*y[7]/(r*r) + A*(y[8] - (2*ion_fc[0]/(r*ion_val[0]*ec))*y[1] - ion_fc[0]/(ion_val[0]*ec));
	// 2nd Ion
	// d(IEP)/dr = y[10]
   dy[9]=y[10];
	// d2(IEP)/dr2
	A=(ion_val[1]*ec/(kb*T))*y[6];
   dy[10]=-2*y[10]/r + 2*y[9]/(r*r) + A*(y[10] - (2*ion_fc[1]/(r*ion_val[1]*ec))*y[1] - ion_fc[1]/(ion_val[1]*ec));
	// 3rd Ion
	// d(IEP)/dr
   dy[11]=y[12];
	// d2(IEP)/dr2
	A=(ion_val[2]*ec/(kb*T))*y[6];
   dy[12]=-2*y[12]/r + 2*y[11]/(r*r) + A*(y[12] - (2*ion_fc[2]/(r*ion_val[2]*ec))*y[1] - ion_fc[2]/(ion_val[2]*ec));

	// Clear Memory
	delete [] ion_conc;delete [] ion_val;delete [] ion_rad;delete [] ion_mob;delete [] ion_fc;}

void inhomogeneous_Prob2_3ion(const state_type &y,state_type &dy,const double r)
	{double T=y[13];								// temperature [Kelvin]
	double viscosity=y[26];						// [Newton*second/meter^2]
	// Organize Ion Data
	int numIon=y[14];	
	double* ion_conc=new double[numIon];
	int* ion_val=new int[numIon];
	double* ion_rad=new double[numIon];
	double* ion_mob=new double[numIon];
	double* ion_fc=new double[numIon];
	// 1st Ion Properties
	ion_val[0]=y[15];
   ion_conc[0]=y[16];  		// mM or mol/m^3	    
	ion_rad[0]=y[17];		// meters
	ion_mob[0]=calc_Ion_Mobility(ion_val[0],ion_rad[0],viscosity);
	ion_fc[0]=calc_Ion_Friction_Coefficient(ion_val[0],ion_mob[0]);
	// 2nd Ion Properties
	ion_val[1]=y[18];
   ion_conc[1]=y[19];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[1]=y[20];													// [meter]
	ion_mob[1]=calc_Ion_Mobility(ion_val[1],ion_rad[1],viscosity);		// [meter^2/Volt*second]
	ion_fc[1]=calc_Ion_Friction_Coefficient(ion_val[1],ion_mob[1]);		// [Newton*second/meter]
	// 3rd Ion Properties
	ion_val[2]=y[21];
   ion_conc[2]=y[22];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[2]=y[23];													// [meter]
	ion_mob[2]=calc_Ion_Mobility(ion_val[2],ion_rad[2],viscosity);		// [meter^2/Volt*second]
	ion_fc[2]=calc_Ion_Friction_Coefficient(ion_val[2],ion_mob[2]);		// [Newton*second/meter]

	double Debye=y[25];	// meters	
	double dielectric=y[24];
	// Convert Concentration to Number Density (particles per volume (m^3))
	ion_conc[0]*=Na;
	ion_conc[1]*=Na;
   ion_conc[2]*=Na;
    // Calculation Constants
	double A,dN_dr;
	int ionIndex;
    // Linearized Governing Equations
	// F FUNCTION
	// df/dr = y[1]
	dy[0]=y[1];
	// d2f/dr2 = y[2]
	dy[1]=y[2];
	// d3f/dr3 = y[3]
	dy[2]=y[3];
	// d4f/dr4 = y[4]
	dy[3]=y[4];
	// d5f/dr5
	A=0;
	for(int i=0;i<numIon;i++)
		{// Ion Equilibrium Number Density
		dN_dr=(-ion_conc[i]*ion_val[i]*ec/(kb*T))*y[6]*exp(-ec*ion_val[i]*y[5]/(kb*T));
		// Ion Contribution
		ionIndex=7+2*i; 
		A+=ion_val[i]*ec*dN_dr*(y[ionIndex]+r);}
   dy[4]=-4*y[4]/r + 4*y[3]/(r*r) + A/(viscosity*r);
	// EQUILIBRIUM POTENTIAL
	// d(potential)/dr = y[6]
	dy[5]=y[6];
	// d2(potential)/dr2
	A=0;
	for(int i=0;i<numIon;i++){A+=ion_val[i]*ion_conc[i]*exp(-ec*ion_val[i]*y[5]/(kb*T));}
	dy[6]=-ec*A/(dielectric*eo) - 2*y[6]/r;
	// INDUCED ELECTROCHEMICAL POTENTIAL FUNCTION (2 ions)
	// 1st Ion
	// d(IEP)/dr = y[8]
   dy[7]=y[8];
	// d2(IEP)/dr2
	A=(ion_val[0]*ec/(kb*T))*y[6];
   dy[8]=-2*y[8]/r + 2*y[7]/(r*r) + A*(y[8] - (2*ion_fc[0]/(r*ion_val[0]*ec))*y[1] + 1);
	// 2nd Ion
	// d(IEP)/dr = y[10]
   dy[9]=y[10];
	// d2(IEP)/dr2
	A=(ion_val[1]*ec/(kb*T))*y[6];
   dy[10]=-2*y[10]/r + 2*y[9]/(r*r) + A*(y[10] - (2*ion_fc[1]/(r*ion_val[1]*ec))*y[1] + 1);
	// 3rd Ion
	// d(IEP)/dr
   dy[11]=y[12];
	// d2(IEP)/dr2
	A=(ion_val[2]*ec/(kb*T))*y[6];
   dy[12]=-2*y[12]/r + 2*y[11]/(r*r) + A*(y[12] - (2*ion_fc[2]/(r*ion_val[2]*ec))*y[1] + 1);

	// Clear Memory
	delete [] ion_conc;delete [] ion_val;delete [] ion_rad;delete [] ion_mob;delete [] ion_fc;}

void homogeneous_form_2ion(const state_type &y,state_type &dy,const double r)
	{double T=y[11];									// temperature [Kelvin]
	double viscosity=y[21];							// [Newton*second/meter^2]
	// Organize Ion Data
	int numIon=y[12];	
	double* ion_conc=new double[numIon];
	int* ion_val=new int[numIon];
	double* ion_rad=new double[numIon];
	double* ion_mob=new double[numIon];
	double* ion_fc=new double[numIon];
	// 1st Ion Properties
	ion_val[0]=y[13];
   ion_conc[0]=y[14];  		// mM or mol/m^3	    
	ion_rad[0]=y[15];		// meters
	ion_mob[0]=calc_Ion_Mobility(ion_val[0],ion_rad[0],viscosity);
	ion_fc[0]=calc_Ion_Friction_Coefficient(ion_val[0],ion_mob[0]);
	//ion_fc[0]=calc_Ion_Friction_Coefficient(ion_val[0],0.00675354);
	// 2nd Ion Properties
	ion_val[1]=y[16];
   ion_conc[1]=y[17];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[1]=y[18];													// [meter]
	ion_mob[1]=calc_Ion_Mobility(ion_val[1],ion_rad[1],viscosity);		// [meter^2/Volt*second]
	ion_fc[1]=calc_Ion_Friction_Coefficient(ion_val[1],ion_mob[1]);		// [Newton*second/meter]
	//ion_fc[1]=calc_Ion_Friction_Coefficient(ion_val[1],0.00648494);

	double Debye=y[20];				// meters	
	double dielectric=y[19];
	// Convert Concentration to Number Density (particles per volume (m^3))
	ion_conc[0]*=Na;
	ion_conc[1]*=Na;	

	//cout<<r<<" "<<y[0]<<" "<<y[5]<<" "<<y[7]<<" "<<y[9]<<endl;
	// Calculation Constants
	double A;
	int ionIndex;
    // Linearized Governing Equations
	// F FUNCTION
    // df/dr = y[1]
    dy[0]=y[1];
    // d2f/dr2 = y[2]
    dy[1]=y[2];
    // d3f/dr3 = y[3]
    dy[2]=y[3];
    // d4f/dr4 = y[4]
    dy[3]=y[4];
    // d5f/dr5
	// 1st Ion Equilibrium Number Density
	double dN1_dr=(-ion_conc[0]*ion_val[0]*ec/(kb*T))*y[6]*exp(-ec*ion_val[0]*y[5]/(kb*T));
	double trm1=ion_val[0]*ec*dN1_dr*y[7];
	// 2nd Ion Equilibrium Number Density
	double dN2_dr=(-ion_conc[1]*ion_val[1]*ec/(kb*T))*y[6]*exp(-ec*ion_val[1]*y[5]/(kb*T));
	double trm2=ion_val[1]*ec*dN2_dr*y[9];
	//A=0;
	//for(int i=0;i<numIon;i++)
	//	{// Ion Equilibrium Number Density
	//	dN_dr=(-ion_conc[i]*ion_val[i]*ec/(kb*T))*y[6]*exp(-ec*ion_val[i]*y[5]/(kb*T));
		// Ion Contribution
	//	ionIndex=7+2*i; 
	//	A+=ion_val[i]*ec*dN_dr*y[ionIndex];}
    //dy[4]=-4.0*y[4]/r + 4.0*y[3]/(r*r) + A/(viscosity*r);
	dy[4]=-4*y[4]/r + 4*y[3]/(r*r) + (trm1+trm2)/(viscosity*r);
	// EQUILIBRIUM POTENTIAL
	// d(potential)/dr = y[6]
	dy[5]=y[6];
	// d2(potential)/dr2
	A=0;
	for(int i=0;i<numIon;i++)
		{A+=ion_val[i]*ion_conc[i]*exp(-ec*ion_val[i]*y[5]/(kb*T));}
	dy[6]=-ec*A/(dielectric*eo) - 2*y[6]/r;
	// INDUCED ELECTROCHEMICAL POTENTIAL FUNCTION (2 ions)
	// 1st Ion
	// d(IEP)/dr = y[8]
   dy[7]=y[8];
	// d2(IEP)/dr2
	A=(ion_val[0]*ec/(kb*T))*y[6];
   dy[8]=-2*y[8]/r + 2*y[7]/(r*r) + A*(y[8] - (2*ion_fc[0]/(r*ion_val[0]*ec))*y[1]);
	// 2nd Ion
	// d(IEP)/dr = y[10]
   dy[9]=y[10];
	// d2(IEP)/dr2
	A=(ion_val[1]*ec/(kb*T))*y[6];
   dy[10]=-2*y[10]/r + 2*y[9]/(r*r) + A*(y[10] - (2*ion_fc[1]/(r*ion_val[1]*ec))*y[1]);

	// Clear Memory
	delete [] ion_conc;delete [] ion_val;delete [] ion_rad;delete [] ion_mob;delete [] ion_fc;}

void inhomogeneous_Prob1_2ion(const state_type &y,state_type &dy,const double r)
	{double T=y[11];									// temperature [Kelvin]
	double viscosity=y[21];							// [Newton*second/meter^2]
	// Organize Ion Data
	int numIon=y[12];	
	double* ion_conc=new double[numIon];
	int* ion_val=new int[numIon];
	double* ion_rad=new double[numIon];
	double* ion_mob=new double[numIon];
	double* ion_fc=new double[numIon];
	// 1st Ion Properties
	ion_val[0]=y[13];
   ion_conc[0]=y[14];  		// mM or mol/m^3	    
	ion_rad[0]=y[15];		// meters
	ion_mob[0]=calc_Ion_Mobility(ion_val[0],ion_rad[0],viscosity);
	ion_fc[0]=calc_Ion_Friction_Coefficient(ion_val[0],ion_mob[0]);

	// 2nd Ion Properties
	ion_val[1]=y[16];
   ion_conc[1]=y[17];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[1]=y[18];													// [meter]
	ion_mob[1]=calc_Ion_Mobility(ion_val[1],ion_rad[1],viscosity);		// [meter^2/Volt*second]
	ion_fc[1]=calc_Ion_Friction_Coefficient(ion_val[1],ion_mob[1]);		// [Newton*second/meter]

	double Debye=y[20];	// meters	
	double dielectric=y[19];
	// Convert Concentration to Number Density (particles per volume (m^3))
	ion_conc[0]*=Na;
	ion_conc[1]*=Na;
    
	// Calculation Constants
	double A,dN_dr;
	int ionIndex;

	// Linearized Governing Equations
	// F FUNCTION
	// df/dr = y[1]
	dy[0]=y[1];
	// d2f/dr2 = y[2]
	dy[1]=y[2];
	// d3f/dr3 = y[3]
	dy[2]=y[3];
	// d4f/dr4 = y[4]
	dy[3]=y[4];
	// d5f/dr5
	A=0;
	for(int i=0;i<numIon;i++)
		{// Ion Equilibrium Number Density
		dN_dr=(-ion_conc[i]*ion_val[i]*ec/(kb*T))*y[6]*exp(-ec*ion_val[i]*y[5]/(kb*T));
		// Ion Contribution
		ionIndex=7+2*i; 
		A+=ion_val[i]*ec*dN_dr*y[ionIndex];}
    dy[4]=-4*y[4]/r + 4*y[3]/(r*r) + A/(viscosity*r);
	// EQUILIBRIUM POTENTIAL
	// d(potential)/dr = y[6]
	dy[5]=y[6];
	// d2(potential)/dr2
	A=0;
	for(int i=0;i<numIon;i++)
		{A+=ion_val[i]*ion_conc[i]*exp(-ec*ion_val[i]*y[5]/(kb*T));}
	dy[6]=-ec*A/(dielectric*eo) - 2*y[6]/r;
	// INDUCED ELECTROCHEMICAL POTENTIAL FUNCTION (2 ions)
	// 1st Ion
	// d(IEP)/dr = y[8]
   dy[7]=y[8];
	// d2(IEP)/dr2
	A=(ion_val[0]*ec/(kb*T))*y[6];
   dy[8]=-2*y[8]/r + 2*y[7]/(r*r) + A*(y[8] - (2*ion_fc[0]/(r*ion_val[0]*ec))*y[1] - ion_fc[0]/(ion_val[0]*ec));
	// 2nd Ion
	// d(IEP)/dr = y[10]
   dy[9]=y[10];
	// d2(IEP)/dr2
	A=(ion_val[1]*ec/(kb*T))*y[6];
   dy[10]=-2*y[10]/r + 2*y[9]/(r*r) + A*(y[10] - (2*ion_fc[1]/(r*ion_val[1]*ec))*y[1] - ion_fc[1]/(ion_val[1]*ec));

	// Clear Memory
	delete [] ion_conc;delete [] ion_val;delete [] ion_rad;delete [] ion_mob;delete [] ion_fc;}

void inhomogeneous_Prob2_2ion(const state_type &y,state_type &dy,const double r)
	{double T=y[11];								// temperature [Kelvin]
	double viscosity=y[21];						// [Newton*second/meter^2]
	// Organize Ion Data
	int numIon=y[12];	
	double* ion_conc=new double[numIon];
	int* ion_val=new int[numIon];
	double* ion_rad=new double[numIon];
	double* ion_mob=new double[numIon];
	double* ion_fc=new double[numIon];
	// 1st Ion Properties
	ion_val[0]=y[13];
   ion_conc[0]=y[14];  		// mM or mol/m^3	    
	ion_rad[0]=y[15];		// meters
	ion_mob[0]=calc_Ion_Mobility(ion_val[0],ion_rad[0],viscosity);
	ion_fc[0]=calc_Ion_Friction_Coefficient(ion_val[0],ion_mob[0]);

	// 2nd Ion Properties
	ion_val[1]=y[16];
   ion_conc[1]=y[17];  												// milli-Molar or [mol/meter^3]	    
	ion_rad[1]=y[18];													// [meter]
	ion_mob[1]=calc_Ion_Mobility(ion_val[1],ion_rad[1],viscosity);		// [meter^2/Volt*second]
	ion_fc[1]=calc_Ion_Friction_Coefficient(ion_val[1],ion_mob[1]);		// [Newton*second/meter]

	double Debye=y[20];	// meters	
	double dielectric=y[19];
	// Convert Concentration to Number Density (particles per volume (m^3))
	ion_conc[0]*=Na;
	ion_conc[1]*=Na;
    
    // Calculation Constants
	double A,dN_dr;
	int ionIndex;
    // Linearized Governing Equations
	// F FUNCTION
	// df/dr = y[1]
	dy[0]=y[1];
	// d2f/dr2 = y[2]
	dy[1]=y[2];
	// d3f/dr3 = y[3]
	dy[2]=y[3];
	// d4f/dr4 = y[4]
	dy[3]=y[4];
	// d5f/dr5
	A=0;
	for(int i=0;i<numIon;i++)
		{// Ion Equilibrium Number Density
		dN_dr=(-ion_conc[i]*ion_val[i]*ec/(kb*T))*y[6]*exp(-ec*ion_val[i]*y[5]/(kb*T));
		// Ion Contribution
		ionIndex=7+2*i; 
		A+=ion_val[i]*ec*dN_dr*(y[ionIndex]+r);}
   dy[4]=-4*y[4]/r + 4*y[3]/(r*r) + A/(viscosity*r);
	// EQUILIBRIUM POTENTIAL
	// d(potential)/dr = y[6]
	dy[5]=y[6];
	// d2(potential)/dr2
	A=0;
	for(int i=0;i<numIon;i++)
		{A+=ion_val[i]*ion_conc[i]*exp(-ec*ion_val[i]*y[5]/(kb*T));}
	dy[6]=-ec*A/(dielectric*eo) - 2*y[6]/r;
	// INDUCED ELECTROCHEMICAL POTENTIAL FUNCTION (2 ions)
	// 1st Ion
	// d(IEP)/dr = y[8]
   dy[7]=y[8];
	// d2(IEP)/dr2
	A=(ion_val[0]*ec/(kb*T))*y[6];
   dy[8]=-2*y[8]/r + 2*y[7]/(r*r) + A*(y[8] - (2*ion_fc[0]/(r*ion_val[0]*ec))*y[1] + 1);
	// 2nd Ion
	// d(IEP)/dr = y[10]
   dy[9]=y[10];
	// d2(IEP)/dr2
	A=(ion_val[1]*ec/(kb*T))*y[6];
   dy[10]=-2*y[10]/r + 2*y[9]/(r*r) + A*(y[10] - (2*ion_fc[1]/(r*ion_val[1]*ec))*y[1] + 1);

	// Clear Memory
	delete [] ion_conc;delete [] ion_val;delete [] ion_rad;delete [] ion_mob;delete [] ion_fc;}

// INPUT:
// Potential
// y[0] = p;
// y[1] = dp/dr;
// Constants
// y[2] = Temperature [Kelvin]
// y[3] = numIons
// Ion Data (Example shown for 2 ion; numIon = 2)
// y[4] = 1st Ion Valence
// y[5] = 1st Ion Concentration [milli-Molar] (or equalivalently [mol/meter^3])
// y[6] = 2nd Ion Valence
// y[7] = 2nd Ion Concentration [milli-Molar] (or equalivalently [mol/meter^3])
void poisson_boltzmann(const state_type &y,state_type &dy,const double r)
	{// Input Handling
	double T=y[2];			// Kelvin
	double dielectric=y[4];
	int numIon=y[3];
	
	// Organize Ion Data
	double* ion_conc=new double[numIon];
	int* ion_val=new int[numIon];

	for(int i=0;i<numIon;i++)
		{ion_val[i]=y[5+2*i];
		ion_conc[i]=y[6+2*i]; // mM or mol/m^3
		// Convert Concentration to Number Density (particles per volume (m^3))
		ion_conc[i]*=Na;}
	
	// d(potential)/dr
	dy[0]=y[1];
	// d2(potential)/dr2
	double A=0;
	for(int i=0;i<numIon;i++){A+=ion_val[i]*ion_conc[i]*exp(-ec*ion_val[i]*y[0]/(kb*T));}
   dy[1]=-ec*A/(dielectric*eo) - 2*y[1]/r;
	//double trm1=ion_val[0]*ion_conc[0]*exp(-ec*ion_val[0]*y[0]/(kb*T));
	//double trm2=ion_val[1]*ion_conc[1]*exp(-ec*ion_val[1]*y[0]/(kb*T));
	//dy[1]=-ec*(trm1+trm2)/(dielectric*eo) - 2*y[1]/r;
	// Clear Memory
	delete [] ion_val;delete [] ion_conc;}

void initialize_PBE(state_type &y,double r0,double C,Solution S)
	{// Convert Debye Length to meters
	double Debye=S.debyeLength*1e-10;
	// Potential [V]
	y[0]=C*exp(-r0/Debye)/r0;
	// d(Potential)/dr
	y[1]=-C*(Debye+r0)*exp(-r0/Debye)/(Debye*r0*r0);
	// Constants
	y[2]=S.temperature;		// Temperature [Kevlin]
	y[3]=S.numIon;
	y[4]=S.dielectric;
	// Ion Data
	for(int i=0;i<S.numIon;i++)
		{// Ion Valence
		y[5+2*i]=S.ionVal[i];
		// Ion Concentration [milli-Molar] (or equalivalently [mol/meter^3])
		y[6+2*i]=S.ionConc[i]*1000;}}

// Input: ion_val = sign charge of ion
// Input: ion_radius = ion radius [meter]
// Input: viscosity [Newton*second/meter^2]
// Output: mobility [meter^2/(Volt*second)]
double calc_Ion_Mobility(int ion_val,double ion_radius,double viscosity){return ion_val*ec/(6*pi*viscosity*ion_radius);}

// Input: ion_val = sign charge of ion
// Input: ion_mobility = electrophoretic mobility of ion in m^2/Vs (calculated by calc_Ion_Mobility)
// Output: friction (drag force) coefficient in Ns/m
// Reference: Micro- and Nanoscale Fliud Mechanics by Kirby p. 253
double calc_Ion_Friction_Coefficient(int ion_val,double ion_mobility){return ion_val*ec/ion_mobility;}

zOutput read_zpred_output_file(string zOutFile)
	{// Define and Initialize Values
	zOutput D;
	D.proteinName="";
	D.proteinRadius=-1;
	D.solvatedRadius=-1;
	D.zetaPotential=NAN;
	D.charge=NAN;
	D.diffusivity=NAN;
	D.semMobility=NAN;
	D.Xsp="";
	D.solution.pH="";
	D.solution.temperature="";
	D.solution.dielectric="";
	D.solution.viscosity="";
	D.solution.density="";
	D.solution.numSolute=-1;
	D.solution.numSolvent=-1;
	D.solution.debyeLength="";

	ifstream fIn;
	fIn.open(zOutFile.c_str());
	if(fIn.fail()){cerr<<"ERROR in read_zpred_output_file!\nZPRED output file could not be opened.\n"<<zOutFile<<endl;exit(EXIT_FAILURE);}
	int Sz=15000,pos;
	char Val[Sz];
	bool CHECKING,SPHERE=false,CYLINDER=false;
	string bld="",tmp="",inputName="",inputVal="",delimiter=";";
	string *sArr;
	double *dArr;
	fIn.getline(Val,Sz);
	while(!fIn.eof())
		{tmp=Val;
		pos=tmp.find(".",0);
		if(pos!=string::npos && pos==0)
			{// Line contains a period, now check if line defines an input parameter
			pos=tmp.find(":",pos);	// defines end of input parameter name
			if(pos!=string::npos)
				{// Extract Input Parameter Name
				inputName=tmp.substr(tmp.find(".",0)+1,pos-tmp.find(".",0)-1);
				// Extract Input Parameter Value(s)
				inputVal=tmp.substr(pos+1,tmp.length()-pos-1);
				// Check for Preceding WhiteSpace(s)
				CHECKING=true;
				pos=inputVal.find(" ",0);
				while(CHECKING)
					{if(pos!=string::npos){inputVal=inputVal.substr(1,inputVal.length()-1);pos=inputVal.find(" ",pos+1);}
					else{CHECKING=false;break;}}
				if(inputVal.length()!=0)
					{// Identify Parameter and Load Values
					if(inputName.compare("shape")==0)
						{// Shape Descriptor
						if(inputVal.compare("sphere")==0){SPHERE=true;}
						else if(inputVal.compare("cylinder")==0){CYLINDER=true;}
						}
					else if(inputName.compare("proteinRadius")==0)
						{// Anhydrous Protein Radius (A)
						D.proteinRadius=strtod(inputVal.c_str(),NULL);}
					else if(inputName.compare("proteinName")==0)
						{// Name of Specific PDB File under Assessment
						D.proteinName=inputVal;}
					else if(inputName.compare("solCondNum")==0)
						{// Name of Specific PDB File under Assessment
						D.solCondNum=inputVal;}
					else if(inputName.compare("solvatedRadius")==0)
						{// Solvated Protein Radius (A)
						D.solvatedRadius=strtod(inputVal.c_str(),NULL);}
					else if(inputName.compare("charge")==0)
						{// Protein Net Charge Valence [e]
						D.charge=strtod(inputVal.c_str(),NULL);}
					else if(inputName.compare("diffusivity")==0)
						{// Protein Diffusivity [m^2/s]
						D.diffusivity=strtod(inputVal.c_str(),NULL);}
					else if(inputName.compare("henryMobility")==0)
						{// Ideal Single-Particle Electrophoretic Mobility [umcm/Vs]
						if(inputVal.compare("NaN")==0)
							{D.henryMobility=nan("");}
						else
							{D.henryMobility=strtod(inputVal.c_str(),NULL);}
						}
					else if(inputName.compare("kuwabaraMobility")==0)
						{// Kuwabara Concentration-Corrected Electrophoretic Mobility [umcm/Vs]
						if(inputVal.compare("NaN")==0)
							{D.kuwabaraMobility=nan("");}
						else
							{D.kuwabaraMobility=strtod(inputVal.c_str(),NULL);}
						}
					else if(inputName.compare("semMobility")==0)
						{// Ideal Single-Particle Electrophoretic Mobility [umcm/Vs]
						if(inputVal.compare("NaN")==0)
							{D.semMobility=nan("");}
						else
							{D.semMobility=strtod(inputVal.c_str(),NULL);}
						}
					//else if(SPHERE && inputName.compare("semMobility2")==0)
					//	{// Kuwabara Concentration-Corrected Electrophoretic Mobility [umcm/Vs]
					//	D.mobility=strtod(inputVal.c_str(),NULL);}
					else if(inputName.compare("Xsp")==0)
						{// Hydration Layer Thickness (A)
						D.Xsp=inputVal;}
					else if(inputName.compare("zetaPotential")==0)
						{// ZPRED Computed Zeta Potential (V)
						D.zetaPotential=strtod(inputVal.c_str(),NULL);}
					else if(inputName.compare("debyeLength")==0)
						{// Solution Debye Length (A)
						D.solution.debyeLength=inputVal;}
					else if(inputName.compare("pH")==0)
						{// Solution pH
						D.solution.pH=inputVal;}
					else if(inputName.compare("temperature")==0)
						{// Solution Temperature [K]
						D.solution.temperature=inputVal;}
					else if(inputName.compare("dielectric")==0)
						{// Solution Relative Dielectric
						D.solution.dielectric=inputVal;}
					else if(inputName.compare("viscosity")==0)
						{// Solution Viscosity [Pa s]
						D.solution.viscosity=inputVal;}
					else if(inputName.compare("density")==0)
						{// Solution Density [kg/L]
						D.solution.density=inputVal;}
					else if(inputName.compare("solvent")==0)
						{// Solution Components (Solvent Names)
						D.solution.numSolvent=count_delimiter(inputVal,delimiter);
						D.solution.solvent=fill_string_array(inputVal,D.solution.numSolvent,delimiter);}
					else if(inputName.compare("solventConc")==0)
						{// Solution Components (Solvent Concentrations) [Mole Fraction]
						D.solution.numSolvent=count_delimiter(inputVal,delimiter);
						D.solution.solventConc=fill_string_array(inputVal,D.solution.numSolvent,delimiter);}
					else if(inputName.compare("solute")==0)
						{// Solution Components (Solute Names)
						D.solution.numSolute=count_delimiter(inputVal,delimiter);
						D.solution.solute=fill_string_array(inputVal,D.solution.numSolute,delimiter);}
					else if(inputName.compare("soluteConc")==0)
						{// Solution Components (Solute Concentrations) [Molar]
						D.solution.numSolute=count_delimiter(inputVal,delimiter);
						D.solution.soluteConc=fill_string_array(inputVal,D.solution.numSolute,delimiter);}
					else if(inputName.compare("generateProfile")==0)
						{if(inputVal.compare("false")==0){D.EP.numPnts=0;}
						else
							{D.EP.numPnts=count_delimiter(inputVal,";");
							D.EP.position=new double[D.EP.numPnts];
							D.EP.potential=new double[D.EP.numPnts];
							sArr=fill_string_array(inputVal,D.EP.numPnts,";");
							for(int i=0;i<D.EP.numPnts;i++)
								{tmp=sArr[i];
								dArr=fill_double_array(tmp,2,",");
								D.EP.position[i]=dArr[0];
								D.EP.potential[i]=dArr[1];
								delete [] dArr;}
							delete [] sArr;}
						}
					else{//cerr<<"ERROR in read_zpred_output_file!\nUnrecognized Parameter ("<<inputName<<").\n";exit(EXIT_FAILURE);
						}
					}
				}
			}
		fIn.getline(Val,Sz);}
	fIn.close();
	return D;}
