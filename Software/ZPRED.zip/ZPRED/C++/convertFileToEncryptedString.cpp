# include <cstdio>
# include <cstring>
# include <fstream>
# include <iostream>
# include <string>
# include <openssl/conf.h>
# include <openssl/evp.h>				// ciphers and message digests
# include <openssl/err.h>
# include <openssl/ssl.h>				// for libssl
# include <unistd.h>

using namespace std;

long getFileSize(string inFile);
void handleErrors(void);
static inline bool is_base64(unsigned char c);
void decryptString(string encStr,const string salt,const string pass,string outFile);
string base64_decode(string const& encoded_string);
string base64_encode(unsigned char const* bytes_to_encode, unsigned int in_len);
string readFile2Encrypt(string inFile);
string encryptFile(string inFile,const string salt,const string pass);

int main(int argc,char *argv[])
{	//string salt="783e007c783e007c";
	//string passWord="Password";
	string inFile,passWord,salt,outFile;
	int ch;
	while((ch=getopt(argc,argv,"i:o:"))!=EOF)
		{switch(ch)
			{case 'i':
				// Input File to Convert to Encrypted String
				inFile=optarg;
				break;
			case 'o':
				// OutputFile
				outFile=optarg;
				break;
			default:
				exit(EXIT_FAILURE);}}

	string Output=encryptFile(inFile,"783e007c783e007c","Password");
	ofstream fOut;
	fOut.open(outFile.c_str());
	if(fOut.fail()){cerr<<"ERROR in readFile2Encrypt!\nOutput file could not be opened.\n"<<outFile<<endl;exit(EXIT_FAILURE);}
	fOut<<Output;
	fOut.close();
}

string base64_encode(unsigned char const* bytes_to_encode, unsigned int in_len)
	{static const string base64_chars = 
		 "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
		 "abcdefghijklmnopqrstuvwxyz"
		 "0123456789+/";
	string ret;
	int i=0,j=0;
	unsigned char char_array_3[3];
	unsigned char char_array_4[4];

	while(in_len--)
		{char_array_3[i++] = *(bytes_to_encode++);
		if(i==3)
			{char_array_4[0]=(char_array_3[0] & 0xfc) >> 2;
			char_array_4[1]=((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
			char_array_4[2]=((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
			char_array_4[3]=char_array_3[2] & 0x3f;

			for(i=0;(i<4);i++){ret+=base64_chars[char_array_4[i]];}
			i=0;}}

	if(i)
		{for(j=i;j<3;j++){char_array_3[j]='\0';}

		char_array_4[0]=( char_array_3[0] & 0xfc) >> 2;
		char_array_4[1]=((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
		char_array_4[2]=((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);

		for(j=0;(j<i+1);j++){ret+=base64_chars[char_array_4[j]];}

		while((i++ < 3)){ret+='=';}}

	return ret;}

string base64_decode(string const& encoded_string)
	{static const string base64_chars = 
             "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
             "abcdefghijklmnopqrstuvwxyz"
             "0123456789+/";
	int in_len=encoded_string.size();
	int i=0,j=0,in_=0;
	unsigned char char_array_4[4], char_array_3[3];
	string ret;

	while(in_len-- && (encoded_string[in_]!='=') && is_base64(encoded_string[in_]))
		{char_array_4[i++]=encoded_string[in_];
		in_++;
		if(i==4)
			{for(i=0;i<4;i++){char_array_4[i]=base64_chars.find(char_array_4[i]);}

			char_array_3[0]=( char_array_4[0] << 2       ) + ((char_array_4[1] & 0x30) >> 4);
			char_array_3[1]=((char_array_4[1] & 0xf) << 4) + ((char_array_4[2] & 0x3c) >> 2);
			char_array_3[2]=((char_array_4[2] & 0x3) << 6) +   char_array_4[3];

			for(i=0;(i<3);i++){ret += char_array_3[i];}
			i=0;}}

	if(i)
		{for(j=0;j<i;j++){char_array_4[j]=base64_chars.find(char_array_4[j]);}

		char_array_3[0]=(char_array_4[0] << 2) + ((char_array_4[1] & 0x30) >> 4);
		char_array_3[1]=((char_array_4[1] & 0xf) << 4) + ((char_array_4[2] & 0x3c) >> 2);

		for(j=0;(j<i-1);j++){ret+=char_array_3[j];}}

	return ret;}

void decryptString(string encStr,const string salt,const string pass,string outFile)
	{// Base 64 Decode String\n";
	string decoded=base64_decode(encStr);
	// Generate Key and IV from Password and Salt\n";
	unsigned char key[32], iv[32];
	// Allocate Space for decrypted text\n";
	unsigned char decryptedtext[decoded.length()];
	int keyLength=EVP_BytesToKey(EVP_aes_256_cbc(),EVP_sha1(),(unsigned char*)salt.c_str(),(unsigned char*)pass.c_str(),pass.length(),1,key,iv);
	// Define Cipher Object
	EVP_CIPHER_CTX *ctx;
	int len,ret;
	// Create and initialize the context
	if(!(ctx=EVP_CIPHER_CTX_new())){handleErrors();}
	// Start Decryption
	if(1 != EVP_DecryptInit_ex(ctx,EVP_aes_256_cbc(),NULL,key,iv)){handleErrors();}
	// Decrypt message and obtain output
	if(1 != EVP_DecryptUpdate(ctx,decryptedtext,&len,(unsigned char*)decoded.c_str(),decoded.length())){handleErrors();}
	int decryptedtext_len=len;
	// Finalize Decryption
	if(1 != EVP_DecryptFinal_ex(ctx,decryptedtext+len,&len)){handleErrors();}
	decryptedtext_len+=len;
	// Clean Up
	EVP_CIPHER_CTX_free(ctx);
	// Add a NULL terminator. We are expecting printable text
	decryptedtext[decryptedtext_len]='\0';
	ofstream fOut;
	fOut.open(outFile.c_str(),ios::out|ios::binary);
	if(fOut.fail())
		{cerr<<"ERROR:\n input file could not be opened.\n"<<outFile<<endl;
		exit(1);}
	for(int i=0;i<decryptedtext_len;i++){fOut<<decryptedtext[i];}
	fOut.close();}

long getFileSize(string inFile)
	{FILE *fI;
	int Err;
	char errMsg[256];
	fI=fopen(inFile.c_str(),"r");
	if(fI==NULL)
		{Err=errno;
		cerr<<"ERROR in getFileSize!\nCould not open input file: "<<inFile<<endl;		
		cerr<<strerror_r(Err,errMsg,256)<<"\n";
		exit(EXIT_FAILURE);}
	fseek(fI,0,SEEK_END);
	long Output=ftell(fI);
	fclose(fI);
	return Output;}

void handleErrors(void){ERR_print_errors_fp(stderr);abort();}

static inline bool is_base64(unsigned char c){return (isalnum(c) || (c == '+') || (c == '/'));}

string encryptFile(string inFile,const string salt,const string pass)
	{string s=readFile2Encrypt(inFile);	
	// Generate Key and IV from Password and Salt
	//const string pass="Password";
	unsigned char key[32], iv[32];
	// Allocate Space for Encrypted (Ciphered) text
	unsigned char ciphertext[s.length()];
  	// Buffer for the decrypted text
	unsigned char decryptedtext[s.length()];
	int keyLength=EVP_BytesToKey(EVP_aes_256_cbc(),EVP_sha1(),(unsigned char*)salt.c_str(),(unsigned char*)pass.c_str(),pass.length(),1,key,iv);
	//cout<<"Key Length:\n"<<keyLength<<"\nKey:\n"<<key<<endl;
	// Define Cipher Object
	EVP_CIPHER_CTX *ctx;
	int len,ret;
	// Create and initialize the context
	if(!(ctx=EVP_CIPHER_CTX_new())){handleErrors();}
	// Start Encryption
	if(1 != EVP_EncryptInit_ex(ctx,EVP_aes_256_cbc(),NULL,key,iv)){handleErrors();}	
	// Encrypt message and obtain output	
	if(1 != EVP_EncryptUpdate(ctx,ciphertext,&len,(unsigned char*)s.c_str(),s.length())){handleErrors();}
	int ciphertext_len=len;
	//cout<<ciphertext<<endl;
	// Finalize Encryption
	if(1 != EVP_EncryptFinal_ex(ctx,ciphertext+len,&len)){handleErrors();}
	ciphertext_len+=len;
	// Clean Up
	EVP_CIPHER_CTX_free(ctx);
	// Check ciphertext
	//cout<<"Ciphered text is:\n";
	//BIO_dump_fp(stdout,(const char*)ciphertext,ciphertext_len);
	// Base64 Encoded Encryption
	//string b64enc=base64_encode(reinterpret_cast<const unsigned char*>(cVal.c_str()), cVal.length());
	string Output=base64_encode(ciphertext,ciphertext_len);
	return Output;}

string readFile2Encrypt(string inFile)
	{long fileSz=getFileSize(inFile);
	char* buf=new char[fileSz];
	ifstream fIn;
	fIn.open(inFile.c_str(),ios::in|ios::binary);
	if(fIn.fail()){cerr<<"ERROR in readFile2Encrypt!\ninput file could not be opened.\n"<<inFile<<endl;exit(EXIT_FAILURE);}
	fIn.read(buf,fileSz);
	fIn.close();
	string val="";
	for(int i=0;i<fileSz;i++){val+=buf[i];}
	delete [] buf;
	string Output=val;
	return Output;}
